// src/main/java/com/hotel/model/Cliente.java
package com.hotel.model;

import java.util.Date;

public class Cliente {
    private int idCliente;
    private String nomeCompleto;
    private String sexo;
    private Date dataNascimento;
    private String telefone;
    private String email;
    private String endereco;
    private int idNacionalidade;
    private String pais;
    private int idTipoDocumento;
    private String tipoDocumento;
    private String numeroDocumento;
    private Date dataRegistro;

    // Construtores
    public Cliente() {}

    // Getters e Setters
    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }
    public String getNomeCompleto() { return nomeCompleto; }
    public void setNomeCompleto(String nomeCompleto) { this.nomeCompleto = nomeCompleto; }
    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }
    public Date getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(Date dataNascimento) { this.dataNascimento = dataNascimento; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public int getIdNacionalidade() { return idNacionalidade; }
    public void setIdNacionalidade(int idNacionalidade) { this.idNacionalidade = idNacionalidade; }
    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }
    public int getIdTipoDocumento() { return idTipoDocumento; }
    public void setIdTipoDocumento(int idTipoDocumento) { this.idTipoDocumento = idTipoDocumento; }
    public String getTipoDocumento() { return tipoDocumento; }
    public void setTipoDocumento(String tipoDocumento) { this.tipoDocumento = tipoDocumento; }
    public String getNumeroDocumento() { return numeroDocumento; }
    public void setNumeroDocumento(String numeroDocumento) { this.numeroDocumento = numeroDocumento; }
    public Date getDataRegistro() { return dataRegistro; }
    public void setDataRegistro(Date dataRegistro) { this.dataRegistro = dataRegistro; }
}