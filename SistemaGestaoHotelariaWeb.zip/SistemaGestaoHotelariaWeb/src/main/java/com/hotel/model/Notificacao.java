// src/main/java/com/hotel/model/Notificacao.java
package com.hotel.model;

import java.util.Date;

public class Notificacao {
    private int id;
    private String titulo;
    private String mensagem;
    private String tipo; // CHECKIN, CHECKOUT, RESERVA, PAGAMENTO, ALERTA
    private String icone;
    private String cor;
    private Date data;
    private boolean lida;
    private int idReferencia; // ID da reserva, checkin, etc.

    public Notificacao() {}

    public Notificacao(String titulo, String mensagem, String tipo, int idReferencia) {
        this.titulo = titulo;
        this.mensagem = mensagem;
        this.tipo = tipo;
        this.idReferencia = idReferencia;
        this.data = new Date();
        this.lida = false;

        // Definir ícone e cor baseado no tipo
        switch (tipo) {
            case "CHECKIN":
                this.icone = "bi-person-check-fill";
                this.cor = "success";
                break;
            case "CHECKOUT":
                this.icone = "bi-person-x-fill";
                this.cor = "info";
                break;
            case "RESERVA":
                this.icone = "bi-calendar-check-fill";
                this.cor = "primary";
                break;
            case "PAGAMENTO":
                this.icone = "bi-cash-stack";
                this.cor = "warning";
                break;
            case "ALERTA":
                this.icone = "bi-exclamation-triangle-fill";
                this.cor = "danger";
                break;
            default:
                this.icone = "bi-bell-fill";
                this.cor = "secondary";
        }
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getMensagem() { return mensagem; }
    public void setMensagem(String mensagem) { this.mensagem = mensagem; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getIcone() { return icone; }
    public void setIcone(String icone) { this.icone = icone; }
    public String getCor() { return cor; }
    public void setCor(String cor) { this.cor = cor; }
    public Date getData() { return data; }
    public void setData(Date data) { this.data = data; }
    public boolean isLida() { return lida; }
    public void setLida(boolean lida) { this.lida = lida; }
    public int getIdReferencia() { return idReferencia; }
    public void setIdReferencia(int idReferencia) { this.idReferencia = idReferencia; }
}