// src/main/java/com/hotel/model/TipoQuarto.java
package com.hotel.model;

public class TipoQuarto {
    private int idTipoQuarto;
    private String nomeTipo;
    private String descricao;
    private double precoDiaria;

    public TipoQuarto() {}

    public int getIdTipoQuarto() { return idTipoQuarto; }
    public void setIdTipoQuarto(int idTipoQuarto) { this.idTipoQuarto = idTipoQuarto; }

    public String getNomeTipo() { return nomeTipo; }
    public void setNomeTipo(String nomeTipo) { this.nomeTipo = nomeTipo; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public double getPrecoDiaria() { return precoDiaria; }
    public void setPrecoDiaria(double precoDiaria) { this.precoDiaria = precoDiaria; }
}