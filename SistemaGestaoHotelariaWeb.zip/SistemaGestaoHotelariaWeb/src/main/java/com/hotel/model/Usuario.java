// src/main/java/com/hotel/model/Usuario.java
package com.hotel.model;

import java.util.Date;

public class Usuario {
    private int idUsuario;
    private String nome;
    private String email;
    private String telefone;
    private String username;
    private String senha;
    private int idPerfil;
    private String nomePerfil;
    private String foto;
    private String estado;

    // Construtores
    public Usuario() {}

    // Getters e Setters
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    public int getIdPerfil() { return idPerfil; }
    public void setIdPerfil(int idPerfil) { this.idPerfil = idPerfil; }
    public String getNomePerfil() { return nomePerfil; }
    public void setNomePerfil(String nomePerfil) { this.nomePerfil = nomePerfil; }
    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}