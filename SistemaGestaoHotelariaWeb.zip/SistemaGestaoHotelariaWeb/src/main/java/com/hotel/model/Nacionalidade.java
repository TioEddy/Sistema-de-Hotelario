// src/main/java/com/hotel/model/Nacionalidade.java
package com.hotel.model;

public class Nacionalidade {
    private int idNacionalidade;
    private String pais;

    public Nacionalidade() {}

    public int getIdNacionalidade() { return idNacionalidade; }
    public void setIdNacionalidade(int idNacionalidade) { this.idNacionalidade = idNacionalidade; }

    public String getPais() { return pais; }
    public void setPais(String pais) { this.pais = pais; }
}