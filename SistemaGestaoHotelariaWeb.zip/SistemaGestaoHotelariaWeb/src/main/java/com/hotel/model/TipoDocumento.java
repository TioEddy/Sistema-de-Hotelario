// src/main/java/com/hotel/model/TipoDocumento.java
package com.hotel.model;

public class TipoDocumento {
    private int idTipoDocumento;
    private String descricao;

    public TipoDocumento() {}

    public int getIdTipoDocumento() { return idTipoDocumento; }
    public void setIdTipoDocumento(int idTipoDocumento) { this.idTipoDocumento = idTipoDocumento; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
}