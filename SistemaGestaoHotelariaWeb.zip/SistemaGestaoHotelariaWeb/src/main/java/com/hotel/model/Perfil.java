// src/main/java/com/hotel/model/Perfil.java
package com.hotel.model;

public class Perfil {
    private int idPerfil;
    private String nomePerfil;

    public Perfil() {}

    public Perfil(int idPerfil, String nomePerfil) {
        this.idPerfil = idPerfil;
        this.nomePerfil = nomePerfil;
    }

    // Getters e Setters
    public int getIdPerfil() { return idPerfil; }
    public void setIdPerfil(int idPerfil) { this.idPerfil = idPerfil; }
    public String getNomePerfil() { return nomePerfil; }
    public void setNomePerfil(String nomePerfil) { this.nomePerfil = nomePerfil; }
}