// src/main/java/com/hotel/model/Quarto.java
package com.hotel.model;

public class Quarto {
    private int idQuarto;
    private String numeroQuarto;
    private int idTipoQuarto;
    private String tipoQuarto;
    private String descricaoTipo;
    private double precoDiaria;
    private int piso;
    private String estado;

    public Quarto() {}

    public Quarto(int idQuarto, String numeroQuarto, int idTipoQuarto, String tipoQuarto,
                  String descricaoTipo, double precoDiaria, int piso, String estado) {
        this.idQuarto = idQuarto;
        this.numeroQuarto = numeroQuarto;
        this.idTipoQuarto = idTipoQuarto;
        this.tipoQuarto = tipoQuarto;
        this.descricaoTipo = descricaoTipo;
        this.precoDiaria = precoDiaria;
        this.piso = piso;
        this.estado = estado;
    }

    // Getters e Setters
    public int getIdQuarto() { return idQuarto; }
    public void setIdQuarto(int idQuarto) { this.idQuarto = idQuarto; }
    public String getNumeroQuarto() { return numeroQuarto; }
    public void setNumeroQuarto(String numeroQuarto) { this.numeroQuarto = numeroQuarto; }
    public int getIdTipoQuarto() { return idTipoQuarto; }
    public void setIdTipoQuarto(int idTipoQuarto) { this.idTipoQuarto = idTipoQuarto; }
    public String getTipoQuarto() { return tipoQuarto; }
    public void setTipoQuarto(String tipoQuarto) { this.tipoQuarto = tipoQuarto; }
    public String getDescricaoTipo() { return descricaoTipo; }
    public void setDescricaoTipo(String descricaoTipo) { this.descricaoTipo = descricaoTipo; }
    public double getPrecoDiaria() { return precoDiaria; }
    public void setPrecoDiaria(double precoDiaria) { this.precoDiaria = precoDiaria; }
    public int getPiso() { return piso; }
    public void setPiso(int piso) { this.piso = piso; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}