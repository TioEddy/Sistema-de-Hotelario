// src/main/java/com/hotel/util/GerenciadorNotificacoes.java
package com.hotel.util;

import com.hotel.model.Notificacao;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

public class GerenciadorNotificacoes {

    private static GerenciadorNotificacoes instance;
    private Queue<Notificacao> notificacoes;
    private Map<Integer, List<Integer>> notificacoesLidas; // usuarioId -> lista de ids lidos
    private int nextId;

    private GerenciadorNotificacoes() {
        notificacoes = new ConcurrentLinkedQueue<>();
        notificacoesLidas = new HashMap<>();
        nextId = 1;
        // Adicionar notificações de exemplo
        carregarNotificacoesExemplo();
    }

    public static synchronized GerenciadorNotificacoes getInstance() {
        if (instance == null) {
            instance = new GerenciadorNotificacoes();
        }
        return instance;
    }

    private void carregarNotificacoesExemplo() {
        // Notificações iniciais para teste
        adicionarNotificacao(new Notificacao("Bem-vindo!", "Sistema de gestão de hotelaria iniciado", "ALERTA", 0));
        adicionarNotificacao(new Notificacao("Check-in Realizado", "Hóspede Carlos Santos fez check-in no quarto 101", "CHECKIN", 1));
        adicionarNotificacao(new Notificacao("Nova Reserva", "Reserva confirmada para o quarto 201 - Suite Executiva", "RESERVA", 2));
    }

    public void adicionarNotificacao(Notificacao notificacao) {
        notificacao.setId(nextId++);
        notificacoes.add(notificacao);

        // Manter apenas últimas 100 notificações
        while (notificacoes.size() > 100) {
            notificacoes.poll();
        }

        // Log no sistema
        System.out.println("🔔 NOTIFICAÇÃO: " + notificacao.getTitulo() + " - " + notificacao.getMensagem());
    }

    public List<Notificacao> getNotificacoes(int usuarioId, int limite) {
        List<Notificacao> lista = new ArrayList<>(notificacoes);
        List<Notificacao> resultado = new ArrayList<>();

        // Ordenar por data decrescente
        lista.sort((a, b) -> b.getData().compareTo(a.getData()));

        // Pegar as últimas 'limite' notificações e marcar se foram lidas
        for (int i = 0; i < Math.min(limite, lista.size()); i++) {
            Notificacao n = lista.get(i);
            Notificacao copia = new Notificacao(n.getTitulo(), n.getMensagem(), n.getTipo(), n.getIdReferencia());
            copia.setId(n.getId());
            copia.setData(n.getData());
            copia.setIcone(n.getIcone());
            copia.setCor(n.getCor());

            // Verificar se o usuário já leu esta notificação
            List<Integer> lidas = notificacoesLidas.getOrDefault(usuarioId, new ArrayList<>());
            copia.setLida(lidas.contains(n.getId()));

            resultado.add(copia);
        }

        return resultado;
    }

    public int getNotificacoesNaoLidas(int usuarioId) {
        List<Notificacao> lista = new ArrayList<>(notificacoes);
        List<Integer> lidas = notificacoesLidas.getOrDefault(usuarioId, new ArrayList<>());

        int naoLidas = 0;
        for (Notificacao n : lista) {
            if (!lidas.contains(n.getId())) {
                naoLidas++;
            }
        }
        return naoLidas;
    }

    public void marcarComoLida(int usuarioId, int notificacaoId) {
        notificacoesLidas.computeIfAbsent(usuarioId, k -> new ArrayList<>());
        if (!notificacoesLidas.get(usuarioId).contains(notificacaoId)) {
            notificacoesLidas.get(usuarioId).add(notificacaoId);
        }
    }

    public void marcarTodasComoLidas(int usuarioId) {
        List<Integer> todosIds = new ArrayList<>();
        for (Notificacao n : notificacoes) {
            todosIds.add(n.getId());
        }
        notificacoesLidas.put(usuarioId, todosIds);
    }

    // Eventos do sistema que geram notificações

    public void notificarCheckin(String hospede, String quarto, int reservaId) {
        Notificacao n = new Notificacao(
                "✅ Check-in Realizado",
                String.format("%s fez check-in no quarto %s", hospede, quarto),
                "CHECKIN",
                reservaId
        );
        adicionarNotificacao(n);
    }

    public void notificarCheckout(String hospede, String quarto, double valor, int reservaId) {
        Notificacao n = new Notificacao(
                "🏨 Check-out Realizado",
                String.format("%s fez check-out do quarto %s. Total: %.2f MZN", hospede, quarto, valor),
                "CHECKOUT",
                reservaId
        );
        adicionarNotificacao(n);
    }

    public void notificarNovaReserva(String cliente, String quarto, String data, int reservaId) {
        Notificacao n = new Notificacao(
                "📅 Nova Reserva",
                String.format("%s reservou o quarto %s para %s", cliente, quarto, data),
                "RESERVA",
                reservaId
        );
        adicionarNotificacao(n);
    }

    public void notificarPagamento(String cliente, double valor, String metodo, int reservaId) {
        Notificacao n = new Notificacao(
                "💰 Pagamento Recebido",
                String.format("%s pagou %.2f MZN via %s", cliente, valor, metodo),
                "PAGAMENTO",
                reservaId
        );
        adicionarNotificacao(n);
    }

    public void notificarCancelamento(String cliente, String quarto, int reservaId) {
        Notificacao n = new Notificacao(
                "❌ Reserva Cancelada",
                String.format("%s cancelou a reserva do quarto %s", cliente, quarto),
                "ALERTA",
                reservaId
        );
        adicionarNotificacao(n);
    }

    public void notificarAlerta(String titulo, String mensagem) {
        Notificacao n = new Notificacao(titulo, mensagem, "ALERTA", 0);
        adicionarNotificacao(n);
    }
}