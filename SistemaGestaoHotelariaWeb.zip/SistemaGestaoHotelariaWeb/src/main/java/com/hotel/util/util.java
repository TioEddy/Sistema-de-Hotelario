package com.hotel.util;

public class util {
}
