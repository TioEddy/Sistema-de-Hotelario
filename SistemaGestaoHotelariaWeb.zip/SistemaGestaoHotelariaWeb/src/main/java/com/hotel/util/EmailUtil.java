// src/main/java/com/hotel/util/EmailUtil.java
package com.hotel.util;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailUtil {

    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "587";
    private static final String EMAIL_REMETENTE = "edsonalbertojose04@gmail.com";
    private static final String SENHA_APP = "oqxx rkgj btvs uzpj";

    private static final String BASE_URL = "http://localhost:8080/SistemaGestaoHotelariaWeb";

    // LOGOTIPO EM BASE64 (FALLBACK - usado se a imagem do servidor não carregar)
    private static final String LOGO_BASE64_FALLBACK = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAC7UlEQVR4nO2bP2gUURDGf7ub86LmQEGCoiCoiGChIEhAQSwMFgKCpVgbpUgrYimIVmJhIQRbQdtYWBgLi2AhWAhCERQRSa1Ibj3vZ9Fsc+65x7o3G8H9YODyZt/MN+83w+7MESJEiBAhQoQIESJEiBAhQoQIESL8vzCJjAxcXgUutYBmU2irW+fqujWbMDUFmUx3P58AhsB2D5hQxVmvz2q3YYiDGHNfe0qUqBkYwLUepCENg9TpXVeYnsZisT6/pRijWwQAAeVyZZ/pNYyf3gKv2pCCPjzh9k4XmJkBZ+f+fiGmWAyDqUXxKTV5AnAeQmm6BmazGDTvZRmsBYBzXvdpzcdhzEcUX4NnPcgsQPYHnP/E8/OCnI0WzHdiEKYnDTATYPYdYgqRAgqYfsAiBzJj+uSLEuD8AQYFyFxJIPsAbRzM3oslQByErkRMIUrA4D+k8AhqFIAoPqtpYJ4CDAcpRgOWlyGdFp/+ILdfoV7HYjHwMwgGDE9g+xtoG6GqUO+qqqGtAH+fw0Iag1n/I+iBY9OMwrYBU9P/i1Nc/JGTE54ZJPo+JJPC1isQZxGz/S/yi+TzUCobYAZYOwAzAMODyCgO+XlQv0oAqbyyPzMTPX/+idQFh3pP48klSI9KDh+5uLYoYgiU5o9vQ6lD+SIxL89Bo2GActkAc+qypCrPqzUjR5A/wJ8SeJ/FAB4/BnJQ74y+rZWSOfLzQhCYnB2QHzHA35/gbcqUNLkErsTz+fcTHDlgIM7zNMTzVw5rG1UCyL8aYFQy5N47iOQCbH4HpzPitNpYlKvVEjFSKQOMh/3Lf6FRkYr7WNtqC8CZy6t4mgglH6tKLZ/yzAgRYh/1Zg2P3mT4/g6+dqG3Anxot+u/lc2mRkKukc+BD4BtVowQIUKECBEiRIgQIUKECP8aP3++GwgAwB8mHjQAAGgWbE6BZz2YdLxG3sRgZMIiBLiPil2/UbBzE2oNTPQ8NnC+NYBCyaT9L/CmAzPzgPJ9tIqQEJA+A45t8RQyU10YnhPmE2niy8o+wZteYk/qG2+6vvdIiBAhQoQIESJEiBAhQoQIESL8b/wBwz53eq9tA9kAAAAASUVORK5CYII=";

    public static boolean enviarCodigoRecuperacao(String emailDestino, String nomeUsuario, String codigo) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.ssl.trust", SMTP_HOST);

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_REMETENTE, SENHA_APP);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_REMETENTE, "Sistema Hotelaria"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailDestino));
            message.setSubject("🔐 Recuperação de Senha - Sistema Hotelaria");

            String htmlContent = "<!DOCTYPE html>" +
                    "<html>" +
                    "<head><meta charset='UTF-8'><style>" +
                    "body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f7fc; margin: 0; padding: 20px; }" +
                    ".container { max-width: 550px; margin: 0 auto; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }" +
                    ".header { background: linear-gradient(135deg, #0B2B40 0%, #1A4B6E 100%); padding: 30px; text-align: center; }" +
                    ".header img { width: 70px; height: 70px; border-radius: 50%; background: white; padding: 10px; object-fit: contain; }" +
                    ".header h1 { color: #FFB800; margin: 10px 0 0; font-size: 24px; }" +
                    ".content { padding: 30px; }" +
                    ".content h2 { color: #0B2B40; margin-bottom: 15px; }" +
                    ".content p { color: #4a5568; line-height: 1.6; margin-bottom: 20px; }" +
                    ".code-box { background: #FFF8E1; border: 2px dashed #FFB800; border-radius: 16px; padding: 25px; text-align: center; margin: 25px 0; }" +
                    ".code { font-size: 32px; font-weight: bold; letter-spacing: 8px; color: #0B2B40; font-family: monospace; }" +
                    ".warning { background: #FEF3F2; border-left: 4px solid #D9534F; padding: 15px; border-radius: 12px; margin: 20px 0; font-size: 13px; }" +
                    ".footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #8AA6B5; border-top: 1px solid #e2eaef; }" +
                    ".btn { display: inline-block; background: #FFB800; color: #0B2B40; padding: 12px 24px; border-radius: 40px; text-decoration: none; font-weight: bold; margin-top: 15px; }" +
                    ".btn:hover { background: #e6a600; color: #0B2B40; }" +
                    "</style></head>" +
                    "<body>" +
                    "<div class='container'>" +
                    "<div class='header'>" +
                    // Tenta carregar do servidor, se falhar usa o fallback inline
                    // src/main/java/com/hotel/util/EmailUtil.java

// Remova a constante LOGO_BASE64_FALLBACK (não vai precisar mais)

// No HTML, mantenha apenas:
                    "<img src='" + BASE_URL + "/assets/images/logotipo.png' alt='Logotipo Hotelaria' style='width: 70px; height: 70px; border-radius: 50%; background: white; padding: 10px; object-fit: contain;'>" +
                    "<h1>Sistema Hotelaria</h1>" +
                    "</div>" +
                    "<div class='content'>" +
                    "<h2>Olá, " + nomeUsuario + "! 👋</h2>" +
                    "<p>Recebemos uma solicitação para redefinir a sua senha de acesso ao <strong>Sistema Hotelaria</strong>.</p>" +
                    "<p>Utilize o código de verificação abaixo para continuar o processo de recuperação:</p>" +
                    "<div class='code-box'>" +
                    "<div class='code'>" + codigo + "</div>" +
                    "<p style='margin-top: 10px; font-size: 12px; color: #6c757d;'>Código válido por 5 minutos</p>" +
                    "</div>" +
                    "<div class='warning'>" +
                    "<strong>⚠️ Atenção:</strong><br>" +
                    "• Este código expira em <strong>5 minutos</strong><br>" +
                    "• Se você não solicitou esta alteração, ignore este e-mail<br>" +
                    "• Nunca compartilhe este código com ninguém" +
                    "</div>" +
                    "<p style='text-align: center;'>" +
                    "<a href='" + BASE_URL + "/login.jsp' class='btn'>🔐 Ir para o Login</a>" +
                    "</p>" +
                    "</div>" +
                    "<div class='footer'>" +
                    "<p>Sistema Hotelaria - Gestão Integrada de Hotelaria</p>" +
                    "<p>Este é um e-mail automático, por favor não responda.</p>" +
                    "</div>" +
                    "</div>" +
                    "</body>" +
                    "</html>";

            message.setContent(htmlContent, "text/html; charset=UTF-8");
            Transport.send(message);
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}