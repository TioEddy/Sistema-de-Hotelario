// src/main/java/com/hotel/dao/TipoQuartoDAO.java
package com.hotel.dao;

import com.hotel.model.TipoQuarto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoQuartoDAO {

    private Connection getConnection() throws SQLException {
        return ConexaoDB.getConexao();
    }

    public List<TipoQuarto> listarTodos() {
        List<TipoQuarto> tipos = new ArrayList<>();
        String sql = "SELECT * FROM tipo_quarto ORDER BY id_tipo_quarto";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                TipoQuarto t = new TipoQuarto();
                t.setIdTipoQuarto(rs.getInt("id_tipo_quarto"));
                t.setNomeTipo(rs.getString("nome_tipo"));
                t.setDescricao(rs.getString("descricao"));
                t.setPrecoDiaria(rs.getDouble("preco_diaria"));
                tipos.add(t);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar tipos: " + e.getMessage());
            e.printStackTrace();
        }
        return tipos;
    }

    public TipoQuarto buscarPorId(int id) {
        String sql = "SELECT * FROM tipo_quarto WHERE id_tipo_quarto = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                TipoQuarto t = new TipoQuarto();
                t.setIdTipoQuarto(rs.getInt("id_tipo_quarto"));
                t.setNomeTipo(rs.getString("nome_tipo"));
                t.setDescricao(rs.getString("descricao"));
                t.setPrecoDiaria(rs.getDouble("preco_diaria"));
                return t;
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar tipo por ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public boolean inserir(TipoQuarto tipo) {
        String sql = "INSERT INTO tipo_quarto (nome_tipo, descricao, preco_diaria) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, tipo.getNomeTipo());
            stmt.setString(2, tipo.getDescricao());
            stmt.setDouble(3, tipo.getPrecoDiaria());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    tipo.setIdTipoQuarto(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Erro ao inserir tipo: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    public boolean atualizar(TipoQuarto tipo) {
        String sql = "UPDATE tipo_quarto SET nome_tipo = ?, descricao = ?, preco_diaria = ? WHERE id_tipo_quarto = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tipo.getNomeTipo());
            stmt.setString(2, tipo.getDescricao());
            stmt.setDouble(3, tipo.getPrecoDiaria());
            stmt.setInt(4, tipo.getIdTipoQuarto());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar tipo: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    public boolean excluir(int id) {
        String sql = "DELETE FROM tipo_quarto WHERE id_tipo_quarto = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao excluir tipo: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}