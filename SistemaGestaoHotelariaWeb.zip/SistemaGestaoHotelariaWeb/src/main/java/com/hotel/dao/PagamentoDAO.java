// src/main/java/com/hotel/dao/PagamentoDAO.java
package com.hotel.dao;

import java.sql.*;

public class PagamentoDAO {

    public double somarPagamentosMes() {
        String sql = "SELECT COALESCE(SUM(valor), 0) as total FROM pagamento " +
                "WHERE MONTH(data_pagamento) = MONTH(CURRENT_DATE()) " +
                "AND YEAR(data_pagamento) = YEAR(CURRENT_DATE()) " +
                "AND estado_pagamento = 'PAGO'";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public double somarPendentes() {
        String sql = "SELECT COALESCE(SUM(valor), 0) as total FROM pagamento " +
                "WHERE estado_pagamento IN ('PENDENTE', 'PARCIAL')";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}