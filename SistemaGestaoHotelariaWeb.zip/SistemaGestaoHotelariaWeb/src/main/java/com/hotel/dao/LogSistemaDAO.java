// src/main/java/com/hotel/dao/LogSistemaDAO.java
package com.hotel.dao;

import com.hotel.model.LogSistema;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LogSistemaDAO {

    public void registrarLog(int idUsuario, String acao, String tabelaAfetada,
                             int idRegistro, String descricao, String ip, String navegador) {
        String sql = "INSERT INTO log_sistema (id_usuario, acao, tabela_afetada, id_registro, descricao, endereco_ip, navegador) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            stmt.setString(2, acao);
            stmt.setString(3, tabelaAfetada);
            stmt.setInt(4, idRegistro);
            stmt.setString(5, descricao);
            stmt.setString(6, ip);
            stmt.setString(7, navegador);
            stmt.executeUpdate();
            System.out.println("✅ Log registrado: " + acao + " - " + descricao);
        } catch (SQLException e) {
            System.err.println("❌ Erro ao registrar log: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<LogSistema> listarTodosLogs() {
        List<LogSistema> logs = new ArrayList<>();
        String sql = "SELECT l.*, COALESCE(u.nome, 'Sistema') as nome_usuario, COALESCE(u.email, 'sistema@hotel.com') as email_usuario " +
                "FROM log_sistema l " +
                "LEFT JOIN usuario u ON l.id_usuario = u.id_usuario " +
                "ORDER BY l.data_log DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                LogSistema log = new LogSistema();
                log.setIdLog(rs.getInt("id_log"));
                log.setIdUsuario(rs.getInt("id_usuario"));
                log.setNomeUsuario(rs.getString("nome_usuario"));
                log.setEmailUsuario(rs.getString("email_usuario"));
                log.setAcao(rs.getString("acao"));
                log.setTabelaAfetada(rs.getString("tabela_afetada"));
                log.setIdRegistro(rs.getInt("id_registro"));
                log.setDescricao(rs.getString("descricao"));
                log.setEnderecoIp(rs.getString("endereco_ip"));
                log.setNavegador(rs.getString("navegador"));
                log.setDataLog(rs.getTimestamp("data_log"));
                logs.add(log);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar logs: " + e.getMessage());
            e.printStackTrace();
        }
        return logs;
    }

    public List<LogSistema> listarComFiltros(int limite, String dataInicio, String dataFim, String acao, String tabela) {
        List<LogSistema> logs = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT l.*, COALESCE(u.nome, 'Sistema') as nome_usuario, COALESCE(u.email, 'sistema@hotel.com') as email_usuario " +
                        "FROM log_sistema l " +
                        "LEFT JOIN usuario u ON l.id_usuario = u.id_usuario " +
                        "WHERE 1=1 "
        );

        List<Object> params = new ArrayList<>();

        if (dataInicio != null && !dataInicio.isEmpty()) {
            sql.append(" AND DATE(l.data_log) >= ? ");
            params.add(dataInicio);
        }
        if (dataFim != null && !dataFim.isEmpty()) {
            sql.append(" AND DATE(l.data_log) <= ? ");
            params.add(dataFim);
        }
        if (acao != null && !acao.isEmpty() && !"TODOS".equals(acao)) {
            sql.append(" AND l.acao = ? ");
            params.add(acao);
        }
        if (tabela != null && !tabela.isEmpty() && !"TODAS".equals(tabela)) {
            sql.append(" AND l.tabela_afetada = ? ");
            params.add(tabela);
        }
        sql.append(" ORDER BY l.data_log DESC LIMIT ?");
        params.add(limite);

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    LogSistema log = new LogSistema();
                    log.setIdLog(rs.getInt("id_log"));
                    log.setIdUsuario(rs.getInt("id_usuario"));
                    log.setNomeUsuario(rs.getString("nome_usuario"));
                    log.setEmailUsuario(rs.getString("email_usuario"));
                    log.setAcao(rs.getString("acao"));
                    log.setTabelaAfetada(rs.getString("tabela_afetada"));
                    log.setIdRegistro(rs.getInt("id_registro"));
                    log.setDescricao(rs.getString("descricao"));
                    log.setEnderecoIp(rs.getString("endereco_ip"));
                    log.setNavegador(rs.getString("navegador"));
                    log.setDataLog(rs.getTimestamp("data_log"));
                    logs.add(log);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar logs com filtros: " + e.getMessage());
            e.printStackTrace();
        }
        return logs;
    }

    // MÉTODO CORRIGIDO - listarAcoesDistintas
    public List<String> listarAcoesDistintas() {
        List<String> acoes = new ArrayList<>();
        String sql = "SELECT DISTINCT acao FROM log_sistema ORDER BY acao";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                acoes.add(rs.getString("acao"));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar ações distintas: " + e.getMessage());
            e.printStackTrace();
        }
        return acoes;
    }

    public List<String> listarTabelasDistintas() {
        List<String> tabelas = new ArrayList<>();
        String sql = "SELECT DISTINCT tabela_afetada FROM log_sistema WHERE tabela_afetada IS NOT NULL AND tabela_afetada != '' ORDER BY tabela_afetada";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                tabelas.add(rs.getString("tabela_afetada"));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar tabelas distintas: " + e.getMessage());
            e.printStackTrace();
        }
        return tabelas;
    }

    public int contarTotalLogs() {
        String sql = "SELECT COUNT(*) FROM log_sistema";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarLoginsHoje() {
        String sql = "SELECT COUNT(*) FROM log_sistema WHERE acao = 'LOGIN' AND DATE(data_log) = CURDATE()";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarAlteracoesSemana() {
        String sql = "SELECT COUNT(*) FROM log_sistema WHERE acao IN ('CREATE', 'UPDATE', 'DELETE') AND data_log >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarUsuariosAtivos() {
        String sql = "SELECT COUNT(DISTINCT id_usuario) FROM log_sistema WHERE data_log >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND id_usuario IS NOT NULL";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void limparLogsAntigos(int dias) {
        String sql = "DELETE FROM log_sistema WHERE data_log < DATE_SUB(NOW(), INTERVAL ? DAY)";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, dias);
            int removidos = stmt.executeUpdate();
            System.out.println("🗑️ " + removidos + " logs antigos removidos");
        } catch (SQLException e) {
            System.err.println("Erro ao limpar logs antigos: " + e.getMessage());
            e.printStackTrace();
        }
    }
}