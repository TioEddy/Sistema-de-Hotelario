// src/main/java/com/hotel/dao/ClienteDAO.java
package com.hotel.dao;

import com.hotel.model.Cliente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    private Connection getConnection() throws SQLException {
        return ConexaoDB.getConexao();
    }

    public List<Cliente> listarTodos() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT c.*, n.pais, td.descricao as tipo_documento FROM cliente c " +
                "LEFT JOIN nacionalidade n ON c.id_nacionalidade = n.id_nacionalidade " +
                "LEFT JOIN tipo_documento td ON c.id_tipo_documento = td.id_tipo_documento " +
                "ORDER BY c.id_cliente DESC";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                clientes.add(extrairCliente(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar clientes: " + e.getMessage());
            e.printStackTrace();
        }
        return clientes;
    }

    public Cliente buscarPorId(int id) {
        String sql = "SELECT c.*, n.pais, td.descricao as tipo_documento FROM cliente c " +
                "LEFT JOIN nacionalidade n ON c.id_nacionalidade = n.id_nacionalidade " +
                "LEFT JOIN tipo_documento td ON c.id_tipo_documento = td.id_tipo_documento " +
                "WHERE c.id_cliente = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return extrairCliente(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Cliente extrairCliente(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setIdCliente(rs.getInt("id_cliente"));
        cliente.setNomeCompleto(rs.getString("nome_completo"));
        cliente.setSexo(rs.getString("sexo"));
        cliente.setDataNascimento(rs.getDate("data_nascimento"));
        cliente.setTelefone(rs.getString("telefone"));
        cliente.setEmail(rs.getString("email"));
        cliente.setEndereco(rs.getString("endereco"));
        cliente.setIdNacionalidade(rs.getInt("id_nacionalidade"));
        cliente.setPais(rs.getString("pais"));
        cliente.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
        cliente.setTipoDocumento(rs.getString("tipo_documento"));
        cliente.setNumeroDocumento(rs.getString("numero_documento"));
        cliente.setDataRegistro(rs.getTimestamp("data_registro"));
        return cliente;
    }

    public int contarTotal() {
        String sql = "SELECT COUNT(*) FROM cliente";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
// Adicionar ao ClienteDAO.java

    public boolean inserir(Cliente cliente) {
        String sql = "INSERT INTO cliente (nome_completo, sexo, data_nascimento, telefone, email, endereco, id_nacionalidade, id_tipo_documento, numero_documento) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, cliente.getNomeCompleto());
            stmt.setString(2, cliente.getSexo());
            stmt.setDate(3, cliente.getDataNascimento() != null ? new java.sql.Date(cliente.getDataNascimento().getTime()) : null);
            stmt.setString(4, cliente.getTelefone());
            stmt.setString(5, cliente.getEmail());
            stmt.setString(6, cliente.getEndereco());
            stmt.setObject(7, cliente.getIdNacionalidade());
            stmt.setObject(8, cliente.getIdTipoDocumento());
            stmt.setString(9, cliente.getNumeroDocumento());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    cliente.setIdCliente(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean atualizar(Cliente cliente) {
        String sql = "UPDATE cliente SET nome_completo = ?, sexo = ?, data_nascimento = ?, telefone = ?, email = ?, "
                + "endereco = ?, id_nacionalidade = ?, id_tipo_documento = ?, numero_documento = ? WHERE id_cliente = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNomeCompleto());
            stmt.setString(2, cliente.getSexo());
            stmt.setDate(3, cliente.getDataNascimento() != null ? new java.sql.Date(cliente.getDataNascimento().getTime()) : null);
            stmt.setString(4, cliente.getTelefone());
            stmt.setString(5, cliente.getEmail());
            stmt.setString(6, cliente.getEndereco());
            stmt.setObject(7, cliente.getIdNacionalidade());
            stmt.setObject(8, cliente.getIdTipoDocumento());
            stmt.setString(9, cliente.getNumeroDocumento());
            stmt.setInt(10, cliente.getIdCliente());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean excluir(int id) {
        String sql = "DELETE FROM cliente WHERE id_cliente = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public int contarPorSexo(String sexo) {
        String sql = "SELECT COUNT(*) FROM cliente WHERE sexo = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, sexo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    public int contarNovosEsteMes() {
        String sql = "SELECT COUNT(*) FROM cliente WHERE MONTH(data_registro) = MONTH(CURRENT_DATE()) AND YEAR(data_registro) = YEAR(CURRENT_DATE())";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}