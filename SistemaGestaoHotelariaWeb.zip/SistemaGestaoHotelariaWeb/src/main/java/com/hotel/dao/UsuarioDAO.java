// src/main/java/com/hotel/dao/UsuarioDAO.java
package com.hotel.dao;

import com.hotel.model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UsuarioDAO {

    // CORRIGIDO: Agora chama o método correto getConexao() da classe ConexaoDB
    private Connection getConnection() throws SQLException {
        return ConexaoDB.getConexao();  // Mudou de getConnection() para getConexao()
    }
    // src/main/java/com/hotel/dao/UsuarioDAO.java
    public Usuario buscarPorEmail(String email) {
        String sql = "SELECT u.*, p.nome_perfil FROM usuario u " +
                "JOIN perfil p ON u.id_perfil = p.id_perfil WHERE u.email = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("id_usuario"));
                    usuario.setNome(rs.getString("nome"));
                    usuario.setEmail(rs.getString("email"));
                    usuario.setUsername(rs.getString("username"));
                    usuario.setSenha(rs.getString("senha"));
                    usuario.setNomePerfil(rs.getString("nome_perfil"));
                    return usuario;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    // Restante do código permanece igual...
    public Usuario autenticar(String username, String senha) {
        // Comente a linha do hash para teste
        // String senhaHash = hashSenha(senha);
        String sql = "SELECT u.*, p.nome_perfil FROM usuario u " +
                "INNER JOIN perfil p ON u.id_perfil = p.id_perfil " +
                "WHERE u.username = ? AND u.senha = ? AND u.estado = 'ATIVO'";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, senha); // Usar senha sem hash para teste
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("id_usuario"));
                usuario.setNome(rs.getString("nome"));
                usuario.setEmail(rs.getString("email"));
                usuario.setTelefone(rs.getString("telefone"));
                usuario.setUsername(rs.getString("username"));
                usuario.setSenha(rs.getString("senha"));
                usuario.setIdPerfil(rs.getInt("id_perfil"));
                usuario.setNomePerfil(rs.getString("nome_perfil"));
                usuario.setFoto(rs.getString("foto"));
                usuario.setEstado(rs.getString("estado"));
                return usuario;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Listar todos usuários
    public List<Usuario> listarTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT u.*, p.nome_perfil FROM usuario u " +
                "INNER JOIN perfil p ON u.id_perfil = p.id_perfil " +
                "ORDER BY u.id_usuario DESC";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                usuarios.add(extrairUsuario(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }

    // Listar com filtros e paginação
    // Listar com filtros e paginação - COM LOGS
    public List<Usuario> listarComFiltros(String search, String perfil, String status, int page, int limit) {
        List<Usuario> usuarios = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT u.*, p.nome_perfil FROM usuario u " +
                        "INNER JOIN perfil p ON u.id_perfil = p.id_perfil WHERE 1=1"
        );

        List<Object> params = new ArrayList<>();

        if (search != null && !search.isEmpty()) {
            sql.append(" AND (u.nome LIKE ? OR u.username LIKE ? OR u.email LIKE ?)");
            String likePattern = "%" + search + "%";
            params.add(likePattern);
            params.add(likePattern);
            params.add(likePattern);
        }

        if (perfil != null && !perfil.isEmpty()) {
            sql.append(" AND u.id_perfil = ?");
            params.add(Integer.parseInt(perfil));
        }

        if (status != null && !status.isEmpty()) {
            sql.append(" AND u.estado = ?");
            params.add(status);
        }

        sql.append(" ORDER BY u.id_usuario DESC LIMIT ? OFFSET ?");
        params.add(limit);
        params.add((page - 1) * limit);

        System.out.println("SQL SELECT: " + sql.toString());
        System.out.println("Params SELECT: " + params);

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                usuarios.add(extrairUsuario(rs));
            }
        } catch (SQLException e) {
            System.out.println("Erro no SELECT: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("Usuários retornados: " + usuarios.size());
        return usuarios;
    }

    // Contar com filtros
    // Contar com filtros - CORRIGIDO
    public int contarComFiltros(String search, String perfil, String status) {
        StringBuilder sql = new StringBuilder(
                "SELECT COUNT(*) FROM usuario u WHERE 1=1"
        );

        List<Object> params = new ArrayList<>();

        if (search != null && !search.isEmpty()) {
            sql.append(" AND (u.nome LIKE ? OR u.username LIKE ? OR u.email LIKE ?)");
            String likePattern = "%" + search + "%";
            params.add(likePattern);
            params.add(likePattern);
            params.add(likePattern);
        }

        if (perfil != null && !perfil.isEmpty()) {
            sql.append(" AND u.id_perfil = ?");
            params.add(Integer.parseInt(perfil));
        }

        if (status != null && !status.isEmpty()) {
            sql.append(" AND u.estado = ?");
            params.add(status);
        }

        System.out.println("SQL COUNT: " + sql.toString());
        System.out.println("Params COUNT: " + params);

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                System.out.println("Total encontrado: " + count);
                return count;
            }
        } catch (SQLException e) {
            System.out.println("Erro no COUNT: " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }

    // Buscar por ID
    public Usuario buscarPorId(int id) {
        String sql = "SELECT u.*, p.nome_perfil FROM usuario u " +
                "INNER JOIN perfil p ON u.id_perfil = p.id_perfil " +
                "WHERE u.id_usuario = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return extrairUsuario(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Inserir usuário
    // Inserir usuário - VERSÃO SEM HASH PARA TESTE
    public boolean inserir(Usuario usuario) {
        String sql = "INSERT INTO usuario (nome, username, senha, email, telefone, id_perfil, estado, foto) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getUsername());
            stmt.setString(3, usuario.getSenha());  // SEM HASH - direto
            stmt.setString(4, usuario.getEmail());
            stmt.setString(5, usuario.getTelefone());
            stmt.setInt(6, usuario.getIdPerfil());
            stmt.setString(7, usuario.getEstado());
            stmt.setString(8, usuario.getFoto());

            int affected = stmt.executeUpdate();

            if (affected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    usuario.setIdUsuario(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    // Atualizar usuário
    // Atualizar usuário - SEM HASH
    public boolean atualizar(Usuario usuario) {
        StringBuilder sql = new StringBuilder(
                "UPDATE usuario SET nome = ?, username = ?, email = ?, telefone = ?, " +
                        "id_perfil = ?, estado = ?"
        );

        List<Object> params = new ArrayList<>();
        params.add(usuario.getNome());
        params.add(usuario.getUsername());
        params.add(usuario.getEmail());
        params.add(usuario.getTelefone());
        params.add(usuario.getIdPerfil());
        params.add(usuario.getEstado());

        if (usuario.getSenha() != null && !usuario.getSenha().isEmpty()) {
            sql.append(", senha = ?");
            params.add(usuario.getSenha());  // SEM HASH
        }

        if (usuario.getFoto() != null && !usuario.getFoto().isEmpty()) {
            sql.append(", foto = ?");
            params.add(usuario.getFoto());
        }

        sql.append(" WHERE id_usuario = ?");
        params.add(usuario.getIdUsuario());

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Excluir usuário
    public boolean excluir(int id) {
        String sql = "DELETE FROM usuario WHERE id_usuario = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Alterar senha
    // Alterar senha - SEM HASH
    public boolean alterarSenha(int id, String novaSenha) {
        String sql = "UPDATE usuario SET senha = ? WHERE id_usuario = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, novaSenha);  // SEM HASH
            stmt.setInt(2, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Alterar status
    public boolean alterarStatus(int id, String status) {
        String sql = "UPDATE usuario SET estado = ? WHERE id_usuario = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Listar perfis
    public List<com.hotel.model.Perfil> listarPerfis() {
        List<com.hotel.model.Perfil> perfis = new ArrayList<>();
        String sql = "SELECT id_perfil, nome_perfil FROM perfil ORDER BY id_perfil";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                com.hotel.model.Perfil perfil = new com.hotel.model.Perfil();
                perfil.setIdPerfil(rs.getInt("id_perfil"));
                perfil.setNomePerfil(rs.getString("nome_perfil"));
                perfis.add(perfil);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return perfis;
    }

    // Métodos auxiliares
    private Usuario extrairUsuario(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(rs.getInt("id_usuario"));
        usuario.setNome(rs.getString("nome"));
        usuario.setUsername(rs.getString("username"));
        usuario.setSenha(rs.getString("senha"));
        usuario.setEmail(rs.getString("email"));
        usuario.setTelefone(rs.getString("telefone"));
        usuario.setIdPerfil(rs.getInt("id_perfil"));
        usuario.setNomePerfil(rs.getString("nome_perfil"));
        usuario.setFoto(rs.getString("foto"));
        usuario.setEstado(rs.getString("estado"));
        return usuario;
    }

    private String hashSenha(String senha) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(senha.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return senha;
        }
    }

    // Métodos estatísticos para o dashboard
    public int contarTotal() {
        String sql = "SELECT COUNT(*) FROM usuario";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarPorStatus(String status) {
        String sql = "SELECT COUNT(*) FROM usuario WHERE estado = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int contarPorPerfil(int idPerfil) {
        String sql = "SELECT COUNT(*) FROM usuario WHERE id_perfil = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idPerfil);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}