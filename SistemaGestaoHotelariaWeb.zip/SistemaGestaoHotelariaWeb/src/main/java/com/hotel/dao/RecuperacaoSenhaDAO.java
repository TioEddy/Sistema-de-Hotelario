// src/main/java/com/hotel/dao/RecuperacaoSenhaDAO.java
package com.hotel.dao;

import java.sql.*;
import java.util.Date;

public class RecuperacaoSenhaDAO {

    public boolean salvarCodigoRecuperacao(int idUsuario, String codigo, Date expiraEm) {
        String sql = "INSERT INTO recuperacao_senha (id_usuario, codigo, expira_em) VALUES (?, ?, ?) " +
                "ON DUPLICATE KEY UPDATE codigo = ?, expira_em = ?";

        System.out.println("📝 SALVANDO CÓDIGO - Usuário ID: " + idUsuario + ", Código: " + codigo + ", Expira: " + expiraEm);

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            stmt.setString(2, codigo);
            stmt.setTimestamp(3, new Timestamp(expiraEm.getTime()));
            stmt.setString(4, codigo);
            stmt.setTimestamp(5, new Timestamp(expiraEm.getTime()));

            int rowsAffected = stmt.executeUpdate();
            System.out.println("✅ Código salvo! Linhas afetadas: " + rowsAffected);
            return true;
        } catch (SQLException e) {
            System.err.println("❌ Erro ao salvar código: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // src/main/java/com/hotel/dao/RecuperacaoSenhaDAO.java

    public boolean validarCodigo(String email, String codigo) {
        // REMOVEMOS a condição de expiração do SQL
        String sql = "SELECT u.id_usuario, r.expira_em, r.codigo FROM recuperacao_senha r " +
                "JOIN usuario u ON r.id_usuario = u.id_usuario " +
                "WHERE u.email = ? AND r.codigo = ?";

        System.out.println("🔍 VALIDANDO CÓDIGO - Email: " + email + ", Código: " + codigo);

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Buscar data de expiração do banco
                    Timestamp expiraEm = rs.getTimestamp("expira_em");
                    Timestamp agora = new Timestamp(System.currentTimeMillis());

                    // Validar se o código ainda não expirou (compara no Java, não no SQL)
                    boolean valido = agora.before(expiraEm);

                    if (valido) {
                        System.out.println("✅ Código VÁLIDO para o email: " + email);
                        System.out.println("   Expira em: " + expiraEm);
                        System.out.println("   Agora: " + agora);
                    } else {
                        System.out.println("❌ Código EXPIRADO! Expira em: " + expiraEm + ", Agora: " + agora);
                        long diffSeconds = (agora.getTime() - expiraEm.getTime()) / 1000;
                        System.out.println("   Expirado há " + diffSeconds + " segundos");
                    }
                    return valido;
                } else {
                    System.out.println("❌ Código INVÁLIDO - não encontrado para o email: " + email);
                    return false;
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erro ao validar código: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Método auxiliar para debug - verifica se o código existe mas está expirado
    private void verificarCodigoExistente(String email, String codigo) {
        String sql = "SELECT r.codigo, r.expira_em FROM recuperacao_senha r " +
                "JOIN usuario u ON r.id_usuario = u.id_usuario " +
                "WHERE u.email = ? AND r.codigo = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, codigo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Timestamp expiraEm = rs.getTimestamp("expira_em");
                Timestamp agora = new Timestamp(System.currentTimeMillis());
                System.out.println("   Código encontrado mas EXPIRADO! Expira em: " + expiraEm + ", Agora: " + agora);
                if (agora.after(expiraEm)) {
                    System.out.println("   Código expirou há " + ((agora.getTime() - expiraEm.getTime()) / 1000) + " segundos");
                }
            } else {
                System.out.println("   Código NÃO encontrado no banco para este email");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getIdUsuarioByEmail(String email) {
        String sql = "SELECT id_usuario FROM usuario WHERE email = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_usuario");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public boolean atualizarSenha(String email, String novaSenha) {
        String sql = "UPDATE usuario SET senha = ? WHERE email = ?";
        System.out.println("📝 ATUALIZANDO SENHA - Email: " + email);
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, novaSenha);
            stmt.setString(2, email);
            int rows = stmt.executeUpdate();
            System.out.println("✅ Senha atualizada! Linhas afetadas: " + rows);
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("❌ Erro ao atualizar senha: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public void removerCodigo(String email) {
        String sql = "DELETE r FROM recuperacao_senha r " +
                "JOIN usuario u ON r.id_usuario = u.id_usuario " +
                "WHERE u.email = ?";
        System.out.println("🗑️ REMOVENDO CÓDIGO - Email: " + email);
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            int rows = stmt.executeUpdate();
            System.out.println("✅ Código removido! Linhas afetadas: " + rows);
        } catch (SQLException e) {
            System.err.println("❌ Erro ao remover código: " + e.getMessage());
            e.printStackTrace();
        }
    }
}