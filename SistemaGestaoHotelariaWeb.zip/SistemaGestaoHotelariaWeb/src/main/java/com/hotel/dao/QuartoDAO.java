// src/main/java/com/hotel/dao/QuartoDAO.java
package com.hotel.dao;

import com.hotel.model.Quarto;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuartoDAO {

    private Connection getConnection() throws SQLException {
        return ConexaoDB.getConexao();
    }

    public List<Quarto> listarTodos() {
        List<Quarto> quartos = new ArrayList<>();
        String sql = "SELECT q.*, tq.nome_tipo, tq.descricao, tq.preco_diaria FROM quarto q " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "ORDER BY q.id_quarto";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                quartos.add(extrairQuarto(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar quartos: " + e.getMessage());
            e.printStackTrace();
        }
        return quartos;
    }

    public List<Quarto> listarDisponiveis() {
        List<Quarto> quartos = new ArrayList<>();
        String sql = "SELECT q.*, tq.nome_tipo, tq.descricao, tq.preco_diaria FROM quarto q " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.estado IN ('LIVRE', 'RESERVADO') " +
                "ORDER BY q.id_quarto";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                quartos.add(extrairQuarto(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return quartos;
    }

    public Quarto buscarPorId(int id) {
        String sql = "SELECT q.*, tq.nome_tipo, tq.descricao, tq.preco_diaria FROM quarto q " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.id_quarto = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return extrairQuarto(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Quarto extrairQuarto(ResultSet rs) throws SQLException {
        Quarto quarto = new Quarto();
        quarto.setIdQuarto(rs.getInt("id_quarto"));
        quarto.setNumeroQuarto(rs.getString("numero_quarto"));
        quarto.setIdTipoQuarto(rs.getInt("id_tipo_quarto"));
        quarto.setTipoQuarto(rs.getString("nome_tipo"));
        quarto.setDescricaoTipo(rs.getString("descricao"));
        quarto.setPrecoDiaria(rs.getDouble("preco_diaria"));
        quarto.setPiso(rs.getInt("piso"));
        quarto.setEstado(rs.getString("estado"));
        return quarto;
    }

    public int contarPorEstado(String estado) {
        String sql = "SELECT COUNT(*) FROM quarto WHERE estado = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, estado);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public Map<String, Integer> contarTodosEstados() {
        Map<String, Integer> estados = new HashMap<>();
        String sql = "SELECT estado, COUNT(*) as total FROM quarto GROUP BY estado";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                estados.put(rs.getString("estado"), rs.getInt("total"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return estados;
    }

    // Adicionar ao QuartoDAO.java
    public boolean inserir(Quarto quarto) {
        String sql = "INSERT INTO quarto (numero_quarto, id_tipo_quarto, piso, estado) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, quarto.getNumeroQuarto());
            stmt.setInt(2, quarto.getIdTipoQuarto());
            stmt.setInt(3, quarto.getPiso());
            stmt.setString(4, quarto.getEstado());
            int affected = stmt.executeUpdate();
            if (affected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) quarto.setIdQuarto(rs.getInt(1));
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean atualizar(Quarto quarto) {
        String sql = "UPDATE quarto SET numero_quarto = ?, id_tipo_quarto = ?, piso = ?, estado = ? WHERE id_quarto = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, quarto.getNumeroQuarto());
            stmt.setInt(2, quarto.getIdTipoQuarto());
            stmt.setInt(3, quarto.getPiso());
            stmt.setString(4, quarto.getEstado());
            stmt.setInt(5, quarto.getIdQuarto());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Adicione este método ao QuartoDAO.java
    public boolean excluir(int id) {
        String sql = "DELETE FROM quarto WHERE id_quarto = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao excluir quarto: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    public int contarTotal() {
        String sql = "SELECT COUNT(*) FROM quarto";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}