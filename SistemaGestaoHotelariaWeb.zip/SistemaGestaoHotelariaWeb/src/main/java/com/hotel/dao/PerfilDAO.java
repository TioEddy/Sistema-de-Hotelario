// src/main/java/com/hotel/dao/PerfilDAO.java
package com.hotel.dao;

import com.hotel.model.Perfil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PerfilDAO {

    public List<Perfil> listarTodos() {
        List<Perfil> perfis = new ArrayList<>();
        String sql = "SELECT * FROM perfil ORDER BY id_perfil";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Perfil p = new Perfil();
                p.setIdPerfil(rs.getInt("id_perfil"));
                p.setNomePerfil(rs.getString("nome_perfil"));
                perfis.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return perfis;
    }
}