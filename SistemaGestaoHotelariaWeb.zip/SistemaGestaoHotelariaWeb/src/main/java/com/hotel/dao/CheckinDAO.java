package com.hotel.dao;

import java.sql.*;
import java.util.*;

public class CheckinDAO {

    public int contarCheckinsHoje() {
        String sql = "SELECT COUNT(*) FROM checkin WHERE DATE(data_checkin) = CURDATE()";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int contarCheckinsPorPeriodo(String dataInicio, String dataFim) {
        String sql = "SELECT COUNT(*) FROM checkin WHERE DATE(data_checkin) BETWEEN ? AND ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, dataInicio);
            stmt.setString(2, dataFim);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public List<Map<String, Object>> listarCheckinsAtivos() {
        List<Map<String, Object>> checkins = new ArrayList<>();
        // CORRIGIDO: checkin NÃO tem id_cliente e NÃO tem data_checkout
        String sql = "SELECT ci.id_checkin, ci.id_reserva, c.nome_completo, q.id_quarto, q.numero_quarto, " +
                "ci.data_checkin, ci.quantidade_hospedes, ci.observacoes " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON ci.id_quarto = q.id_quarto " +
                "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                "WHERE co.id_checkout IS NULL";
        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Map<String, Object> checkin = new HashMap<>();
                checkin.put("id_checkin", rs.getInt("id_checkin"));
                checkin.put("id_reserva", rs.getInt("id_reserva"));
                checkin.put("cliente_nome", rs.getString("nome_completo"));
                checkin.put("id_quarto", rs.getInt("id_quarto"));
                checkin.put("numero_quarto", rs.getString("numero_quarto"));
                checkin.put("data_checkin", rs.getTimestamp("data_checkin"));
                checkin.put("quantidade_hospedes", rs.getInt("quantidade_hospedes"));
                checkin.put("observacoes", rs.getString("observacoes"));
                checkins.add(checkin);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return checkins;
    }
}