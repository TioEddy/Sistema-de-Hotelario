package com.hotel.dao;

import com.hotel.model.Reserva;
import com.hotel.model.Quarto;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ReservaDAO {

    private Connection getConnection() throws SQLException {
        return ConexaoDB.getConexao();
    }

    // Método auxiliar para normalizar datas (remover hora)
    private java.sql.Date normalizarData(java.util.Date date) {
        if (date == null) return null;
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return new java.sql.Date(cal.getTimeInMillis());
    }

    // LISTAR TODAS AS RESERVAS
    public List<Reserva> listarTodas() {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT r.*, c.nome_completo as cliente_nome, q.numero_quarto, tq.nome_tipo as tipo_quarto, tq.preco_diaria " +
                "FROM reserva r " +
                "INNER JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "INNER JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "ORDER BY r.data_reserva DESC";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Reserva r = new Reserva();
                r.setIdReserva(rs.getInt("id_reserva"));
                r.setIdCliente(rs.getInt("id_cliente"));
                r.setNomeCliente(rs.getString("cliente_nome"));
                r.setIdQuarto(rs.getInt("id_quarto"));
                r.setNumeroQuarto(rs.getString("numero_quarto"));
                r.setTipoQuarto(rs.getString("tipo_quarto"));
                r.setPrecoDiaria(rs.getDouble("preco_diaria"));
                r.setDataReserva(rs.getTimestamp("data_reserva"));
                r.setDataEntrada(rs.getDate("data_entrada"));
                r.setDataSaida(rs.getDate("data_saida"));
                r.setNumeroHospedes(rs.getInt("numero_hospedes"));
                r.setEstadoReserva(rs.getString("estado_reserva"));
                r.setObservacoes(rs.getString("observacoes"));
                reservas.add(r);
            }
        } catch (SQLException e) {
            System.err.println("Erro SQL em listarTodas: " + e.getMessage());
            e.printStackTrace();
        }
        return reservas;
    }

    // LISTAR QUARTOS DISPONÍVEIS COM VALIDAÇÃO CORRETA
    public List<Quarto> listarQuartosDisponiveis(java.util.Date dataEntrada, java.util.Date dataSaida) {
        List<Quarto> quartos = new ArrayList<>();

        // Normalizar datas (remover hora)
        java.sql.Date sqlDataEntrada = normalizarData(dataEntrada);
        java.sql.Date sqlDataSaida = normalizarData(dataSaida);

        // SQL corrigido para verificar sobreposição corretamente
        String sql = "SELECT DISTINCT q.id_quarto, q.numero_quarto, q.piso, q.estado, " +
                "tq.id_tipo_quarto, tq.nome_tipo, tq.preco_diaria, tq.descricao " +
                "FROM quarto q " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.estado != 'MANUTENCAO' " +
                "AND q.id_quarto NOT IN (" +
                "    SELECT DISTINCT r.id_quarto FROM reserva r " +
                "    WHERE r.estado_reserva NOT IN ('CANCELADA', 'FINALIZADA') " +
                "    AND r.data_entrada < ? " +  // data_saida da nova reserva > data_entrada da reserva existente
                "    AND r.data_saida > ? " +    // data_entrada da nova reserva < data_saida da reserva existente
                ") " +
                "ORDER BY q.numero_quarto";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, sqlDataSaida);
            stmt.setDate(2, sqlDataEntrada);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Quarto q = new Quarto();
                    q.setIdQuarto(rs.getInt("id_quarto"));
                    q.setNumeroQuarto(rs.getString("numero_quarto"));
                    q.setPiso(rs.getInt("piso"));
                    q.setEstado(rs.getString("estado"));
                    q.setIdTipoQuarto(rs.getInt("id_tipo_quarto"));
                    q.setTipoQuarto(rs.getString("nome_tipo"));
                    q.setPrecoDiaria(rs.getDouble("preco_diaria"));
                    q.setDescricaoTipo(rs.getString("descricao"));
                    quartos.add(q);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar quartos disponíveis: " + e.getMessage());
            e.printStackTrace();
        }
        return quartos;
    }

    // LISTAR QUARTOS DISPONÍVEIS PARA EDIÇÃO
    public List<Quarto> listarQuartosDisponiveisParaEdicao(java.util.Date dataEntrada, java.util.Date dataSaida, int idReservaAtual) {
        List<Quarto> quartos = new ArrayList<>();

        java.sql.Date sqlDataEntrada = normalizarData(dataEntrada);
        java.sql.Date sqlDataSaida = normalizarData(dataSaida);

        String sql = "SELECT DISTINCT q.id_quarto, q.numero_quarto, q.piso, q.estado, " +
                "tq.id_tipo_quarto, tq.nome_tipo, tq.preco_diaria, tq.descricao " +
                "FROM quarto q " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.estado != 'MANUTENCAO' " +
                "AND (q.id_quarto NOT IN (" +
                "    SELECT DISTINCT r.id_quarto FROM reserva r " +
                "    WHERE r.estado_reserva NOT IN ('CANCELADA', 'FINALIZADA') " +
                "    AND r.id_reserva != ? " +
                "    AND r.data_entrada < ? " +
                "    AND r.data_saida > ? " +
                ")) " +
                "ORDER BY q.numero_quarto";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idReservaAtual);
            stmt.setDate(2, sqlDataSaida);
            stmt.setDate(3, sqlDataEntrada);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Quarto q = new Quarto();
                    q.setIdQuarto(rs.getInt("id_quarto"));
                    q.setNumeroQuarto(rs.getString("numero_quarto"));
                    q.setPiso(rs.getInt("piso"));
                    q.setEstado(rs.getString("estado"));
                    q.setIdTipoQuarto(rs.getInt("id_tipo_quarto"));
                    q.setTipoQuarto(rs.getString("nome_tipo"));
                    q.setPrecoDiaria(rs.getDouble("preco_diaria"));
                    q.setDescricaoTipo(rs.getString("descricao"));
                    quartos.add(q);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar quartos disponíveis para edição: " + e.getMessage());
            e.printStackTrace();
        }
        return quartos;
    }

    // INSERIR RESERVA
    public boolean inserir(Reserva reserva) {
        // Validar datas antes de inserir
        if (!validarPeriodoEstadia(reserva)) {
            System.err.println("Período de estadia inválido");
            return false;
        }

        String sql = "INSERT INTO reserva (id_cliente, id_quarto, data_entrada, data_saida, numero_hospedes, estado_reserva, observacoes) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            java.sql.Date dataEntrada = normalizarData(reserva.getDataEntrada());
            java.sql.Date dataSaida = normalizarData(reserva.getDataSaida());

            stmt.setInt(1, reserva.getIdCliente());
            stmt.setInt(2, reserva.getIdQuarto());
            stmt.setDate(3, dataEntrada);
            stmt.setDate(4, dataSaida);
            stmt.setInt(5, reserva.getNumeroHospedes());
            stmt.setString(6, reserva.getEstadoReserva());
            stmt.setString(7, reserva.getObservacoes());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    reserva.setIdReserva(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ATUALIZAR RESERVA
    public boolean atualizar(Reserva reserva) {
        // Validar datas antes de atualizar
        if (!validarPeriodoEstadia(reserva)) {
            System.err.println("Período de estadia inválido");
            return false;
        }

        String sql = "UPDATE reserva SET id_cliente = ?, id_quarto = ?, data_entrada = ?, data_saida = ?, " +
                "numero_hospedes = ?, estado_reserva = ?, observacoes = ? WHERE id_reserva = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            java.sql.Date dataEntrada = normalizarData(reserva.getDataEntrada());
            java.sql.Date dataSaida = normalizarData(reserva.getDataSaida());

            stmt.setInt(1, reserva.getIdCliente());
            stmt.setInt(2, reserva.getIdQuarto());
            stmt.setDate(3, dataEntrada);
            stmt.setDate(4, dataSaida);
            stmt.setInt(5, reserva.getNumeroHospedes());
            stmt.setString(6, reserva.getEstadoReserva());
            stmt.setString(7, reserva.getObservacoes());
            stmt.setInt(8, reserva.getIdReserva());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // VALIDAÇÃO COMPLETA DO PERÍODO DE ESTADIA
    private boolean validarPeriodoEstadia(Reserva reserva) {
        if (reserva.getDataEntrada() == null || reserva.getDataSaida() == null) {
            return false;
        }

        // Obter data atual sem hora
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        java.util.Date hojeSemHora = cal.getTime();

        // Normalizar as datas da reserva
        java.util.Date entrada = normalizarData(reserva.getDataEntrada());
        java.util.Date saida = normalizarData(reserva.getDataSaida());

        // 1. Data de entrada não pode ser anterior a hoje
        if (entrada.before(hojeSemHora)) {
            System.err.println("Data de entrada não pode ser anterior a hoje");
            return false;
        }

        // 2. Data de saída deve ser após data de entrada (mínimo 1 dia)
        long diffMilissegundos = saida.getTime() - entrada.getTime();
        long diffDias = diffMilissegundos / (1000 * 60 * 60 * 24);

        if (diffDias < 1) {
            System.err.println("A estadia deve ter no mínimo 1 dia");
            return false;
        }

        // 3. Período máximo de 30 dias
        if (diffDias > 30) {
            System.err.println("Período máximo de estadia é de 30 dias");
            return false;
        }

        return true;
    }

    // VERIFICAR DISPONIBILIDADE DO QUARTO
    public boolean isQuartoDisponivel(int idQuarto, java.util.Date dataEntrada, java.util.Date dataSaida, Integer idReservaExcluir) {
        java.sql.Date sqlDataEntrada = normalizarData(dataEntrada);
        java.sql.Date sqlDataSaida = normalizarData(dataSaida);

        String sql = "SELECT COUNT(*) FROM reserva r " +
                "WHERE r.id_quarto = ? " +
                "AND r.estado_reserva NOT IN ('CANCELADA', 'FINALIZADA') " +
                "AND r.data_entrada < ? " +
                "AND r.data_saida > ? ";

        if (idReservaExcluir != null && idReservaExcluir > 0) {
            sql += "AND r.id_reserva != ?";
        }

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idQuarto);
            stmt.setDate(2, sqlDataSaida);
            stmt.setDate(3, sqlDataEntrada);

            if (idReservaExcluir != null && idReservaExcluir > 0) {
                stmt.setInt(4, idReservaExcluir);
            }

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // BUSCAR RESERVA POR ID
    public Reserva buscarPorId(int idReserva) {
        String sql = "SELECT r.*, c.nome_completo as cliente_nome, q.numero_quarto, tq.nome_tipo as tipo_quarto, tq.preco_diaria " +
                "FROM reserva r " +
                "INNER JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "INNER JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.id_reserva = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idReserva);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Reserva r = new Reserva();
                    r.setIdReserva(rs.getInt("id_reserva"));
                    r.setIdCliente(rs.getInt("id_cliente"));
                    r.setNomeCliente(rs.getString("cliente_nome"));
                    r.setIdQuarto(rs.getInt("id_quarto"));
                    r.setNumeroQuarto(rs.getString("numero_quarto"));
                    r.setTipoQuarto(rs.getString("tipo_quarto"));
                    r.setPrecoDiaria(rs.getDouble("preco_diaria"));
                    r.setDataReserva(rs.getTimestamp("data_reserva"));
                    r.setDataEntrada(rs.getDate("data_entrada"));
                    r.setDataSaida(rs.getDate("data_saida"));
                    r.setNumeroHospedes(rs.getInt("numero_hospedes"));
                    r.setEstadoReserva(rs.getString("estado_reserva"));
                    r.setObservacoes(rs.getString("observacoes"));
                    return r;
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar reserva por ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public int contarPorStatus(String status) {
        String sql = "SELECT COUNT(*) FROM reserva WHERE estado_reserva = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    // LISTAR ÚLTIMAS RESERVAS (para dashboard)
    public List<Reserva> listarUltimas(int limite) {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT r.*, c.nome_completo as cliente_nome, q.numero_quarto, tq.nome_tipo as tipo_quarto, tq.preco_diaria " +
                "FROM reserva r " +
                "INNER JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "INNER JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "ORDER BY r.data_reserva DESC LIMIT ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, limite);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Reserva r = new Reserva();
                    r.setIdReserva(rs.getInt("id_reserva"));
                    r.setIdCliente(rs.getInt("id_cliente"));
                    r.setNomeCliente(rs.getString("cliente_nome"));
                    r.setIdQuarto(rs.getInt("id_quarto"));
                    r.setNumeroQuarto(rs.getString("numero_quarto"));
                    r.setTipoQuarto(rs.getString("tipo_quarto"));
                    r.setPrecoDiaria(rs.getDouble("preco_diaria"));
                    r.setDataReserva(rs.getTimestamp("data_reserva"));
                    r.setDataEntrada(rs.getDate("data_entrada"));
                    r.setDataSaida(rs.getDate("data_saida"));
                    r.setNumeroHospedes(rs.getInt("numero_hospedes"));
                    r.setEstadoReserva(rs.getString("estado_reserva"));
                    r.setObservacoes(rs.getString("observacoes"));
                    reservas.add(r);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar últimas reservas: " + e.getMessage());
            e.printStackTrace();
        }
        return reservas;
    }
    public int contarTotal() {
        String sql = "SELECT COUNT(*) FROM reserva";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}