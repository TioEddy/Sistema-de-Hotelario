// src/main/java/com/hotel/dao/NacionalidadeDAO.java
package com.hotel.dao;

import com.hotel.model.Nacionalidade;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NacionalidadeDAO {

    private Connection getConnection() throws SQLException {
        return ConexaoDB.getConexao();
    }

    public List<Nacionalidade> listarTodos() {
        List<Nacionalidade> nacionalidades = new ArrayList<>();
        String sql = "SELECT * FROM nacionalidade ORDER BY pais";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Nacionalidade n = new Nacionalidade();
                n.setIdNacionalidade(rs.getInt("id_nacionalidade"));
                n.setPais(rs.getString("pais"));
                nacionalidades.add(n);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar nacionalidades: " + e.getMessage());
            e.printStackTrace();
        }
        return nacionalidades;
    }

    public Nacionalidade buscarPorId(int id) {
        String sql = "SELECT * FROM nacionalidade WHERE id_nacionalidade = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Nacionalidade n = new Nacionalidade();
                n.setIdNacionalidade(rs.getInt("id_nacionalidade"));
                n.setPais(rs.getString("pais"));
                return n;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}