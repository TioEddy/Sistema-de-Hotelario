// src/main/java/com/hotel/dao/TipoDocumentoDAO.java
package com.hotel.dao;

import com.hotel.model.TipoDocumento;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoDocumentoDAO {

    private Connection getConnection() throws SQLException {
        return ConexaoDB.getConexao();
    }

    public List<TipoDocumento> listarTodos() {
        List<TipoDocumento> tipos = new ArrayList<>();
        String sql = "SELECT * FROM tipo_documento ORDER BY descricao";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                TipoDocumento t = new TipoDocumento();
                t.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                t.setDescricao(rs.getString("descricao"));
                tipos.add(t);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar tipos documento: " + e.getMessage());
            e.printStackTrace();
        }
        return tipos;
    }

    public TipoDocumento buscarPorId(int id) {
        String sql = "SELECT * FROM tipo_documento WHERE id_tipo_documento = ?";
        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                TipoDocumento t = new TipoDocumento();
                t.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                t.setDescricao(rs.getString("descricao"));
                return t;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}