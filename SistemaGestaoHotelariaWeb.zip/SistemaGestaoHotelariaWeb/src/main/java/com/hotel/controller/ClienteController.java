// src/main/java/com/hotel/controller/ClienteController.java
package com.hotel.controller;

import com.hotel.dao.ClienteDAO;
import com.hotel.dao.NacionalidadeDAO;
import com.hotel.dao.TipoDocumentoDAO;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Cliente;
import com.hotel.model.Nacionalidade;
import com.hotel.model.TipoDocumento;
import com.hotel.model.Usuario;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/clientes",
        "/Admin/clientes/listar",
        "/Admin/clientes/salvar",
        "/Admin/clientes/editar",
        "/Admin/clientes/excluir",
        "/Admin/nacionalidades/listar",
        "/Admin/tipos-documento/listar"
})
public class ClienteController extends HttpServlet {

    private ClienteDAO clienteDAO;
    private NacionalidadeDAO nacionalidadeDAO;
    private TipoDocumentoDAO tipoDocumentoDAO;
    private LogSistemaDAO logDAO;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat sdfDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    public void init() {
        clienteDAO = new ClienteDAO();
        nacionalidadeDAO = new NacionalidadeDAO();
        tipoDocumentoDAO = new TipoDocumentoDAO();
        logDAO = new LogSistemaDAO();
        System.out.println("✅ ClienteController iniciado com sucesso!");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        System.out.println("📥 GET request: " + path);

        if ("/Admin/clientes".equals(path)) {
            request.getRequestDispatcher("/Admin/cliente.jsp").forward(request, response);

        } else if ("/Admin/clientes/listar".equals(path)) {
            listarClientes(response);

        } else if ("/Admin/clientes/editar".equals(path)) {
            editarCliente(request, response);

        } else if ("/Admin/nacionalidades/listar".equals(path)) {
            listarNacionalidades(response);

        } else if ("/Admin/tipos-documento/listar".equals(path)) {
            listarTiposDocumento(response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        System.out.println("📤 POST request: " + path);

        if ("/Admin/clientes/salvar".equals(path)) {
            salvarCliente(request, response);

        } else if ("/Admin/clientes/excluir".equals(path)) {
            excluirCliente(request, response);
        }
    }

    // LISTAR CLIENTES
    private void listarClientes(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            System.out.println("=== LISTANDO CLIENTES ===");
            List<Cliente> clientes = clienteDAO.listarTodos();
            System.out.println("Clientes encontrados: " + clientes.size());

            StringBuilder json = new StringBuilder();
            json.append("{\"clientes\":[");

            for (int i = 0; i < clientes.size(); i++) {
                Cliente c = clientes.get(i);
                if (i > 0) json.append(",");

                json.append("{");
                json.append("\"idCliente\":").append(c.getIdCliente()).append(",");
                json.append("\"nomeCompleto\":\"").append(escapeJson(c.getNomeCompleto())).append("\",");
                json.append("\"sexo\":\"").append(escapeJson(c.getSexo())).append("\",");
                json.append("\"dataNascimento\":\"").append(c.getDataNascimento() != null ? sdf.format(c.getDataNascimento()) : "").append("\",");
                json.append("\"telefone\":\"").append(escapeJson(c.getTelefone())).append("\",");
                json.append("\"email\":\"").append(escapeJson(c.getEmail())).append("\",");
                json.append("\"endereco\":\"").append(escapeJson(c.getEndereco())).append("\",");
                json.append("\"idNacionalidade\":").append(c.getIdNacionalidade()).append(",");
                json.append("\"pais\":\"").append(escapeJson(c.getPais())).append("\",");
                json.append("\"idTipoDocumento\":").append(c.getIdTipoDocumento()).append(",");
                json.append("\"tipoDocumento\":\"").append(escapeJson(c.getTipoDocumento())).append("\",");
                json.append("\"numeroDocumento\":\"").append(escapeJson(c.getNumeroDocumento())).append("\",");
                json.append("\"dataRegistro\":\"").append(c.getDataRegistro() != null ? sdfDateTime.format(c.getDataRegistro()) : "").append("\"");
                json.append("}");
            }

            json.append("],\"total\":").append(clientes.size()).append("}");
            System.out.println("JSON gerado com sucesso!");
            out.print(json.toString());

        } catch (Exception e) {
            System.err.println("❌ ERRO ao listar clientes: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"clientes\":[], \"total\":0, \"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // LISTAR NACIONALIDADES
    private void listarNacionalidades(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            List<Nacionalidade> nacionalidades = nacionalidadeDAO.listarTodos();
            System.out.println("Nacionalidades encontradas: " + nacionalidades.size());

            StringBuilder json = new StringBuilder();
            json.append("{\"nacionalidades\":[");

            for (int i = 0; i < nacionalidades.size(); i++) {
                Nacionalidade n = nacionalidades.get(i);
                if (i > 0) json.append(",");
                json.append("{");
                json.append("\"idNacionalidade\":").append(n.getIdNacionalidade()).append(",");
                json.append("\"pais\":\"").append(escapeJson(n.getPais())).append("\"");
                json.append("}");
            }
            json.append("]}");
            out.print(json.toString());

        } catch (Exception e) {
            System.err.println("❌ ERRO ao listar nacionalidades: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"nacionalidades\":[]}");
        }
        out.flush();
    }

    // LISTAR TIPOS DE DOCUMENTO
    private void listarTiposDocumento(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            List<TipoDocumento> tipos = tipoDocumentoDAO.listarTodos();
            System.out.println("Tipos de documento encontrados: " + tipos.size());

            StringBuilder json = new StringBuilder();
            json.append("{\"tiposDocumento\":[");

            for (int i = 0; i < tipos.size(); i++) {
                TipoDocumento t = tipos.get(i);
                if (i > 0) json.append(",");
                json.append("{");
                json.append("\"idTipoDocumento\":").append(t.getIdTipoDocumento()).append(",");
                json.append("\"descricao\":\"").append(escapeJson(t.getDescricao())).append("\"");
                json.append("}");
            }
            json.append("]}");
            out.print(json.toString());

        } catch (Exception e) {
            System.err.println("❌ ERRO ao listar tipos documento: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"tiposDocumento\":[]}");
        }
        out.flush();
    }

    // EDITAR CLIENTE
    private void editarCliente(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"error\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            Cliente cliente = clienteDAO.buscarPorId(id);

            if (cliente != null) {
                StringBuilder json = new StringBuilder();
                json.append("{");
                json.append("\"idCliente\":").append(cliente.getIdCliente()).append(",");
                json.append("\"nomeCompleto\":\"").append(escapeJson(cliente.getNomeCompleto())).append("\",");
                json.append("\"sexo\":\"").append(escapeJson(cliente.getSexo())).append("\",");
                json.append("\"dataNascimento\":\"").append(cliente.getDataNascimento() != null ? sdf.format(cliente.getDataNascimento()) : "").append("\",");
                json.append("\"telefone\":\"").append(escapeJson(cliente.getTelefone())).append("\",");
                json.append("\"email\":\"").append(escapeJson(cliente.getEmail())).append("\",");
                json.append("\"endereco\":\"").append(escapeJson(cliente.getEndereco())).append("\",");
                json.append("\"idNacionalidade\":").append(cliente.getIdNacionalidade()).append(",");
                json.append("\"pais\":\"").append(escapeJson(cliente.getPais())).append("\",");
                json.append("\"idTipoDocumento\":").append(cliente.getIdTipoDocumento()).append(",");
                json.append("\"tipoDocumento\":\"").append(escapeJson(cliente.getTipoDocumento())).append("\",");
                json.append("\"numeroDocumento\":\"").append(escapeJson(cliente.getNumeroDocumento())).append("\",");
                json.append("\"dataRegistro\":\"").append(cliente.getDataRegistro() != null ? sdfDateTime.format(cliente.getDataRegistro()) : "").append("\"");
                json.append("}");
                out.print(json.toString());
            } else {
                out.print("{\"error\": \"Cliente não encontrado\"}");
            }
        } catch (Exception e) {
            System.err.println("❌ ERRO ao editar cliente: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"error\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // SALVAR CLIENTE
    private void salvarCliente(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            String nomeCompleto = request.getParameter("nomeCompleto");
            String sexo = request.getParameter("sexo");
            String dataNascimentoStr = request.getParameter("dataNascimento");
            String telefone = request.getParameter("telefone");
            String email = request.getParameter("email");
            String endereco = request.getParameter("endereco");
            String idNacionalidadeStr = request.getParameter("idNacionalidade");
            String idTipoDocumentoStr = request.getParameter("idTipoDocumento");
            String numeroDocumento = request.getParameter("numeroDocumento");

            System.out.println("📝 Parâmetros recebidos para CLIENTE:");
            System.out.println("   id: " + idStr);
            System.out.println("   nomeCompleto: " + nomeCompleto);
            System.out.println("   sexo: " + sexo);
            System.out.println("   telefone: " + telefone);
            System.out.println("   email: " + email);

            if (nomeCompleto == null || nomeCompleto.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Nome completo é obrigatório\"}");
                out.flush();
                return;
            }

            int id = (idStr != null && !idStr.trim().isEmpty()) ? Integer.parseInt(idStr.trim()) : 0;
            Integer idNacionalidade = (idNacionalidadeStr != null && !idNacionalidadeStr.trim().isEmpty()) ? Integer.parseInt(idNacionalidadeStr.trim()) : null;
            Integer idTipoDocumento = (idTipoDocumentoStr != null && !idTipoDocumentoStr.trim().isEmpty()) ? Integer.parseInt(idTipoDocumentoStr.trim()) : null;

            Cliente cliente = new Cliente();
            cliente.setIdCliente(id);
            cliente.setNomeCompleto(nomeCompleto.trim());
            cliente.setSexo(sexo);
            if (dataNascimentoStr != null && !dataNascimentoStr.trim().isEmpty()) {
                cliente.setDataNascimento(new SimpleDateFormat("yyyy-MM-dd").parse(dataNascimentoStr));
            }
            cliente.setTelefone(telefone);
            cliente.setEmail(email);
            cliente.setEndereco(endereco);
            cliente.setIdNacionalidade(idNacionalidade);
            cliente.setIdTipoDocumento(idTipoDocumento);
            cliente.setNumeroDocumento(numeroDocumento);

            boolean success;
            String acao;

            if (id == 0) {
                success = clienteDAO.inserir(cliente);
                acao = "CREATE";
                System.out.println("Inserindo novo cliente: " + success);
            } else {
                success = clienteDAO.atualizar(cliente);
                acao = "UPDATE";
                System.out.println("Atualizando cliente ID " + id + ": " + success);
            }

            if (success && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        acao,
                        "cliente",
                        cliente.getIdCliente(),
                        "Cliente " + (id == 0 ? "criado" : "atualizado") + ": " + nomeCompleto,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + ", \"id\": " + cliente.getIdCliente() + "}");

        } catch (NumberFormatException e) {
            System.err.println("❌ ERRO de formato: " + e.getMessage());
            out.print("{\"success\": false, \"message\": \"Formato de número inválido\"}");
        } catch (Exception e) {
            System.err.println("❌ ERRO ao salvar cliente: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // EXCLUIR CLIENTE
    private void excluirCliente(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            Cliente cliente = clienteDAO.buscarPorId(id);
            boolean success = clienteDAO.excluir(id);

            if (success && cliente != null && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        "DELETE",
                        "cliente",
                        id,
                        "Cliente excluído: " + cliente.getNomeCompleto(),
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            System.err.println("❌ ERRO ao excluir cliente: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}