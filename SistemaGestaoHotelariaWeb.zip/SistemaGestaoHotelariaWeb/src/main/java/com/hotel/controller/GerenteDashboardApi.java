package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

@WebServlet(urlPatterns = {
        "/Gerente/api/dashboard",
        "/Gerente/api/checkins/hoje",
        "/Gerente/api/quartos"
})
public class GerenteDashboardApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/dashboard":
                getDashboardData(response);
                break;
            case "/Gerente/api/checkins/hoje":
                getCheckinsHoje(response);
                break;
            case "/Gerente/api/quartos":
                getQuartos(response);
                break;
        }
    }

    private void getDashboardData(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        String hoje = sdfData.format(new Date());

        try (Connection conn = ConexaoDB.getConexao()) {
            // Taxa de ocupação
            String sqlOcupacao = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN estado IN ('OCUPADO', 'RESERVADO') THEN 1 ELSE 0 END) as ocupados " +
                    "FROM quarto";
            try (PreparedStatement stmt = conn.prepareStatement(sqlOcupacao);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int total = rs.getInt("total");
                    int ocupados = rs.getInt("ocupados");
                    double taxa = total > 0 ? (ocupados * 100.0 / total) : 0;
                    result.addProperty("taxa_ocupacao", Math.round(taxa));
                    result.addProperty("ocupacao_variacao", "+5% vs ontem");
                }
            }

            // Check-ins hoje
            String sqlCheckins = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN ci.id_checkin IS NOT NULL THEN 1 ELSE 0 END) as realizados " +
                    "FROM reserva r " +
                    "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "WHERE r.data_entrada = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckins)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        result.addProperty("checkins_hoje", rs.getInt("total"));
                        result.addProperty("checkins_realizados", rs.getInt("realizados"));
                    }
                }
            }

            // Check-outs hoje
            String sqlCheckouts = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN co.id_checkout IS NOT NULL THEN 1 ELSE 0 END) as realizados " +
                    "FROM reserva r " +
                    "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE r.data_saida = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckouts)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        result.addProperty("checkouts_hoje", rs.getInt("total"));
                        result.addProperty("checkouts_aguardando", rs.getInt("total") - rs.getInt("realizados"));
                    }
                }
            }

            // Consumo total
            String sqlConsumo = "SELECT COALESCE(SUM(cs.subtotal), 0) as total FROM consumo_servico cs";
            try (PreparedStatement stmt = conn.prepareStatement(sqlConsumo);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("consumo_total", rs.getDouble("total"));
                    result.addProperty("consumo_variacao", "+12% vs mês anterior");
                }
            }

            // Reservas por estado
            JsonObject reservasEstado = new JsonObject();
            String sqlReservasEstado = "SELECT estado_reserva, COUNT(*) as total FROM reserva GROUP BY estado_reserva";
            try (PreparedStatement stmt = conn.prepareStatement(sqlReservasEstado);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    reservasEstado.addProperty(rs.getString("estado_reserva"), rs.getInt("total"));
                }
            }
            result.add("reservas_estado", reservasEstado);

            // Top serviços
            JsonArray topServicos = new JsonArray();
            String sqlTopServicos = "SELECT s.nome_servico, COUNT(cs.id_consumo) as quantidade " +
                    "FROM consumo_servico cs " +
                    "JOIN servico s ON cs.id_servico = s.id_servico " +
                    "GROUP BY s.id_servico, s.nome_servico " +
                    "ORDER BY quantidade DESC LIMIT 4";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTopServicos);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("nome", rs.getString("nome_servico"));
                    item.addProperty("quantidade", rs.getInt("quantidade"));
                    topServicos.add(item);
                }
            }
            result.add("top_servicos", topServicos);

            // Pagamentos do dia
            JsonObject pagamentosDia = new JsonObject();
            String sqlPagamentos = "SELECT mp.nome_metodo, COALESCE(SUM(p.valor), 0) as total " +
                    "FROM metodo_pagamento mp " +
                    "LEFT JOIN pagamento p ON mp.id_metodo_pagamento = p.id_metodo_pagamento " +
                    "AND DATE(p.data_pagamento) = CURDATE() AND p.estado_pagamento = 'PAGO' " +
                    "GROUP BY mp.id_metodo_pagamento, mp.nome_metodo";
            double totalPagamentos = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlPagamentos);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String metodo = rs.getString("nome_metodo");
                    double valor = rs.getDouble("total");
                    totalPagamentos += valor;
                    if ("Dinheiro".equals(metodo)) pagamentosDia.addProperty("dinheiro", valor);
                    else if ("POS".equals(metodo)) pagamentosDia.addProperty("pos", valor);
                    else if ("M-Pesa".equals(metodo)) pagamentosDia.addProperty("mpesa", valor);
                    else if ("Transferência Bancária".equals(metodo)) pagamentosDia.addProperty("transferencia", valor);
                }
            }
            pagamentosDia.addProperty("total", totalPagamentos);
            result.add("pagamentos_dia", pagamentosDia);

            // Funcionários
            JsonObject funcionarios = new JsonObject();
            String sqlFuncionarios = "SELECT cargo, COUNT(*) as total FROM funcionario GROUP BY cargo";
            int totalFunc = 0, recepcionistas = 0, housekeeping = 0, manutencao = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlFuncionarios);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String cargo = rs.getString("cargo");
                    int total = rs.getInt("total");
                    totalFunc += total;
                    if (cargo != null && cargo.contains("Recepcionista")) recepcionistas += total;
                    if (cargo != null && (cargo.contains("Housekeeping") || cargo.contains("Governante"))) housekeeping += total;
                    if (cargo != null && cargo.contains("Manutenção")) manutencao += total;
                }
            }
            funcionarios.addProperty("total", totalFunc);
            funcionarios.addProperty("recepcionistas", recepcionistas);
            funcionarios.addProperty("housekeeping", housekeeping);
            funcionarios.addProperty("manutencao", manutencao);
            result.add("funcionarios", funcionarios);

            // Faturação mensal
            JsonArray faturamentoMensal = new JsonArray();
            String sqlFaturamento = "SELECT DATE_FORMAT(data_emissao, '%b') as mes, " +
                    "COALESCE(SUM(total), 0) as total " +
                    "FROM fatura " +
                    "WHERE data_emissao >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
                    "GROUP BY YEAR(data_emissao), MONTH(data_emissao) " +
                    "ORDER BY data_emissao ASC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturamento);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("mes", rs.getString("mes"));
                    item.addProperty("total", rs.getDouble("total"));
                    faturamentoMensal.add(item);
                }
            }
            result.add("faturamento_mensal", faturamentoMensal);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getCheckinsHoje(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray checkins = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "DATE_FORMAT(r.data_entrada, '%H:%i') as hora_checkin, " +
                "r.numero_hospedes, r.observacoes, " +
                "CASE WHEN ci.id_checkin IS NOT NULL THEN 'REALIZADO' ELSE 'PENDENTE' END as status " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                "WHERE r.data_entrada = ? " +
                "ORDER BY r.data_entrada ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    item.addProperty("quarto_num", rs.getString("quarto_num"));
                    item.addProperty("hora_checkin", rs.getString("hora_checkin"));
                    item.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    item.addProperty("observacoes", rs.getString("observacoes"));
                    item.addProperty("status", rs.getString("status"));
                    checkins.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(checkins));
        out.flush();
    }

    private void getQuartos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray quartos = new JsonArray();

        String sql = "SELECT q.numero_quarto, q.piso, q.estado, " +
                "tq.nome_tipo as tipo, " +
                "c.nome_completo as hospede_atual " +
                "FROM quarto q " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN reserva r ON q.id_quarto = r.id_quarto " +
                "AND r.estado_reserva IN ('CONFIRMADA', 'CHECK-IN') " +
                "AND CURDATE() BETWEEN r.data_entrada AND r.data_saida " +
                "LEFT JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "ORDER BY q.numero_quarto ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject quarto = new JsonObject();
                quarto.addProperty("numero_quarto", rs.getString("numero_quarto"));
                quarto.addProperty("piso", rs.getInt("piso"));
                quarto.addProperty("estado", rs.getString("estado"));
                quarto.addProperty("tipo", rs.getString("tipo"));
                quarto.addProperty("hospede_atual", rs.getString("hospede_atual") != null ? rs.getString("hospede_atual") : "-");
                quartos.add(quarto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(quartos));
        out.flush();
    }
}