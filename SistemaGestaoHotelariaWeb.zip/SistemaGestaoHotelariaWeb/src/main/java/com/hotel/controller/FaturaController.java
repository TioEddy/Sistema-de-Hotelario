// src/main/java/com/hotel/controller/FaturaController.java
package com.hotel.controller;

import com.hotel.dao.*;
import com.hotel.model.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/faturas",
        "/Admin/faturas/listar",
        "/Admin/faturas/emitir",
        "/Admin/faturas/reservas",
        "/Admin/faturas/stats",
        "/Admin/faturas/pdf",
        "/Admin/faturas/imprimir"
})
public class FaturaController extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private SimpleDateFormat sdfDataFront = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    // ==================== LISTAR FATURAS ====================
    private void listarFaturas(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT f.id_fatura, f.numero_fatura, f.id_reserva, " +
                "f.subtotal, f.iva, f.total, f.data_emissao, " +
                "c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo " +
                "FROM fatura f " +
                "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "ORDER BY f.data_emissao DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_fatura", rs.getInt("id_fatura"));
                obj.addProperty("numero_fatura", rs.getString("numero_fatura"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("subtotal", rs.getDouble("subtotal"));
                obj.addProperty("iva", rs.getDouble("iva"));
                obj.addProperty("total", rs.getDouble("total"));

                Timestamp dataEmissao = rs.getTimestamp("data_emissao");
                obj.addProperty("data_emissao_timestamp", dataEmissao != null ? dataEmissao.getTime() : 0);
                obj.addProperty("data_emissao", dataEmissao != null ? sdfDataFront.format(dataEmissao) : "");

                obj.addProperty("cliente_nome", rs.getString("cliente_nome") != null ? rs.getString("cliente_nome") : "");
                obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + (rs.getString("quarto_tipo") != null ? rs.getString("quarto_tipo") : ""));
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            System.err.println("Erro ao listar faturas: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== LISTAR RESERVAS PARA FATURA ====================
    private void listarReservasParaFatura(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "tq.preco_diaria, " +
                "GREATEST(DATEDIFF(r.data_saida, r.data_entrada), 1) as dias, " +
                "r.data_entrada, r.data_saida, r.estado_reserva " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva IN ('CONFIRMADA', 'FINALIZADA') " +
                "AND NOT EXISTS (SELECT 1 FROM fatura WHERE fatura.id_reserva = r.id_reserva) " +
                "ORDER BY r.id_reserva DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome") != null ? rs.getString("cliente_nome") : "");
                obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + (rs.getString("quarto_tipo") != null ? rs.getString("quarto_tipo") : ""));
                obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));

                int dias = rs.getInt("dias");
                obj.addProperty("dias", dias);

                double valorTotal = rs.getDouble("preco_diaria") * dias;
                obj.addProperty("valor_total", valorTotal);
                obj.addProperty("periodo", formatarDataBR(rs.getString("data_entrada")) + " a " + formatarDataBR(rs.getString("data_saida")));
                obj.addProperty("estado_reserva", rs.getString("estado_reserva") != null ? rs.getString("estado_reserva") : "");
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            System.err.println("Erro ao listar reservas: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== OBTER ESTATÍSTICAS ====================
    private void getStats(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total de faturas
            String sqlTotal = "SELECT COUNT(*) FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total", rs.next() ? rs.getInt(1) : 0);
            }

            // Faturamento total
            String sqlFaturamento = "SELECT COALESCE(SUM(total), 0) FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturamento);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faturamento_total", rs.next() ? rs.getDouble(1) : 0);
            }

            // Faturas este mês
            String sqlMes = "SELECT COUNT(*) FROM fatura WHERE MONTH(data_emissao) = MONTH(CURDATE()) AND YEAR(data_emissao) = YEAR(CURDATE())";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMes);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faturas_mes", rs.next() ? rs.getInt(1) : 0);
            }

            // Ticket médio
            String sqlTicket = "SELECT COALESCE(AVG(total), 0) FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTicket);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("ticket_medio", rs.next() ? rs.getDouble(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total", 0);
            stats.addProperty("faturamento_total", 0);
            stats.addProperty("faturas_mes", 0);
            stats.addProperty("ticket_medio", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    // ==================== EXPORTAR FATURA EM PDF ====================
    private void exportarFaturaPDF(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String idFaturaStr = request.getParameter("id");

        if (idFaturaStr == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID da fatura não informado");
            return;
        }

        int idFatura = Integer.parseInt(idFaturaStr);

        // Buscar dados da fatura
        String sql = "SELECT f.id_fatura, f.numero_fatura, f.id_reserva, " +
                "f.subtotal, f.iva, f.total, f.data_emissao, " +
                "c.nome_completo as cliente_nome, c.email as cliente_email, c.telefone, " +
                "r.data_entrada, r.data_saida, r.numero_hospedes, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, tq.preco_diaria " +
                "FROM fatura f " +
                "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE f.id_fatura = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idFatura);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    response.setContentType("application/pdf");
                    response.setHeader("Content-Disposition", "attachment; filename=fatura_" + rs.getString("numero_fatura") + ".pdf");

                    Document document = new Document(PageSize.A4);
                    PdfWriter.getInstance(document, response.getOutputStream());
                    document.open();

                    // Cabeçalho
                    addHeader(document);

                    // Título
                    Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
                    Paragraph title = new Paragraph("FATURA DE SERVIÇOS", titleFont);
                    title.setAlignment(Element.ALIGN_CENTER);
                    document.add(title);
                    document.add(new Paragraph(" "));

                    // Informações da fatura
                    Font infoFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
                    PdfPTable infoTable = new PdfPTable(2);
                    infoTable.setWidthPercentage(100);
                    infoTable.setWidths(new float[]{30f, 70f});

                    addInfoRow(infoTable, "Nº Fatura:", rs.getString("numero_fatura"));
                    addInfoRow(infoTable, "Data Emissão:", sdfDataFront.format(rs.getTimestamp("data_emissao")));
                    addInfoRow(infoTable, "Cliente:", rs.getString("cliente_nome"));
                    addInfoRow(infoTable, "Email:", rs.getString("cliente_email"));
                    addInfoRow(infoTable, "Telefone:", rs.getString("telefone"));
                    addInfoRow(infoTable, "Quarto:", rs.getString("numero_quarto") + " - " + rs.getString("quarto_tipo"));
                    addInfoRow(infoTable, "Período:", formatarDataBR(rs.getString("data_entrada")) + " a " + formatarDataBR(rs.getString("data_saida")));
                    addInfoRow(infoTable, "Hóspedes:", String.valueOf(rs.getInt("numero_hospedes")));

                    document.add(infoTable);
                    document.add(new Paragraph(" "));

                    // Tabela de valores
                    PdfPTable valuesTable = new PdfPTable(2);
                    valuesTable.setWidthPercentage(60);
                    valuesTable.setWidths(new float[]{50f, 50f});
                    valuesTable.setHorizontalAlignment(Element.ALIGN_RIGHT);

                    addValueRow(valuesTable, "Subtotal:", rs.getDouble("subtotal"));
                    addValueRow(valuesTable, "IVA (16%):", rs.getDouble("iva"));
                    addValueRowTotal(valuesTable, "TOTAL:", rs.getDouble("total"));

                    document.add(valuesTable);
                    document.add(new Paragraph(" "));

                    // Rodapé
                    addFooter(document);

                    document.close();

                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Fatura não encontrada");
                }
            }
        } catch (SQLException | DocumentException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Erro ao gerar PDF");
        }
    }

    private void addInfoRow(PdfPTable table, String label, String value) {
        Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
        Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 10);

        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setPadding(5);

        PdfPCell valueCell = new PdfPCell(new Phrase(value != null ? value : "-", valueFont));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setPadding(5);

        table.addCell(labelCell);
        table.addCell(valueCell);
    }

    private void addValueRow(PdfPTable table, String label, double value) {
        Font labelFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
        Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 10);

        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setPadding(5);
        labelCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

        PdfPCell valueCell = new PdfPCell(new Phrase(String.format("%,.2f MZN", value), valueFont));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setPadding(5);
        valueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

        table.addCell(labelCell);
        table.addCell(valueCell);
    }

    private void addValueRowTotal(PdfPTable table, String label, double value) {
        Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        Font valueFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);

        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setPadding(8);
        labelCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        labelCell.setBackgroundColor(new BaseColor(255, 184, 0));

        PdfPCell valueCell = new PdfPCell(new Phrase(String.format("%,.2f MZN", value), valueFont));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setPadding(8);
        valueCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        valueCell.setBackgroundColor(new BaseColor(255, 184, 0));

        table.addCell(labelCell);
        table.addCell(valueCell);
    }

    private void addHeader(Document document) throws DocumentException {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
        Font subFont = FontFactory.getFont(FontFactory.HELVETICA, 12);

        Paragraph hotel = new Paragraph("Sistema Hotelaria", titleFont);
        hotel.setAlignment(Element.ALIGN_CENTER);
        document.add(hotel);

        Paragraph slogan = new Paragraph("Gestão de Faturas e Serviços Hoteleiros", subFont);
        slogan.setAlignment(Element.ALIGN_CENTER);
        document.add(slogan);

        document.add(new Paragraph(" "));

        Paragraph linha = new Paragraph("__________________________________________________________________________________________________");
        linha.setAlignment(Element.ALIGN_CENTER);
        document.add(linha);
        document.add(new Paragraph(" "));
    }

    private void addFooter(Document document) throws DocumentException {
        Font footerFont = FontFactory.getFont(FontFactory.HELVETICA, 8);

        Paragraph linha = new Paragraph("__________________________________________________________________________________________________");
        linha.setAlignment(Element.ALIGN_CENTER);
        document.add(linha);
        document.add(new Paragraph(" "));

        Paragraph footer = new Paragraph("Documento emitido eletronicamente - Sistema Hotelaria", footerFont);
        footer.setAlignment(Element.ALIGN_CENTER);
        document.add(footer);
    }

    // ==================== EMITIR FATURA ====================
    private void emitirFatura(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            if (usuarioLogado == null) {
                result.addProperty("success", false);
                result.addProperty("message", "Usuário não autenticado");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            String idReservaStr = request.getParameter("id_reserva");
            String subtotalStr = request.getParameter("subtotal");
            String ivaStr = request.getParameter("iva");
            String totalStr = request.getParameter("total");

            if (idReservaStr == null || subtotalStr == null || ivaStr == null || totalStr == null) {
                result.addProperty("success", false);
                result.addProperty("message", "Parâmetros incompletos");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            int idReserva = Integer.parseInt(idReservaStr);
            double subtotal = Double.parseDouble(subtotalStr);
            double iva = Double.parseDouble(ivaStr);
            double total = Double.parseDouble(totalStr);

            // Verificar se reserva já possui fatura
            String sqlCheck = "SELECT COUNT(*) FROM fatura WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmtCheck = conn.prepareStatement(sqlCheck)) {
                stmtCheck.setInt(1, idReserva);
                try (ResultSet rs = stmtCheck.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        result.addProperty("success", false);
                        result.addProperty("message", "Esta reserva já possui uma fatura emitida");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            // Gerar número da fatura
            String ano = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
            String sqlSequencial = "SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(numero_fatura, '-', -1) AS UNSIGNED)), 0) + 1 FROM fatura WHERE numero_fatura LIKE ?";
            int sequencial = 1;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlSequencial)) {
                stmt.setString(1, "FT-" + ano + "-%");
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        sequencial = rs.getInt(1);
                    }
                }
            }
            String numeroFatura = "FT-" + ano + "-" + String.format("%04d", sequencial);

            String sql = "INSERT INTO fatura (numero_fatura, id_reserva, subtotal, iva, total, data_emissao) " +
                    "VALUES (?, ?, ?, ?, ?, NOW())";

            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, numeroFatura);
                stmt.setInt(2, idReserva);
                stmt.setDouble(3, subtotal);
                stmt.setDouble(4, iva);
                stmt.setDouble(5, total);
                success = stmt.executeUpdate() > 0;
            }

            result.addProperty("success", success);
            if (success) {
                result.addProperty("numero_fatura", numeroFatura);
                result.addProperty("message", "Fatura emitida com sucesso");
            } else {
                result.addProperty("message", "Erro ao inserir fatura no banco de dados");
            }
            out.print(gson.toJson(result));

        } catch (NumberFormatException e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", "Erro no formato dos valores numéricos: " + e.getMessage());
            out.print(gson.toJson(result));
        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", "Erro ao emitir fatura: " + e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    private String formatarDataBR(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return "";
        String[] parts = dateStr.split("-");
        if (parts.length == 3) {
            return parts[2] + "/" + parts[1] + "/" + parts[0];
        }
        return dateStr;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/faturas".equals(path)) {
            request.getRequestDispatcher("/Admin/fatura.jsp").forward(request, response);

        } else if ("/Admin/faturas/listar".equals(path)) {
            listarFaturas(response);

        } else if ("/Admin/faturas/reservas".equals(path)) {
            listarReservasParaFatura(response);

        } else if ("/Admin/faturas/stats".equals(path)) {
            getStats(response);

        } else if ("/Admin/faturas/pdf".equals(path)) {
            exportarFaturaPDF(request, response);

        } else if ("/Admin/faturas/imprimir".equals(path)) {
            exportarFaturaPDF(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/faturas/emitir".equals(path)) {
            emitirFatura(request, response);
        }
    }
}