package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/hospede/estatisticas",
        "/Recepcionista/api/hospede/lista",
        "/Recepcionista/api/hospede/reservas",
        "/Recepcionista/api/hospede/checkouts",
        "/Recepcionista/api/hospede/detalhes",
        "/Recepcionista/api/hospede/movimento"
})
public class RecepcionistaHospedeApi extends HttpServlet {

    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/hospede/estatisticas":
                getEstatisticas(response);
                break;
            case "/Recepcionista/api/hospede/lista":
                getHospedes(response);
                break;
            case "/Recepcionista/api/hospede/reservas":
                getReservasPendentes(response);
                break;
            case "/Recepcionista/api/hospede/checkouts":
                getCheckoutsHoje(response);
                break;
            case "/Recepcionista/api/hospede/detalhes":
                getDetalhesHospede(request, response);
                break;
            case "/Recepcionista/api/hospede/movimento":
                getMovimentoMensal(response);
                break;
        }
    }

    private void getEstatisticas(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Hóspedes no hotel
            String sqlHospedados = "SELECT COUNT(*) as total FROM checkin ci LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin WHERE co.id_checkout IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedados);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("hospedados", rs.getInt("total"));
                else result.addProperty("hospedados", 0);
            }

            // Check-outs hoje
            String hoje = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
            String sqlCheckouts = "SELECT COUNT(*) as total FROM reserva WHERE DATE(data_saida) = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckouts)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("checkouts_hoje", rs.getInt("total"));
                    else result.addProperty("checkouts_hoje", 0);
                }
            }

            // Reservas hoje (check-ins pendentes)
            String sqlReservas = "SELECT COUNT(*) as total FROM reserva WHERE DATE(data_entrada) = ? AND estado_reserva = 'CONFIRMADA'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlReservas)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("reservas_hoje", rs.getInt("total"));
                    else result.addProperty("reservas_hoje", 0);
                }
            }

            // Hóspedes VIP (com consumo > 5000) - Corrigido: usando id_reserva em vez de id_checkin
            String sqlVip = "SELECT COUNT(DISTINCT ci.id_checkin) as total FROM checkin ci " +
                    "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                    "JOIN consumo_servico cs ON r.id_reserva = cs.id_reserva " +
                    "GROUP BY ci.id_checkin HAVING SUM(cs.subtotal) > 5000";
            try (PreparedStatement stmt = conn.prepareStatement(sqlVip);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("vip", rs.getInt("total"));
                else result.addProperty("vip", 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getHospedes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray hospedes = new JsonArray();

        // Corrigido: usando cs.id_reserva em vez de cs.id_checkin
        String sql = "SELECT ci.id_checkin, c.nome_completo, COALESCE(c.telefone, 'N/A') as telefone, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(ci.data_checkin, '%d/%m/%Y %H:%i') as data_checkin, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "COALESCE((SELECT SUM(cs2.subtotal) FROM consumo_servico cs2 WHERE cs2.id_reserva = r.id_reserva), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                "WHERE co.id_checkout IS NULL " +
                "GROUP BY ci.id_checkin, c.nome_completo, c.telefone, q.numero_quarto, " +
                "tq.nome_tipo, ci.data_checkin, r.data_saida " +
                "ORDER BY ci.data_checkin DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject hospede = new JsonObject();
                hospede.addProperty("id_checkin", rs.getInt("id_checkin"));
                hospede.addProperty("nome", rs.getString("nome_completo"));
                hospede.addProperty("telefone", rs.getString("telefone"));
                hospede.addProperty("quarto_num", rs.getString("numero_quarto"));
                hospede.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                hospede.addProperty("data_checkin", rs.getString("data_checkin"));
                hospede.addProperty("data_saida", rs.getString("data_saida"));
                hospede.addProperty("consumo_total", rs.getDouble("consumo_total"));
                hospedes.add(hospede);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(hospedes));
        out.flush();
    }

    private void getReservasPendentes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray reservas = new JsonArray();
        String hoje = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());

        String sql = "SELECT r.id_reserva, c.nome_completo, c.telefone, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_entrada, '%d/%m/%Y') as data_entrada, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "r.numero_hospedes, COALESCE(r.observacoes, '') as observacoes " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                "WHERE DATE(r.data_entrada) = ? AND ci.id_checkin IS NULL AND r.estado_reserva = 'CONFIRMADA' " +
                "ORDER BY r.data_entrada ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("id_reserva", rs.getInt("id_reserva"));
                    item.addProperty("cliente_nome", rs.getString("nome_completo"));
                    item.addProperty("telefone", rs.getString("telefone"));
                    item.addProperty("quarto_num", rs.getString("numero_quarto"));
                    item.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    item.addProperty("data_entrada", rs.getString("data_entrada"));
                    item.addProperty("data_saida", rs.getString("data_saida"));
                    item.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    item.addProperty("observacoes", rs.getString("observacoes"));
                    reservas.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(reservas));
        out.flush();
    }

    private void getCheckoutsHoje(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray checkouts = new JsonArray();
        String hoje = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());

        String sql = "SELECT ci.id_checkin, c.nome_completo, c.telefone, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "DATEDIFF(r.data_saida, r.data_entrada) as diarias, " +
                "COALESCE((SELECT SUM(cs2.subtotal) FROM consumo_servico cs2 WHERE cs2.id_reserva = r.id_reserva), 0) as consumo_total, " +
                "COALESCE(tq.preco_diaria, 2500) as preco_diaria " +
                "FROM reserva r " +
                "JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                "WHERE DATE(r.data_saida) = ? AND co.id_checkout IS NULL " +
                "GROUP BY ci.id_checkin, c.nome_completo, c.telefone, q.numero_quarto, tq.nome_tipo, " +
                "r.data_saida, r.data_entrada, tq.preco_diaria " +
                "ORDER BY c.nome_completo ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("id_checkin", rs.getInt("id_checkin"));
                    item.addProperty("nome", rs.getString("nome_completo"));
                    item.addProperty("telefone", rs.getString("telefone"));
                    item.addProperty("quarto_num", rs.getString("numero_quarto"));
                    item.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    item.addProperty("data_saida", rs.getString("data_saida"));
                    item.addProperty("diarias", rs.getInt("diarias"));
                    item.addProperty("consumo_total", rs.getDouble("consumo_total"));
                    item.addProperty("preco_diaria", rs.getDouble("preco_diaria"));

                    double totalQuarto = rs.getInt("diarias") * rs.getDouble("preco_diaria");
                    item.addProperty("total", totalQuarto + rs.getDouble("consumo_total"));
                    checkouts.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(checkouts));
        out.flush();
    }

    private void getDetalhesHospede(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idCheckin = request.getParameter("id");
        JsonObject result = new JsonObject();

        String sql = "SELECT ci.id_checkin, c.nome_completo, q.numero_quarto, " +
                "DATE_FORMAT(ci.data_checkin, '%d/%m/%Y %H:%i') as data_checkin, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "ci.quantidade_hospedes, ci.observacoes, " +
                "COALESCE((SELECT SUM(cs2.subtotal) FROM consumo_servico cs2 WHERE cs2.id_reserva = r.id_reserva), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "WHERE ci.id_checkin = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idCheckin));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_checkin", rs.getInt("id_checkin"));
                    result.addProperty("nome", rs.getString("nome_completo"));
                    result.addProperty("quarto_num", rs.getString("numero_quarto"));
                    result.addProperty("data_checkin", rs.getString("data_checkin"));
                    result.addProperty("data_saida", rs.getString("data_saida"));
                    result.addProperty("quantidade_hospedes", rs.getInt("quantidade_hospedes"));
                    result.addProperty("consumo_total", rs.getDouble("consumo_total"));
                    result.addProperty("observacoes", rs.getString("observacoes"));
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getMovimentoMensal(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        JsonArray entradas = new JsonArray();
        JsonArray saidas = new JsonArray();

        String sqlEntradas = "SELECT MONTH(data_entrada) as mes, COUNT(*) as total FROM reserva " +
                "WHERE YEAR(data_entrada) = YEAR(CURDATE()) " +
                "GROUP BY MONTH(data_entrada) ORDER BY mes";

        String sqlSaidas = "SELECT MONTH(data_saida) as mes, COUNT(*) as total FROM reserva " +
                "WHERE YEAR(data_saida) = YEAR(CURDATE()) " +
                "GROUP BY MONTH(data_saida) ORDER BY mes";

        try (Connection conn = ConexaoDB.getConexao()) {
            // Inicializar arrays com zeros
            for (int i = 0; i < 12; i++) {
                entradas.add(0);
                saidas.add(0);
            }

            try (PreparedStatement stmt = conn.prepareStatement(sqlEntradas);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int mes = rs.getInt("mes") - 1;
                    int total = rs.getInt("total");
                    entradas.set(mes, new com.google.gson.JsonPrimitive(total));
                }
            }

            try (PreparedStatement stmt = conn.prepareStatement(sqlSaidas);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int mes = rs.getInt("mes") - 1;
                    int total = rs.getInt("total");
                    saidas.set(mes, new com.google.gson.JsonPrimitive(total));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        result.add("entradas", entradas);
        result.add("saidas", saidas);
        out.print(gson.toJson(result));
        out.flush();
    }
}