// src/main/java/com/hotel/controller/QRCodeController.java
package com.hotel.controller;

import com.hotel.dao.*;
import com.hotel.model.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/qr",
        "/Admin/qr/listar",
        "/Admin/qr/gerar",
        "/Admin/qr/reservas",
        "/Admin/qr/stats"
})
public class QRCodeController extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    private SimpleDateFormat sdfDataSQL = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    // ==================== LISTAR QR CODES ====================
    private void listarQRCodes(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT q.id_qrcode, q.id_reserva, q.codigo, q.data_geracao, q.estado, " +
                "c.nome_completo as hospede_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "DATE(r.data_entrada) as data_entrada, DATE(r.data_saida) as data_saida, " +
                "r.estado_reserva " +
                "FROM qr_code q " +
                "JOIN reserva r ON q.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "LEFT JOIN quarto qu ON r.id_quarto = qu.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON qu.id_tipo_quarto = tq.id_tipo_quarto " +
                "ORDER BY q.data_geracao DESC";

        System.out.println("=== LISTANDO QR CODES ===");

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_qrcode", rs.getInt("id_qrcode"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("codigo", rs.getString("codigo"));
                obj.addProperty("data_geracao", rs.getTimestamp("data_geracao") != null ? sdfData.format(rs.getTimestamp("data_geracao")) : "");
                obj.addProperty("estado", rs.getString("estado"));
                obj.addProperty("hospede_nome", rs.getString("hospede_nome"));
                obj.addProperty("quarto_num", (rs.getString("numero_quarto") != null ? rs.getString("numero_quarto") : "N/A") + " - " + (rs.getString("quarto_tipo") != null ? rs.getString("quarto_tipo") : "N/D"));
                obj.addProperty("data_entrada", rs.getString("data_entrada") != null ? formatarDataBR(rs.getString("data_entrada")) : "");
                obj.addProperty("data_saida", rs.getString("data_saida") != null ? formatarDataBR(rs.getString("data_saida")) : "");
                obj.addProperty("estado_reserva", rs.getString("estado_reserva"));
                jsonArray.add(obj);
            }

            System.out.println("QR Codes encontrados: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            System.err.println("Erro ao listar QR Codes: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== LISTAR RESERVAS PARA GERAR QR CODE (TODAS) ====================
    private void listarReservasParaQR(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        // Agora busca TODAS as reservas que NÃO têm QR Code, independente do status
        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "DATE(r.data_entrada) as data_entrada, DATE(r.data_saida) as data_saida, " +
                "r.estado_reserva, r.numero_hospedes " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE NOT EXISTS (SELECT 1 FROM qr_code WHERE qr_code.id_reserva = r.id_reserva) " +
                "ORDER BY r.id_reserva DESC";

        System.out.println("=== LISTANDO RESERVAS PARA QR CODE ===");

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + rs.getString("quarto_tipo"));
                obj.addProperty("periodo", formatarDataBR(rs.getString("data_entrada")) + " a " + formatarDataBR(rs.getString("data_saida")));
                obj.addProperty("estado_reserva", rs.getString("estado_reserva"));
                obj.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                jsonArray.add(obj);
            }

            System.out.println("Reservas encontradas: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            System.err.println("Erro ao listar reservas: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== OBTER ESTATÍSTICAS ====================
    private void getStats(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total QR Codes
            String sqlTotal = "SELECT COUNT(*) FROM qr_code";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total", rs.next() ? rs.getInt(1) : 0);
            }

            // QR Codes ATIVOS
            String sqlAtivos = "SELECT COUNT(*) FROM qr_code WHERE estado = 'ATIVO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlAtivos);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("ativos", rs.next() ? rs.getInt(1) : 0);
            }

            // QR Codes USADOS
            String sqlUsados = "SELECT COUNT(*) FROM qr_code WHERE estado = 'USADO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlUsados);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("usados", rs.next() ? rs.getInt(1) : 0);
            }

            // QR Codes EXPIRADOS
            String sqlExpirados = "SELECT COUNT(*) FROM qr_code WHERE estado = 'EXPIRADO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlExpirados);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("expirados", rs.next() ? rs.getInt(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total", 0);
            stats.addProperty("ativos", 0);
            stats.addProperty("usados", 0);
            stats.addProperty("expirados", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    // ==================== GERAR QR CODE ====================
    private void gerarQRCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));

            // Buscar informações completas da reserva
            String sqlInfo = "SELECT c.nome_completo, c.email, c.telefone, " +
                    "q.numero_quarto, tq.nome_tipo, tq.preco_diaria, " +
                    "r.data_entrada, r.data_saida, r.numero_hospedes, r.observacoes " +
                    "FROM reserva r " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                    "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                    "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                    "WHERE r.id_reserva = ?";

            StringBuilder informacoes = new StringBuilder();
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlInfo)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        informacoes.append("=== INFORMAÇÕES DA RESERVA ===\n");
                        informacoes.append("Reserva #: ").append(idReserva).append("\n");
                        informacoes.append("Hóspede: ").append(rs.getString("nome_completo")).append("\n");
                        informacoes.append("Email: ").append(rs.getString("email")).append("\n");
                        informacoes.append("Telefone: ").append(rs.getString("telefone")).append("\n");
                        informacoes.append("Quarto: ").append(rs.getString("numero_quarto")).append(" - ").append(rs.getString("nome_tipo")).append("\n");
                        informacoes.append("Diária: ").append(rs.getDouble("preco_diaria")).append(" MZN\n");
                        informacoes.append("Check-in: ").append(formatarDataBR(rs.getString("data_entrada"))).append("\n");
                        informacoes.append("Check-out: ").append(formatarDataBR(rs.getString("data_saida"))).append("\n");
                        informacoes.append("Hóspedes: ").append(rs.getInt("numero_hospedes")).append("\n");
                        informacoes.append("Observações: ").append(rs.getString("observacoes") != null ? rs.getString("observacoes") : "Nenhuma");
                    }
                }
            }

            String codigo = informacoes.toString();
            String numeroQuarto = "";

            // Buscar número do quarto para salvar
            String sqlBusca = "SELECT q.numero_quarto FROM reserva r JOIN quarto q ON r.id_quarto = q.id_quarto WHERE r.id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlBusca)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        numeroQuarto = rs.getString("numero_quarto");
                    }
                }
            }

            String sqlInsert = "INSERT INTO qr_code (id_reserva, codigo, data_geracao, estado, numero_quarto) VALUES (?, ?, NOW(), 'ATIVO', ?)";

            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, idReserva);
                stmt.setString(2, codigo);
                stmt.setString(3, numeroQuarto);
                success = stmt.executeUpdate() > 0;
            }

            JsonObject result = new JsonObject();
            result.addProperty("success", success);
            if (success) {
                result.addProperty("codigo", codigo);
            }
            out.print(gson.toJson(result));

        } catch (Exception e) {
            e.printStackTrace();
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    private String formatarDataBR(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return "";
        String[] parts = dateStr.split("-");
        if (parts.length == 3) {
            return parts[2] + "/" + parts[1] + "/" + parts[0];
        }
        return dateStr;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/qr".equals(path)) {
            request.getRequestDispatcher("/Admin/qr.jsp").forward(request, response);

        } else if ("/Admin/qr/listar".equals(path)) {
            listarQRCodes(response);

        } else if ("/Admin/qr/reservas".equals(path)) {
            listarReservasParaQR(response);

        } else if ("/Admin/qr/stats".equals(path)) {
            getStats(response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/qr/gerar".equals(path)) {
            gerarQRCode(request, response);
        }
    }
}