// src/main/java/com/hotel/controller/RecepcionistaConsumoApi.java
package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/consumo/listar",
        "/Recepcionista/api/consumo/detalhes",
        "/Recepcionista/api/consumo/criar",
        "/Recepcionista/api/consumo/atualizar",
        "/Recepcionista/api/consumo/estatisticas",
        "/Recepcionista/api/servico/listar"
        // REMOVIDOS: "/Recepcionista/api/hospede/lista", "/Recepcionista/api/hospede/ativos"
        // Estes endpoints já existem no RecepcionistaHospedeApi
})
public class RecepcionistaConsumoApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfDataHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/consumo/listar":
                listarConsumos(response);
                break;
            case "/Recepcionista/api/consumo/detalhes":
                detalhesConsumo(request, response);
                break;
            case "/Recepcionista/api/consumo/estatisticas":
                getEstatisticas(response);
                break;
            case "/Recepcionista/api/servico/listar":
                listarServicos(response);
                break;
            // CASOS REMOVIDOS (já existem no RecepcionistaHospedeApi)
            // case "/Recepcionista/api/hospede/lista":
            //     listarHospedesParaSelect(response);
            //     break;
            // case "/Recepcionista/api/hospede/ativos":
            //     listarHospedesAtivos(response);
            //     break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/consumo/criar":
                criarConsumo(request, response);
                break;
            case "/Recepcionista/api/consumo/atualizar":
                atualizarConsumo(request, response);
                break;
        }
    }

    // ==================== LISTAR CONSUMOS ====================
    private void listarConsumos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray consumos = new JsonArray();

        String sql = "SELECT cs.id_consumo, cs.id_reserva, cs.id_servico, cs.quantidade, cs.subtotal, cs.data_consumo, " +
                "c.nome_completo as hospede_nome, q.numero_quarto, s.nome_servico, s.preco as preco_unitario " +
                "FROM consumo_servico cs " +
                "JOIN reserva r ON cs.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN servico s ON cs.id_servico = s.id_servico " +
                "ORDER BY cs.data_consumo DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject consumo = new JsonObject();
                consumo.addProperty("id_consumo", rs.getInt("id_consumo"));
                consumo.addProperty("id_reserva", rs.getInt("id_reserva"));
                consumo.addProperty("id_servico", rs.getInt("id_servico"));
                consumo.addProperty("quantidade", rs.getInt("quantidade"));
                consumo.addProperty("subtotal", rs.getDouble("subtotal"));
                consumo.addProperty("data_consumo", rs.getString("data_consumo"));
                consumo.addProperty("hospede_nome", rs.getString("hospede_nome"));
                consumo.addProperty("quarto_num", rs.getString("numero_quarto"));
                consumo.addProperty("servico_nome", rs.getString("nome_servico"));
                consumo.addProperty("preco_unitario", rs.getDouble("preco_unitario"));
                consumos.add(consumo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(consumos));
        out.flush();
    }

    // ==================== DETALHES DO CONSUMO ====================
    private void detalhesConsumo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idConsumo = request.getParameter("id");
        JsonObject result = new JsonObject();

        String sql = "SELECT cs.id_consumo, cs.id_reserva, cs.id_servico, cs.quantidade, cs.subtotal, cs.data_consumo, " +
                "c.nome_completo as hospede_nome, q.numero_quarto, s.nome_servico, s.preco as preco_unitario " +
                "FROM consumo_servico cs " +
                "JOIN reserva r ON cs.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN servico s ON cs.id_servico = s.id_servico " +
                "WHERE cs.id_consumo = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idConsumo));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_consumo", rs.getInt("id_consumo"));
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("id_servico", rs.getInt("id_servico"));
                    result.addProperty("quantidade", rs.getInt("quantidade"));
                    result.addProperty("subtotal", rs.getDouble("subtotal"));
                    result.addProperty("data_consumo", rs.getString("data_consumo"));
                    result.addProperty("hospede_nome", rs.getString("hospede_nome"));
                    result.addProperty("quarto_num", rs.getString("numero_quarto"));
                    result.addProperty("servico_nome", rs.getString("nome_servico"));
                    result.addProperty("preco_unitario", rs.getDouble("preco_unitario"));
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== ESTATÍSTICAS ====================
    private void getEstatisticas(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total de consumos
            String sqlTotal = "SELECT COUNT(*) as total FROM consumo_servico";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("total_consumos", rs.getInt("total"));
                else result.addProperty("total_consumos", 0);
            }

            // Total faturado
            String sqlFaturado = "SELECT COALESCE(SUM(subtotal), 0) as total FROM consumo_servico";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturado);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("total_faturado", rs.getDouble("total"));
                else result.addProperty("total_faturado", 0);
            }

            // Hóspedes ativos
            String sqlHospedes = "SELECT COUNT(DISTINCT r.id_cliente) as total " +
                    "FROM consumo_servico cs " +
                    "JOIN reserva r ON cs.id_reserva = r.id_reserva " +
                    "JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE co.id_checkout IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedes);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("hospedes_ativos", rs.getInt("total"));
                else result.addProperty("hospedes_ativos", 0);
            }

            // Serviço mais consumido
            String sqlTopServico = "SELECT s.nome_servico, SUM(cs.quantidade) as total " +
                    "FROM consumo_servico cs " +
                    "JOIN servico s ON cs.id_servico = s.id_servico " +
                    "GROUP BY s.id_servico, s.nome_servico " +
                    "ORDER BY total DESC LIMIT 1";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTopServico);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("top_servico_nome", rs.getString("nome_servico"));
                    result.addProperty("top_servico_total", rs.getInt("total"));
                } else {
                    result.addProperty("top_servico_nome", "Nenhum");
                    result.addProperty("top_servico_total", 0);
                }
            }

            result.addProperty("success", true);

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== LISTAR SERVIÇOS ====================
    private void listarServicos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray servicos = new JsonArray();

        String sql = "SELECT id_servico, nome_servico, descricao, preco FROM servico ORDER BY nome_servico";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject servico = new JsonObject();
                servico.addProperty("id_servico", rs.getInt("id_servico"));
                servico.addProperty("nome_servico", rs.getString("nome_servico"));
                servico.addProperty("descricao", rs.getString("descricao") != null ? rs.getString("descricao") : "");
                servico.addProperty("preco", rs.getDouble("preco"));
                servicos.add(servico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(servicos));
        out.flush();
    }

    // ==================== CRIAR CONSUMO ====================
    private void criarConsumo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            int idServico = Integer.parseInt(request.getParameter("id_servico"));
            int quantidade = Integer.parseInt(request.getParameter("quantidade"));

            // Buscar preço do serviço
            double preco = 0;
            String sqlPreco = "SELECT preco FROM servico WHERE id_servico = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlPreco)) {
                stmt.setInt(1, idServico);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        preco = rs.getDouble("preco");
                    }
                }
            }

            double subtotal = preco * quantidade;
            String dataConsumo = sdfDataHora.format(new Date());

            String sql = "INSERT INTO consumo_servico (id_reserva, id_servico, quantidade, subtotal, data_consumo) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, idReserva);
                stmt.setInt(2, idServico);
                stmt.setInt(3, quantidade);
                stmt.setDouble(4, subtotal);
                stmt.setString(5, dataConsumo);
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    result.addProperty("id_consumo", rs.getInt(1));
                }
            }

            result.addProperty("success", true);
            result.addProperty("message", "Consumo registrado com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== ATUALIZAR CONSUMO ====================
    private void atualizarConsumo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idConsumo = Integer.parseInt(request.getParameter("id_consumo"));
            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            int idServico = Integer.parseInt(request.getParameter("id_servico"));
            int quantidade = Integer.parseInt(request.getParameter("quantidade"));

            // Buscar preço do serviço
            double preco = 0;
            String sqlPreco = "SELECT preco FROM servico WHERE id_servico = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlPreco)) {
                stmt.setInt(1, idServico);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        preco = rs.getDouble("preco");
                    }
                }
            }

            double subtotal = preco * quantidade;

            String sql = "UPDATE consumo_servico SET id_reserva = ?, id_servico = ?, quantidade = ?, subtotal = ? WHERE id_consumo = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idReserva);
                stmt.setInt(2, idServico);
                stmt.setInt(3, quantidade);
                stmt.setDouble(4, subtotal);
                stmt.setInt(5, idConsumo);
                stmt.executeUpdate();
            }

            result.addProperty("success", true);
            result.addProperty("message", "Consumo atualizado com sucesso!");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}