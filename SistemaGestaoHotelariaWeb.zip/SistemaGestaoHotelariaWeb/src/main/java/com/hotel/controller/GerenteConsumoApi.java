package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/consumo/listar",
        "/Gerente/api/consumo/stats",
        "/Gerente/api/consumo/graficos",
        "/Gerente/api/consumo/hospedes",
        "/Gerente/api/consumo/servicos",
        "/Gerente/api/consumo/detalhes",
        "/Gerente/api/consumo/salvar"
})
public class GerenteConsumoApi extends HttpServlet {

    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/consumo/listar":
                listarConsumos(request, response);
                break;
            case "/Gerente/api/consumo/stats":
                getStats(response);
                break;
            case "/Gerente/api/consumo/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/consumo/hospedes":
                getHospedesAtivos(response);
                break;
            case "/Gerente/api/consumo/servicos":
                getServicos(response);
                break;
            case "/Gerente/api/consumo/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/consumo/salvar".equals(request.getServletPath())) {
            salvarConsumo(request, response);
        }
    }

    private void listarConsumos(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String servico = request.getParameter("servico");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT cs.id_consumo, cs.id_reserva, cs.id_servico, cs.quantidade, ");
            sql.append("cs.subtotal, cs.data_consumo, ");
            sql.append("c.nome_completo as cliente_nome, ");
            sql.append("CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, ");
            sql.append("s.nome_servico as servico_nome, s.preco as preco_unitario ");
            sql.append("FROM consumo_servico cs ");
            sql.append("JOIN reserva r ON cs.id_reserva = r.id_reserva ");
            sql.append("JOIN cliente c ON r.id_cliente = c.id_cliente ");
            sql.append("JOIN quarto q ON r.id_quarto = q.id_quarto ");
            sql.append("JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto ");
            sql.append("JOIN servico s ON cs.id_servico = s.id_servico ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (c.nome_completo LIKE ? OR s.nome_servico LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (servico != null && !servico.isEmpty()) {
                sql.append("AND s.nome_servico = ? ");
                params.add(servico);
            }

            sql.append("ORDER BY cs.data_consumo DESC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM consumo_servico cs " +
                    "JOIN reserva r ON cs.id_reserva = r.id_reserva " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                    "JOIN servico s ON cs.id_servico = s.id_servico WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND (c.nome_completo LIKE '%" + search + "%' OR s.nome_servico LIKE '%" + search + "%')";
            }
            if (servico != null && !servico.isEmpty()) {
                countSql += " AND s.nome_servico = '" + servico + "'";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray consumosArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_consumo", rs.getInt("id_consumo"));
                        obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                        obj.addProperty("id_servico", rs.getInt("id_servico"));
                        obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                        obj.addProperty("quarto_num", rs.getString("quarto_num"));
                        obj.addProperty("servico_nome", rs.getString("servico_nome"));
                        obj.addProperty("quantidade", rs.getInt("quantidade"));
                        obj.addProperty("preco_unitario", rs.getDouble("preco_unitario"));
                        obj.addProperty("subtotal", rs.getDouble("subtotal"));
                        obj.addProperty("data_consumo", rs.getString("data_consumo"));
                        consumosArray.add(obj);
                    }
                }
            }

            result.add("consumos", consumosArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("consumos", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total de consumos
            String sqlTotal = "SELECT COUNT(*) as total FROM consumo_servico";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_consumos", rs.next() ? rs.getInt("total") : 0);
            }

            // Total faturado
            String sqlFaturado = "SELECT COALESCE(SUM(subtotal), 0) as total FROM consumo_servico";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturado);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_faturado", rs.next() ? rs.getDouble("total") : 0);
            }

            // Hóspedes ativos (com consumo)
            String sqlHospedes = "SELECT COUNT(DISTINCT id_reserva) as total FROM consumo_servico";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedes);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("hospedes_ativos", rs.next() ? rs.getInt("total") : 0);
            }

            // Serviço mais consumido
            String sqlTop = "SELECT s.nome_servico, COUNT(cs.id_consumo) as total " +
                    "FROM consumo_servico cs JOIN servico s ON cs.id_servico = s.id_servico " +
                    "GROUP BY s.id_servico, s.nome_servico ORDER BY total DESC LIMIT 1";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTop);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("top_servico", rs.next() ? rs.getString("nome_servico") : "-");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Por serviço
            JsonArray porServico = new JsonArray();
            String sqlServico = "SELECT s.nome_servico, COALESCE(SUM(cs.subtotal), 0) as total " +
                    "FROM servico s LEFT JOIN consumo_servico cs ON s.id_servico = cs.id_servico " +
                    "GROUP BY s.id_servico, s.nome_servico ORDER BY total DESC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlServico);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("nome", rs.getString("nome_servico"));
                    item.addProperty("total", rs.getDouble("total"));
                    porServico.add(item);
                }
            }
            result.add("por_servico", porServico);

            // Por hóspede
            JsonArray porHospede = new JsonArray();
            String sqlHospede = "SELECT c.nome_completo, COALESCE(SUM(cs.subtotal), 0) as total " +
                    "FROM cliente c " +
                    "JOIN reserva r ON c.id_cliente = r.id_cliente " +
                    "LEFT JOIN consumo_servico cs ON r.id_reserva = cs.id_reserva " +
                    "GROUP BY c.id_cliente, c.nome_completo " +
                    "HAVING total > 0 ORDER BY total DESC LIMIT 5";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospede);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("nome", rs.getString("nome_completo"));
                    item.addProperty("total", rs.getDouble("total"));
                    porHospede.add(item);
                }
            }
            result.add("por_hospede", porHospede);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getHospedesAtivos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray hospedes = new JsonArray();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva = 'CHECK-IN' " +
                "ORDER BY c.nome_completo";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto_num", rs.getString("quarto_num"));
                hospedes.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(hospedes));
        out.flush();
    }

    private void getServicos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray servicos = new JsonArray();

        String sql = "SELECT id_servico, nome_servico, preco FROM servico ORDER BY nome_servico";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_servico", rs.getInt("id_servico"));
                obj.addProperty("nome_servico", rs.getString("nome_servico"));
                obj.addProperty("preco", rs.getDouble("preco"));
                servicos.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(servicos));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT cs.id_consumo, cs.id_reserva, cs.id_servico, cs.quantidade, " +
                "cs.subtotal, cs.data_consumo, " +
                "c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "s.nome_servico as servico_nome, s.preco as preco_unitario " +
                "FROM consumo_servico cs " +
                "JOIN reserva r ON cs.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "JOIN servico s ON cs.id_servico = s.id_servico " +
                "WHERE cs.id_consumo = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_consumo", rs.getInt("id_consumo"));
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("id_servico", rs.getInt("id_servico"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("quarto_num", rs.getString("quarto_num"));
                    result.addProperty("servico_nome", rs.getString("servico_nome"));
                    result.addProperty("quantidade", rs.getInt("quantidade"));
                    result.addProperty("preco_unitario", rs.getDouble("preco_unitario"));
                    result.addProperty("subtotal", rs.getDouble("subtotal"));
                    result.addProperty("data_consumo", rs.getString("data_consumo"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void salvarConsumo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            String idConsumo = data.has("id_consumo") && !data.get("id_consumo").isJsonNull() ? data.get("id_consumo").getAsString() : null;
            int idReserva = data.get("id_reserva").getAsInt();
            int idServico = data.get("id_servico").getAsInt();
            int quantidade = data.get("quantidade").getAsInt();
            String dataConsumo = data.has("data_consumo") && !data.get("data_consumo").isJsonNull() ? data.get("data_consumo").getAsString() : null;

            // Buscar preço do serviço
            double preco = 0;
            String sqlPreco = "SELECT preco FROM servico WHERE id_servico = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlPreco)) {
                stmt.setInt(1, idServico);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) preco = rs.getDouble("preco");
                }
            }

            double subtotal = preco * quantidade;

            boolean success = false;

            if (idConsumo != null && !idConsumo.isEmpty()) {
                String sql = "UPDATE consumo_servico SET id_reserva=?, id_servico=?, quantidade=?, subtotal=?, data_consumo=? WHERE id_consumo=?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, idReserva);
                    stmt.setInt(2, idServico);
                    stmt.setInt(3, quantidade);
                    stmt.setDouble(4, subtotal);
                    stmt.setTimestamp(5, dataConsumo != null ? Timestamp.valueOf(dataConsumo.replace('T', ' ')) : new Timestamp(System.currentTimeMillis()));
                    stmt.setInt(6, Integer.parseInt(idConsumo));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO consumo_servico (id_reserva, id_servico, quantidade, subtotal, data_consumo) VALUES (?, ?, ?, ?, ?)";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, idReserva);
                    stmt.setInt(2, idServico);
                    stmt.setInt(3, quantidade);
                    stmt.setDouble(4, subtotal);
                    stmt.setTimestamp(5, dataConsumo != null ? Timestamp.valueOf(dataConsumo.replace('T', ' ')) : new Timestamp(System.currentTimeMillis()));
                    success = stmt.executeUpdate() > 0;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "CONSUMO", "consumo_servico", 0,
                        "Consumo " + (idConsumo != null ? "atualizado" : "registrado") + " no valor de " + subtotal + " MZN",
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Consumo registrado com sucesso!" : "Erro ao registrar consumo");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}