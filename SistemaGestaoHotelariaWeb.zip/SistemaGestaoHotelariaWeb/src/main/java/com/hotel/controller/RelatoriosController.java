// src/main/java/com/hotel/controller/RelatoriosController.java
package com.hotel.controller;

import com.hotel.dao.*;
import com.hotel.model.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/relatorios",
        "/Admin/relatorios/dados",
        "/Admin/relatorios/pdf",
        "/Admin/relatorios/csv",
        "/Admin/relatorios/stats"
})
public class RelatoriosController extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/relatorios".equals(path)) {
            request.getRequestDispatcher("/Admin/relatorios.jsp").forward(request, response);
        } else if ("/Admin/relatorios/dados".equals(path)) {
            getDadosRelatorio(request, response);
        } else if ("/Admin/relatorios/pdf".equals(path)) {
            exportarPDF(request, response);
        } else if ("/Admin/relatorios/csv".equals(path)) {
            exportarCSV(request, response);
        } else if ("/Admin/relatorios/stats".equals(path)) {
            getStats(request, response);
        }
    }

    private void getStats(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        String tipoRelatorio = request.getParameter("tipo");
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");

        try (Connection conn = ConexaoDB.getConexao()) {
            if ("faturas".equals(tipoRelatorio)) {
                String sql = "SELECT COUNT(*) as total, COALESCE(SUM(total), 0) as valor_total FROM fatura";
                if (dataInicio != null && !dataInicio.isEmpty()) {
                    sql += " WHERE DATE(data_emissao) >= '" + dataInicio + "'";
                    if (dataFim != null && !dataFim.isEmpty()) {
                        sql += " AND DATE(data_emissao) <= '" + dataFim + "'";
                    }
                }
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    if (rs.next()) {
                        stats.addProperty("total", rs.getInt("total"));
                        stats.addProperty("valor_total", rs.getDouble("valor_total"));
                    }
                }
            } else if ("reservas".equals(tipoRelatorio)) {
                String sql = "SELECT COUNT(*) as total FROM reserva";
                if (dataInicio != null && !dataInicio.isEmpty()) {
                    sql += " WHERE DATE(data_reserva) >= '" + dataInicio + "'";
                    if (dataFim != null && !dataFim.isEmpty()) {
                        sql += " AND DATE(data_reserva) <= '" + dataFim + "'";
                    }
                }
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    if (rs.next()) stats.addProperty("total", rs.getInt("total"));
                }
            } else if ("ocupacao".equals(tipoRelatorio)) {
                String sql = "SELECT COUNT(*) as ocupados FROM quarto WHERE estado = 'OCUPADO'";
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    if (rs.next()) stats.addProperty("ocupados", rs.getInt("ocupados"));
                }
                String sqlTotal = "SELECT COUNT(*) as total FROM quarto";
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sqlTotal)) {
                    if (rs.next()) stats.addProperty("total_quartos", rs.getInt("total"));
                }
            } else if ("clientes".equals(tipoRelatorio)) {
                String sql = "SELECT COUNT(*) as total FROM cliente";
                if (dataInicio != null && !dataInicio.isEmpty()) {
                    sql += " WHERE DATE(data_registro) >= '" + dataInicio + "'";
                    if (dataFim != null && !dataFim.isEmpty()) {
                        sql += " AND DATE(data_registro) <= '" + dataFim + "'";
                    }
                }
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    if (rs.next()) stats.addProperty("total", rs.getInt("total"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getDadosRelatorio(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String tipoRelatorio = request.getParameter("tipo");
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");
        String statusFiltro = request.getParameter("status");

        JsonArray jsonArray = new JsonArray();

        try (Connection conn = ConexaoDB.getConexao()) {
            if ("faturas".equals(tipoRelatorio)) {
                String sql = "SELECT f.id_fatura, f.numero_fatura, f.subtotal, f.iva, f.total, f.data_emissao, " +
                        "c.nome_completo as cliente_nome, r.id_reserva " +
                        "FROM fatura f " +
                        "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                        "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                        "WHERE 1=1";

                if (dataInicio != null && !dataInicio.isEmpty()) {
                    sql += " AND DATE(f.data_emissao) >= '" + dataInicio + "'";
                }
                if (dataFim != null && !dataFim.isEmpty()) {
                    sql += " AND DATE(f.data_emissao) <= '" + dataFim + "'";
                }
                sql += " ORDER BY f.data_emissao DESC";

                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id", rs.getInt("id_fatura"));
                        obj.addProperty("numero", rs.getString("numero_fatura"));
                        obj.addProperty("cliente", rs.getString("cliente_nome"));
                        obj.addProperty("reserva", rs.getInt("id_reserva"));
                        obj.addProperty("subtotal", rs.getDouble("subtotal"));
                        obj.addProperty("iva", rs.getDouble("iva"));
                        obj.addProperty("total", rs.getDouble("total"));
                        obj.addProperty("data", sdf.format(rs.getTimestamp("data_emissao")));
                        jsonArray.add(obj);
                    }
                }
            } else if ("reservas".equals(tipoRelatorio)) {
                String sql = "SELECT r.id_reserva, r.data_reserva, r.data_entrada, r.data_saida, " +
                        "r.numero_hospedes, r.estado_reserva, " +
                        "c.nome_completo as cliente_nome, " +
                        "q.numero_quarto, tq.nome_tipo as quarto_tipo " +
                        "FROM reserva r " +
                        "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                        "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                        "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                        "WHERE 1=1";

                if (dataInicio != null && !dataInicio.isEmpty()) {
                    sql += " AND DATE(r.data_reserva) >= '" + dataInicio + "'";
                }
                if (dataFim != null && !dataFim.isEmpty()) {
                    sql += " AND DATE(r.data_reserva) <= '" + dataFim + "'";
                }
                if (statusFiltro != null && !statusFiltro.isEmpty() && !"TODOS".equals(statusFiltro)) {
                    sql += " AND r.estado_reserva = '" + statusFiltro + "'";
                }
                sql += " ORDER BY r.data_reserva DESC";

                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id", rs.getInt("id_reserva"));
                        obj.addProperty("cliente", rs.getString("cliente_nome"));
                        obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + rs.getString("quarto_tipo"));
                        obj.addProperty("entrada", formatarDataBR(rs.getString("data_entrada")));
                        obj.addProperty("saida", formatarDataBR(rs.getString("data_saida")));
                        obj.addProperty("hospedes", rs.getInt("numero_hospedes"));
                        obj.addProperty("status", rs.getString("estado_reserva"));
                        obj.addProperty("data_reserva", sdf.format(rs.getTimestamp("data_reserva")));
                        jsonArray.add(obj);
                    }
                }
            } else if ("ocupacao".equals(tipoRelatorio)) {
                String sql = "SELECT q.id_quarto, q.numero_quarto, q.estado, " +
                        "tq.nome_tipo, tq.preco_diaria " +
                        "FROM quarto q " +
                        "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                        "ORDER BY q.numero_quarto";

                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id", rs.getInt("id_quarto"));
                        obj.addProperty("numero", rs.getString("numero_quarto"));
                        obj.addProperty("tipo", rs.getString("nome_tipo"));
                        obj.addProperty("preco", rs.getDouble("preco_diaria"));
                        obj.addProperty("estado", rs.getString("estado"));
                        jsonArray.add(obj);
                    }
                }
            } else if ("clientes".equals(tipoRelatorio)) {
                String sql = "SELECT c.id_cliente, c.nome_completo, c.sexo, c.telefone, c.email, " +
                        "c.data_registro, n.pais as nacionalidade " +
                        "FROM cliente c " +
                        "LEFT JOIN nacionalidade n ON c.id_nacionalidade = n.id_nacionalidade " +
                        "WHERE 1=1";

                if (dataInicio != null && !dataInicio.isEmpty()) {
                    sql += " AND DATE(c.data_registro) >= '" + dataInicio + "'";
                }
                if (dataFim != null && !dataFim.isEmpty()) {
                    sql += " AND DATE(c.data_registro) <= '" + dataFim + "'";
                }
                sql += " ORDER BY c.data_registro DESC";

                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id", rs.getInt("id_cliente"));
                        obj.addProperty("nome", rs.getString("nome_completo"));
                        obj.addProperty("sexo", rs.getString("sexo"));
                        obj.addProperty("telefone", rs.getString("telefone"));
                        obj.addProperty("email", rs.getString("email"));
                        obj.addProperty("nacionalidade", rs.getString("nacionalidade"));
                        obj.addProperty("data_registro", sdf.format(rs.getTimestamp("data_registro")));
                        jsonArray.add(obj);
                    }
                }
            } else if ("financeiro".equals(tipoRelatorio)) {
                String sql = "SELECT " +
                        "COALESCE(SUM(f.total), 0) as faturamento_total, " +
                        "COALESCE(SUM(p.valor), 0) as recebido_total, " +
                        "COALESCE(SUM(f.total) - SUM(p.valor), 0) as pendente_total, " +
                        "COUNT(DISTINCT f.id_fatura) as total_faturas, " +
                        "COUNT(DISTINCT p.id_pagamento) as total_pagamentos " +
                        "FROM fatura f " +
                        "LEFT JOIN pagamento p ON f.id_reserva = p.id_reserva";

                if (dataInicio != null && !dataInicio.isEmpty()) {
                    sql += " WHERE DATE(f.data_emissao) >= '" + dataInicio + "'";
                    if (dataFim != null && !dataFim.isEmpty()) {
                        sql += " AND DATE(f.data_emissao) <= '" + dataFim + "'";
                    }
                }

                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    if (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("faturamento_total", rs.getDouble("faturamento_total"));
                        obj.addProperty("recebido_total", rs.getDouble("recebido_total"));
                        obj.addProperty("pendente_total", rs.getDouble("pendente_total"));
                        obj.addProperty("total_faturas", rs.getInt("total_faturas"));
                        obj.addProperty("total_pagamentos", rs.getInt("total_pagamentos"));
                        jsonArray.add(obj);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(jsonArray));
        out.flush();
    }

    private void exportarPDF(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String tipoRelatorio = request.getParameter("tipo");
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");
        String statusFiltro = request.getParameter("status");

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=relatorio_" + tipoRelatorio + "_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".pdf");

        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            addHeader(document, tipoRelatorio);
            addFiltros(document, dataInicio, dataFim, statusFiltro);

            if ("faturas".equals(tipoRelatorio)) {
                addTabelaFaturas(document, dataInicio, dataFim);
            } else if ("reservas".equals(tipoRelatorio)) {
                addTabelaReservas(document, dataInicio, dataFim, statusFiltro);
            } else if ("ocupacao".equals(tipoRelatorio)) {
                addTabelaOcupacao(document);
            } else if ("clientes".equals(tipoRelatorio)) {
                addTabelaClientes(document, dataInicio, dataFim);
            } else if ("financeiro".equals(tipoRelatorio)) {
                addTabelaFinanceiro(document, dataInicio, dataFim);
            }

            addFooter(document);
            document.close();

        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }

    private void exportarCSV(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String tipoRelatorio = request.getParameter("tipo");
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");
        String statusFiltro = request.getParameter("status");

        response.setContentType("text/csv");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=relatorio_" + tipoRelatorio + "_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".csv");

        PrintWriter out = response.getWriter();

        try (Connection conn = ConexaoDB.getConexao()) {
            if ("faturas".equals(tipoRelatorio)) {
                out.println("ID;Nº FATURA;CLIENTE;RESERVA;SUBTOTAL;IVA;TOTAL;DATA");
                String sql = "SELECT f.id_fatura, f.numero_fatura, f.subtotal, f.iva, f.total, f.data_emissao, " +
                        "c.nome_completo as cliente_nome, r.id_reserva " +
                        "FROM fatura f JOIN reserva r ON f.id_reserva = r.id_reserva " +
                        "JOIN cliente c ON r.id_cliente = c.id_cliente WHERE 1=1";
                if (dataInicio != null && !dataInicio.isEmpty()) sql += " AND DATE(f.data_emissao) >= '" + dataInicio + "'";
                if (dataFim != null && !dataFim.isEmpty()) sql += " AND DATE(f.data_emissao) <= '" + dataFim + "'";
                sql += " ORDER BY f.data_emissao DESC";
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                        out.printf("%d;%s;%s;%d;%.2f;%.2f;%.2f;%s\n",
                                rs.getInt("id_fatura"), rs.getString("numero_fatura"), rs.getString("cliente_nome"),
                                rs.getInt("id_reserva"), rs.getDouble("subtotal"), rs.getDouble("iva"),
                                rs.getDouble("total"), sdf.format(rs.getTimestamp("data_emissao")));
                    }
                }
            } else if ("reservas".equals(tipoRelatorio)) {
                out.println("ID;CLIENTE;QUARTO;ENTRADA;SAÍDA;HÓSPEDES;STATUS;DATA RESERVA");
                String sql = "SELECT r.id_reserva, r.data_reserva, r.data_entrada, r.data_saida, " +
                        "r.numero_hospedes, r.estado_reserva, c.nome_completo as cliente_nome, " +
                        "q.numero_quarto FROM reserva r JOIN cliente c ON r.id_cliente = c.id_cliente " +
                        "JOIN quarto q ON r.id_quarto = q.id_quarto WHERE 1=1";
                if (dataInicio != null && !dataInicio.isEmpty()) sql += " AND DATE(r.data_reserva) >= '" + dataInicio + "'";
                if (dataFim != null && !dataFim.isEmpty()) sql += " AND DATE(r.data_reserva) <= '" + dataFim + "'";
                if (statusFiltro != null && !statusFiltro.isEmpty() && !"TODOS".equals(statusFiltro)) {
                    sql += " AND r.estado_reserva = '" + statusFiltro + "'";
                }
                sql += " ORDER BY r.data_reserva DESC";
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                        out.printf("%d;%s;%s;%s;%s;%d;%s;%s\n",
                                rs.getInt("id_reserva"), rs.getString("cliente_nome"), rs.getString("numero_quarto"),
                                formatarDataBR(rs.getString("data_entrada")), formatarDataBR(rs.getString("data_saida")),
                                rs.getInt("numero_hospedes"), rs.getString("estado_reserva"),
                                sdf.format(rs.getTimestamp("data_reserva")));
                    }
                }
            } else if ("clientes".equals(tipoRelatorio)) {
                out.println("ID;NOME;SEXO;TELEFONE;EMAIL;NACIONALIDADE;DATA REGISTRO");
                String sql = "SELECT c.id_cliente, c.nome_completo, c.sexo, c.telefone, c.email, " +
                        "c.data_registro, n.pais as nacionalidade FROM cliente c " +
                        "LEFT JOIN nacionalidade n ON c.id_nacionalidade = n.id_nacionalidade WHERE 1=1";
                if (dataInicio != null && !dataInicio.isEmpty()) sql += " AND DATE(c.data_registro) >= '" + dataInicio + "'";
                if (dataFim != null && !dataFim.isEmpty()) sql += " AND DATE(c.data_registro) <= '" + dataFim + "'";
                sql += " ORDER BY c.data_registro DESC";
                try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                    while (rs.next()) {
                        out.printf("%d;%s;%s;%s;%s;%s;%s\n",
                                rs.getInt("id_cliente"), rs.getString("nome_completo"),
                                rs.getString("sexo"), rs.getString("telefone"), rs.getString("email"),
                                rs.getString("nacionalidade"), sdf.format(rs.getTimestamp("data_registro")));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        out.flush();
    }

    private void addHeader(Document document, String tipo) throws DocumentException {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
        Font subFont = FontFactory.getFont(FontFactory.HELVETICA, 12);

        Paragraph hotel = new Paragraph("Sistema Hotelaria", titleFont);
        hotel.setAlignment(Element.ALIGN_CENTER);
        document.add(hotel);

        String titulo = "";
        switch (tipo) {
            case "faturas": titulo = "Relatório de Faturas"; break;
            case "reservas": titulo = "Relatório de Reservas"; break;
            case "ocupacao": titulo = "Relatório de Ocupação"; break;
            case "clientes": titulo = "Relatório de Clientes"; break;
            case "financeiro": titulo = "Relatório Financeiro"; break;
            default: titulo = "Relatório do Sistema";
        }
        Paragraph sub = new Paragraph(titulo, subFont);
        sub.setAlignment(Element.ALIGN_CENTER);
        document.add(sub);
        document.add(new Paragraph(" "));
        document.add(new Paragraph("__________________________________________________________________________________________________"));
        document.add(new Paragraph(" "));
    }

    private void addFiltros(Document document, String dataInicio, String dataFim, String status) throws DocumentException {
        Font filterFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
        Paragraph filtros = new Paragraph();
        filtros.add(new Chunk("📅 Período: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
        filtros.add(new Chunk((dataInicio != null && !dataInicio.isEmpty() ? dataInicio : "Todas") + " a " +
                (dataFim != null && !dataFim.isEmpty() ? dataFim : "Hoje"), filterFont));
        if (status != null && !status.isEmpty() && !"TODOS".equals(status)) {
            filtros.add(new Chunk(" | Status: " + status, filterFont));
        }
        filtros.add(new Chunk(" | Gerado em: " + sdf.format(new Date()), filterFont));
        document.add(filtros);
        document.add(new Paragraph(" "));
    }

    private void addFooter(Document document) throws DocumentException {
        document.add(new Paragraph(" "));
        document.add(new Paragraph("__________________________________________________________________________________________________"));
        Font footerFont = FontFactory.getFont(FontFactory.HELVETICA, 8);
        Paragraph footer = new Paragraph("Documento gerado eletronicamente - Sistema Hotelaria", footerFont);
        footer.setAlignment(Element.ALIGN_CENTER);
        document.add(footer);
    }

    private void addTabelaFaturas(Document document, String dataInicio, String dataFim) throws DocumentException {
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{10f, 15f, 20f, 10f, 10f, 10f, 15f});
        addTableHeader(table, "ID", "Nº FATURA", "CLIENTE", "SUBTOTAL", "IVA", "TOTAL", "DATA");

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT f.id_fatura, f.numero_fatura, f.subtotal, f.iva, f.total, f.data_emissao, " +
                    "c.nome_completo as cliente_nome FROM fatura f " +
                    "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente WHERE 1=1";
            if (dataInicio != null && !dataInicio.isEmpty()) sql += " AND DATE(f.data_emissao) >= '" + dataInicio + "'";
            if (dataFim != null && !dataFim.isEmpty()) sql += " AND DATE(f.data_emissao) <= '" + dataFim + "'";
            sql += " ORDER BY f.data_emissao DESC";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    addTableCell(table, String.valueOf(rs.getInt("id_fatura")));
                    addTableCell(table, rs.getString("numero_fatura"));
                    addTableCell(table, rs.getString("cliente_nome"));
                    addTableCell(table, String.format("%,.2f", rs.getDouble("subtotal")));
                    addTableCell(table, String.format("%,.2f", rs.getDouble("iva")));
                    addTableCell(table, String.format("%,.2f", rs.getDouble("total")));
                    addTableCell(table, sdf.format(rs.getTimestamp("data_emissao")));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        document.add(table);
    }

    private void addTabelaReservas(Document document, String dataInicio, String dataFim, String status) throws DocumentException {
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{10f, 20f, 15f, 12f, 12f, 10f, 21f});
        addTableHeader(table, "ID", "CLIENTE", "QUARTO", "ENTRADA", "SAÍDA", "HÓSPEDES", "DATA RESERVA");

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT r.id_reserva, r.data_reserva, r.data_entrada, r.data_saida, " +
                    "r.numero_hospedes, c.nome_completo as cliente_nome, " +
                    "q.numero_quarto FROM reserva r " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                    "JOIN quarto q ON r.id_quarto = q.id_quarto WHERE 1=1";
            if (dataInicio != null && !dataInicio.isEmpty()) sql += " AND DATE(r.data_reserva) >= '" + dataInicio + "'";
            if (dataFim != null && !dataFim.isEmpty()) sql += " AND DATE(r.data_reserva) <= '" + dataFim + "'";
            if (status != null && !status.isEmpty() && !"TODOS".equals(status)) sql += " AND r.estado_reserva = '" + status + "'";
            sql += " ORDER BY r.data_reserva DESC";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    addTableCell(table, String.valueOf(rs.getInt("id_reserva")));
                    addTableCell(table, rs.getString("cliente_nome"));
                    addTableCell(table, rs.getString("numero_quarto"));
                    addTableCell(table, formatarDataBR(rs.getString("data_entrada")));
                    addTableCell(table, formatarDataBR(rs.getString("data_saida")));
                    addTableCell(table, String.valueOf(rs.getInt("numero_hospedes")));
                    addTableCell(table, sdf.format(rs.getTimestamp("data_reserva")));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        document.add(table);
    }

    private void addTabelaOcupacao(Document document) throws DocumentException {
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        addTableHeader(table, "QUARTO", "TIPO", "PREÇO DIÁRIA", "ESTADO");

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT q.numero_quarto, tq.nome_tipo, tq.preco_diaria, q.estado " +
                    "FROM quarto q JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto ORDER BY q.numero_quarto";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    addTableCell(table, rs.getString("numero_quarto"));
                    addTableCell(table, rs.getString("nome_tipo"));
                    addTableCell(table, String.format("%,.2f MZN", rs.getDouble("preco_diaria")));
                    addTableCell(table, rs.getString("estado"));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        document.add(table);
    }

    private void addTabelaClientes(Document document, String dataInicio, String dataFim) throws DocumentException {
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        addTableHeader(table, "ID", "NOME", "TELEFONE", "EMAIL", "NACIONALIDADE", "DATA REGISTRO");

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT c.id_cliente, c.nome_completo, c.telefone, c.email, " +
                    "c.data_registro, n.pais as nacionalidade FROM cliente c " +
                    "LEFT JOIN nacionalidade n ON c.id_nacionalidade = n.id_nacionalidade WHERE 1=1";
            if (dataInicio != null && !dataInicio.isEmpty()) sql += " AND DATE(c.data_registro) >= '" + dataInicio + "'";
            if (dataFim != null && !dataFim.isEmpty()) sql += " AND DATE(c.data_registro) <= '" + dataFim + "'";
            sql += " ORDER BY c.data_registro DESC LIMIT 100";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    addTableCell(table, String.valueOf(rs.getInt("id_cliente")));
                    addTableCell(table, rs.getString("nome_completo"));
                    addTableCell(table, rs.getString("telefone") != null ? rs.getString("telefone") : "-");
                    addTableCell(table, rs.getString("email") != null ? rs.getString("email") : "-");
                    addTableCell(table, rs.getString("nacionalidade") != null ? rs.getString("nacionalidade") : "-");
                    addTableCell(table, sdf.format(rs.getTimestamp("data_registro")));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        document.add(table);
    }

    private void addTabelaFinanceiro(Document document, String dataInicio, String dataFim) throws DocumentException {
        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(60);
        addTableHeader(table, "INDICADOR", "VALOR");

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT " +
                    "COALESCE(SUM(f.total), 0) as faturamento_total, " +
                    "COALESCE(SUM(p.valor), 0) as recebido_total, " +
                    "COALESCE(SUM(f.total) - SUM(p.valor), 0) as pendente_total, " +
                    "COUNT(DISTINCT f.id_fatura) as total_faturas, " +
                    "COUNT(DISTINCT p.id_pagamento) as total_pagamentos " +
                    "FROM fatura f LEFT JOIN pagamento p ON f.id_reserva = p.id_reserva";
            if (dataInicio != null && !dataInicio.isEmpty()) sql += " WHERE DATE(f.data_emissao) >= '" + dataInicio + "'";
            if (dataFim != null && !dataFim.isEmpty()) sql += " AND DATE(f.data_emissao) <= '" + dataFim + "'";
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                if (rs.next()) {
                    addTableCell(table, "Total de Faturas");
                    addTableCell(table, String.valueOf(rs.getInt("total_faturas")));
                    addTableCell(table, "Faturamento Total");
                    addTableCell(table, String.format("%,.2f MZN", rs.getDouble("faturamento_total")));
                    addTableCell(table, "Total Recebido");
                    addTableCell(table, String.format("%,.2f MZN", rs.getDouble("recebido_total")));
                    addTableCell(table, "Valor Pendente");
                    addTableCell(table, String.format("%,.2f MZN", rs.getDouble("pendente_total")));
                    addTableCell(table, "Total de Pagamentos");
                    addTableCell(table, String.valueOf(rs.getInt("total_pagamentos")));
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        document.add(table);
    }

    private void addTableHeader(PdfPTable table, String... headers) {
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8);
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, font));
            cell.setBackgroundColor(new BaseColor(26, 75, 140));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(5);
            table.addCell(cell);
        }
    }

    private void addTableCell(PdfPTable table, String text) {
        Font font = FontFactory.getFont(FontFactory.HELVETICA, 8);
        PdfPCell cell = new PdfPCell(new Phrase(text != null ? text : "-", font));
        cell.setPadding(4);
        table.addCell(cell);
    }

    private String formatarDataBR(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return "";
        String[] parts = dateStr.split("-");
        if (parts.length == 3) return parts[2] + "/" + parts[1] + "/" + parts[0];
        return dateStr;
    }
}