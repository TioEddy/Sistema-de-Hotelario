// src/main/java/com/hotel/controller/LogController.java
package com.hotel.controller;

import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.LogSistema;
import com.hotel.model.Usuario;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.List;

@WebServlet("/admin/logs/*")
public class LogController extends HttpServlet {

    private LogSistemaDAO logDAO;
    private Gson gson;

    @Override
    public void init() {
        logDAO = new LogSistemaDAO();
        gson = new Gson();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || "/".equals(pathInfo)) {
            request.getRequestDispatcher("/admin/logs.jsp").forward(request, response);
        } else if ("/api/listar".equals(pathInfo)) {
            listarLogsJSON(request, response);
        } else if ("/api/filtros".equals(pathInfo)) {
            carregarFiltros(response);
        } else if ("/exportar/pdf".equals(pathInfo)) {
            exportarPDF(request, response);
        } else if ("/exportar/csv".equals(pathInfo)) {
            exportarCSV(request, response);
        } else if ("/exportar/pdf/completo".equals(pathInfo)) {
            exportarPDFCompleto(request, response);
        }
    }

    private void listarLogsJSON(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        int limite = 500;
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");
        String acao = request.getParameter("acao");
        String tabela = request.getParameter("tabela");

        List<LogSistema> logs = logDAO.listarComFiltros(limite, dataInicio, dataFim, acao, tabela);
        JsonArray jsonArray = new JsonArray();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        for (LogSistema log : logs) {
            JsonObject obj = new JsonObject();
            obj.addProperty("id_log", log.getIdLog());
            obj.addProperty("usuario", log.getNomeUsuario());
            obj.addProperty("acao", log.getAcao());
            obj.addProperty("tabela", log.getTabelaAfetada() != null ? log.getTabelaAfetada() : "-");
            obj.addProperty("id_registro", log.getIdRegistro());
            obj.addProperty("descricao", log.getDescricao() != null ? log.getDescricao() : "-");
            obj.addProperty("ip", log.getEnderecoIp() != null ? log.getEnderecoIp() : "-");
            obj.addProperty("data", log.getDataLog() != null ? sdf.format(log.getDataLog()) : "-");
            jsonArray.add(obj);
        }

        out.print(gson.toJson(jsonArray));
        out.flush();
    }

    private void carregarFiltros(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        JsonObject obj = new JsonObject();

        JsonArray acoes = new JsonArray();
        for (String a : logDAO.listarAcoesDistintas()) {
            acoes.add(a);
        }
        obj.add("acoes", acoes);

        JsonArray tabelas = new JsonArray();
        for (String t : logDAO.listarTabelasDistintas()) {
            tabelas.add(t);
        }
        obj.add("tabelas", tabelas);

        out.print(gson.toJson(obj));
        out.flush();
    }

    private void exportarCSV(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");
        String acao = request.getParameter("acao");
        String tabela = request.getParameter("tabela");

        List<LogSistema> logs = logDAO.listarComFiltros(10000, dataInicio, dataFim, acao, tabela);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        response.setContentType("text/csv");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=relatorio_logs_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date()) + ".csv");

        PrintWriter out = response.getWriter();

        // Cabeçalho CSV com informações do sistema
        out.println("# SISTEMA DE GESTÃO DE HOTELARIA - RELATÓRIO DE LOGS");
        out.println("# Universidade Rovuma - Instituto Superior de Transportes, Logística e Telecomunicações");
        out.println("# Gerado em: " + sdf.format(new java.util.Date()));
        out.println("# Filtros: Data Início=" + (dataInicio != null && !dataInicio.isEmpty() ? dataInicio : "Todas") +
                " | Data Fim=" + (dataFim != null && !dataFim.isEmpty() ? dataFim : "Todas") +
                " | Ação=" + (acao != null && !acao.isEmpty() && !"TODOS".equals(acao) ? acao : "Todas") +
                " | Tabela=" + (tabela != null && !tabela.isEmpty() && !"TODAS".equals(tabela) ? tabela : "Todas"));
        out.println("#");
        out.println("ID;USUÁRIO;AÇÃO;TABELA;ID REGISTRO;DESCRIÇÃO;IP;DATA/HORA");

        // Dados
        for (LogSistema log : logs) {
            out.printf("%d;%s;%s;%s;%d;%s;%s;%s\n",
                    log.getIdLog(),
                    escapeCSV(log.getNomeUsuario()),
                    log.getAcao(),
                    escapeCSV(log.getTabelaAfetada() != null ? log.getTabelaAfetada() : "-"),
                    log.getIdRegistro(),
                    escapeCSV(log.getDescricao() != null ? log.getDescricao() : "-"),
                    escapeCSV(log.getEnderecoIp() != null ? log.getEnderecoIp() : "-"),
                    log.getDataLog() != null ? sdf.format(log.getDataLog()) : "-"
            );
        }
        out.flush();
    }

    private void exportarPDF(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");
        String acao = request.getParameter("acao");
        String tabela = request.getParameter("tabela");

        List<LogSistema> logs = logDAO.listarComFiltros(500, dataInicio, dataFim, acao, tabela);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=relatorio_logs_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date()) + ".pdf");

        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            // Cabeçalho com logo do caminho real
            addHeader(document, request);

            // Título
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Paragraph title = new Paragraph("RELATÓRIO DE LOGS DO SISTEMA", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph(" "));

            // Filtros aplicados
            Font filterFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
            Paragraph filtros = new Paragraph();
            filtros.add(new Chunk("Filtros aplicados: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10)));
            filtros.add(new Chunk("Data Início: " + (dataInicio != null && !dataInicio.isEmpty() ? dataInicio : "Todas") + " | ", filterFont));
            filtros.add(new Chunk("Data Fim: " + (dataFim != null && !dataFim.isEmpty() ? dataFim : "Todas") + " | ", filterFont));
            filtros.add(new Chunk("Ação: " + (acao != null && !acao.isEmpty() && !"TODOS".equals(acao) ? acao : "Todas") + " | ", filterFont));
            filtros.add(new Chunk("Tabela: " + (tabela != null && !tabela.isEmpty() && !"TODAS".equals(tabela) ? tabela : "Todas"), filterFont));
            document.add(filtros);
            document.add(new Paragraph(" "));

            // Data de geração
            Paragraph dataGeracao = new Paragraph("Gerado em: " + sdf.format(new java.util.Date()), filterFont);
            dataGeracao.setAlignment(Element.ALIGN_RIGHT);
            document.add(dataGeracao);
            document.add(new Paragraph(" "));

            // Tabela de logs
            PdfPTable table = new PdfPTable(7);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{8f, 15f, 12f, 15f, 8f, 20f, 22f});

            // Cabeçalho da tabela
            addTableHeader(table, "#");
            addTableHeader(table, "USUÁRIO");
            addTableHeader(table, "AÇÃO");
            addTableHeader(table, "TABELA");
            addTableHeader(table, "ID REG");
            addTableHeader(table, "DESCRIÇÃO");
            addTableHeader(table, "DATA/HORA");

            // Dados
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 8);
            for (LogSistema log : logs) {
                addTableCell(table, String.valueOf(log.getIdLog()), cellFont);
                addTableCell(table, log.getNomeUsuario(), cellFont);
                addTableCell(table, log.getAcao(), cellFont);
                addTableCell(table, log.getTabelaAfetada() != null ? log.getTabelaAfetada() : "-", cellFont);
                addTableCell(table, String.valueOf(log.getIdRegistro()), cellFont);
                addTableCell(table, log.getDescricao() != null ? (log.getDescricao().length() > 50 ? log.getDescricao().substring(0, 47) + "..." : log.getDescricao()) : "-", cellFont);
                addTableCell(table, log.getDataLog() != null ? sdf.format(log.getDataLog()) : "-", cellFont);
            }

            document.add(table);
            document.add(new Paragraph(" "));

            // Rodapé com total
            Paragraph total = new Paragraph("Total de registros: " + logs.size(),
                    FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10));
            total.setAlignment(Element.ALIGN_RIGHT);
            document.add(total);

            document.close();

        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }

    private void exportarPDFCompleto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String dataInicio = request.getParameter("dataInicio");
        String dataFim = request.getParameter("dataFim");
        String acao = request.getParameter("acao");
        String tabela = request.getParameter("tabela");

        List<LogSistema> logs = logDAO.listarComFiltros(10000, dataInicio, dataFim, acao, tabela);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=relatorio_completo_logs_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date()) + ".pdf");

        try {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, response.getOutputStream());

            // Adicionar evento de rodapé com página
            writer.setPageEvent(new PdfPageEventHelper() {
                @Override
                public void onEndPage(PdfWriter writer, Document document) {
                    try {
                        Font footerFont = FontFactory.getFont(FontFactory.HELVETICA, 7);
                        PdfPTable footer = new PdfPTable(1);
                        footer.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
                        footer.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                        footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
                        footer.addCell(new Phrase("Página " + writer.getPageNumber() + " - Sistema Hotelaria", footerFont));
                        footer.writeSelectedRows(0, -1, document.leftMargin(), document.bottomMargin(), writer.getDirectContent());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            document.open();

            // Cabeçalho com logo do caminho real
            addHeader(document, request);

            // Título
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20);
            Paragraph title = new Paragraph("RELATÓRIO COMPLETO DE AUDITORIA", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            Paragraph subtitle = new Paragraph("Sistema de Gestão de Hotelaria",
                    FontFactory.getFont(FontFactory.HELVETICA, 12));
            subtitle.setAlignment(Element.ALIGN_CENTER);
            document.add(subtitle);
            document.add(new Paragraph(" "));

            // Filtros aplicados
            Font filterFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
            Paragraph filtros = new Paragraph();
            filtros.add(new Chunk("📅 Filtros aplicados: ", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
            filtros.add(new Chunk("Data Início: " + (dataInicio != null && !dataInicio.isEmpty() ? dataInicio : "Todas") + " | ", filterFont));
            filtros.add(new Chunk("Data Fim: " + (dataFim != null && !dataFim.isEmpty() ? dataFim : "Todas") + " | ", filterFont));
            filtros.add(new Chunk("Ação: " + (acao != null && !acao.isEmpty() && !"TODOS".equals(acao) ? acao : "Todas") + " | ", filterFont));
            filtros.add(new Chunk("Tabela: " + (tabela != null && !tabela.isEmpty() && !"TODAS".equals(tabela) ? tabela : "Todas"), filterFont));
            document.add(filtros);
            document.add(new Paragraph(" "));

            // Data de geração
            Paragraph dataGeracao = new Paragraph("📄 Gerado em: " + sdf.format(new java.util.Date()), filterFont);
            dataGeracao.setAlignment(Element.ALIGN_RIGHT);
            document.add(dataGeracao);
            document.add(new Paragraph(" "));

            // Tabela de logs
            PdfPTable table = new PdfPTable(8);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{6f, 14f, 10f, 12f, 7f, 8f, 25f, 18f});

            // Cabeçalho da tabela
            addTableHeader(table, "ID");
            addTableHeader(table, "USUÁRIO");
            addTableHeader(table, "AÇÃO");
            addTableHeader(table, "TABELA");
            addTableHeader(table, "ID REG");
            addTableHeader(table, "IP");
            addTableHeader(table, "DESCRIÇÃO");
            addTableHeader(table, "DATA/HORA");

            // Dados
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 7);
            for (LogSistema log : logs) {
                addTableCell(table, String.valueOf(log.getIdLog()), cellFont);
                addTableCell(table, log.getNomeUsuario(), cellFont);
                addTableCell(table, log.getAcao(), cellFont);
                addTableCell(table, log.getTabelaAfetada() != null ? log.getTabelaAfetada() : "-", cellFont);
                addTableCell(table, String.valueOf(log.getIdRegistro()), cellFont);
                addTableCell(table, log.getEnderecoIp() != null ? log.getEnderecoIp() : "-", cellFont);
                addTableCell(table, log.getDescricao() != null ? (log.getDescricao().length() > 60 ? log.getDescricao().substring(0, 57) + "..." : log.getDescricao()) : "-", cellFont);
                addTableCell(table, log.getDataLog() != null ? sdf.format(log.getDataLog()) : "-", cellFont);
            }

            document.add(table);
            document.add(new Paragraph(" "));

            // Resumo estatístico
            Font summaryFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
            Paragraph summary = new Paragraph("📊 RESUMO ESTATÍSTICO", summaryFont);
            document.add(summary);
            document.add(new Paragraph(" "));

            PdfPTable summaryTable = new PdfPTable(2);
            summaryTable.setWidthPercentage(50);

            addTableCell(summaryTable, "Total de registros:", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9));
            addTableCell(summaryTable, String.valueOf(logs.size()), FontFactory.getFont(FontFactory.HELVETICA, 9));

            document.add(summaryTable);

            document.close();

        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }

    /**
     * Adiciona cabeçalho com logotipo da aplicação
     */
    private void addHeader(Document document, HttpServletRequest request) throws DocumentException {
        try {
            // Caminho real do logotipo na aplicação
            String logoPath = request.getServletContext().getRealPath("/assets/images/logotipo.png");

            // Se não encontrar no caminho real, tenta como recurso
            Image logo = null;

            // Tenta carregar do caminho real do sistema de arquivos
            File logoFile = new File(logoPath);
            if (logoFile.exists()) {
                logo = Image.getInstance(logoPath);
            } else {
                // Tenta carregar como recurso do classpath
                InputStream is = getServletContext().getResourceAsStream("/assets/images/logotipo.png");
                if (is != null) {
                    byte[] imageBytes = is.readAllBytes();
                    logo = Image.getInstance(imageBytes);
                }
            }

            // Se ainda não conseguiu, tenta um caminho alternativo
            if (logo == null) {
                String altPath = request.getServletContext().getRealPath("/assets/img/logo.png");
                File altFile = new File(altPath);
                if (altFile.exists()) {
                    logo = Image.getInstance(altPath);
                }
            }

            PdfPTable headerTable = new PdfPTable(1);
            headerTable.setWidthPercentage(100);
            headerTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            headerTable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

            PdfPCell cell = new PdfPCell();
            cell.setBorder(Rectangle.NO_BORDER);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);

            // Adiciona o logotipo se encontrado
            if (logo != null) {
                logo.scaleToFit(80, 80);
                logo.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(logo);
                cell.addElement(new Paragraph(" "));
            } else {
                // Fallback: texto alternativo
                Font logoFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
                Paragraph logoText = new Paragraph("🏨 SISTEMA HOTELARIA", logoFont);
                logoText.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(logoText);
                cell.addElement(new Paragraph(" "));
            }

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Paragraph universidade = new Paragraph("Universidade Rovuma", titleFont);
            universidade.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(universidade);

            Font subFont = FontFactory.getFont(FontFactory.HELVETICA, 11);
            Paragraph instituto = new Paragraph("Instituto Superior de Transportes, Logística e Telecomunicações", subFont);
            instituto.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(instituto);

            headerTable.addCell(cell);
            document.add(headerTable);
            document.add(new Paragraph(" "));

            Paragraph linha = new Paragraph("__________________________________________________________________________________________________");
            linha.setAlignment(Element.ALIGN_CENTER);
            document.add(linha);
            document.add(new Paragraph(" "));

        } catch (Exception e) {
            e.printStackTrace();
            // Fallback: adiciona apenas texto se não conseguir carregar a imagem
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Paragraph universidade = new Paragraph("Universidade Rovuma", titleFont);
            universidade.setAlignment(Element.ALIGN_CENTER);
            document.add(universidade);

            Font subFont = FontFactory.getFont(FontFactory.HELVETICA, 11);
            Paragraph instituto = new Paragraph("Instituto Superior de Transportes, Logística e Telecomunicações", subFont);
            instituto.setAlignment(Element.ALIGN_CENTER);
            document.add(instituto);
            document.add(new Paragraph(" "));

            Paragraph linha = new Paragraph("__________________________________________________________________________________________________");
            linha.setAlignment(Element.ALIGN_CENTER);
            document.add(linha);
            document.add(new Paragraph(" "));
        }
    }

    private void addTableHeader(PdfPTable table, String text) {
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8);
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBackgroundColor(new BaseColor(26, 75, 140));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setPadding(5);
        table.addCell(cell);
    }

    private void addTableCell(PdfPTable table, String text, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text != null ? text : "-", font));
        cell.setPadding(4);
        table.addCell(cell);
    }

    private String escapeCSV(String value) {
        if (value == null) return "";
        return value.replace(";", ",").replace("\n", " ").replace("\r", " ");
    }
}