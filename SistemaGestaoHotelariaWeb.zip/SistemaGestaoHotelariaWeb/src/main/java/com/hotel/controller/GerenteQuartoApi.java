package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/quartos/listar",
        "/Gerente/api/quartos/stats",
        "/Gerente/api/quartos/graficos",
        "/Gerente/api/quartos/tipos",
        "/Gerente/api/quartos/detalhes",
        "/Gerente/api/quartos/salvar"
})
public class GerenteQuartoApi extends HttpServlet {

    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/quartos/listar":
                listarQuartos(request, response);
                break;
            case "/Gerente/api/quartos/stats":
                getStats(response);
                break;
            case "/Gerente/api/quartos/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/quartos/tipos":
                getTiposQuarto(response);
                break;
            case "/Gerente/api/quartos/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/quartos/salvar".equals(request.getServletPath())) {
            salvarQuarto(request, response);
        }
    }

    private void listarQuartos(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String estado = request.getParameter("estado");
        String tipo = request.getParameter("tipo");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT q.id_quarto, q.numero_quarto, q.piso, q.estado, ");
            sql.append("tq.id_tipo_quarto, tq.nome_tipo as tipo_nome, tq.preco_diaria, ");
            sql.append("(SELECT c.nome_completo FROM reserva r ");
            sql.append("JOIN cliente c ON r.id_cliente = c.id_cliente ");
            sql.append("WHERE r.id_quarto = q.id_quarto ");
            sql.append("AND r.estado_reserva IN ('CHECK-IN', 'CONFIRMADA') ");
            sql.append("AND CURDATE() BETWEEN r.data_entrada AND r.data_saida LIMIT 1) as hospede_atual ");
            sql.append("FROM quarto q ");
            sql.append("JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (q.numero_quarto LIKE ? OR tq.nome_tipo LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (estado != null && !estado.isEmpty()) {
                sql.append("AND q.estado = ? ");
                params.add(estado);
            }
            if (tipo != null && !tipo.isEmpty()) {
                sql.append("AND tq.nome_tipo = ? ");
                params.add(tipo);
            }

            sql.append("ORDER BY CAST(q.numero_quarto AS UNSIGNED) ASC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM quarto q JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND (q.numero_quarto LIKE '%" + search + "%' OR tq.nome_tipo LIKE '%" + search + "%')";
            }
            if (estado != null && !estado.isEmpty()) {
                countSql += " AND q.estado = '" + estado + "'";
            }
            if (tipo != null && !tipo.isEmpty()) {
                countSql += " AND tq.nome_tipo = '" + tipo + "'";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray quartosArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_quarto", rs.getInt("id_quarto"));
                        obj.addProperty("numero_quarto", rs.getString("numero_quarto"));
                        obj.addProperty("piso", rs.getInt("piso"));
                        obj.addProperty("estado", rs.getString("estado"));
                        obj.addProperty("id_tipo_quarto", rs.getInt("id_tipo_quarto"));
                        obj.addProperty("tipo_nome", rs.getString("tipo_nome"));
                        obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                        obj.addProperty("hospede_atual", rs.getString("hospede_atual"));
                        quartosArray.add(obj);
                    }
                }
            }

            result.add("quartos", quartosArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("quartos", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN estado = 'LIVRE' THEN 1 ELSE 0 END) as livres, " +
                    "SUM(CASE WHEN estado = 'OCUPADO' THEN 1 ELSE 0 END) as ocupados " +
                    "FROM quarto";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int total = rs.getInt("total");
                    int ocupados = rs.getInt("ocupados");
                    stats.addProperty("total", total);
                    stats.addProperty("livres", rs.getInt("livres"));
                    stats.addProperty("ocupados", ocupados);
                    stats.addProperty("taxa_ocupacao", total > 0 ? Math.round((ocupados * 100.0 / total)) : 0);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Distribuição por estado
            String sqlEstado = "SELECT estado, COUNT(*) as total FROM quarto GROUP BY estado";
            try (PreparedStatement stmt = conn.prepareStatement(sqlEstado);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String estado = rs.getString("estado");
                    int total = rs.getInt("total");
                    switch (estado) {
                        case "LIVRE": result.addProperty("livres", total); break;
                        case "OCUPADO": result.addProperty("ocupados", total); break;
                        case "RESERVADO": result.addProperty("reservados", total); break;
                        case "MANUTENCAO": result.addProperty("manutencao", total); break;
                        case "LIMPEZA": result.addProperty("limpeza", total); break;
                    }
                }
            }

            // Ocupação por tipo de quarto
            JsonArray ocupacaoPorTipo = new JsonArray();
            String sqlOcupacaoTipo = "SELECT tq.nome_tipo, " +
                    "COUNT(q.id_quarto) as total, " +
                    "SUM(CASE WHEN q.estado = 'OCUPADO' THEN 1 ELSE 0 END) as ocupados " +
                    "FROM tipo_quarto tq " +
                    "LEFT JOIN quarto q ON tq.id_tipo_quarto = q.id_tipo_quarto " +
                    "GROUP BY tq.id_tipo_quarto, tq.nome_tipo";
            try (PreparedStatement stmt = conn.prepareStatement(sqlOcupacaoTipo);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    int total = rs.getInt("total");
                    int ocupados = rs.getInt("ocupados");
                    item.addProperty("tipo", rs.getString("nome_tipo"));
                    item.addProperty("taxa", total > 0 ? Math.round((ocupados * 100.0 / total)) : 0);
                    ocupacaoPorTipo.add(item);
                }
            }
            result.add("ocupacao_por_tipo", ocupacaoPorTipo);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getTiposQuarto(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray tipos = new JsonArray();

        String sql = "SELECT id_tipo_quarto, nome_tipo, preco_diaria FROM tipo_quarto ORDER BY preco_diaria ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_tipo_quarto", rs.getInt("id_tipo_quarto"));
                obj.addProperty("nome_tipo", rs.getString("nome_tipo"));
                obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                tipos.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(tipos));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT q.id_quarto, q.numero_quarto, q.piso, q.estado, " +
                "q.id_tipo_quarto, tq.nome_tipo as tipo_nome, tq.preco_diaria " +
                "FROM quarto q " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.id_quarto = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_quarto", rs.getInt("id_quarto"));
                    result.addProperty("numero_quarto", rs.getString("numero_quarto"));
                    result.addProperty("piso", rs.getInt("piso"));
                    result.addProperty("estado", rs.getString("estado"));
                    result.addProperty("id_tipo_quarto", rs.getInt("id_tipo_quarto"));
                    result.addProperty("tipo_nome", rs.getString("tipo_nome"));
                    result.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void salvarQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            String idQuarto = data.has("id_quarto") && !data.get("id_quarto").isJsonNull() ? data.get("id_quarto").getAsString() : null;
            String numeroQuarto = data.get("numero_quarto").getAsString();
            int idTipoQuarto = data.get("id_tipo_quarto").getAsInt();
            Integer piso = data.has("piso") && !data.get("piso").isJsonNull() ? data.get("piso").getAsInt() : null;
            String estado = data.get("estado").getAsString();

            boolean success = false;

            if (idQuarto != null && !idQuarto.isEmpty()) {
                String sql = "UPDATE quarto SET numero_quarto=?, id_tipo_quarto=?, piso=?, estado=? WHERE id_quarto=?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, numeroQuarto);
                    stmt.setInt(2, idTipoQuarto);
                    if (piso != null) stmt.setInt(3, piso);
                    else stmt.setNull(3, Types.INTEGER);
                    stmt.setString(4, estado);
                    stmt.setInt(5, Integer.parseInt(idQuarto));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO quarto (numero_quarto, id_tipo_quarto, piso, estado) VALUES (?, ?, ?, ?)";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, numeroQuarto);
                    stmt.setInt(2, idTipoQuarto);
                    if (piso != null) stmt.setInt(3, piso);
                    else stmt.setNull(3, Types.INTEGER);
                    stmt.setString(4, estado);
                    success = stmt.executeUpdate() > 0;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "QUARTO", "quarto", 0,
                        "Quarto " + (idQuarto != null ? "atualizado" : "criado") + ": " + numeroQuarto,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Quarto salvo com sucesso!" : "Erro ao salvar quarto");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}