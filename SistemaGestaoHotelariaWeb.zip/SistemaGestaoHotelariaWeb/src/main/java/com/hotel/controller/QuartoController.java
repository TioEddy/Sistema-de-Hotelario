// src/main/java/com/hotel/controller/QuartoController.java
package com.hotel.controller;

import com.hotel.dao.QuartoDAO;
import com.hotel.dao.TipoQuartoDAO;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Quarto;
import com.hotel.model.TipoQuarto;
import com.hotel.model.Usuario;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/quartos",
        "/Admin/quartos/listar",
        "/Admin/quartos/salvar",
        "/Admin/quartos/editar",
        "/Admin/quartos/excluir",
        "/Admin/quartos/tipos",
        "/Admin/tipos-quarto/salvar",
        "/Admin/tipos-quarto/editar",
        "/Admin/tipos-quarto/excluir"
})
public class QuartoController extends HttpServlet {

    private QuartoDAO quartoDAO;
    private TipoQuartoDAO tipoQuartoDAO;
    private LogSistemaDAO logDAO;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    public void init() {
        quartoDAO = new QuartoDAO();
        tipoQuartoDAO = new TipoQuartoDAO();
        logDAO = new LogSistemaDAO();
        System.out.println("✅ QuartoController iniciado com sucesso!");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        System.out.println("📥 GET request: " + path);

        if ("/Admin/quartos".equals(path)) {
            request.getRequestDispatcher("/Admin/quarto.jsp").forward(request, response);

        } else if ("/Admin/quartos/listar".equals(path)) {
            listarQuartos(response);

        } else if ("/Admin/quartos/editar".equals(path)) {
            editarQuarto(request, response);

        } else if ("/Admin/quartos/tipos".equals(path)) {
            listarTiposQuarto(response);

        } else if ("/Admin/tipos-quarto/editar".equals(path)) {
            editarTipoQuarto(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        System.out.println("📤 POST request: " + path);

        if ("/Admin/quartos/salvar".equals(path)) {
            salvarQuarto(request, response);

        } else if ("/Admin/quartos/excluir".equals(path)) {
            excluirQuarto(request, response);

        } else if ("/Admin/tipos-quarto/salvar".equals(path)) {
            salvarTipoQuarto(request, response);

        } else if ("/Admin/tipos-quarto/excluir".equals(path)) {
            excluirTipoQuarto(request, response);
        }
    }

    // ============================================
    // LISTAR QUARTOS
    // ============================================
    private void listarQuartos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            System.out.println("=== LISTANDO QUARTOS ===");
            List<Quarto> quartos = quartoDAO.listarTodos();
            System.out.println("Quartos encontrados: " + quartos.size());

            StringBuilder json = new StringBuilder();
            json.append("{\"quartos\":[");

            for (int i = 0; i < quartos.size(); i++) {
                Quarto q = quartos.get(i);
                if (i > 0) json.append(",");

                json.append("{");
                json.append("\"idQuarto\":").append(q.getIdQuarto()).append(",");
                json.append("\"numeroQuarto\":\"").append(escapeJson(q.getNumeroQuarto())).append("\",");
                json.append("\"idTipoQuarto\":").append(q.getIdTipoQuarto()).append(",");
                json.append("\"tipoQuarto\":\"").append(escapeJson(q.getTipoQuarto())).append("\",");
                json.append("\"descricaoTipo\":\"").append(escapeJson(q.getDescricaoTipo())).append("\",");
                json.append("\"precoDiaria\":").append(q.getPrecoDiaria()).append(",");
                json.append("\"piso\":").append(q.getPiso()).append(",");
                json.append("\"estado\":\"").append(escapeJson(q.getEstado())).append("\"");
                json.append("}");
            }

            json.append("],\"total\":").append(quartos.size()).append("}");
            System.out.println("JSON gerado com sucesso!");
            out.print(json.toString());

        } catch (Exception e) {
            System.err.println("❌ ERRO ao listar quartos: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"quartos\":[], \"total\":0, \"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ============================================
    // LISTAR TIPOS DE QUARTO
    // ============================================
    private void listarTiposQuarto(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            System.out.println("=== LISTANDO TIPOS DE QUARTO ===");
            List<TipoQuarto> tipos = tipoQuartoDAO.listarTodos();
            System.out.println("Tipos encontrados: " + tipos.size());

            StringBuilder json = new StringBuilder();
            json.append("{\"tipos\":[");

            for (int i = 0; i < tipos.size(); i++) {
                TipoQuarto t = tipos.get(i);
                if (i > 0) json.append(",");

                json.append("{");
                json.append("\"idTipoQuarto\":").append(t.getIdTipoQuarto()).append(",");
                json.append("\"nomeTipo\":\"").append(escapeJson(t.getNomeTipo())).append("\",");
                json.append("\"descricao\":\"").append(escapeJson(t.getDescricao())).append("\",");
                json.append("\"precoDiaria\":").append(t.getPrecoDiaria());
                json.append("}");
            }

            json.append("]}");
            System.out.println("JSON gerado com sucesso!");
            out.print(json.toString());

        } catch (Exception e) {
            System.err.println("❌ ERRO ao listar tipos: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"tipos\":[]}");
        }
        out.flush();
    }

    // ============================================
    // EDITAR QUARTO
    // ============================================
    private void editarQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"error\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            Quarto quarto = quartoDAO.buscarPorId(id);

            if (quarto != null) {
                StringBuilder json = new StringBuilder();
                json.append("{");
                json.append("\"idQuarto\":").append(quarto.getIdQuarto()).append(",");
                json.append("\"numeroQuarto\":\"").append(escapeJson(quarto.getNumeroQuarto())).append("\",");
                json.append("\"idTipoQuarto\":").append(quarto.getIdTipoQuarto()).append(",");
                json.append("\"tipoQuarto\":\"").append(escapeJson(quarto.getTipoQuarto())).append("\",");
                json.append("\"precoDiaria\":").append(quarto.getPrecoDiaria()).append(",");
                json.append("\"piso\":").append(quarto.getPiso()).append(",");
                json.append("\"estado\":\"").append(escapeJson(quarto.getEstado())).append("\"");
                json.append("}");
                out.print(json.toString());
            } else {
                out.print("{\"error\": \"Quarto não encontrado\"}");
            }
        } catch (Exception e) {
            System.err.println("❌ ERRO ao editar quarto: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"error\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ============================================
    // SALVAR QUARTO
    // ============================================
    private void salvarQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            String numeroQuarto = request.getParameter("numeroQuarto");
            String idTipoQuartoStr = request.getParameter("idTipoQuarto");
            String pisoStr = request.getParameter("piso");
            String estado = request.getParameter("estado");

            System.out.println("📝 Parâmetros recebidos para QUARTO:");
            System.out.println("   id: " + idStr);
            System.out.println("   numeroQuarto: " + numeroQuarto);
            System.out.println("   idTipoQuarto: " + idTipoQuartoStr);
            System.out.println("   piso: " + pisoStr);
            System.out.println("   estado: " + estado);

            if (numeroQuarto == null || numeroQuarto.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Número do quarto é obrigatório\"}");
                out.flush();
                return;
            }

            if (idTipoQuartoStr == null || idTipoQuartoStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Tipo de quarto é obrigatório\"}");
                out.flush();
                return;
            }

            int id = (idStr != null && !idStr.trim().isEmpty()) ? Integer.parseInt(idStr.trim()) : 0;
            int idTipoQuarto = Integer.parseInt(idTipoQuartoStr.trim());
            int piso = (pisoStr != null && !pisoStr.trim().isEmpty()) ? Integer.parseInt(pisoStr.trim()) : 0;
            String estadoFinal = (estado != null && !estado.trim().isEmpty()) ? estado.trim() : "LIVRE";

            Quarto quarto = new Quarto();
            quarto.setIdQuarto(id);
            quarto.setNumeroQuarto(numeroQuarto.trim());
            quarto.setIdTipoQuarto(idTipoQuarto);
            quarto.setPiso(piso);
            quarto.setEstado(estadoFinal);

            TipoQuarto tipoQuarto = tipoQuartoDAO.buscarPorId(idTipoQuarto);
            if (tipoQuarto != null) {
                quarto.setPrecoDiaria(tipoQuarto.getPrecoDiaria());
                quarto.setTipoQuarto(tipoQuarto.getNomeTipo());
                quarto.setDescricaoTipo(tipoQuarto.getDescricao());
            }

            boolean success;
            String acao;

            if (id == 0) {
                success = quartoDAO.inserir(quarto);
                acao = "CREATE";
                System.out.println("Inserindo novo quarto: " + success);
            } else {
                success = quartoDAO.atualizar(quarto);
                acao = "UPDATE";
                System.out.println("Atualizando quarto ID " + id + ": " + success);
            }

            if (success && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        acao,
                        "quarto",
                        quarto.getIdQuarto(),
                        "Quarto " + (id == 0 ? "criado" : "atualizado") + ": " + numeroQuarto,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + ", \"id\": " + quarto.getIdQuarto() + "}");

        } catch (NumberFormatException e) {
            System.err.println("❌ ERRO de formato: " + e.getMessage());
            out.print("{\"success\": false, \"message\": \"Formato de número inválido\"}");
        } catch (Exception e) {
            System.err.println("❌ ERRO ao salvar quarto: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ============================================
    // EXCLUIR QUARTO
    // ============================================
    private void excluirQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            Quarto quarto = quartoDAO.buscarPorId(id);
            boolean success = quartoDAO.excluir(id);

            if (success && quarto != null && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        "DELETE",
                        "quarto",
                        id,
                        "Quarto excluído: " + quarto.getNumeroQuarto(),
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            System.err.println("❌ ERRO ao excluir quarto: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ============================================
    // EDITAR TIPO DE QUARTO
    // ============================================
    private void editarTipoQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"error\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            TipoQuarto tipo = tipoQuartoDAO.buscarPorId(id);

            if (tipo != null) {
                StringBuilder json = new StringBuilder();
                json.append("{");
                json.append("\"idTipoQuarto\":").append(tipo.getIdTipoQuarto()).append(",");
                json.append("\"nomeTipo\":\"").append(escapeJson(tipo.getNomeTipo())).append("\",");
                json.append("\"descricao\":\"").append(escapeJson(tipo.getDescricao())).append("\",");
                json.append("\"precoDiaria\":").append(tipo.getPrecoDiaria());
                json.append("}");
                out.print(json.toString());
            } else {
                out.print("{\"error\": \"Tipo não encontrado\"}");
            }
        } catch (Exception e) {
            System.err.println("❌ ERRO ao editar tipo: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"error\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ============================================
    // SALVAR TIPO DE QUARTO
    // ============================================
    private void salvarTipoQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            String nomeTipo = request.getParameter("nomeTipo");
            String descricao = request.getParameter("descricao");
            String precoDiariaStr = request.getParameter("precoDiaria");

            System.out.println("📝 Parâmetros recebidos para TIPO DE QUARTO:");
            System.out.println("   id: " + idStr);
            System.out.println("   nomeTipo: " + nomeTipo);
            System.out.println("   descricao: " + descricao);
            System.out.println("   precoDiaria: " + precoDiariaStr);

            if (nomeTipo == null || nomeTipo.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Nome do tipo é obrigatório\"}");
                out.flush();
                return;
            }

            if (precoDiariaStr == null || precoDiariaStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Preço diária é obrigatório\"}");
                out.flush();
                return;
            }

            int id = (idStr != null && !idStr.trim().isEmpty()) ? Integer.parseInt(idStr.trim()) : 0;
            double precoDiaria = Double.parseDouble(precoDiariaStr.trim());

            TipoQuarto tipo = new TipoQuarto();
            tipo.setIdTipoQuarto(id);
            tipo.setNomeTipo(nomeTipo.trim());
            tipo.setDescricao(descricao != null ? descricao.trim() : "");
            tipo.setPrecoDiaria(precoDiaria);

            boolean success;
            String acao;

            if (id == 0) {
                success = tipoQuartoDAO.inserir(tipo);
                acao = "CREATE";
                System.out.println("Inserindo novo tipo: " + success);
            } else {
                success = tipoQuartoDAO.atualizar(tipo);
                acao = "UPDATE";
                System.out.println("Atualizando tipo ID " + id + ": " + success);
            }

            if (success && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        acao,
                        "tipo_quarto",
                        tipo.getIdTipoQuarto(),
                        "Tipo de quarto " + (id == 0 ? "criado" : "atualizado") + ": " + nomeTipo,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + ", \"id\": " + tipo.getIdTipoQuarto() + "}");

        } catch (NumberFormatException e) {
            System.err.println("❌ ERRO de formato: " + e.getMessage());
            out.print("{\"success\": false, \"message\": \"Preço inválido\"}");
        } catch (Exception e) {
            System.err.println("❌ ERRO ao salvar tipo: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ============================================
    // EXCLUIR TIPO DE QUARTO
    // ============================================
    private void excluirTipoQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            TipoQuarto tipo = tipoQuartoDAO.buscarPorId(id);
            boolean success = tipoQuartoDAO.excluir(id);

            if (success && tipo != null && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        "DELETE",
                        "tipo_quarto",
                        id,
                        "Tipo de quarto excluído: " + tipo.getNomeTipo(),
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            System.err.println("❌ ERRO ao excluir tipo: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}