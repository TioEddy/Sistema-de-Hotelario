package com.hotel.controller;

import com.hotel.model.Usuario;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

@WebServlet("/Gerente/dashboard")
public class GerenteDashboardServlet extends HttpServlet {

    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat sdfHora = new SimpleDateFormat("HH:mm");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        if (usuario == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try (Connection conn = ConexaoDB.getConexao()) {
            // 1. Taxa de ocupação
            String sqlOcupacao = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN estado IN ('OCUPADO', 'RESERVADO') THEN 1 ELSE 0 END) as ocupados " +
                    "FROM quarto";
            try (PreparedStatement stmt = conn.prepareStatement(sqlOcupacao);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {

                    int total = rs.getInt("total");
                    int ocupados = rs.getInt("ocupados");
                    double taxa = total > 0 ? (ocupados * 100.0 / total) : 0;
                    request.setAttribute("totalQuartos", total);
                    request.setAttribute("taxaOcupacao", Math.round(taxa));
                    request.setAttribute("ocupacaoVariacao", "+5% vs ontem");
                }
            }

            // 2. Check-ins hoje
            String hoje = sdfData.format(new Date());
            String sqlCheckins = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN ci.id_checkin IS NOT NULL THEN 1 ELSE 0 END) as realizados " +
                    "FROM reserva r " +
                    "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "WHERE r.data_entrada = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckins)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        int total = rs.getInt("total");
                        int realizados = rs.getInt("realizados");
                        request.setAttribute("checkinsHoje", total);
                        request.setAttribute("checkinsRealizados", realizados);
                    }
                }
            }

            // 3. Check-outs hoje
            String sqlCheckouts = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN co.id_checkout IS NOT NULL THEN 1 ELSE 0 END) as realizados " +
                    "FROM reserva r " +
                    "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE r.data_saida = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckouts)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        int total = rs.getInt("total");
                        int realizados = rs.getInt("realizados");
                        request.setAttribute("checkoutsHoje", total);
                        request.setAttribute("checkoutsAguardando", total - realizados);
                    }
                }
            }

            // 4. Consumo do mês
            String sqlConsumo = "SELECT COALESCE(SUM(cs.subtotal), 0) as total " +
                    "FROM consumo_servico cs " +
                    "WHERE MONTH(cs.data_consumo) = MONTH(CURDATE()) " +
                    "AND YEAR(cs.data_consumo) = YEAR(CURDATE())";
            try (PreparedStatement stmt = conn.prepareStatement(sqlConsumo);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    request.setAttribute("consumoMes", rs.getDouble("total"));
                    request.setAttribute("consumoVariacao", "+12% vs mês anterior");
                }
            }

            // 5. Lista de check-ins de hoje (detalhada)
            String sqlCheckinsLista = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                    "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                    "DATE_FORMAT(r.data_entrada, '%H:%i') as hora_checkin, " +
                    "r.numero_hospedes, r.observacoes, " +
                    "CASE WHEN ci.id_checkin IS NOT NULL THEN 'confirmada' ELSE 'pendente' END as status " +
                    "FROM reserva r " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                    "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                    "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                    "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "WHERE r.data_entrada = ? " +
                    "ORDER BY r.data_entrada ASC";
            List<Map<String, Object>> checkinsLista = new ArrayList<>();
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckinsLista)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Map<String, Object> item = new HashMap<>();
                        item.put("clienteNome", rs.getString("cliente_nome"));
                        item.put("quartoNumero", rs.getString("numero_quarto"));
                        item.put("quartoTipo", rs.getString("quarto_tipo"));
                        item.put("horaCheckin", rs.getString("hora_checkin"));
                        item.put("numeroHospedes", rs.getInt("numero_hospedes"));
                        item.put("observacoes", rs.getString("observacoes"));
                        item.put("status", rs.getString("status"));
                        checkinsLista.add(item);
                    }
                }
            }
            request.setAttribute("checkinsHojeLista", checkinsLista);

            // 6. Lista de quartos
            String sqlQuartos = "SELECT q.id_quarto, q.numero_quarto, q.piso, q.estado, " +
                    "tq.nome_tipo as tipo_quarto, " +
                    "c.nome_completo as hospede_atual " +
                    "FROM quarto q " +
                    "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                    "LEFT JOIN reserva r ON q.id_quarto = r.id_quarto " +
                    "AND r.estado_reserva IN ('CONFIRMADA', 'CHECK-IN') " +
                    "AND CURDATE() BETWEEN r.data_entrada AND r.data_saida " +
                    "LEFT JOIN cliente c ON r.id_cliente = c.id_cliente " +
                    "ORDER BY q.numero_quarto ASC";
            List<Map<String, Object>> quartos = new ArrayList<>();
            try (PreparedStatement stmt = conn.prepareStatement(sqlQuartos);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> quarto = new HashMap<>();
                    quarto.put("numeroQuarto", rs.getString("numero_quarto"));
                    quarto.put("tipoQuarto", rs.getString("tipo_quarto"));
                    quarto.put("piso", rs.getInt("piso"));
                    quarto.put("estado", rs.getString("estado"));
                    quarto.put("hospedeAtual", rs.getString("hospede_atual"));
                    quartos.add(quarto);
                }
            }
            request.setAttribute("quartos", quartos);

            // 7. Top serviços consumidos
            String sqlTopServicos = "SELECT s.nome_servico, COUNT(cs.id_consumo) as total " +
                    "FROM consumo_servico cs " +
                    "JOIN servico s ON cs.id_servico = s.id_servico " +
                    "GROUP BY s.id_servico, s.nome_servico " +
                    "ORDER BY total DESC LIMIT 4";
            List<Map<String, Object>> topServicos = new ArrayList<>();
            try (PreparedStatement stmt = conn.prepareStatement(sqlTopServicos);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("nome", rs.getString("nome_servico"));
                    item.put("total", rs.getInt("total"));
                    topServicos.add(item);
                }
            }
            request.setAttribute("topServicos", topServicos);

            // 8. Pagamentos do dia
            String sqlPagamentos = "SELECT mp.nome_metodo, COALESCE(SUM(p.valor), 0) as total " +
                    "FROM metodo_pagamento mp " +
                    "LEFT JOIN pagamento p ON mp.id_metodo_pagamento = p.id_metodo_pagamento " +
                    "AND DATE(p.data_pagamento) = CURDATE() AND p.estado_pagamento = 'PAGO' " +
                    "GROUP BY mp.id_metodo_pagamento, mp.nome_metodo";
            double dinheiro = 0, pos = 0, mpesa = 0, transferencia = 0, totalPagamentos = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlPagamentos);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String metodo = rs.getString("nome_metodo");
                    double valor = rs.getDouble("total");
                    totalPagamentos += valor;
                    if ("Dinheiro".equals(metodo)) dinheiro = valor;
                    else if ("POS".equals(metodo)) pos = valor;
                    else if ("M-Pesa".equals(metodo)) mpesa = valor;
                    else if ("Transferência Bancária".equals(metodo)) transferencia = valor;
                }
            }
            request.setAttribute("pagamentoDinheiro", dinheiro);
            request.setAttribute("pagamentoPos", pos);
            request.setAttribute("pagamentoMpesa", mpesa);
            request.setAttribute("pagamentoTransferencia", transferencia);
            request.setAttribute("totalPagamentosDia", totalPagamentos);

            // 9. Funcionários por cargo
            String sqlFuncionarios = "SELECT cargo, COUNT(*) as total FROM funcionario GROUP BY cargo";
            int totalFunc = 0, recepcionistas = 0, housekeeping = 0, manutencao = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlFuncionarios);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String cargo = rs.getString("cargo");
                    int total = rs.getInt("total");
                    totalFunc += total;
                    if (cargo != null && cargo.contains("Recepcionista")) recepcionistas += total;
                    if (cargo != null && (cargo.contains("Housekeeping") || cargo.contains("Governante"))) housekeeping += total;
                    if (cargo != null && cargo.contains("Manutenção")) manutencao += total;
                }
            }
            request.setAttribute("totalFuncionarios", totalFunc);
            request.setAttribute("recepcionistasCount", recepcionistas);
            request.setAttribute("housekeepingCount", housekeeping);
            request.setAttribute("manutencaoCount", manutencao);

            // 10. Reservas por estado (para gráfico)
            String sqlReservasEstado = "SELECT estado_reserva, COUNT(*) as total FROM reserva GROUP BY estado_reserva";
            int confirmadas = 0, pendentes = 0, finalizadas = 0, canceladas = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlReservasEstado);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String estado = rs.getString("estado_reserva");
                    int total = rs.getInt("total");
                    if ("CONFIRMADA".equals(estado)) confirmadas = total;
                    else if ("PENDENTE".equals(estado)) pendentes = total;
                    else if ("FINALIZADA".equals(estado)) finalizadas = total;
                    else if ("CANCELADA".equals(estado)) canceladas = total;
                }
            }
            request.setAttribute("reservasConfirmadas", confirmadas);
            request.setAttribute("reservasPendentes", pendentes);
            request.setAttribute("reservasFinalizadas", finalizadas);
            request.setAttribute("reservasCanceladas", canceladas);

            // 11. Serviços para gráfico
            String sqlServicosGrafico = "SELECT s.nome_servico, COUNT(cs.id_consumo) as total " +
                    "FROM consumo_servico cs " +
                    "JOIN servico s ON cs.id_servico = s.id_servico " +
                    "GROUP BY s.id_servico, s.nome_servico " +
                    "ORDER BY total DESC LIMIT 5";
            List<Map<String, Object>> servicosGrafico = new ArrayList<>();
            try (PreparedStatement stmt = conn.prepareStatement(sqlServicosGrafico);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("nome", rs.getString("nome_servico"));
                    item.put("total", rs.getInt("total"));
                    servicosGrafico.add(item);
                }
            }
            request.setAttribute("servicosGrafico", servicosGrafico);

            // 12. Faturação mensal (últimos 6 meses)
            String sqlFaturamentoMensal = "SELECT DATE_FORMAT(data_emissao, '%b') as mes, " +
                    "COALESCE(SUM(total), 0) as total " +
                    "FROM fatura " +
                    "WHERE data_emissao >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
                    "GROUP BY YEAR(data_emissao), MONTH(data_emissao), DATE_FORMAT(data_emissao, '%b') " +
                    "ORDER BY data_emissao ASC";
            List<Map<String, Object>> faturamentoMensal = new ArrayList<>();
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturamentoMensal);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("mes", rs.getString("mes"));
                    item.put("total", rs.getDouble("total"));
                    faturamentoMensal.add(item);
                }
            }
            request.setAttribute("faturamentoMensal", faturamentoMensal);

        } catch (SQLException e) {
            e.printStackTrace();
            // Valores padrão em caso de erro
            request.setAttribute("taxaOcupacao", 0);
            request.setAttribute("checkinsHoje", 0);
            request.setAttribute("checkoutsHoje", 0);
            request.setAttribute("consumoMes", 0);
        }

        request.getRequestDispatcher("/Gerente/dashboard.jsp").forward(request, response);
    }
}