package com.hotel.controller;

import com.hotel.dao.*;
import com.hotel.model.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/consumos",
        "/Admin/consumos/listar",
        "/Admin/consumos/salvar",
        "/Admin/consumos/editar",
        "/Admin/consumos/excluir",
        "/Admin/consumos/hospedes",
        "/Admin/consumos/servicos",
        "/Admin/consumos/stats",
        "/Admin/consumos/servicos/listar",
        "/Admin/consumos/servicos/salvar",
        "/Admin/consumos/servicos/excluir",
        "/Admin/consumos/salvar-multiplo"
})
public class ConsumoController extends HttpServlet {

    private Gson gson = new Gson();
    private LogSistemaDAO logDAO = new LogSistemaDAO();

    // ==================== LISTAR CONSUMOS ====================
    private void listarConsumos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT cs.id_consumo, cs.id_reserva, cs.id_servico, " +
                "cs.quantidade, cs.subtotal, cs.data_consumo, " +
                "s.nome_servico, s.preco as preco_unitario, " +
                "c.nome_completo as hospede_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "u.nome as usuario_nome " +
                "FROM consumo_servico cs " +
                "JOIN servico s ON cs.id_servico = s.id_servico " +
                "JOIN reserva r ON cs.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN usuario u ON cs.id_usuario = u.id_usuario " +
                "ORDER BY cs.data_consumo DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_consumo", rs.getInt("id_consumo"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("id_servico", rs.getInt("id_servico"));
                obj.addProperty("servico_nome", rs.getString("nome_servico"));
                obj.addProperty("quantidade", rs.getInt("quantidade"));
                obj.addProperty("preco_unitario", rs.getDouble("preco_unitario"));
                obj.addProperty("subtotal", rs.getDouble("subtotal"));
                obj.addProperty("data_consumo", rs.getString("data_consumo"));
                obj.addProperty("hospede_nome", rs.getString("hospede_nome"));
                obj.addProperty("quarto_num", rs.getString("numero_quarto") + " - " + rs.getString("quarto_tipo"));
                obj.addProperty("usuario_nome", rs.getString("usuario_nome") != null ? rs.getString("usuario_nome") : "Sistema");
                jsonArray.add(obj);
            }

            System.out.println("📊 Consumos encontrados: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== LISTAR TODOS OS HÓSPEDES CADASTRADOS ====================
    private void listarTodosHospedes(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT c.id_cliente, c.nome_completo " +
                "FROM cliente c " +
                "ORDER BY c.nome_completo";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_cliente", rs.getInt("id_cliente"));
                obj.addProperty("cliente_nome", rs.getString("nome_completo"));
                obj.addProperty("quarto", "Selecionar consumo");
                jsonArray.add(obj);
            }

            System.out.println("👥 Hóspedes encontrados: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== LISTAR SERVIÇOS (para o select) ====================
    private void listarServicosSelect(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT id_servico, nome_servico, descricao, preco FROM servico ORDER BY nome_servico";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_servico", rs.getInt("id_servico"));
                obj.addProperty("nome_servico", rs.getString("nome_servico"));
                obj.addProperty("descricao", rs.getString("descricao") != null ? rs.getString("descricao") : "");
                obj.addProperty("preco", rs.getDouble("preco"));
                jsonArray.add(obj);
            }

            System.out.println("🛒 Serviços encontrados: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== LISTAR SERVIÇOS (para listagem) ====================
    private void listarServicos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT s.id_servico, s.nome_servico, s.descricao, s.preco, " +
                "COALESCE(SUM(cs.quantidade), 0) as total_consumido " +
                "FROM servico s " +
                "LEFT JOIN consumo_servico cs ON s.id_servico = cs.id_servico " +
                "GROUP BY s.id_servico ORDER BY s.nome_servico";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_servico", rs.getInt("id_servico"));
                obj.addProperty("nome_servico", rs.getString("nome_servico"));
                obj.addProperty("descricao", rs.getString("descricao") != null ? rs.getString("descricao") : "");
                obj.addProperty("preco", rs.getDouble("preco"));
                obj.addProperty("total_consumido", rs.getInt("total_consumido"));
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== SALVAR SERVIÇO ====================
    private void salvarServico(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            String nomeServico = request.getParameter("nome_servico");
            String descricao = request.getParameter("descricao");
            double preco = Double.parseDouble(request.getParameter("preco"));

            boolean success = false;

            if (idStr != null && !idStr.isEmpty()) {
                String sql = "UPDATE servico SET nome_servico = ?, descricao = ?, preco = ? WHERE id_servico = ?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, nomeServico);
                    stmt.setString(2, descricao);
                    stmt.setDouble(3, preco);
                    stmt.setInt(4, Integer.parseInt(idStr));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO servico (nome_servico, descricao, preco) VALUES (?, ?, ?)";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    stmt.setString(1, nomeServico);
                    stmt.setString(2, descricao);
                    stmt.setDouble(3, preco);
                    success = stmt.executeUpdate() > 0;
                }
            }

            JsonObject result = new JsonObject();
            result.addProperty("success", success);
            out.print(gson.toJson(result));

        } catch (Exception e) {
            e.printStackTrace();
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    // ==================== EXCLUIR SERVIÇO ====================
    private void excluirServico(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            String sql = "DELETE FROM servico WHERE id_servico = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                boolean success = stmt.executeUpdate() > 0;

                JsonObject result = new JsonObject();
                result.addProperty("success", success);
                out.print(gson.toJson(result));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    // ==================== OBTER ESTATÍSTICAS (CARDS) - CORRIGIDO ====================
    private void getStats(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            System.out.println("🔌 Conexão com banco estabelecida!");

            // 1. Total de consumos
            String sqlTotal = "SELECT COUNT(*) as total FROM consumo_servico";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlTotal)) {
                int total = rs.next() ? rs.getInt("total") : 0;
                stats.addProperty("total_consumos", total);
                System.out.println("📊 Total consumos: " + total);
            }

            // 2. Total faturado (soma de todos os subtotais)
            String sqlFaturado = "SELECT COALESCE(SUM(subtotal), 0) as total FROM consumo_servico";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlFaturado)) {
                double total = rs.next() ? rs.getDouble("total") : 0;
                stats.addProperty("total_faturado", total);
                System.out.println("💰 Total faturado: " + total);
            }

            // 3. Hóspedes ativos - CORRIGIDO!
            // A tabela checkin NÃO tem coluna data_checkout!
            // Corrigido: usa LEFT JOIN com a tabela checkout
            String sqlHospedes = "SELECT COUNT(*) as total FROM checkin ci " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE co.id_checkout IS NULL";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlHospedes)) {
                int total = rs.next() ? rs.getInt("total") : 0;
                stats.addProperty("hospedes_ativos", total);
                System.out.println("🏨 Hóspedes ativos: " + total);
            }

            // 4. Serviço mais consumido
            String sqlTopServico = "SELECT s.nome_servico, COALESCE(SUM(cs.quantidade), 0) as total " +
                    "FROM servico s " +
                    "LEFT JOIN consumo_servico cs ON s.id_servico = cs.id_servico " +
                    "GROUP BY s.id_servico, s.nome_servico ORDER BY total DESC LIMIT 1";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sqlTopServico)) {
                if (rs.next()) {
                    int total = rs.getInt("total");
                    if (total > 0) {
                        stats.addProperty("top_servico", rs.getString("nome_servico") + " (" + total + ")");
                        System.out.println("🏆 Serviço + consumido: " + rs.getString("nome_servico") + " (" + total + ")");
                    } else {
                        stats.addProperty("top_servico", "Nenhum consumo registrado");
                        System.out.println("🏆 Nenhum consumo registrado");
                    }
                } else {
                    stats.addProperty("top_servico", "Nenhum serviço cadastrado");
                }
            }

        } catch (SQLException e) {
            System.err.println("❌ Erro ao carregar stats: " + e.getMessage());
            e.printStackTrace();
            stats.addProperty("total_consumos", 0);
            stats.addProperty("total_faturado", 0);
            stats.addProperty("hospedes_ativos", 0);
            stats.addProperty("top_servico", "Erro: " + e.getMessage());
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    // ==================== EDITAR CONSUMO ====================
    private void editarConsumo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT cs.id_consumo, cs.id_reserva, cs.id_servico, " +
                "cs.quantidade, cs.subtotal, cs.data_consumo, " +
                "s.nome_servico, s.preco as preco_unitario " +
                "FROM consumo_servico cs " +
                "JOIN servico s ON cs.id_servico = s.id_servico " +
                "WHERE cs.id_consumo = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_consumo", rs.getInt("id_consumo"));
                    obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                    obj.addProperty("id_servico", rs.getInt("id_servico"));
                    obj.addProperty("quantidade", rs.getInt("quantidade"));
                    obj.addProperty("subtotal", rs.getDouble("subtotal"));
                    obj.addProperty("data_consumo", rs.getString("data_consumo"));
                    out.print(gson.toJson(obj));
                } else {
                    out.print("{}");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{}");
        }
        out.flush();
    }

    // ==================== SALVAR MÚLTIPLOS CONSUMOS ====================
    private void salvarMultiplosConsumos(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            int idCliente = Integer.parseInt(request.getParameter("id_cliente"));
            String dataConsumo = request.getParameter("data_consumo");
            String servicosJson = request.getParameter("servicos");

            JsonArray servicosArray = gson.fromJson(servicosJson, JsonArray.class);
            int totalInseridos = 0;

            // Buscar uma reserva CONFIRMADA para este cliente
            String sqlBuscaReserva = "SELECT id_reserva FROM reserva WHERE id_cliente = ? AND estado_reserva = 'CONFIRMADA' ORDER BY id_reserva DESC LIMIT 1";
            int idReserva = -1;

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlBuscaReserva)) {
                stmt.setInt(1, idCliente);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    idReserva = rs.getInt("id_reserva");
                }
            }

            if (idReserva == -1) {
                JsonObject result = new JsonObject();
                result.addProperty("success", false);
                result.addProperty("message", "Cliente não possui reserva confirmada. Faça uma reserva primeiro.");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            String sql = "INSERT INTO consumo_servico (id_reserva, id_servico, quantidade, subtotal, data_consumo, id_usuario) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                for (int i = 0; i < servicosArray.size(); i++) {
                    JsonObject item = servicosArray.get(i).getAsJsonObject();
                    int idServico = item.get("id_servico").getAsInt();
                    int quantidade = item.get("quantidade").getAsInt();
                    double preco = item.get("preco").getAsDouble();
                    double subtotal = preco * quantidade;

                    stmt.setInt(1, idReserva);
                    stmt.setInt(2, idServico);
                    stmt.setInt(3, quantidade);
                    stmt.setDouble(4, subtotal);
                    stmt.setString(5, dataConsumo);
                    stmt.setInt(6, usuarioLogado != null ? usuarioLogado.getIdUsuario() : 1);

                    if (stmt.executeUpdate() > 0) {
                        totalInseridos++;
                    }
                }
            }

            JsonObject result = new JsonObject();
            result.addProperty("success", totalInseridos > 0);
            result.addProperty("totalInseridos", totalInseridos);
            out.print(gson.toJson(result));

        } catch (Exception e) {
            e.printStackTrace();
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    // ==================== EXCLUIR CONSUMO ====================
    private void excluirConsumo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            String sql = "DELETE FROM consumo_servico WHERE id_consumo = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                boolean success = stmt.executeUpdate() > 0;

                JsonObject result = new JsonObject();
                result.addProperty("success", success);
                out.print(gson.toJson(result));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    // ==================== DO GET ====================
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/consumos".equals(path)) {
            request.getRequestDispatcher("/Admin/consumo.jsp").forward(request, response);

        } else if ("/Admin/consumos/listar".equals(path)) {
            listarConsumos(response);

        } else if ("/Admin/consumos/editar".equals(path)) {
            editarConsumo(request, response);

        } else if ("/Admin/consumos/hospedes".equals(path)) {
            listarTodosHospedes(response);

        } else if ("/Admin/consumos/servicos".equals(path)) {
            listarServicosSelect(response);

        } else if ("/Admin/consumos/servicos/listar".equals(path)) {
            listarServicos(response);

        } else if ("/Admin/consumos/stats".equals(path)) {
            getStats(response);
            // Dentro do doGet, altere esta linha:
        } else if ("/Admin/consumos/hospedes".equals(path)) {
            listarHospedesComReservaConfirmada(response);  // <-- Mude para o novo método
        }
    }
// Substitua o método listarTodosHospedes por este:

    // ==================== LISTAR HÓSPEDES COM RESERVA CONFIRMADA ====================
    private void listarHospedesComReservaConfirmada(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        // SQL para buscar apenas clientes com reserva CONFIRMADA
        String sql = "SELECT DISTINCT c.id_cliente, c.nome_completo, q.numero_quarto, tq.nome_tipo " +
                "FROM cliente c " +
                "INNER JOIN reserva r ON c.id_cliente = r.id_cliente " +
                "INNER JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva = 'CONFIRMADA' " +
                "ORDER BY c.nome_completo";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_cliente", rs.getInt("id_cliente"));
                obj.addProperty("cliente_nome", rs.getString("nome_completo"));
                obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + rs.getString("nome_tipo"));
                jsonArray.add(obj);
            }

            System.out.println("👥 Hóspedes com reserva confirmada encontrados: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }
    // ==================== DO POST ====================
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/consumos/salvar".equals(path)) {
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", "Use o método salvar-multiplo");
            response.setContentType("application/json");
            response.getWriter().print(gson.toJson(result));
            response.getWriter().flush();

        } else if ("/Admin/consumos/excluir".equals(path)) {
            excluirConsumo(request, response);

        } else if ("/Admin/consumos/servicos/salvar".equals(path)) {
            salvarServico(request, response);

        } else if ("/Admin/consumos/servicos/excluir".equals(path)) {
            excluirServico(request, response);

        } else if ("/Admin/consumos/salvar-multiplo".equals(path)) {
            salvarMultiplosConsumos(request, response);
        }
    }
}