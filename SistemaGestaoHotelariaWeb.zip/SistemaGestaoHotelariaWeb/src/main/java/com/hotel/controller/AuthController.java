// src/main/java/com/hotel/controller/AuthController.java (ATUALIZADO)
package com.hotel.controller;

import com.hotel.dao.UsuarioDAO;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "AuthController", urlPatterns = {"/login", "/logout"})
public class AuthController extends HttpServlet {

    private UsuarioDAO usuarioDAO;
    private LogSistemaDAO logDAO;

    @Override
    public void init() {
        usuarioDAO = new UsuarioDAO();
        logDAO = new LogSistemaDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String senha = request.getParameter("senha");
        String ip = request.getRemoteAddr();
        String navegador = request.getHeader("User-Agent");

        if (username == null || senha == null || username.trim().isEmpty() || senha.trim().isEmpty()) {
            request.setAttribute("erro", "Preencha todos os campos!");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        Usuario usuario = usuarioDAO.autenticar(username, senha);

        if (usuario != null) {
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogado", usuario);
            session.setAttribute("idUsuario", usuario.getIdUsuario());
            session.setAttribute("nomeUsuario", usuario.getNome());
            session.setAttribute("perfil", usuario.getNomePerfil());

            // Registrar LOGIN no sistema
            logDAO.registrarLog(
                    usuario.getIdUsuario(),
                    "LOGIN",
                    "sistema",
                    0,
                    "Usuário " + usuario.getNome() + " fez login no sistema",
                    ip,
                    navegador
            );

            String perfil = usuario.getNomePerfil().toLowerCase();
            String redirectPath = "";

            switch (perfil) {
                case "administrador":
                    redirectPath = "/Admin/dashboard";
                    break;
                case "gerente":
                    redirectPath = "/Gerente/dashboard.jsp";
                    break;
                case "financeiro":
                    redirectPath = "/Financeiro/dashboard.jsp";
                    break;
                case "recepcionista":
                    redirectPath = "/Recepcionista/dashboard.jsp";
                    break;
                default:
                    redirectPath = "/index.jsp";
            }

            response.sendRedirect(request.getContextPath() + redirectPath);
        } else {
            // Registrar tentativa de login falha
            logDAO.registrarLog(
                    0,
                    "LOGIN_FALHA",
                    "sistema",
                    0,
                    "Tentativa de login falha para usuário: " + username,
                    ip,
                    navegador
            );
            request.setAttribute("erro", "Usuário ou senha inválidos!");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if ("/logout".equals(request.getServletPath())) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
                if (usuario != null) {
                    // Registrar LOGOUT
                    logDAO.registrarLog(
                            usuario.getIdUsuario(),
                            "LOGOUT",
                            "sistema",
                            0,
                            "Usuário " + usuario.getNome() + " fez logout do sistema",
                            request.getRemoteAddr(),
                            request.getHeader("User-Agent")
                    );
                }
                session.invalidate();
            }
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }
    }
}