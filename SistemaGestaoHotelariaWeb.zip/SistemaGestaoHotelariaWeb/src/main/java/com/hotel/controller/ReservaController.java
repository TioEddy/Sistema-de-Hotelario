package com.hotel.controller;

import com.hotel.dao.ReservaDAO;
import com.hotel.dao.ClienteDAO;
import com.hotel.dao.QuartoDAO;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Reserva;
import com.hotel.model.Usuario;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/reservas",
        "/Admin/reservas/listar",
        "/Admin/reservas/salvar",
        "/Admin/reservas/editar",
        "/Admin/reservas/quartos/disponiveis"
})
@MultipartConfig(maxFileSize = 5 * 1024 * 1024)
public class ReservaController extends HttpServlet {

    private ReservaDAO reservaDAO;
    private LogSistemaDAO logDAO;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat sdfDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    public void init() {
        reservaDAO = new ReservaDAO();
        logDAO = new LogSistemaDAO();
        System.out.println("✅ ReservaController iniciado com sucesso!");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        System.out.println("📥 GET request: " + path);

        if ("/Admin/reservas".equals(path)) {
            request.getRequestDispatcher("/Admin/reservas.jsp").forward(request, response);

        } else if ("/Admin/reservas/listar".equals(path)) {
            listarReservas(response);

        } else if ("/Admin/reservas/editar".equals(path)) {
            editarReserva(request, response);

        } else if ("/Admin/reservas/quartos/disponiveis".equals(path)) {
            listarQuartosDisponiveis(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        System.out.println("📤 POST request: " + path);

        if ("/Admin/reservas/salvar".equals(path)) {
            salvarReserva(request, response);
        }
    }

    // Método auxiliar para normalizar data (remover hora)
    private Date normalizarData(Date date) {
        if (date == null) return null;
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    // Obter data atual sem hora
    private Date getHojeSemHora() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    // VALIDAÇÃO COMPLETA DE DATAS
    private String validarDatasReserva(Date dataEntrada, Date dataSaida) {
        if (dataEntrada == null || dataSaida == null) {
            return "Datas de entrada e saída são obrigatórias";
        }

        Date hoje = getHojeSemHora();
        Date entrada = normalizarData(dataEntrada);
        Date saida = normalizarData(dataSaida);

        // 1. Data de entrada não pode ser anterior a hoje
        if (entrada.before(hoje)) {
            return "A data de entrada não pode ser anterior a hoje";
        }

        // 2. Data de saída deve ser após data de entrada
        if (!saida.after(entrada)) {
            return "A data de saída deve ser posterior à data de entrada";
        }

        // 3. Período mínimo de 1 dia
        long diffMilissegundos = saida.getTime() - entrada.getTime();
        long diffDias = diffMilissegundos / (1000 * 60 * 60 * 24);

        if (diffDias < 1) {
            return "A estadia deve ter no mínimo 1 dia";
        }

        // 4. Período máximo de 30 dias
        if (diffDias > 30) {
            return "O período máximo de estadia é de 30 dias";
        }

        return null; // null significa válido
    }

    // LISTAR RESERVAS
    private void listarReservas(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            List<Reserva> reservas = reservaDAO.listarTodas();

            StringBuilder json = new StringBuilder();
            json.append("{\"reservas\":[");

            for (int i = 0; i < reservas.size(); i++) {
                Reserva r = reservas.get(i);
                if (i > 0) json.append(",");

                json.append("{");
                json.append("\"idReserva\":").append(r.getIdReserva()).append(",");
                json.append("\"idCliente\":").append(r.getIdCliente()).append(",");
                json.append("\"nomeCliente\":\"").append(escapeJson(r.getNomeCliente())).append("\",");
                json.append("\"idQuarto\":").append(r.getIdQuarto()).append(",");
                json.append("\"numeroQuarto\":\"").append(escapeJson(r.getNumeroQuarto())).append("\",");
                json.append("\"tipoQuarto\":\"").append(escapeJson(r.getTipoQuarto())).append("\",");
                json.append("\"precoDiaria\":").append(r.getPrecoDiaria()).append(",");
                json.append("\"dataEntrada\":\"").append(r.getDataEntrada() != null ? sdf.format(r.getDataEntrada()) : "").append("\",");
                json.append("\"dataSaida\":\"").append(r.getDataSaida() != null ? sdf.format(r.getDataSaida()) : "").append("\",");
                json.append("\"numeroHospedes\":").append(r.getNumeroHospedes()).append(",");
                json.append("\"estadoReserva\":\"").append(escapeJson(r.getEstadoReserva())).append("\",");
                json.append("\"observacoes\":\"").append(escapeJson(r.getObservacoes())).append("\",");
                json.append("\"dataRegistro\":\"").append(r.getDataReserva() != null ? sdfDateTime.format(r.getDataReserva()) : "").append("\"");
                json.append("}");
            }

            json.append("],\"total\":").append(reservas.size()).append("}");
            out.print(json.toString());

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"reservas\":[], \"total\":0, \"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // LISTAR QUARTOS DISPONÍVEIS
    private void listarQuartosDisponiveis(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String dataEntradaStr = request.getParameter("dataEntrada");
            String dataSaidaStr = request.getParameter("dataSaida");
            String idReservaAtualStr = request.getParameter("idReservaAtual");

            if (dataEntradaStr == null || dataSaidaStr == null) {
                out.print("{\"quartos\":[], \"error\": \"Datas não informadas\"}");
                out.flush();
                return;
            }

            Date dataEntrada = sdf.parse(dataEntradaStr);
            Date dataSaida = sdf.parse(dataSaidaStr);

            // Validar datas antes de buscar quartos
            String erroValidacao = validarDatasReserva(dataEntrada, dataSaida);
            if (erroValidacao != null) {
                out.print("{\"quartos\":[], \"error\": \"" + escapeJson(erroValidacao) + "\"}");
                out.flush();
                return;
            }

            com.hotel.dao.QuartoDAO quartoDAO = new com.hotel.dao.QuartoDAO();
            List<com.hotel.model.Quarto> quartos;

            if (idReservaAtualStr != null && !idReservaAtualStr.isEmpty()) {
                int idReservaAtual = Integer.parseInt(idReservaAtualStr);
                quartos = reservaDAO.listarQuartosDisponiveisParaEdicao(dataEntrada, dataSaida, idReservaAtual);
            } else {
                quartos = reservaDAO.listarQuartosDisponiveis(dataEntrada, dataSaida);
            }

            StringBuilder json = new StringBuilder();
            json.append("{\"quartos\":[");

            for (int i = 0; i < quartos.size(); i++) {
                com.hotel.model.Quarto q = quartos.get(i);
                if (i > 0) json.append(",");
                json.append("{");
                json.append("\"idQuarto\":").append(q.getIdQuarto()).append(",");
                json.append("\"numeroQuarto\":\"").append(escapeJson(q.getNumeroQuarto())).append("\",");
                json.append("\"tipoQuarto\":\"").append(escapeJson(q.getTipoQuarto())).append("\",");
                json.append("\"precoDiaria\":").append(q.getPrecoDiaria());
                json.append("}");
            }

            json.append("]}");
            out.print(json.toString());

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"quartos\":[], \"error\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // EDITAR RESERVA
    private void editarReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"error\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            Reserva reserva = reservaDAO.buscarPorId(id);

            if (reserva != null) {
                StringBuilder json = new StringBuilder();
                json.append("{");
                json.append("\"idReserva\":").append(reserva.getIdReserva()).append(",");
                json.append("\"idCliente\":").append(reserva.getIdCliente()).append(",");
                json.append("\"nomeCliente\":\"").append(escapeJson(reserva.getNomeCliente())).append("\",");
                json.append("\"idQuarto\":").append(reserva.getIdQuarto()).append(",");
                json.append("\"numeroQuarto\":\"").append(escapeJson(reserva.getNumeroQuarto())).append("\",");
                json.append("\"tipoQuarto\":\"").append(escapeJson(reserva.getTipoQuarto())).append("\",");
                json.append("\"precoDiaria\":").append(reserva.getPrecoDiaria()).append(",");
                json.append("\"dataEntrada\":\"").append(reserva.getDataEntrada() != null ? sdf.format(reserva.getDataEntrada()) : "").append("\",");
                json.append("\"dataSaida\":\"").append(reserva.getDataSaida() != null ? sdf.format(reserva.getDataSaida()) : "").append("\",");
                json.append("\"numeroHospedes\":").append(reserva.getNumeroHospedes()).append(",");
                json.append("\"estadoReserva\":\"").append(escapeJson(reserva.getEstadoReserva())).append("\",");
                json.append("\"observacoes\":\"").append(escapeJson(reserva.getObservacoes())).append("\",");
                json.append("\"dataRegistro\":\"").append(reserva.getDataReserva() != null ? sdfDateTime.format(reserva.getDataReserva()) : "").append("\"");
                json.append("}");
                out.print(json.toString());
            } else {
                out.print("{\"error\": \"Reserva não encontrada\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"error\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // SALVAR RESERVA
    private void salvarReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            String idClienteStr = request.getParameter("idCliente");
            String idQuartoStr = request.getParameter("idQuarto");
            String dataEntradaStr = request.getParameter("dataEntrada");
            String dataSaidaStr = request.getParameter("dataSaida");
            String numeroHospedesStr = request.getParameter("numeroHospedes");
            String estadoReserva = request.getParameter("estadoReserva");
            String observacoes = request.getParameter("observacoes");

            // Validação de campos obrigatórios
            if (idClienteStr == null || idClienteStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Selecione um cliente\"}");
                out.flush();
                return;
            }

            if (idQuartoStr == null || idQuartoStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Selecione um quarto\"}");
                out.flush();
                return;
            }

            if (dataEntradaStr == null || dataEntradaStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Informe a data de entrada\"}");
                out.flush();
                return;
            }

            if (dataSaidaStr == null || dataSaidaStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Informe a data de saída\"}");
                out.flush();
                return;
            }

            int id = (idStr != null && !idStr.trim().isEmpty()) ? Integer.parseInt(idStr.trim()) : 0;
            int idCliente = Integer.parseInt(idClienteStr.trim());
            int idQuarto = Integer.parseInt(idQuartoStr.trim());
            int numeroHospedes = (numeroHospedesStr != null && !numeroHospedesStr.trim().isEmpty()) ?
                    Integer.parseInt(numeroHospedesStr.trim()) : 1;

            Date entradaDate = sdf.parse(dataEntradaStr);
            Date saidaDate = sdf.parse(dataSaidaStr);

            // VALIDAÇÃO DE DATAS (front-end + back-end)
            String erroValidacao = validarDatasReserva(entradaDate, saidaDate);
            if (erroValidacao != null) {
                out.print("{\"success\": false, \"message\": \"" + escapeJson(erroValidacao) + "\"}");
                out.flush();
                return;
            }

            // VERIFICAR DISPONIBILIDADE DO QUARTO
            boolean quartoDisponivel;
            if (id == 0) {
                quartoDisponivel = reservaDAO.isQuartoDisponivel(idQuarto, entradaDate, saidaDate, null);
            } else {
                quartoDisponivel = reservaDAO.isQuartoDisponivel(idQuarto, entradaDate, saidaDate, id);
            }

            if (!quartoDisponivel) {
                out.print("{\"success\": false, \"message\": \"O quarto selecionado não está disponível no período escolhido\"}");
                out.flush();
                return;
            }

            Reserva reserva = new Reserva();
            reserva.setIdReserva(id);
            reserva.setIdCliente(idCliente);
            reserva.setIdQuarto(idQuarto);
            reserva.setDataEntrada(entradaDate);
            reserva.setDataSaida(saidaDate);
            reserva.setNumeroHospedes(numeroHospedes);
            reserva.setEstadoReserva(estadoReserva != null ? estadoReserva : "PENDENTE");
            reserva.setObservacoes(observacoes != null ? observacoes : "");

            boolean success;
            if (id == 0) {
                success = reservaDAO.inserir(reserva);
                System.out.println("Inserindo nova reserva: " + success);
            } else {
                success = reservaDAO.atualizar(reserva);
                System.out.println("Atualizando reserva ID " + id + ": " + success);
            }

            if (success && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        id == 0 ? "CREATE" : "UPDATE",
                        "reserva",
                        reserva.getIdReserva(),
                        "Reserva " + (id == 0 ? "criada" : "atualizada") + " para cliente ID: " + idCliente + " | Período: " + dataEntradaStr + " a " + dataSaidaStr,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            System.err.println("❌ ERRO ao salvar reserva: " + e.getMessage());
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}