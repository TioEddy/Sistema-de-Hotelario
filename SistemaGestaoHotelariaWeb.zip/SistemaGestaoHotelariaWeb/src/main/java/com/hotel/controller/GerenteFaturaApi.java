package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/fatura/listar",
        "/Gerente/api/fatura/stats",
        "/Gerente/api/fatura/graficos",
        "/Gerente/api/fatura/reservas-disponiveis",
        "/Gerente/api/fatura/detalhes",
        "/Gerente/api/fatura/emitir"
})
public class GerenteFaturaApi extends HttpServlet {

    private Gson gson = new Gson();
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/fatura/listar":
                listarFaturas(request, response);
                break;
            case "/Gerente/api/fatura/stats":
                getStats(response);
                break;
            case "/Gerente/api/fatura/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/fatura/reservas-disponiveis":
                getReservasDisponiveis(response);
                break;
            case "/Gerente/api/fatura/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/fatura/emitir".equals(request.getServletPath())) {
            emitirFatura(request, response);
        }
    }

    private void listarFaturas(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String estado = request.getParameter("estado");
        String data = request.getParameter("data");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT f.id_fatura, f.numero_fatura, f.id_reserva, f.subtotal, f.iva, ");
            sql.append("f.total, f.data_emissao, DATE_ADD(f.data_emissao, INTERVAL 30 DAY) as data_vencimento, ");
            sql.append("c.nome_completo as cliente_nome, ");
            sql.append("CASE ");
            sql.append("  WHEN COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva AND estado_pagamento = 'PAGO'), 0) >= f.total THEN 'PAGA' ");
            sql.append("  WHEN DATE_ADD(f.data_emissao, INTERVAL 30 DAY) < CURDATE() THEN 'VENCIDA' ");
            sql.append("  ELSE 'PENDENTE' ");
            sql.append("END as estado_pagamento ");
            sql.append("FROM fatura f ");
            sql.append("JOIN reserva r ON f.id_reserva = r.id_reserva ");
            sql.append("JOIN cliente c ON r.id_cliente = c.id_cliente ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (c.nome_completo LIKE ? OR f.numero_fatura LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (estado != null && !estado.isEmpty()) {
                if ("PAGA".equals(estado)) {
                    sql.append("AND COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva AND estado_pagamento = 'PAGO'), 0) >= f.total ");
                } else if ("VENCIDA".equals(estado)) {
                    sql.append("AND DATE_ADD(f.data_emissao, INTERVAL 30 DAY) < CURDATE() ");
                    sql.append("AND COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva AND estado_pagamento = 'PAGO'), 0) < f.total ");
                } else if ("PENDENTE".equals(estado)) {
                    sql.append("AND DATE_ADD(f.data_emissao, INTERVAL 30 DAY) >= CURDATE() ");
                    sql.append("AND COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva AND estado_pagamento = 'PAGO'), 0) < f.total ");
                }
            }
            if (data != null && !data.isEmpty()) {
                sql.append("AND DATE(f.data_emissao) = ? ");
                params.add(data);
            }

            sql.append("ORDER BY f.id_fatura DESC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM fatura f " +
                    "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND (c.nome_completo LIKE '%" + search + "%' OR f.numero_fatura LIKE '%" + search + "%')";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray faturasArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_fatura", rs.getInt("id_fatura"));
                        obj.addProperty("numero_fatura", rs.getString("numero_fatura"));
                        obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                        obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                        obj.addProperty("subtotal", rs.getDouble("subtotal"));
                        obj.addProperty("iva", rs.getDouble("iva"));
                        obj.addProperty("total", rs.getDouble("total"));
                        obj.addProperty("data_emissao", rs.getString("data_emissao"));
                        obj.addProperty("data_vencimento", rs.getString("data_vencimento"));
                        obj.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                        faturasArray.add(obj);
                    }
                }
            }

            result.add("faturas", faturasArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("faturas", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total faturado
            String sqlFaturado = "SELECT COALESCE(SUM(total), 0) as total FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturado);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_faturado", rs.next() ? rs.getDouble("total") : 0);
            }

            // Contas a receber
            String sqlReceber = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento WHERE estado_pagamento = 'PAGO' GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE (f.total - COALESCE(p.pago, 0)) > 0";
            try (PreparedStatement stmt = conn.prepareStatement(sqlReceber);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("contas_receber", rs.next() ? rs.getDouble("total") : 0);
            }

            // Total de faturas
            String sqlTotal = "SELECT COUNT(*) as total FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_faturas", rs.next() ? rs.getInt("total") : 0);
            }

            // Faturas este mês
            String sqlMes = "SELECT COUNT(*) as total FROM fatura WHERE MONTH(data_emissao) = MONTH(CURDATE()) AND YEAR(data_emissao) = YEAR(CURDATE())";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMes);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faturas_mes", rs.next() ? rs.getInt("total") : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Por estado
            String sqlEstado = "SELECT " +
                    "SUM(CASE WHEN COALESCE(p.pago, 0) >= f.total THEN 1 ELSE 0 END) as pagas, " +
                    "SUM(CASE WHEN DATE_ADD(f.data_emissao, INTERVAL 30 DAY) < CURDATE() AND COALESCE(p.pago, 0) < f.total THEN 1 ELSE 0 END) as vencidas, " +
                    "SUM(CASE WHEN DATE_ADD(f.data_emissao, INTERVAL 30 DAY) >= CURDATE() AND COALESCE(p.pago, 0) < f.total THEN 1 ELSE 0 END) as pendentes " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento WHERE estado_pagamento = 'PAGO' GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva";
            try (PreparedStatement stmt = conn.prepareStatement(sqlEstado);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("pagas", rs.getInt("pagas"));
                    result.addProperty("vencidas", rs.getInt("vencidas"));
                    result.addProperty("pendentes", rs.getInt("pendentes"));
                }
            }

            // Faturação mensal (últimos 6 meses)
            JsonArray faturacaoMensal = new JsonArray();
            String sqlMensal = "SELECT DATE_FORMAT(data_emissao, '%b') as mes, COALESCE(SUM(total), 0) as total " +
                    "FROM fatura WHERE data_emissao >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
                    "GROUP BY YEAR(data_emissao), MONTH(data_emissao) ORDER BY data_emissao ASC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMensal);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("mes", rs.getString("mes"));
                    item.addProperty("total", rs.getDouble("total"));
                    faturacaoMensal.add(item);
                }
            }
            result.add("faturacao_mensal", faturacaoMensal);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getReservasDisponiveis(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray reservas = new JsonArray();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "tq.preco_diaria, DATEDIFF(r.data_saida, r.data_entrada) as dias, " +
                "(tq.preco_diaria * GREATEST(DATEDIFF(r.data_saida, r.data_entrada), 1)) as valor_total, " +
                "r.data_entrada, r.data_saida " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva IN ('CONFIRMADA', 'FINALIZADA', 'CHECK-IN') " +
                "AND NOT EXISTS (SELECT 1 FROM fatura WHERE fatura.id_reserva = r.id_reserva) " +
                "ORDER BY r.id_reserva DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto_num", rs.getString("quarto_num"));
                obj.addProperty("dias", rs.getInt("dias"));
                obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                obj.addProperty("valor_total", rs.getDouble("valor_total"));
                obj.addProperty("data_entrada", rs.getString("data_entrada"));
                obj.addProperty("data_saida", rs.getString("data_saida"));
                reservas.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(reservas));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT f.id_fatura, f.numero_fatura, f.id_reserva, f.subtotal, f.iva, f.total, f.data_emissao, " +
                "DATE_ADD(f.data_emissao, INTERVAL 30 DAY) as data_vencimento, " +
                "c.nome_completo as cliente_nome " +
                "FROM fatura f " +
                "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "WHERE f.id_fatura = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_fatura", rs.getInt("id_fatura"));
                    result.addProperty("numero_fatura", rs.getString("numero_fatura"));
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("subtotal", rs.getDouble("subtotal"));
                    result.addProperty("iva", rs.getDouble("iva"));
                    result.addProperty("total", rs.getDouble("total"));
                    result.addProperty("data_emissao", rs.getString("data_emissao"));
                    result.addProperty("data_vencimento", rs.getString("data_vencimento"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void emitirFatura(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            int idReserva = data.get("id_reserva").getAsInt();
            String dataVencimento = data.has("data_vencimento") && !data.get("data_vencimento").isJsonNull() ?
                    data.get("data_vencimento").getAsString() : null;

            // Verificar se já existe fatura
            String sqlCheck = "SELECT COUNT(*) FROM fatura WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlCheck)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        result.addProperty("success", false);
                        result.addProperty("message", "Esta reserva já possui uma fatura emitida");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            // Calcular valores
            String sqlValores = "SELECT tq.preco_diaria, DATEDIFF(r.data_saida, r.data_entrada) as dias, " +
                    "COALESCE((SELECT SUM(subtotal) FROM consumo_servico WHERE id_reserva = r.id_reserva), 0) as total_servicos " +
                    "FROM reserva r " +
                    "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                    "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                    "WHERE r.id_reserva = ?";

            double subtotal = 0;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlValores)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        int dias = Math.max(rs.getInt("dias"), 1);
                        double precoDiaria = rs.getDouble("preco_diaria");
                        double totalServicos = rs.getDouble("total_servicos");
                        subtotal = (precoDiaria * dias) + totalServicos;
                    }
                }
            }

            double iva = subtotal * 0.16;
            double total = subtotal + iva;

            // Gerar número da fatura
            String ano = String.valueOf(java.time.Year.now().getValue());
            String sqlSequencial = "SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(numero_fatura, '-', -1) AS UNSIGNED)), 0) + 1 as prox " +
                    "FROM fatura WHERE numero_fatura LIKE ?";
            int sequencial = 1;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlSequencial)) {
                stmt.setString(1, "FT-" + ano + "-%");
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        sequencial = rs.getInt("prox");
                    }
                }
            }
            String numeroFatura = "FT-" + ano + "-" + String.format("%04d", sequencial);
            String dataEmissao = LocalDateTime.now().format(dtf);

            String sqlInsert = "INSERT INTO fatura (numero_fatura, id_reserva, subtotal, iva, total, data_emissao) VALUES (?, ?, ?, ?, ?, ?)";
            boolean success = false;

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlInsert)) {
                stmt.setString(1, numeroFatura);
                stmt.setInt(2, idReserva);
                stmt.setDouble(3, subtotal);
                stmt.setDouble(4, iva);
                stmt.setDouble(5, total);
                stmt.setString(6, dataEmissao);
                success = stmt.executeUpdate() > 0;
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "FATURA", "fatura", 0,
                        "Fatura " + numeroFatura + " emitida para reserva ID: " + idReserva,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Fatura emitida com sucesso!" : "Erro ao emitir fatura");
            result.addProperty("numero_fatura", numeroFatura);

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}