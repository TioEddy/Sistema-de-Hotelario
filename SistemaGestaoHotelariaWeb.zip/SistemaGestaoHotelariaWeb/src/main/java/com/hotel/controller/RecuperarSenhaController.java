// src/main/java/com/hotel/controller/RecuperarSenhaController.java
package com.hotel.controller;

import com.hotel.dao.RecuperacaoSenhaDAO;
import com.hotel.dao.UsuarioDAO;
import com.hotel.model.Usuario;
import com.hotel.util.EmailUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Random;

@WebServlet(name = "RecuperarSenhaController", urlPatterns = {"/recuperarSenha", "/validarCodigo", "/redefinirSenha"})
public class RecuperarSenhaController extends HttpServlet {

    private RecuperacaoSenhaDAO recuperacaoDAO;
    private UsuarioDAO usuarioDAO;
    private Gson gson = new Gson();

    @Override
    public void init() {
        recuperacaoDAO = new RecuperacaoSenhaDAO();
        usuarioDAO = new UsuarioDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        switch (path) {
            case "/recuperarSenha":
                String email = request.getParameter("email");
                result = enviarCodigoRecuperacao(email);
                break;
            case "/validarCodigo":
                String emailValidar = request.getParameter("email");
                String codigoValidar = request.getParameter("codigo");
                result = validarCodigo(emailValidar, codigoValidar);
                break;
            case "/redefinirSenha":
                String emailRedefinir = request.getParameter("email");
                String codigoRedefinir = request.getParameter("codigo");
                String novaSenha = request.getParameter("nova_senha");
                result = redefinirSenha(emailRedefinir, codigoRedefinir, novaSenha);
                break;
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private JsonObject enviarCodigoRecuperacao(String email) {
        JsonObject result = new JsonObject();

        try {
            // Verificar se o email existe no sistema
            Usuario usuario = usuarioDAO.buscarPorEmail(email);
            if (usuario == null) {
                result.addProperty("success", false);
                result.addProperty("message", "E-mail não encontrado no sistema.");
                return result;
            }

            // Gerar código de 6 dígitos
            String codigo = gerarCodigoRecuperacao();

            // Definir expiração em 5 minutos
            Date expiraEm = new Date(System.currentTimeMillis() + (5 * 60 * 1000));

            // Salvar no banco
            recuperacaoDAO.salvarCodigoRecuperacao(usuario.getIdUsuario(), codigo, expiraEm);

            // Enviar e-mail
            boolean emailEnviado = EmailUtil.enviarCodigoRecuperacao(email, usuario.getNome(), codigo);

            if (emailEnviado) {
                result.addProperty("success", true);
                result.addProperty("message", "Código de verificação enviado para " + email);
                result.addProperty("email", email);
            } else {
                result.addProperty("success", false);
                result.addProperty("message", "Erro ao enviar e-mail. Tente novamente.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", "Erro ao processar solicitação.");
        }

        return result;
    }

    private JsonObject validarCodigo(String email, String codigo) {
        JsonObject result = new JsonObject();

        boolean valido = recuperacaoDAO.validarCodigo(email, codigo);

        result.addProperty("success", valido);
        if (valido) {
            result.addProperty("message", "Código válido! Redefina sua senha.");
        } else {
            result.addProperty("message", "Código inválido ou expirado.");
        }

        return result;
    }

    private JsonObject redefinirSenha(String email, String codigo, String novaSenha) {
        JsonObject result = new JsonObject();

        // Validar código novamente
        boolean valido = recuperacaoDAO.validarCodigo(email, codigo);

        if (!valido) {
            result.addProperty("success", false);
            result.addProperty("message", "Código inválido ou expirado.");
            return result;
        }

        // Validar tamanho da senha
        if (novaSenha == null || novaSenha.length() < 4) {
            result.addProperty("success", false);
            result.addProperty("message", "A senha deve ter no mínimo 4 caracteres.");
            return result;
        }

        // Atualizar senha
        boolean atualizado = recuperacaoDAO.atualizarSenha(email, novaSenha);

        if (atualizado) {
            // Remover código usado
            recuperacaoDAO.removerCodigo(email);
            result.addProperty("success", true);
            result.addProperty("message", "Senha redefinida com sucesso! Faça login com sua nova senha.");
        } else {
            result.addProperty("success", false);
            result.addProperty("message", "Erro ao redefinir senha.");
        }

        return result;
    }

    private String gerarCodigoRecuperacao() {
        Random random = new Random();
        int codigo = 100000 + random.nextInt(900000);
        return String.valueOf(codigo);
    }
}