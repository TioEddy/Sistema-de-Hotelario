package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/reserva/listar",
        "/Recepcionista/api/reserva/criar",
        "/Recepcionista/api/reserva/atualizar",
        "/Recepcionista/api/reserva/buscar",
        "/Recepcionista/api/reserva/cancelar",
        "/Recepcionista/api/reserva/clientes",
        "/Recepcionista/api/reserva/quartos"
})
public class RecepcionistaReservaApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");
    private LogSistemaDAO logDAO = new LogSistemaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/reserva/listar":
                listarReservas(request, response);
                break;
            case "/Recepcionista/api/reserva/buscar":
                buscarReserva(request, response);
                break;
            case "/Recepcionista/api/reserva/clientes":
                listarClientes(response);
                break;
            case "/Recepcionista/api/reserva/quartos":
                listarQuartos(response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/reserva/criar":
                criarReserva(request, response);
                break;
            case "/Recepcionista/api/reserva/atualizar":
                atualizarReserva(request, response);
                break;
            case "/Recepcionista/api/reserva/cancelar":
                cancelarReserva(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    // ==================== MÉTODOS GET ====================

    private void listarReservas(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray reservas = new JsonArray();

        String sql = "SELECT r.id_reserva, r.id_cliente, c.nome_completo as cliente_nome, " +
                "r.id_quarto, q.numero_quarto as quarto_num, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_entrada, '%Y-%m-%d') as data_entrada, " +
                "DATE_FORMAT(r.data_saida, '%Y-%m-%d') as data_saida, " +
                "r.numero_hospedes, r.estado_reserva, COALESCE(r.observacoes, '') as observacoes, " +
                "DATE_FORMAT(r.data_reserva, '%Y-%m-%d %H:%i:%s') as data_registro " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "ORDER BY r.data_reserva DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject reserva = new JsonObject();
                reserva.addProperty("id_reserva", rs.getInt("id_reserva"));
                reserva.addProperty("id_cliente", rs.getInt("id_cliente"));
                reserva.addProperty("cliente_nome", rs.getString("cliente_nome"));
                reserva.addProperty("id_quarto", rs.getInt("id_quarto"));
                reserva.addProperty("quarto_num", rs.getString("quarto_num"));
                reserva.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                reserva.addProperty("data_entrada", rs.getString("data_entrada"));
                reserva.addProperty("data_saida", rs.getString("data_saida"));
                reserva.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                reserva.addProperty("estado_reserva", rs.getString("estado_reserva"));
                reserva.addProperty("observacoes", rs.getString("observacoes"));
                reserva.addProperty("data_registro", rs.getString("data_registro"));
                reservas.add(reserva);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JsonObject error = new JsonObject();
            error.addProperty("error", e.getMessage());
            out.print(gson.toJson(error));
            out.flush();
            return;
        }

        out.print(gson.toJson(reservas));
        out.flush();
    }

    private void buscarReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idReserva = request.getParameter("id");
        JsonObject result = new JsonObject();

        String sql = "SELECT r.id_reserva, r.id_cliente, c.nome_completo as cliente_nome, " +
                "r.id_quarto, q.numero_quarto as quarto_num, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_entrada, '%Y-%m-%d') as data_entrada, " +
                "DATE_FORMAT(r.data_saida, '%Y-%m-%d') as data_saida, " +
                "r.numero_hospedes, r.estado_reserva, COALESCE(r.observacoes, '') as observacoes, " +
                "DATE_FORMAT(r.data_reserva, '%Y-%m-%d %H:%i:%s') as data_registro " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.id_reserva = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idReserva));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("id_cliente", rs.getInt("id_cliente"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("id_quarto", rs.getInt("id_quarto"));
                    result.addProperty("quarto_num", rs.getString("quarto_num"));
                    result.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    result.addProperty("data_entrada", rs.getString("data_entrada"));
                    result.addProperty("data_saida", rs.getString("data_saida"));
                    result.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    result.addProperty("estado_reserva", rs.getString("estado_reserva"));
                    result.addProperty("observacoes", rs.getString("observacoes"));
                    result.addProperty("data_registro", rs.getString("data_registro"));
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                    result.addProperty("error", "Reserva não encontrada");
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void listarClientes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray jsonArray = new JsonArray();

        String sql = "SELECT id_cliente, nome_completo, telefone, email FROM cliente ORDER BY nome_completo";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_cliente", rs.getInt("id_cliente"));
                obj.addProperty("nome_completo", rs.getString("nome_completo"));
                obj.addProperty("telefone", rs.getString("telefone"));
                obj.addProperty("email", rs.getString("email"));
                jsonArray.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(jsonArray));
        out.flush();
    }

    private void listarQuartos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray jsonArray = new JsonArray();

        String sql = "SELECT q.id_quarto, q.numero_quarto, tq.nome_tipo as tipo, tq.preco_diaria, " +
                "COALESCE(q.estado, 'LIVRE') as estado " +
                "FROM quarto q " +
                "INNER JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.estado NOT IN ('MANUTENCAO') " +
                "ORDER BY q.numero_quarto";

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_quarto", rs.getInt("id_quarto"));
                obj.addProperty("numero", rs.getString("numero_quarto"));
                obj.addProperty("tipo", rs.getString("tipo"));
                obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                obj.addProperty("estado", rs.getString("estado"));
                jsonArray.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(jsonArray));
        out.flush();
    }

    // ==================== MÉTODOS POST ====================

    private void criarReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idCliente = Integer.parseInt(request.getParameter("id_cliente"));
            int idQuarto = Integer.parseInt(request.getParameter("id_quarto"));
            String dataEntrada = request.getParameter("data_entrada");
            String dataSaida = request.getParameter("data_saida");
            int numeroHospedes = Integer.parseInt(request.getParameter("numero_hospedes"));
            String estado = request.getParameter("estado");
            String observacoes = request.getParameter("observacoes");

            if (estado == null || estado.isEmpty()) {
                estado = "PENDENTE";
            }

            // Verificar disponibilidade do quarto
            String sqlCheck = "SELECT COUNT(*) as total FROM reserva WHERE id_quarto = ? " +
                    "AND estado_reserva NOT IN ('CANCELADA', 'FINALIZADA') " +
                    "AND ((data_entrada <= ? AND data_saida >= ?) OR " +
                    "(data_entrada <= ? AND data_saida >= ?) OR " +
                    "(data_entrada >= ? AND data_saida <= ?))";

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlCheck)) {
                stmt.setInt(1, idQuarto);
                stmt.setString(2, dataSaida);
                stmt.setString(3, dataEntrada);
                stmt.setString(4, dataSaida);
                stmt.setString(5, dataEntrada);
                stmt.setString(6, dataEntrada);
                stmt.setString(7, dataSaida);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next() && rs.getInt("total") > 0) {
                        result.addProperty("success", false);
                        result.addProperty("error", "Quarto já reservado para este período");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            // Inserir reserva
            String sql = "INSERT INTO reserva (id_cliente, id_quarto, data_entrada, data_saida, numero_hospedes, estado_reserva, observacoes) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, idCliente);
                stmt.setInt(2, idQuarto);
                stmt.setString(3, dataEntrada);
                stmt.setString(4, dataSaida);
                stmt.setInt(5, numeroHospedes);
                stmt.setString(6, estado);
                stmt.setString(7, observacoes);
                stmt.executeUpdate();

                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        result.addProperty("id_reserva", rs.getInt(1));
                    }
                }
            }

            // Atualizar estado do quarto
            String sqlUpdateQuarto = "UPDATE quarto SET estado = 'RESERVADO' WHERE id_quarto = ? AND estado = 'LIVRE'";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlUpdateQuarto)) {
                stmt.setInt(1, idQuarto);
                stmt.executeUpdate();
            }

            // Registrar log
            HttpSession session = request.getSession();
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            if (usuario != null) {
                logDAO.registrarLog(
                        usuario.getIdUsuario(),
                        "CREATE",
                        "reserva",
                        result.get("id_reserva").getAsInt(),
                        "Nova reserva criada para cliente ID: " + idCliente,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            result.addProperty("success", true);
            result.addProperty("message", "Reserva criada com sucesso!");

        } catch (Exception e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void atualizarReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            int idCliente = Integer.parseInt(request.getParameter("id_cliente"));
            int idQuarto = Integer.parseInt(request.getParameter("id_quarto"));
            String dataEntrada = request.getParameter("data_entrada");
            String dataSaida = request.getParameter("data_saida");
            int numeroHospedes = Integer.parseInt(request.getParameter("numero_hospedes"));
            String estado = request.getParameter("estado");
            String observacoes = request.getParameter("observacoes");

            if (estado == null || estado.isEmpty()) {
                estado = "PENDENTE";
            }

            // Buscar quarto antigo
            int quartoAntigo = 0;
            String sqlQuartoAntigo = "SELECT id_quarto FROM reserva WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlQuartoAntigo)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        quartoAntigo = rs.getInt("id_quarto");
                    }
                }
            }

            // Verificar disponibilidade se o quarto mudou
            if (quartoAntigo != idQuarto) {
                String sqlCheck = "SELECT COUNT(*) as total FROM reserva WHERE id_quarto = ? AND id_reserva != ? " +
                        "AND estado_reserva NOT IN ('CANCELADA', 'FINALIZADA') " +
                        "AND ((data_entrada <= ? AND data_saida >= ?) OR " +
                        "(data_entrada <= ? AND data_saida >= ?) OR " +
                        "(data_entrada >= ? AND data_saida <= ?))";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sqlCheck)) {
                    stmt.setInt(1, idQuarto);
                    stmt.setInt(2, idReserva);
                    stmt.setString(3, dataSaida);
                    stmt.setString(4, dataEntrada);
                    stmt.setString(5, dataSaida);
                    stmt.setString(6, dataEntrada);
                    stmt.setString(7, dataEntrada);
                    stmt.setString(8, dataSaida);
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next() && rs.getInt("total") > 0) {
                            result.addProperty("success", false);
                            result.addProperty("error", "Quarto já reservado para este período");
                            out.print(gson.toJson(result));
                            out.flush();
                            return;
                        }
                    }
                }
            }

            // Atualizar reserva
            String sql = "UPDATE reserva SET id_cliente = ?, id_quarto = ?, data_entrada = ?, data_saida = ?, " +
                    "numero_hospedes = ?, estado_reserva = ?, observacoes = ? WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idCliente);
                stmt.setInt(2, idQuarto);
                stmt.setString(3, dataEntrada);
                stmt.setString(4, dataSaida);
                stmt.setInt(5, numeroHospedes);
                stmt.setString(6, estado);
                stmt.setString(7, observacoes);
                stmt.setInt(8, idReserva);
                stmt.executeUpdate();
            }

            // Atualizar estados dos quartos
            if (quartoAntigo != 0 && quartoAntigo != idQuarto) {
                String sqlLiberarAntigo = "UPDATE quarto SET estado = 'LIVRE' WHERE id_quarto = ?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sqlLiberarAntigo)) {
                    stmt.setInt(1, quartoAntigo);
                    stmt.executeUpdate();
                }
            }

            if (estado.equals("CANCELADA") || estado.equals("FINALIZADA")) {
                String sqlLiberarQuarto = "UPDATE quarto SET estado = 'LIVRE' WHERE id_quarto = ?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sqlLiberarQuarto)) {
                    stmt.setInt(1, idQuarto);
                    stmt.executeUpdate();
                }
            } else if (estado.equals("CONFIRMADA")) {
                String sqlReservarQuarto = "UPDATE quarto SET estado = 'RESERVADO' WHERE id_quarto = ? AND estado = 'LIVRE'";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sqlReservarQuarto)) {
                    stmt.setInt(1, idQuarto);
                    stmt.executeUpdate();
                }
            }

            // Registrar log
            HttpSession session = request.getSession();
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            if (usuario != null) {
                logDAO.registrarLog(
                        usuario.getIdUsuario(),
                        "UPDATE",
                        "reserva",
                        idReserva,
                        "Reserva atualizada para novo estado: " + estado,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            result.addProperty("success", true);
            result.addProperty("message", "Reserva atualizada com sucesso!");

        } catch (Exception e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void cancelarReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));

            // Buscar quarto
            int idQuarto = 0;
            String sqlQuarto = "SELECT id_quarto FROM reserva WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlQuarto)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        idQuarto = rs.getInt("id_quarto");
                    }
                }
            }

            // Atualizar estado da reserva
            String sql = "UPDATE reserva SET estado_reserva = 'CANCELADA' WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idReserva);
                stmt.executeUpdate();
            }

            // Liberar quarto
            if (idQuarto > 0) {
                String sqlLiberarQuarto = "UPDATE quarto SET estado = 'LIVRE' WHERE id_quarto = ?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sqlLiberarQuarto)) {
                    stmt.setInt(1, idQuarto);
                    stmt.executeUpdate();
                }
            }

            // Registrar log
            HttpSession session = request.getSession();
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
            if (usuario != null) {
                logDAO.registrarLog(
                        usuario.getIdUsuario(),
                        "UPDATE",
                        "reserva",
                        idReserva,
                        "Reserva cancelada",
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            result.addProperty("success", true);
            result.addProperty("message", "Reserva cancelada com sucesso!");

        } catch (Exception e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}