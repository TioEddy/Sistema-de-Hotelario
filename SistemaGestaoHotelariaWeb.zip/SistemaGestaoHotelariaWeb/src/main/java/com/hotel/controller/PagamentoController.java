// src/main/java/com/hotel/controller/PagamentoController.java
package com.hotel.controller;

import com.hotel.dao.*;
import com.hotel.model.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Admin/pagamentos",
        "/Admin/pagamentos/listar",
        "/Admin/pagamentos/salvar",
        "/Admin/pagamentos/editar",
        "/Admin/pagamentos/excluir",
        "/Admin/pagamentos/reservas",
        "/Admin/pagamentos/metodos",
        "/Admin/pagamentos/stats"
})
public class PagamentoController extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    // ==================== LISTAR PAGAMENTOS ====================
    private void listarPagamentos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT p.id_pagamento, p.id_reserva, p.valor, p.id_metodo_pagamento, " +
                "mp.nome_metodo as metodo, p.referencia_pagamento as referencia, " +
                "p.data_pagamento, p.estado_pagamento, " +
                "c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo " +
                "FROM pagamento p " +
                "JOIN reserva r ON p.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN metodo_pagamento mp ON p.id_metodo_pagamento = mp.id_metodo_pagamento " +
                "ORDER BY p.data_pagamento DESC";

        System.out.println("=== LISTANDO PAGAMENTOS ===");

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_pagamento", rs.getInt("id_pagamento"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("valor", rs.getDouble("valor"));
                obj.addProperty("metodo", rs.getString("metodo") != null ? rs.getString("metodo") : "-");
                obj.addProperty("referencia", rs.getString("referencia") != null ? rs.getString("referencia") : "-");
                obj.addProperty("data_pagamento", rs.getTimestamp("data_pagamento") != null ? sdfData.format(rs.getTimestamp("data_pagamento")) : "");
                obj.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto_num", rs.getString("numero_quarto") + " - " + rs.getString("quarto_tipo"));
                jsonArray.add(obj);
            }

            System.out.println("Pagamentos encontrados: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            System.err.println("Erro ao listar pagamentos: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== LISTAR RESERVAS PARA PAGAMENTO ====================
    private void listarReservasParaPagamento(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "tq.preco_diaria, " +
                "DATEDIFF(r.data_saida, r.data_entrada) as dias, " +
                "r.data_entrada, r.data_saida, r.estado_reserva, " +
                "COALESCE((SELECT SUM(valor) FROM pagamento WHERE id_reserva = r.id_reserva AND estado_pagamento = 'PAGO'), 0) as total_pago " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva IN ('CONFIRMADA', 'PENDENTE', 'FINALIZADA') " +
                "ORDER BY r.id_reserva DESC";

        System.out.println("=== LISTANDO RESERVAS PARA PAGAMENTO ===");

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + rs.getString("quarto_tipo"));
                obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                obj.addProperty("dias", rs.getInt("dias"));
                double valorTotal = rs.getDouble("preco_diaria") * rs.getInt("dias");
                obj.addProperty("valor_total", valorTotal);
                obj.addProperty("total_pago", rs.getDouble("total_pago"));
                obj.addProperty("saldo_pendente", valorTotal - rs.getDouble("total_pago"));
                obj.addProperty("periodo", formatarDataBR(rs.getString("data_entrada")) + " a " + formatarDataBR(rs.getString("data_saida")));
                obj.addProperty("estado_reserva", rs.getString("estado_reserva"));
                jsonArray.add(obj);
            }

            System.out.println("Reservas encontradas: " + jsonArray.size());
            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            System.err.println("Erro ao listar reservas: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== LISTAR MÉTODOS DE PAGAMENTO ====================
    private void listarMetodosPagamento(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT id_metodo_pagamento, nome_metodo FROM metodo_pagamento ORDER BY id_metodo_pagamento";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                obj.addProperty("nome_metodo", rs.getString("nome_metodo"));
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // ==================== OBTER ESTATÍSTICAS ====================
    private void getStats(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total arrecadado (pagamentos PAGO)
            String sqlArrecadado = "SELECT COALESCE(SUM(valor), 0) FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlArrecadado);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_arrecadado", rs.next() ? rs.getDouble(1) : 0);
            }

            // Total pendente (saldo de reservas confirmadas)
            String sqlPendente = "SELECT COALESCE(SUM(tq.preco_diaria * DATEDIFF(r.data_saida, r.data_entrada) - " +
                    "COALESCE((SELECT SUM(valor) FROM pagamento WHERE id_reserva = r.id_reserva AND estado_pagamento = 'PAGO'), 0)), 0) " +
                    "FROM reserva r " +
                    "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                    "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                    "WHERE r.estado_reserva IN ('CONFIRMADA', 'PENDENTE')";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPendente);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_pendente", rs.next() ? rs.getDouble(1) : 0);
            }

            // Pagamentos hoje
            String sqlHoje = "SELECT COUNT(*) FROM pagamento WHERE DATE(data_pagamento) = CURDATE()";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHoje);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("pagamentos_hoje", rs.next() ? rs.getInt(1) : 0);
            }

            // Ticket médio
            String sqlTicket = "SELECT COALESCE(AVG(valor), 0) FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTicket);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("ticket_medio", rs.next() ? rs.getDouble(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total_arrecadado", 0);
            stats.addProperty("total_pendente", 0);
            stats.addProperty("pagamentos_hoje", 0);
            stats.addProperty("ticket_medio", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    // ==================== EDITAR PAGAMENTO (buscar por ID) ====================
    private void editarPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT id_pagamento, id_reserva, valor, id_metodo_pagamento, " +
                "referencia_pagamento, data_pagamento, estado_pagamento " +
                "FROM pagamento WHERE id_pagamento = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_pagamento", rs.getInt("id_pagamento"));
                    obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                    obj.addProperty("valor", rs.getDouble("valor"));
                    obj.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                    obj.addProperty("referencia", rs.getString("referencia_pagamento"));
                    obj.addProperty("data_pagamento", rs.getTimestamp("data_pagamento") != null ?
                            new SimpleDateFormat("yyyy-MM-dd'T'HH:mm").format(rs.getTimestamp("data_pagamento")) : "");
                    obj.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                    out.print(gson.toJson(obj));
                } else {
                    out.print("{}");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{}");
        }
        out.flush();
    }

    // ==================== SALVAR PAGAMENTO (SEM id_usuario) ====================
    private void salvarPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String idStr = request.getParameter("id");
            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            double valor = Double.parseDouble(request.getParameter("valor"));
            int idMetodoPagamento = Integer.parseInt(request.getParameter("id_metodo_pagamento"));
            String referencia = request.getParameter("referencia");
            String dataPagamento = request.getParameter("data_pagamento");
            String estadoPagamento = request.getParameter("estado_pagamento");

            boolean success = false;

            if (idStr != null && !idStr.isEmpty()) {
                // UPDATE
                String sql = "UPDATE pagamento SET valor = ?, id_metodo_pagamento = ?, " +
                        "referencia_pagamento = ?, data_pagamento = ?, estado_pagamento = ? " +
                        "WHERE id_pagamento = ?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setDouble(1, valor);
                    stmt.setInt(2, idMetodoPagamento);
                    stmt.setString(3, referencia);
                    stmt.setString(4, dataPagamento != null && !dataPagamento.isEmpty() ?
                            dataPagamento.replace('T', ' ') + ":00" : null);
                    stmt.setString(5, estadoPagamento);
                    stmt.setInt(6, Integer.parseInt(idStr));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                // INSERT (SEM id_usuario)
                String sql = "INSERT INTO pagamento (id_reserva, valor, id_metodo_pagamento, " +
                        "referencia_pagamento, data_pagamento, estado_pagamento) " +
                        "VALUES (?, ?, ?, ?, NOW(), ?)";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    stmt.setInt(1, idReserva);
                    stmt.setDouble(2, valor);
                    stmt.setInt(3, idMetodoPagamento);
                    stmt.setString(4, referencia);
                    stmt.setString(5, estadoPagamento);
                    success = stmt.executeUpdate() > 0;
                }
            }

            JsonObject result = new JsonObject();
            result.addProperty("success", success);
            out.print(gson.toJson(result));

        } catch (Exception e) {
            e.printStackTrace();
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    // ==================== EXCLUIR PAGAMENTO ====================
    private void excluirPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            String sql = "DELETE FROM pagamento WHERE id_pagamento = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                boolean success = stmt.executeUpdate() > 0;

                JsonObject result = new JsonObject();
                result.addProperty("success", success);
                out.print(gson.toJson(result));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JsonObject result = new JsonObject();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    private String formatarDataBR(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return "";
        String[] parts = dateStr.split("-");
        if (parts.length == 3) {
            return parts[2] + "/" + parts[1] + "/" + parts[0];
        }
        return dateStr;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/pagamentos".equals(path)) {
            request.getRequestDispatcher("/Admin/pagamento.jsp").forward(request, response);

        } else if ("/Admin/pagamentos/listar".equals(path)) {
            listarPagamentos(response);

        } else if ("/Admin/pagamentos/editar".equals(path)) {
            editarPagamento(request, response);

        } else if ("/Admin/pagamentos/reservas".equals(path)) {
            listarReservasParaPagamento(response);

        } else if ("/Admin/pagamentos/metodos".equals(path)) {
            listarMetodosPagamento(response);

        } else if ("/Admin/pagamentos/stats".equals(path)) {
            getStats(response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/pagamentos/salvar".equals(path)) {
            salvarPagamento(request, response);

        } else if ("/Admin/pagamentos/excluir".equals(path)) {
            excluirPagamento(request, response);
        }
    }
}