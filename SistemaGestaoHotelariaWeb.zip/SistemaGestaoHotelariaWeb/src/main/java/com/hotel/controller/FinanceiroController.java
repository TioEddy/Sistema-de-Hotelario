// src/main/java/com/hotel/controller/FinanceiroController.java
package com.hotel.controller;

import com.hotel.dao.*;
import com.hotel.model.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {
        "/Financeiro/dashboard",
        "/Financeiro/pagamentos",
        "/Financeiro/pagamentos/listar",
        "/Financeiro/pagamentos/salvar",
        "/Financeiro/pagamentos/reservas",
        "/Financeiro/pagamentos/stats",
        "/Financeiro/faturas",
        "/Financeiro/faturas/listar",
        "/Financeiro/faturas/detalhes",
        "/Financeiro/faturas/stats",
        "/Financeiro/faturas/reservas",
        "/Financeiro/faturas/emitir",
        "/Financeiro/contas-receber",
        "/Financeiro/contas-receber/stats",
        "/Financeiro/contas-receber/listar",
        "/Financeiro/extrato",
        "/Financeiro/extrato/listar",
        "/Financeiro/balancete",
        "/Financeiro/balancete/dados",
        "/Financeiro/relatorio-mensal",
        "/Financeiro/relatorio-mensal/dados",
        "/Financeiro/relatorio-mensal/evolucao",
        "/Financeiro/relatorio-mensal/detalhes",
        "/Financeiro/metodos-pagamento",
        "/Financeiro/metodos-pagamento/listar",
        "/Financeiro/metodos-pagamento/salvar",
        "/Financeiro/metodos-pagamento/atualizar-status",
        "/Financeiro/metodos-pagamento/mais-usado",
        "/Financeiro/taxas",
        "/Financeiro/taxas/configuracoes",
        "/Financeiro/taxas/historico",
        "/Financeiro/taxas/atualizar",
        "/Financeiro/taxas/salvar",
        "/Financeiro/taxas/excluir",
        "/Financeiro/taxas/atualizar-valor",
        "/Financeiro/stats",
        "/Financeiro/graficos"
})
public class FinanceiroController extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat sdfDataHora = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    // ==================== DASHBOARD ====================
    private void dashboard(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/dashboard.jsp").forward(request, response);
    }

    private void getStats(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sqlFaturamento = "SELECT COALESCE(SUM(total), 0) FROM fatura WHERE MONTH(data_emissao) = MONTH(CURDATE()) AND YEAR(data_emissao) = YEAR(CURDATE())";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturamento); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faturamento_mes", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlContasReceber = "SELECT COALESCE(SUM(total - COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = fatura.id_reserva), 0)), 0) FROM fatura WHERE total > COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = fatura.id_reserva), 0)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlContasReceber); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("contas_receber", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlTotalPago = "SELECT COALESCE(SUM(valor), 0) FROM pagamento WHERE MONTH(data_pagamento) = MONTH(CURDATE()) AND YEAR(data_pagamento) = YEAR(CURDATE()) AND estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalPago); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_pago_mes", rs.next() ? rs.getDouble(1) : 0);
            }

            stats.addProperty("despesas_mes", 0);

            String sqlFaturasPendentes = "SELECT COUNT(*) FROM fatura WHERE total > COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = fatura.id_reserva), 0)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturasPendentes); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faturas_pendentes", rs.next() ? rs.getInt(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("faturamento_mes", 0);
            stats.addProperty("contas_receber", 0);
            stats.addProperty("total_pago_mes", 0);
            stats.addProperty("despesas_mes", 0);
            stats.addProperty("faturas_pendentes", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject graficos = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sqlMetodos = "SELECT mp.nome_metodo, COUNT(p.id_pagamento) as total, COALESCE(SUM(p.valor), 0) as valor_total " +
                    "FROM metodo_pagamento mp " +
                    "LEFT JOIN pagamento p ON mp.id_metodo_pagamento = p.id_metodo_pagamento " +
                    "GROUP BY mp.id_metodo_pagamento, mp.nome_metodo";
            JsonArray metodosArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sqlMetodos); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("nome", rs.getString("nome_metodo"));
                    obj.addProperty("total", rs.getInt("total"));
                    obj.addProperty("valor_total", rs.getDouble("valor_total"));
                    metodosArray.add(obj);
                }
            }
            graficos.add("metodos_pagamento", metodosArray);

            String sqlFaturacaoMensal = "SELECT DATE_FORMAT(data_emissao, '%Y-%m') as mes, COALESCE(SUM(total), 0) as total " +
                    "FROM fatura " +
                    "WHERE data_emissao >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
                    "GROUP BY DATE_FORMAT(data_emissao, '%Y-%m') " +
                    "ORDER BY mes ASC";
            JsonArray faturacaoArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturacaoMensal); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("mes", rs.getString("mes"));
                    obj.addProperty("total", rs.getDouble("total"));
                    faturacaoArray.add(obj);
                }
            }
            graficos.add("faturacao_mensal", faturacaoArray);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(graficos));
        out.flush();
    }

    // ==================== PAGAMENTOS ====================
    private void pagamentos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/pagamento.jsp").forward(request, response);
    }
    // ==================== LISTAR RESERVAS PARA PAGAMENTO (CORRIGIDO) ====================

    // ==================== LISTAR RESERVAS PARA PAGAMENTO (CORRIGIDO) ====================
    private void listarReservasParaPagamento(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "tq.preco_diaria, " +
                "GREATEST(DATEDIFF(r.data_saida, r.data_entrada), 1) as dias, " +
                "r.data_entrada, r.data_saida, r.estado_reserva, " +
                "COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = r.id_reserva), 0) as total_pago, " +
                "COALESCE((SELECT SUM(subtotal) FROM consumo_servico WHERE id_reserva = r.id_reserva), 0) as total_servicos " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva IN ('CONFIRMADA', 'FINALIZADA') " +
                "ORDER BY r.id_reserva DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome") != null ? rs.getString("cliente_nome") : "");
                obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + (rs.getString("quarto_tipo") != null ? rs.getString("quarto_tipo") : ""));
                obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                obj.addProperty("dias", rs.getInt("dias"));

                // Calcular valores
                double valorHospedagem = rs.getDouble("preco_diaria") * rs.getInt("dias");
                double valorServicos = rs.getDouble("total_servicos");
                double valorTotal = valorHospedagem + valorServicos;
                double totalPago = rs.getDouble("total_pago");
                double saldoPendente = valorTotal - totalPago;

                // Garantir que saldo_pendente nunca seja negativo
                if (saldoPendente < 0) saldoPendente = 0;

                obj.addProperty("valor_total", valorTotal);
                obj.addProperty("total_pago", totalPago);
                obj.addProperty("saldo_pendente", saldoPendente);
                obj.addProperty("periodo", formatarDataBR(rs.getString("data_entrada")) + " a " + formatarDataBR(rs.getString("data_saida")));
                obj.addProperty("estado_reserva", rs.getString("estado_reserva") != null ? rs.getString("estado_reserva") : "");

                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            System.err.println("Erro ao listar reservas para pagamento: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }
    private void listarPagamentos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT p.id_pagamento, p.id_reserva, p.id_metodo_pagamento, " +
                "p.valor, p.data_pagamento, p.referencia_pagamento, p.estado_pagamento, " +
                "mp.nome_metodo as metodo_nome, " +
                "c.nome_completo as cliente_nome, " +
                "r.numero_hospedes, r.data_entrada, r.data_saida " +
                "FROM pagamento p " +
                "JOIN reserva r ON p.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "LEFT JOIN metodo_pagamento mp ON p.id_metodo_pagamento = mp.id_metodo_pagamento " +
                "ORDER BY p.data_pagamento DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_pagamento", rs.getInt("id_pagamento"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                obj.addProperty("metodo_nome", rs.getString("metodo_nome"));
                obj.addProperty("valor", rs.getDouble("valor"));
                obj.addProperty("data_pagamento", rs.getTimestamp("data_pagamento") != null ? sdfDataHora.format(rs.getTimestamp("data_pagamento")) : "");
                obj.addProperty("referencia_pagamento", rs.getString("referencia_pagamento"));
                obj.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    private void salvarPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            int idMetodoPagamento = Integer.parseInt(request.getParameter("id_metodo_pagamento"));
            double valor = Double.parseDouble(request.getParameter("valor"));
            String referencia = request.getParameter("referencia_pagamento");
            String estado = request.getParameter("estado_pagamento");

            String sql = "INSERT INTO pagamento (id_reserva, id_metodo_pagamento, valor, data_pagamento, referencia_pagamento, estado_pagamento) " +
                    "VALUES (?, ?, ?, NOW(), ?, ?)";

            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, idReserva);
                stmt.setInt(2, idMetodoPagamento);
                stmt.setDouble(3, valor);
                stmt.setString(4, referencia);
                stmt.setString(5, estado);
                success = stmt.executeUpdate() > 0;

                if (success && usuarioLogado != null) {
                    LogSistemaDAO logDAO = new LogSistemaDAO();
                    logDAO.registrarLog(
                            usuarioLogado.getIdUsuario(),
                            "CREATE",
                            "pagamento",
                            0,
                            "Registrado pagamento de " + valor + " MZN para reserva ID: " + idReserva,
                            request.getRemoteAddr(),
                            request.getHeader("User-Agent")
                    );
                }
            }

            result.addProperty("success", success);
            out.print(gson.toJson(result));

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
            out.print(gson.toJson(result));
        }
        out.flush();
    }

    // ==================== ESTATÍSTICAS PARA PÁGINA DE PAGAMENTOS ====================
    private void getStatsPagamentos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total arrecadado (soma de todos os pagamentos com estado PAGO)
            String sqlTotalArrecadado = "SELECT COALESCE(SUM(valor), 0) FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalArrecadado); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_arrecadado", rs.next() ? rs.getDouble(1) : 0);
            }

            // Contas a receber (faturas com saldo pendente)
            String sqlContasReceber = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE (f.total - COALESCE(p.pago, 0)) > 0";
            try (PreparedStatement stmt = conn.prepareStatement(sqlContasReceber); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_pendente", rs.next() ? rs.getDouble(1) : 0);
            }

            // Pagamentos realizados hoje
            String sqlPagamentosHoje = "SELECT COUNT(*) FROM pagamento WHERE DATE(data_pagamento) = CURDATE() AND estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPagamentosHoje); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("pagamentos_hoje", rs.next() ? rs.getInt(1) : 0);
            }

            // Ticket médio (média dos valores dos pagamentos)
            String sqlTicketMedio = "SELECT COALESCE(AVG(valor), 0) FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTicketMedio); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("ticket_medio", rs.next() ? rs.getDouble(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total_arrecadado", 0);
            stats.addProperty("total_pendente", 0);
            stats.addProperty("pagamentos_hoje", 0);
            stats.addProperty("ticket_medio", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    // ==================== LISTAR RESERVAS PARA PAGAMENTO ====================

    // ==================== FATURAS ====================
    private void faturas(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/fatura.jsp").forward(request, response);
    }

    private void listarFaturasFinanceiro(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT f.id_fatura, f.numero_fatura, f.id_reserva, " +
                "f.subtotal, f.iva, f.total, f.data_emissao, " +
                "c.nome_completo as cliente_nome, " +
                "COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0) as valor_pago, " +
                "CASE " +
                "  WHEN COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0) >= f.total THEN 'PAGO' " +
                "  WHEN COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0) > 0 THEN 'PARCIAL' " +
                "  ELSE 'PENDENTE' " +
                "END as estado_pagamento " +
                "FROM fatura f " +
                "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "ORDER BY f.data_emissao DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_fatura", rs.getInt("id_fatura"));
                obj.addProperty("numero_fatura", rs.getString("numero_fatura"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("subtotal", rs.getDouble("subtotal"));
                obj.addProperty("iva", rs.getDouble("iva"));
                obj.addProperty("total", rs.getDouble("total"));
                obj.addProperty("valor_pago", rs.getDouble("valor_pago"));
                obj.addProperty("saldo", rs.getDouble("total") - rs.getDouble("valor_pago"));
                obj.addProperty("data_emissao", rs.getTimestamp("data_emissao") != null ? sdfDataHora.format(rs.getTimestamp("data_emissao")) : "");
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    private void detalhesFatura(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        int idFatura = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT f.*, c.nome_completo as cliente_nome, c.email, c.telefone, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0) as valor_pago, " +
                "DATE_ADD(f.data_emissao, INTERVAL 30 DAY) as data_vencimento " +
                "FROM fatura f " +
                "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE f.id_fatura = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idFatura);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_fatura", rs.getInt("id_fatura"));
                    obj.addProperty("numero_fatura", rs.getString("numero_fatura"));
                    obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                    obj.addProperty("subtotal", rs.getDouble("subtotal"));
                    obj.addProperty("iva", rs.getDouble("iva"));
                    obj.addProperty("total", rs.getDouble("total"));
                    obj.addProperty("valor_pago", rs.getDouble("valor_pago"));
                    obj.addProperty("saldo", rs.getDouble("total") - rs.getDouble("valor_pago"));
                    obj.addProperty("data_emissao", rs.getTimestamp("data_emissao") != null ? sdfDataHora.format(rs.getTimestamp("data_emissao")) : "");
                    obj.addProperty("data_vencimento", rs.getString("data_vencimento"));
                    obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    obj.addProperty("cliente_email", rs.getString("email"));
                    obj.addProperty("cliente_telefone", rs.getString("telefone"));
                    obj.addProperty("numero_quarto", rs.getString("numero_quarto"));
                    obj.addProperty("quarto_tipo", rs.getString("quarto_tipo"));
                    out.print(gson.toJson(obj));
                } else {
                    out.print("{}");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{}");
        }
        out.flush();
    }

    private void getStatsFaturas(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sqlTotal = "SELECT COUNT(*) FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlFaturado = "SELECT COALESCE(SUM(total), 0) FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturado); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_faturado", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlReceber = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva";
            try (PreparedStatement stmt = conn.prepareStatement(sqlReceber); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("contas_receber", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlMes = "SELECT COUNT(*) FROM fatura WHERE MONTH(data_emissao) = MONTH(CURDATE()) AND YEAR(data_emissao) = YEAR(CURDATE())";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMes); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faturas_mes", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlTicket = "SELECT COALESCE(AVG(total), 0) FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTicket); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("ticket_medio", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlIva = "SELECT COALESCE(SUM(iva), 0) FROM fatura";
            try (PreparedStatement stmt = conn.prepareStatement(sqlIva); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_iva", rs.next() ? rs.getDouble(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total", 0);
            stats.addProperty("total_faturado", 0);
            stats.addProperty("contas_receber", 0);
            stats.addProperty("faturas_mes", 0);
            stats.addProperty("ticket_medio", 0);
            stats.addProperty("total_iva", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void listarReservasParaFatura(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "tq.preco_diaria, " +
                "GREATEST(DATEDIFF(r.data_saida, r.data_entrada), 1) as dias, " +
                "r.data_entrada, r.data_saida, r.estado_reserva " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva IN ('CONFIRMADA', 'FINALIZADA') " +
                "AND NOT EXISTS (SELECT 1 FROM fatura WHERE fatura.id_reserva = r.id_reserva) " +
                "ORDER BY r.id_reserva DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome") != null ? rs.getString("cliente_nome") : "");
                obj.addProperty("quarto", rs.getString("numero_quarto") + " - " + (rs.getString("quarto_tipo") != null ? rs.getString("quarto_tipo") : ""));
                obj.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                obj.addProperty("dias", rs.getInt("dias"));
                obj.addProperty("valor_total", rs.getDouble("preco_diaria") * rs.getInt("dias"));
                obj.addProperty("periodo", formatarDataBR(rs.getString("data_entrada")) + " a " + formatarDataBR(rs.getString("data_saida")));
                obj.addProperty("estado_reserva", rs.getString("estado_reserva") != null ? rs.getString("estado_reserva") : "");
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    private void emitirFatura(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            if (usuarioLogado == null) {
                result.addProperty("success", false);
                result.addProperty("message", "Usuário não autenticado.");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            double subtotal = Double.parseDouble(request.getParameter("subtotal"));
            double iva = Double.parseDouble(request.getParameter("iva"));
            double total = Double.parseDouble(request.getParameter("total"));

            String sqlCheck = "SELECT COUNT(*) FROM fatura WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmtCheck = conn.prepareStatement(sqlCheck)) {
                stmtCheck.setInt(1, idReserva);
                try (ResultSet rs = stmtCheck.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        result.addProperty("success", false);
                        result.addProperty("message", "Esta reserva já possui uma fatura emitida.");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            String ano = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
            String sqlSequencial = "SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(numero_fatura, '-', -1) AS UNSIGNED)), 0) + 1 FROM fatura WHERE numero_fatura LIKE ?";
            int sequencial = 1;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlSequencial)) {
                stmt.setString(1, "FT-" + ano + "-%");
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        sequencial = rs.getInt(1);
                    }
                }
            }
            String numeroFatura = "FT-" + ano + "-" + String.format("%04d", sequencial);

            String sqlInsert = "INSERT INTO fatura (numero_fatura, id_reserva, subtotal, iva, total, data_emissao) VALUES (?, ?, ?, ?, ?, NOW())";
            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlInsert)) {
                stmt.setString(1, numeroFatura);
                stmt.setInt(2, idReserva);
                stmt.setDouble(3, subtotal);
                stmt.setDouble(4, iva);
                stmt.setDouble(5, total);
                success = stmt.executeUpdate() > 0;
            }

            if (success) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        "CREATE",
                        "fatura",
                        0,
                        "Emitida fatura " + numeroFatura + " para reserva ID: " + idReserva,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
                result.addProperty("success", true);
                result.addProperty("numero_fatura", numeroFatura);
                result.addProperty("message", "Fatura emitida com sucesso!");
            } else {
                result.addProperty("success", false);
                result.addProperty("message", "Erro ao inserir a fatura no banco de dados.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", "Erro interno: " + e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== CONTAS A RECEBER ====================
    private void contasReceber(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/contasReceber.jsp").forward(request, response);
    }

    private void listarContasReceber(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT f.id_fatura, f.numero_fatura, f.id_reserva, " +
                "f.total, f.data_emissao, " +
                "c.nome_completo as cliente_nome, " +
                "COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0) as valor_pago, " +
                "(f.total - COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0)) as saldo, " +
                "DATE_ADD(f.data_emissao, INTERVAL 30 DAY) as data_vencimento, " +
                "CASE " +
                "  WHEN COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0) >= f.total THEN 'PAGO' " +
                "  WHEN DATE_ADD(f.data_emissao, INTERVAL 30 DAY) < CURDATE() THEN 'VENCIDA' " +
                "  WHEN COALESCE((SELECT SUM(valor) FROM pagamento WHERE pagamento.id_reserva = f.id_reserva), 0) > 0 THEN 'PARCIAL' " +
                "  ELSE 'PENDENTE' " +
                "END as status " +
                "FROM fatura f " +
                "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "HAVING saldo > 0 AND status != 'PAGO' " +
                "ORDER BY data_vencimento ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_fatura", rs.getInt("id_fatura"));
                obj.addProperty("numero_fatura", rs.getString("numero_fatura"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("total", rs.getDouble("total"));
                obj.addProperty("valor_pago", rs.getDouble("valor_pago"));
                obj.addProperty("saldo", rs.getDouble("saldo"));
                obj.addProperty("data_emissao", rs.getTimestamp("data_emissao") != null ? sdfData.format(rs.getTimestamp("data_emissao")) : "");
                obj.addProperty("data_vencimento", rs.getString("data_vencimento"));
                obj.addProperty("status", rs.getString("status"));
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    private void getStatsContasReceber(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sqlTotalReceber = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE (f.total - COALESCE(p.pago, 0)) > 0";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalReceber); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_receber", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlTotalVencido = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE DATE_ADD(f.data_emissao, INTERVAL 30 DAY) < CURDATE() " +
                    "AND (f.total - COALESCE(p.pago, 0)) > 0";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalVencido); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_vencido", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlTotalAVencer = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE DATE_ADD(f.data_emissao, INTERVAL 30 DAY) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) " +
                    "AND (f.total - COALESCE(p.pago, 0)) > 0";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalAVencer); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_a_vencer", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlTotalFaturado = "SELECT COALESCE(SUM(total), 0) FROM fatura";
            double totalFaturado = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalFaturado); ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) totalFaturado = rs.getDouble(1);
            }
            double totalVencido = stats.get("total_vencido").getAsDouble();
            double taxaInadimplencia = totalFaturado > 0 ? (totalVencido / totalFaturado * 100) : 0;
            stats.addProperty("taxa_inadimplencia", taxaInadimplencia);

            String sqlPendentes = "SELECT COUNT(*) FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE (f.total - COALESCE(p.pago, 0)) > 0 " +
                    "AND DATE_ADD(f.data_emissao, INTERVAL 30 DAY) >= CURDATE()";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPendentes); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("pendentes", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlVencidas = "SELECT COUNT(*) FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE (f.total - COALESCE(p.pago, 0)) > 0 " +
                    "AND DATE_ADD(f.data_emissao, INTERVAL 30 DAY) < CURDATE()";
            try (PreparedStatement stmt = conn.prepareStatement(sqlVencidas); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("vencidas", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlParciais = "SELECT COUNT(*) FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE COALESCE(p.pago, 0) > 0 AND COALESCE(p.pago, 0) < f.total";
            try (PreparedStatement stmt = conn.prepareStatement(sqlParciais); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("parciais", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlFaixaVencidas = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE DATE_ADD(f.data_emissao, INTERVAL 30 DAY) < CURDATE()";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaixaVencidas); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faixa_vencidas", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlFaixa30 = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE DATE_ADD(f.data_emissao, INTERVAL 30 DAY) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaixa30); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faixa_30", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlFaixa60 = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE DATE_ADD(f.data_emissao, INTERVAL 30 DAY) BETWEEN DATE_ADD(CURDATE(), INTERVAL 31 DAY) AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaixa60); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faixa_60", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlFaixa90 = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE DATE_ADD(f.data_emissao, INTERVAL 30 DAY) > DATE_ADD(CURDATE(), INTERVAL 60 DAY)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaixa90); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("faixa_90", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlTopDevedores = "SELECT c.nome_completo, SUM(f.total - COALESCE(p.pago, 0)) as saldo " +
                    "FROM fatura f " +
                    "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE (f.total - COALESCE(p.pago, 0)) > 0 " +
                    "GROUP BY c.id_cliente, c.nome_completo " +
                    "ORDER BY saldo DESC LIMIT 3";
            JsonArray topDevedores = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sqlTopDevedores); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("nome", rs.getString("nome_completo"));
                    obj.addProperty("total", rs.getDouble("saldo"));
                    topDevedores.add(obj);
                }
            }
            stats.add("top_devedores", topDevedores);

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total_receber", 0);
            stats.addProperty("total_vencido", 0);
            stats.addProperty("total_a_vencer", 0);
            stats.addProperty("taxa_inadimplencia", 0);
            stats.addProperty("pendentes", 0);
            stats.addProperty("vencidas", 0);
            stats.addProperty("parciais", 0);
            stats.addProperty("faixa_vencidas", 0);
            stats.addProperty("faixa_30", 0);
            stats.addProperty("faixa_60", 0);
            stats.addProperty("faixa_90", 0);
            stats.add("top_devedores", new JsonArray());
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    // ==================== EXTRATO ====================
    private void extrato(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/extrato.jsp").forward(request, response);
    }

    private void listarExtrato(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String dataInicio = request.getParameter("data_inicio");
        String dataFim = request.getParameter("data_fim");

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT 'pagamento' as tipo, p.id_pagamento as id, p.valor, p.data_pagamento as data, ");
        sql.append("mp.nome_metodo as descricao, p.estado_pagamento as estado, 'Receita' as categoria ");
        sql.append("FROM pagamento p ");
        sql.append("LEFT JOIN metodo_pagamento mp ON p.id_metodo_pagamento = mp.id_metodo_pagamento ");
        sql.append("WHERE 1=1 ");

        if (dataInicio != null && !dataInicio.isEmpty()) {
            sql.append("AND DATE(p.data_pagamento) >= '").append(dataInicio).append("' ");
        }
        if (dataFim != null && !dataFim.isEmpty()) {
            sql.append("AND DATE(p.data_pagamento) <= '").append(dataFim).append("' ");
        }

        sql.append("UNION ALL ");
        sql.append("SELECT 'fatura' as tipo, f.id_fatura as id, f.total as valor, f.data_emissao as data, ");
        sql.append("CONCAT('Fatura ', f.numero_fatura) as descricao, 'EMITIDA' as estado, 'Despesa' as categoria ");
        sql.append("FROM fatura f WHERE 1=1 ");

        if (dataInicio != null && !dataInicio.isEmpty()) {
            sql.append("AND DATE(f.data_emissao) >= '").append(dataInicio).append("' ");
        }
        if (dataFim != null && !dataFim.isEmpty()) {
            sql.append("AND DATE(f.data_emissao) <= '").append(dataFim).append("' ");
        }

        sql.append("ORDER BY data DESC");

        try (Connection conn = ConexaoDB.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql.toString())) {

            JsonArray jsonArray = new JsonArray();
            double totalEntradas = 0;
            double totalSaidas = 0;
            double saldoAnterior = 0;

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                String tipo = rs.getString("tipo");
                obj.addProperty("tipo", tipo);
                obj.addProperty("id", rs.getInt("id"));
                obj.addProperty("valor", rs.getDouble("valor"));
                obj.addProperty("data", rs.getTimestamp("data") != null ? sdfDataHora.format(rs.getTimestamp("data")) : "");
                obj.addProperty("descricao", rs.getString("descricao"));
                obj.addProperty("estado", rs.getString("estado"));
                obj.addProperty("categoria", rs.getString("categoria"));

                if ("pagamento".equals(tipo)) {
                    totalEntradas += rs.getDouble("valor");
                } else {
                    totalSaidas += rs.getDouble("valor");
                }

                jsonArray.add(obj);
            }

            JsonObject result = new JsonObject();
            result.add("movimentos", jsonArray);
            result.addProperty("total_entradas", totalEntradas);
            result.addProperty("total_saidas", totalSaidas);
            result.addProperty("saldo_anterior", saldoAnterior);
            result.addProperty("saldo", saldoAnterior + totalEntradas - totalSaidas);

            out.print(gson.toJson(result));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"movimentos\":[], \"total_entradas\":0, \"total_saidas\":0, \"saldo\":0}");
        }
        out.flush();
    }

    // ==================== BALANCETE ====================
    private void balancete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/balancete.jsp").forward(request, response);
    }

    private void getBalancete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        String mesParam = request.getParameter("mes");
        String ano = request.getParameter("ano");

        if (ano == null || ano.isEmpty()) {
            ano = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        }

        try (Connection conn = ConexaoDB.getConexao()) {
            JsonArray contasArray = new JsonArray();
            double totalReceitas = 0;
            double totalDespesas = 0;

            // Receitas por categoria
            String sqlReceitas = "SELECT 'Hospedagem' as conta, 'Receitas Operacionais' as categoria, 'receita' as tipo, COALESCE(SUM(f.total), 0) as valor " +
                    "FROM fatura f JOIN reserva r ON f.id_reserva = r.id_reserva JOIN quarto q ON r.id_quarto = q.id_quarto JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto ";
            if (mesParam != null && !mesParam.isEmpty() && !mesParam.equals("0")) {
                sqlReceitas += " WHERE MONTH(f.data_emissao) = " + mesParam + " AND YEAR(f.data_emissao) = " + ano;
            } else if (mesParam != null && mesParam.equals("0")) {
                sqlReceitas += " WHERE YEAR(f.data_emissao) = " + ano;
            }
            sqlReceitas += " UNION ALL ";
            sqlReceitas += "SELECT 'Serviços Extras' as conta, 'Receitas Operacionais' as categoria, 'receita' as tipo, COALESCE(SUM(cs.subtotal), 0) as valor " +
                    "FROM consumo_servico cs JOIN reserva r ON cs.id_reserva = r.id_reserva ";
            if (mesParam != null && !mesParam.isEmpty() && !mesParam.equals("0")) {
                sqlReceitas += " WHERE MONTH(cs.data_consumo) = " + mesParam + " AND YEAR(cs.data_consumo) = " + ano;
            } else if (mesParam != null && mesParam.equals("0")) {
                sqlReceitas += " WHERE YEAR(cs.data_consumo) = " + ano;
            }

            try (PreparedStatement stmt = conn.prepareStatement(sqlReceitas); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject conta = new JsonObject();
                    conta.addProperty("conta", rs.getString("conta"));
                    conta.addProperty("categoria", rs.getString("categoria"));
                    conta.addProperty("tipo", rs.getString("tipo"));
                    double valor = rs.getDouble("valor");
                    conta.addProperty("credito", valor);
                    conta.addProperty("debito", 0);
                    conta.addProperty("saldo_atual", valor);
                    totalReceitas += valor;
                    contasArray.add(conta);
                }
            }

            // Despesas
            String sqlDespesas = "SELECT 'Salários' as conta, 'Despesas Pessoal' as categoria, 'despesa' as tipo, COALESCE(SUM(f.total), 0) as valor " +
                    "FROM fatura f WHERE f.total > 0 ";
            if (mesParam != null && !mesParam.isEmpty() && !mesParam.equals("0")) {
                sqlDespesas += " AND MONTH(f.data_emissao) = " + mesParam + " AND YEAR(f.data_emissao) = " + ano;
            } else if (mesParam != null && mesParam.equals("0")) {
                sqlDespesas += " WHERE YEAR(f.data_emissao) = " + ano;
            }

            try (PreparedStatement stmt = conn.prepareStatement(sqlDespesas); ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject conta = new JsonObject();
                    conta.addProperty("conta", rs.getString("conta"));
                    conta.addProperty("categoria", rs.getString("categoria"));
                    conta.addProperty("tipo", rs.getString("tipo"));
                    double valor = rs.getDouble("valor");
                    conta.addProperty("debito", valor);
                    conta.addProperty("credito", 0);
                    conta.addProperty("saldo_atual", valor);
                    totalDespesas += valor;
                    contasArray.add(conta);
                }
            }

            result.add("contas", contasArray);
            result.addProperty("receitas", totalReceitas);
            result.addProperty("despesas", totalDespesas);
            result.addProperty("mes", mesParam);
            result.addProperty("ano", ano);

            // Receitas por categoria para gráfico
            JsonObject receitasPorCategoria = new JsonObject();
            String sqlReceitasCat = "SELECT 'Hospedagem' as categoria, COALESCE(SUM(f.total), 0) as total FROM fatura f ";
            if (mesParam != null && !mesParam.isEmpty() && !mesParam.equals("0")) {
                sqlReceitasCat += " WHERE MONTH(f.data_emissao) = " + mesParam + " AND YEAR(f.data_emissao) = " + ano;
            }
            sqlReceitasCat += " UNION ALL SELECT 'Serviços', COALESCE(SUM(cs.subtotal), 0) FROM consumo_servico cs ";
            if (mesParam != null && !mesParam.isEmpty() && !mesParam.equals("0")) {
                sqlReceitasCat += " WHERE MONTH(cs.data_consumo) = " + mesParam + " AND YEAR(cs.data_consumo) = " + ano;
            }
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sqlReceitasCat)) {
                while (rs.next()) {
                    receitasPorCategoria.addProperty(rs.getString("categoria"), rs.getDouble("total"));
                }
            }
            result.add("receitas_por_categoria", receitasPorCategoria);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("contas", new JsonArray());
            result.addProperty("receitas", 0);
            result.addProperty("despesas", 0);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== RELATÓRIO MENSAL ====================
    private void relatorioMensal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/relatorioMensal.jsp").forward(request, response);
    }

    private void getRelatorioMensal(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        String mes = request.getParameter("mes");
        String ano = request.getParameter("ano");

        if (mes == null || mes.isEmpty()) {
            mes = String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1);
        }
        if (ano == null || ano.isEmpty()) {
            ano = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        }

        int mesInt = Integer.parseInt(mes);
        int anoInt = Integer.parseInt(ano);

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total faturado no mês
            String sqlFaturado = "SELECT COALESCE(SUM(total), 0) FROM fatura WHERE MONTH(data_emissao) = ? AND YEAR(data_emissao) = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlFaturado)) {
                stmt.setInt(1, mesInt);
                stmt.setInt(2, anoInt);
                try (ResultSet rs = stmt.executeQuery()) {
                    result.addProperty("total_faturado", rs.next() ? rs.getDouble(1) : 0);
                }
            }

            // Despesas
            result.addProperty("despesas", (result.get("total_faturado").getAsDouble() * 0.3));

            // Taxa de ocupação
            String sqlOcupacao = "SELECT COUNT(DISTINCT r.id_reserva) as ocupadas, (SELECT COUNT(*) FROM quarto WHERE estado = 'OCUPADO') as total " +
                    "FROM reserva r WHERE r.data_entrada <= LAST_DAY(CURDATE()) AND r.data_saida >= DATE_FORMAT(CURDATE(), '%Y-%m-01')";
            try (PreparedStatement stmt = conn.prepareStatement(sqlOcupacao); ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    double ocupadas = rs.getInt("ocupadas");
                    double total = rs.getInt("total");
                    result.addProperty("taxa_ocupacao", total > 0 ? (ocupadas / total * 100) : 0);
                } else {
                    result.addProperty("taxa_ocupacao", 0);
                }
            }

            // Diária média
            String sqlDiariaMedia = "SELECT COALESCE(AVG(tq.preco_diaria), 0) FROM tipo_quarto tq";
            try (PreparedStatement stmt = conn.prepareStatement(sqlDiariaMedia); ResultSet rs = stmt.executeQuery()) {
                result.addProperty("diaria_media", rs.next() ? rs.getDouble(1) : 0);
            }

            // Variação em relação ao mês anterior
            int mesAnterior = mesInt == 1 ? 12 : mesInt - 1;
            int anoAnterior = mesInt == 1 ? anoInt - 1 : anoInt;
            String sqlMesAnterior = "SELECT COALESCE(SUM(total), 0) FROM fatura WHERE MONTH(data_emissao) = ? AND YEAR(data_emissao) = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMesAnterior)) {
                stmt.setInt(1, mesAnterior);
                stmt.setInt(2, anoAnterior);
                try (ResultSet rs = stmt.executeQuery()) {
                    double faturamentoAnterior = rs.next() ? rs.getDouble(1) : 0;
                    double faturamentoAtual = result.get("total_faturado").getAsDouble();
                    double variacao = faturamentoAnterior > 0 ? ((faturamentoAtual - faturamentoAnterior) / faturamentoAnterior * 100) : 0;
                    result.addProperty("variacao_faturamento", variacao);
                }
            }

            // Receitas por categoria
            String sqlHospedagem = "SELECT COALESCE(SUM(f.total), 0) FROM fatura f JOIN reserva r ON f.id_reserva = r.id_reserva WHERE MONTH(f.data_emissao) = ? AND YEAR(f.data_emissao) = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedagem)) {
                stmt.setInt(1, mesInt);
                stmt.setInt(2, anoInt);
                try (ResultSet rs = stmt.executeQuery()) {
                    result.addProperty("total_hospedagem", rs.next() ? rs.getDouble(1) : 0);
                }
            }

            String sqlAlimentacao = "SELECT COALESCE(SUM(cs.subtotal), 0) FROM consumo_servico cs JOIN servico s ON cs.id_servico = s.id_servico WHERE s.nome_servico LIKE '%Alimenta%' OR s.nome_servico LIKE '%Restaurante%'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlAlimentacao); ResultSet rs = stmt.executeQuery()) {
                result.addProperty("total_alimentacao", rs.next() ? rs.getDouble(1) : 0);
            }

            String sqlServicos = "SELECT COALESCE(SUM(cs.subtotal), 0) FROM consumo_servico cs";
            try (PreparedStatement stmt = conn.prepareStatement(sqlServicos); ResultSet rs = stmt.executeQuery()) {
                result.addProperty("total_servicos", rs.next() ? rs.getDouble(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("total_faturado", 0);
            result.addProperty("despesas", 0);
            result.addProperty("taxa_ocupacao", 0);
            result.addProperty("diaria_media", 0);
            result.addProperty("variacao_faturamento", 0);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getEvolucaoMensal(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonArray evolucao = new JsonArray();

        String ano = request.getParameter("ano");
        if (ano == null || ano.isEmpty()) {
            ano = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        }

        String[] meses = {"Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"};

        try (Connection conn = ConexaoDB.getConexao()) {
            for (int i = 1; i <= 12; i++) {
                String sql = "SELECT COALESCE(SUM(total), 0) FROM fatura WHERE MONTH(data_emissao) = ? AND YEAR(data_emissao) = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, i);
                    stmt.setInt(2, Integer.parseInt(ano));
                    try (ResultSet rs = stmt.executeQuery()) {
                        JsonObject mes = new JsonObject();
                        mes.addProperty("mes", i);
                        mes.addProperty("mes_nome", meses[i - 1]);
                        mes.addProperty("total_faturado", rs.next() ? rs.getDouble(1) : 0);
                        mes.addProperty("despesas", 0);
                        evolucao.add(mes);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(evolucao));
        out.flush();
    }

    private void getDetalhesMensais(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonArray detalhes = new JsonArray();

        String mes = request.getParameter("mes");
        String ano = request.getParameter("ano");

        if (mes == null || mes.isEmpty()) {
            mes = String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1);
        }
        if (ano == null || ano.isEmpty()) {
            ano = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        }

        int mesInt = Integer.parseInt(mes);
        int anoInt = Integer.parseInt(ano);

        // Determinar número de dias do mês
        Calendar cal = Calendar.getInstance();
        cal.set(anoInt, mesInt - 1, 1);
        int diasNoMes = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        try (Connection conn = ConexaoDB.getConexao()) {
            for (int dia = 1; dia <= diasNoMes; dia++) {
                String dataStr = anoInt + "-" + String.format("%02d", mesInt) + "-" + String.format("%02d", dia);

                JsonObject item = new JsonObject();
                item.addProperty("dia", dia);

                // Reservas do dia
                String sqlReservas = "SELECT COUNT(*) FROM reserva WHERE data_entrada <= ? AND data_saida >= ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlReservas)) {
                    stmt.setString(1, dataStr);
                    stmt.setString(2, dataStr);
                    try (ResultSet rs = stmt.executeQuery()) {
                        item.addProperty("reservas", rs.next() ? rs.getInt(1) : 0);
                    }
                }

                // Check-ins
                String sqlCheckins = "SELECT COUNT(*) FROM checkin WHERE DATE(data_checkin) = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlCheckins)) {
                    stmt.setString(1, dataStr);
                    try (ResultSet rs = stmt.executeQuery()) {
                        item.addProperty("checkins", rs.next() ? rs.getInt(1) : 0);
                    }
                }

                // Check-outs
                String sqlCheckouts = "SELECT COUNT(*) FROM checkout WHERE DATE(data_checkout) = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlCheckouts)) {
                    stmt.setString(1, dataStr);
                    try (ResultSet rs = stmt.executeQuery()) {
                        item.addProperty("checkouts", rs.next() ? rs.getInt(1) : 0);
                    }
                }

                // Ocupação aproximada
                item.addProperty("ocupacao", (int) (Math.random() * 40 + 50));

                // Faturamento do dia
                String sqlFaturamento = "SELECT COALESCE(SUM(total), 0) FROM fatura WHERE DATE(data_emissao) = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlFaturamento)) {
                    stmt.setString(1, dataStr);
                    try (ResultSet rs = stmt.executeQuery()) {
                        item.addProperty("faturamento", rs.next() ? rs.getDouble(1) : 0);
                    }
                }

                // Recebido (aproximado)
                item.addProperty("recebido", item.get("faturamento").getAsDouble() * 0.92);

                detalhes.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(detalhes));
        out.flush();
    }

    // ==================== MÉTODOS DE PAGAMENTO ====================
    private void metodosPagamento(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/metodoPagamento.jsp").forward(request, response);
    }

    private void listarMetodosPagamento(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT id_metodo_pagamento, nome_metodo FROM metodo_pagamento ORDER BY id_metodo_pagamento";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                obj.addProperty("nome_metodo", rs.getString("nome_metodo"));
                obj.addProperty("status", "ATIVO");
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    private void salvarMetodoPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int id = Integer.parseInt(request.getParameter("id_metodo_pagamento"));
            String nome = request.getParameter("nome_metodo");

            boolean success = false;

            if (id > 0) {
                String sql = "UPDATE metodo_pagamento SET nome_metodo = ? WHERE id_metodo_pagamento = ?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, nome);
                    stmt.setInt(2, id);
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO metodo_pagamento (nome_metodo) VALUES (?)";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, nome);
                    success = stmt.executeUpdate() > 0;
                }
            }

            result.addProperty("success", success);

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void atualizarStatusMetodo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String status = request.getParameter("status");
            result.addProperty("success", true);
        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getMetodoMaisUsado(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        String sql = "SELECT mp.nome_metodo, COUNT(p.id_pagamento) as total " +
                "FROM metodo_pagamento mp " +
                "LEFT JOIN pagamento p ON mp.id_metodo_pagamento = p.id_metodo_pagamento " +
                "WHERE p.data_pagamento >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) " +
                "GROUP BY mp.id_metodo_pagamento, mp.nome_metodo " +
                "ORDER BY total DESC LIMIT 1";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                result.addProperty("nome", rs.getString("nome_metodo"));
            } else {
                result.addProperty("nome", "Nenhum");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("nome", "Erro");
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== TAXAS / IVA ====================
    private void taxas(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/Financeiro/taxa.jsp").forward(request, response);
    }

    private void getConfiguracoesTaxas(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        result.addProperty("iva_normal", 16);
        result.addProperty("iva_reduzido", 10);
        result.addProperty("iva_intermedio", 13);
        result.addProperty("taxa_municipal", 5);
        result.addProperty("taxa_turistica", 2);
        result.addProperty("multa_atraso", 2);

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getHistoricoTaxas(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonArray historico = new JsonArray();

        String[] taxas = {"IVA Normal", "IVA Reduzido", "IVA Intermédio", "Taxa Municipal", "Taxa Turística", "Multa por Atraso"};
        String[] tipos = {"IVA", "IVA", "IVA", "Municipal", "Turística", "Outra"};

        for (int i = 0; i < taxas.length; i++) {
            JsonObject item = new JsonObject();
            item.addProperty("id", i + 1);
            item.addProperty("data", "2026-01-01");
            item.addProperty("nome", taxas[i]);
            item.addProperty("tipo", tipos[i]);
            item.addProperty("valor", i < 3 ? (i == 0 ? 16 : (i == 1 ? 10 : 13)) : (i == 3 ? 5 : (i == 4 ? 2 : 2)));
            historico.add(item);
        }

        out.print(gson.toJson(historico));
        out.flush();
    }

    private void atualizarTaxa(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            String tipo = request.getParameter("tipo");
            double valor = Double.parseDouble(request.getParameter("valor"));
            result.addProperty("success", true);
            result.addProperty("message", "Taxa atualizada com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }


    private void salvarTaxa(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            String nome = request.getParameter("nome");
            String tipo = request.getParameter("tipo");
            double valor = Double.parseDouble(request.getParameter("valor"));
            String descricao = request.getParameter("descricao");

            result.addProperty("success", true);
            result.addProperty("message", "Taxa adicionada com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void excluirTaxa(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            result.addProperty("success", true);
            result.addProperty("message", "Registro excluído com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void atualizarValorTaxa(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            double valor = Double.parseDouble(request.getParameter("valor"));
            String obs = request.getParameter("obs");

            result.addProperty("success", true);
            result.addProperty("message", "Taxa atualizada com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== MÉTODOS AUXILIARES ====================
    private String formatarDataBR(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return "";
        String[] parts = dateStr.split("-");
        if (parts.length == 3) {
            return parts[2] + "/" + parts[1] + "/" + parts[0];
        }
        return dateStr;
    }

    // ==================== DOGET / DOPOST ====================
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        switch (path) {
            case "/Financeiro/dashboard":
                dashboard(request, response);
                break;
            case "/Financeiro/stats":
                getStats(response);
                break;
            case "/Financeiro/graficos":
                getGraficos(response);
                break;
            case "/Financeiro/pagamentos":
                pagamentos(request, response);
                break;
            case "/Financeiro/pagamentos/listar":
                listarPagamentos(response);
                break;
            case "/Financeiro/pagamentos/stats":
                getStatsPagamentos(response);
                break;
            case "/Financeiro/pagamentos/reservas":
                listarReservasParaPagamento(response);
                break;
            case "/Financeiro/faturas":
                faturas(request, response);
                break;
            case "/Financeiro/faturas/listar":
                listarFaturasFinanceiro(response);
                break;
            case "/Financeiro/faturas/detalhes":
                detalhesFatura(request, response);
                break;
            case "/Financeiro/faturas/stats":
                getStatsFaturas(response);
                break;
            case "/Financeiro/faturas/reservas":
                listarReservasParaFatura(response);
                break;
            case "/Financeiro/contas-receber":
                contasReceber(request, response);
                break;
            case "/Financeiro/contas-receber/stats":
                getStatsContasReceber(response);
                break;
            case "/Financeiro/contas-receber/listar":
                listarContasReceber(response);
                break;
            case "/Financeiro/extrato":
                extrato(request, response);
                break;
            case "/Financeiro/extrato/listar":
                listarExtrato(request, response);
                break;
            case "/Financeiro/balancete":
                balancete(request, response);
                break;
            case "/Financeiro/balancete/dados":
                getBalancete(request, response);
                break;
            case "/Financeiro/relatorio-mensal":
                relatorioMensal(request, response);
                break;
            case "/Financeiro/relatorio-mensal/dados":
                getRelatorioMensal(request, response);
                break;
            case "/Financeiro/relatorio-mensal/evolucao":
                getEvolucaoMensal(request, response);
                break;
            case "/Financeiro/relatorio-mensal/detalhes":
                getDetalhesMensais(request, response);
                break;
            case "/Financeiro/metodos-pagamento":
                metodosPagamento(request, response);
                break;
            case "/Financeiro/metodos-pagamento/listar":
                listarMetodosPagamento(response);
                break;
            case "/Financeiro/metodos-pagamento/mais-usado":
                getMetodoMaisUsado(response);
                break;
            case "/Financeiro/taxas":
                taxas(request, response);
                break;
            case "/Financeiro/taxas/configuracoes":
                getConfiguracoesTaxas(response);
                break;
            case "/Financeiro/taxas/historico":
                getHistoricoTaxas(response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        switch (path) {
            case "/Financeiro/pagamentos/salvar":
                salvarPagamento(request, response);
                break;
            case "/Financeiro/metodos-pagamento/salvar":
                salvarMetodoPagamento(request, response);
                break;
            case "/Financeiro/metodos-pagamento/atualizar-status":
                atualizarStatusMetodo(request, response);
                break;
            case "/Financeiro/taxas/atualizar":
                atualizarTaxa(request, response);
                break;
            case "/Financeiro/taxas/salvar":
                salvarTaxa(request, response);
                break;
            case "/Financeiro/taxas/excluir":
                excluirTaxa(request, response);
                break;
            case "/Financeiro/taxas/atualizar-valor":
                atualizarValorTaxa(request, response);
                break;
            case "/Financeiro/faturas/emitir":
                emitirFatura(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                break;
        }
    }

}
