package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/pagamento/listar",
        "/Recepcionista/api/pagamento/detalhes",
        "/Recepcionista/api/pagamento/criar",
        "/Recepcionista/api/pagamento/atualizar",
        "/Recepcionista/api/pagamento/estatisticas",
        "/Recepcionista/api/metodo/listar"
})
public class RecepcionistaPagamentoApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfDataHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/pagamento/listar":
                listarPagamentos(response);
                break;
            case "/Recepcionista/api/pagamento/detalhes":
                detalhesPagamento(request, response);
                break;
            case "/Recepcionista/api/pagamento/estatisticas":
                getEstatisticas(response);
                break;
            case "/Recepcionista/api/metodo/listar":
                listarMetodos(response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/pagamento/criar":
                criarPagamento(request, response);
                break;
            case "/Recepcionista/api/pagamento/atualizar":
                atualizarPagamento(request, response);
                break;
        }
    }

    private void listarPagamentos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray pagamentos = new JsonArray();

        String sql = "SELECT p.id_pagamento, p.id_reserva, p.valor, p.metodo, p.referencia_pagamento, p.data_pagamento, p.estado_pagamento, " +
                "c.nome_completo as cliente_nome " +
                "FROM pagamento p " +
                "JOIN reserva r ON p.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "ORDER BY p.data_pagamento DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject pagamento = new JsonObject();
                pagamento.addProperty("id_pagamento", rs.getInt("id_pagamento"));
                pagamento.addProperty("id_reserva", rs.getInt("id_reserva"));
                pagamento.addProperty("valor", rs.getDouble("valor"));
                pagamento.addProperty("metodo", rs.getString("metodo"));
                pagamento.addProperty("referencia_pagamento", rs.getString("referencia_pagamento"));
                pagamento.addProperty("data_pagamento", rs.getString("data_pagamento"));
                pagamento.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                pagamento.addProperty("cliente_nome", rs.getString("cliente_nome"));
                pagamentos.add(pagamento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(pagamentos));
        out.flush();
    }

    private void detalhesPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idPagamento = request.getParameter("id");
        JsonObject result = new JsonObject();

        String sql = "SELECT p.id_pagamento, p.id_reserva, p.valor, p.metodo, p.referencia_pagamento, p.data_pagamento, p.estado_pagamento, " +
                "c.nome_completo as cliente_nome " +
                "FROM pagamento p " +
                "JOIN reserva r ON p.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "WHERE p.id_pagamento = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idPagamento));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_pagamento", rs.getInt("id_pagamento"));
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("valor", rs.getDouble("valor"));
                    result.addProperty("metodo", rs.getString("metodo"));
                    result.addProperty("referencia_pagamento", rs.getString("referencia_pagamento"));
                    result.addProperty("data_pagamento", rs.getString("data_pagamento"));
                    result.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getEstatisticas(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total arrecadado
            String sqlTotal = "SELECT COALESCE(SUM(valor), 0) as total FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("total_arrecadado", rs.getDouble("total"));
            }

            // Total pendente
            String sqlPendente = "SELECT COALESCE(SUM(valor), 0) as total FROM pagamento WHERE estado_pagamento IN ('PENDENTE', 'PARCIAL')";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPendente);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("total_pendente", rs.getDouble("total"));
            }

            // Pagamentos hoje
            String hoje = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String sqlHoje = "SELECT COUNT(*) as total FROM pagamento WHERE DATE(data_pagamento) = ? AND estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHoje)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("pagamentos_hoje", rs.getInt("total"));
                }
            }

            // Ticket médio
            String sqlTicket = "SELECT AVG(valor) as media FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTicket);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("ticket_medio", rs.getDouble("media"));
            }

            result.addProperty("success", true);

        } catch (SQLException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void listarMetodos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray metodos = new JsonArray();

        String sql = "SELECT id_metodo_pagamento, nome_metodo FROM metodo_pagamento ORDER BY nome_metodo";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject metodo = new JsonObject();
                metodo.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                metodo.addProperty("nome_metodo", rs.getString("nome_metodo"));
                metodos.add(metodo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(metodos));
        out.flush();
    }

    private void criarPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            double valor = Double.parseDouble(request.getParameter("valor"));
            String metodo = request.getParameter("metodo");
            String referencia = request.getParameter("referencia");
            String estado = request.getParameter("estado");
            String dataPagamento = sdfDataHora.format(new Date());

            String sql = "INSERT INTO pagamento (id_reserva, valor, metodo, referencia_pagamento, data_pagamento, estado_pagamento) VALUES (?, ?, ?, ?, ?, ?)";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, idReserva);
                stmt.setDouble(2, valor);
                stmt.setString(3, metodo);
                stmt.setString(4, referencia);
                stmt.setString(5, dataPagamento);
                stmt.setString(6, estado);
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    result.addProperty("id_pagamento", rs.getInt(1));
                }
            }

            result.addProperty("success", true);
            result.addProperty("message", "Pagamento registrado com sucesso!");

        } catch (Exception e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // NOVO MÉTODO: Atualizar Pagamento
    private void atualizarPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idPagamento = Integer.parseInt(request.getParameter("id_pagamento"));
            double valor = Double.parseDouble(request.getParameter("valor"));
            String metodo = request.getParameter("metodo");
            String referencia = request.getParameter("referencia");
            String estado = request.getParameter("estado");

            String sql = "UPDATE pagamento SET valor = ?, metodo = ?, referencia_pagamento = ?, estado_pagamento = ? WHERE id_pagamento = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setDouble(1, valor);
                stmt.setString(2, metodo);
                stmt.setString(3, referencia);
                stmt.setString(4, estado);
                stmt.setInt(5, idPagamento);
                stmt.executeUpdate();
            }

            result.addProperty("success", true);
            result.addProperty("message", "Pagamento atualizado com sucesso!");

        } catch (Exception e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}