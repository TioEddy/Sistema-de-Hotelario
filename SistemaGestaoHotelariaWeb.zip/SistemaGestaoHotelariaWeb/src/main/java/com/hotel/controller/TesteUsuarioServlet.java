package com.hotel.controller;

import com.hotel.dao.UsuarioDAO;
import com.hotel.model.Usuario;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/teste/usuario")
public class TesteUsuarioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        System.out.println("=== TesteUsuarioServlet chamado ===");

        UsuarioDAO dao = new UsuarioDAO();
        List<Usuario> usuarios = dao.listarTodos();

        System.out.println("Usuários encontrados: " + usuarios.size());

        Gson gson = new Gson();
        String json = gson.toJson(usuarios);

        PrintWriter out = response.getWriter();
        out.print(json);
        out.flush();

        System.out.println("JSON enviado com sucesso!");
    }
}