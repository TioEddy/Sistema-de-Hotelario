package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/reservas/listar",
        "/Gerente/api/reservas/stats",
        "/Gerente/api/reservas/graficos",
        "/Gerente/api/reservas/clientes-quartos",
        "/Gerente/reservas/detalhes",
        "/Gerente/reservas/salvar"
})
public class GerenteReservaApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/reservas/listar":
                listarReservas(request, response);
                break;
            case "/Gerente/api/reservas/stats":
                getStats(response);
                break;
            case "/Gerente/api/reservas/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/reservas/clientes-quartos":
                getClientesQuartos(response);
                break;
            case "/Gerente/reservas/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/reservas/salvar".equals(request.getServletPath())) {
            salvarReserva(request, response);
        }
    }

    private void listarReservas(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String status = request.getParameter("status");
        String data = request.getParameter("data");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT r.id_reserva, r.id_cliente, r.id_quarto, r.data_entrada, r.data_saida, ");
            sql.append("r.numero_hospedes, r.estado_reserva, r.observacoes, ");
            sql.append("c.nome_completo as cliente_nome, ");
            sql.append("q.numero_quarto, tq.nome_tipo as quarto_tipo ");
            sql.append("FROM reserva r ");
            sql.append("JOIN cliente c ON r.id_cliente = c.id_cliente ");
            sql.append("JOIN quarto q ON r.id_quarto = q.id_quarto ");
            sql.append("JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (c.nome_completo LIKE ? OR q.numero_quarto LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (status != null && !status.isEmpty()) {
                sql.append("AND r.estado_reserva = ? ");
                params.add(status);
            }
            if (data != null && !data.isEmpty()) {
                sql.append("AND (r.data_entrada = ? OR r.data_saida = ?) ");
                params.add(data);
                params.add(data);
            }

            sql.append("ORDER BY r.id_reserva DESC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM reserva r JOIN cliente c ON r.id_cliente = c.id_cliente WHERE 1=1";
            String countWhere = "";
            if (search != null && !search.isEmpty()) {
                countWhere += " AND (c.nome_completo LIKE '%" + search + "%')";
            }
            if (status != null && !status.isEmpty()) {
                countWhere += " AND r.estado_reserva = '" + status + "'";
            }
            if (data != null && !data.isEmpty()) {
                countWhere += " AND (r.data_entrada = '" + data + "' OR r.data_saida = '" + data + "')";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql + countWhere)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray reservasArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                        obj.addProperty("id_cliente", rs.getInt("id_cliente"));
                        obj.addProperty("id_quarto", rs.getInt("id_quarto"));
                        obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                        obj.addProperty("quarto_numero", rs.getString("numero_quarto"));
                        obj.addProperty("quarto_tipo", rs.getString("quarto_tipo"));
                        obj.addProperty("data_entrada", rs.getString("data_entrada"));
                        obj.addProperty("data_saida", rs.getString("data_saida"));
                        obj.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                        obj.addProperty("estado", rs.getString("estado_reserva"));
                        obj.addProperty("observacoes", rs.getString("observacoes"));
                        reservasArray.add(obj);
                    }
                }
            }

            result.add("reservas", reservasArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("reservas", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT " +
                    "COUNT(*) as total, " +
                    "SUM(CASE WHEN estado_reserva = 'CONFIRMADA' THEN 1 ELSE 0 END) as confirmadas, " +
                    "SUM(CASE WHEN estado_reserva = 'PENDENTE' THEN 1 ELSE 0 END) as pendentes, " +
                    "SUM(CASE WHEN estado_reserva = 'CHECK-IN' THEN 1 ELSE 0 END) as checkin, " +
                    "SUM(CASE WHEN estado_reserva = 'FINALIZADA' THEN 1 ELSE 0 END) as finalizadas, " +
                    "SUM(CASE WHEN estado_reserva = 'CANCELADA' THEN 1 ELSE 0 END) as canceladas, " +
                    "SUM(CASE WHEN MONTH(data_entrada) = MONTH(CURDATE()) AND YEAR(data_entrada) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as reservas_mes " +
                    "FROM reserva";

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    stats.addProperty("total", rs.getInt("total"));
                    stats.addProperty("confirmadas", rs.getInt("confirmadas"));
                    stats.addProperty("pendentes", rs.getInt("pendentes"));
                    stats.addProperty("checkin", rs.getInt("checkin"));
                    stats.addProperty("finalizadas", rs.getInt("finalizadas"));
                    stats.addProperty("canceladas", rs.getInt("canceladas"));
                    stats.addProperty("reservas_mes", rs.getInt("reservas_mes"));
                }
            }

            // Taxa de ocupação
            String sqlOcupacao = "SELECT COUNT(*) as total, SUM(CASE WHEN estado IN ('OCUPADO', 'RESERVADO') THEN 1 ELSE 0 END) as ocupados FROM quarto";
            try (PreparedStatement stmt = conn.prepareStatement(sqlOcupacao);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int total = rs.getInt("total");
                    int ocupados = rs.getInt("ocupados");
                    double taxa = total > 0 ? (ocupados * 100.0 / total) : 0;
                    stats.addProperty("taxa_ocupacao", Math.round(taxa));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Estatísticas por estado
            String sqlStats = "SELECT " +
                    "SUM(CASE WHEN estado_reserva = 'CONFIRMADA' THEN 1 ELSE 0 END) as confirmadas, " +
                    "SUM(CASE WHEN estado_reserva = 'PENDENTE' THEN 1 ELSE 0 END) as pendentes, " +
                    "SUM(CASE WHEN estado_reserva = 'CHECK-IN' THEN 1 ELSE 0 END) as checkin, " +
                    "SUM(CASE WHEN estado_reserva = 'FINALIZADA' THEN 1 ELSE 0 END) as finalizadas, " +
                    "SUM(CASE WHEN estado_reserva = 'CANCELADA' THEN 1 ELSE 0 END) as canceladas " +
                    "FROM reserva";
            try (PreparedStatement stmt = conn.prepareStatement(sqlStats);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("confirmadas", rs.getInt("confirmadas"));
                    result.addProperty("pendentes", rs.getInt("pendentes"));
                    result.addProperty("checkin", rs.getInt("checkin"));
                    result.addProperty("finalizadas", rs.getInt("finalizadas"));
                    result.addProperty("canceladas", rs.getInt("canceladas"));
                }
            }

            // Reservas por mês (últimos 6 meses)
            JsonArray reservasPorMes = new JsonArray();
            String sqlMeses = "SELECT DATE_FORMAT(data_entrada, '%b') as mes, COUNT(*) as total " +
                    "FROM reserva WHERE data_entrada >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
                    "GROUP BY YEAR(data_entrada), MONTH(data_entrada) ORDER BY data_entrada ASC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMeses);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("mes", rs.getString("mes"));
                    item.addProperty("total", rs.getInt("total"));
                    reservasPorMes.add(item);
                }
            }
            result.add("reservas_por_mes", reservasPorMes);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getClientesQuartos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Clientes
            JsonArray clientes = new JsonArray();
            String sqlClientes = "SELECT id_cliente, nome_completo FROM cliente ORDER BY nome_completo";
            try (PreparedStatement stmt = conn.prepareStatement(sqlClientes);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_cliente", rs.getInt("id_cliente"));
                    obj.addProperty("nome", rs.getString("nome_completo"));
                    clientes.add(obj);
                }
            }

            // Quartos disponíveis
            JsonArray quartos = new JsonArray();
            String sqlQuartos = "SELECT q.id_quarto, q.numero_quarto, tq.nome_tipo as tipo " +
                    "FROM quarto q JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                    "WHERE q.estado != 'OCUPADO' ORDER BY q.numero_quarto";
            try (PreparedStatement stmt = conn.prepareStatement(sqlQuartos);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_quarto", rs.getInt("id_quarto"));
                    obj.addProperty("numero", rs.getString("numero_quarto"));
                    obj.addProperty("tipo", rs.getString("tipo"));
                    quartos.add(obj);
                }
            }

            result.add("clientes", clientes);
            result.add("quartos", quartos);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT r.id_reserva, r.id_cliente, r.id_quarto, r.data_entrada, r.data_saida, " +
                "r.numero_hospedes, r.estado_reserva, r.observacoes, r.data_registro, " +
                "c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.id_reserva = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("id_cliente", rs.getInt("id_cliente"));
                    result.addProperty("id_quarto", rs.getInt("id_quarto"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("quarto_num", rs.getString("quarto_num"));
                    result.addProperty("data_entrada", rs.getString("data_entrada"));
                    result.addProperty("data_saida", rs.getString("data_saida"));
                    result.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    result.addProperty("estado_reserva", rs.getString("estado_reserva"));
                    result.addProperty("observacoes", rs.getString("observacoes"));
                    result.addProperty("data_registro", rs.getString("data_registro"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void salvarReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            // Ler JSON do body
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            String idReserva = data.has("id_reserva") && !data.get("id_reserva").isJsonNull() ? data.get("id_reserva").getAsString() : null;
            int idCliente = data.get("id_cliente").getAsInt();
            int idQuarto = data.get("id_quarto").getAsInt();
            String dataEntrada = data.get("data_entrada").getAsString();
            String dataSaida = data.get("data_saida").getAsString();
            int numeroHospedes = data.get("numero_hospedes").getAsInt();
            String estadoReserva = data.get("estado_reserva").getAsString();
            String observacoes = data.has("observacoes") ? data.get("observacoes").getAsString() : null;

            boolean success = false;

            if (idReserva != null && !idReserva.isEmpty()) {
                String sql = "UPDATE reserva SET id_cliente=?, id_quarto=?, data_entrada=?, data_saida=?, " +
                        "numero_hospedes=?, estado_reserva=?, observacoes=? WHERE id_reserva=?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, idCliente);
                    stmt.setInt(2, idQuarto);
                    stmt.setDate(3, java.sql.Date.valueOf(dataEntrada));
                    stmt.setDate(4, java.sql.Date.valueOf(dataSaida));
                    stmt.setInt(5, numeroHospedes);
                    stmt.setString(6, estadoReserva);
                    stmt.setString(7, observacoes);
                    stmt.setInt(8, Integer.parseInt(idReserva));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO reserva (id_cliente, id_quarto, data_entrada, data_saida, " +
                        "numero_hospedes, estado_reserva, observacoes, data_reserva) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, idCliente);
                    stmt.setInt(2, idQuarto);
                    stmt.setDate(3, java.sql.Date.valueOf(dataEntrada));
                    stmt.setDate(4, java.sql.Date.valueOf(dataSaida));
                    stmt.setInt(5, numeroHospedes);
                    stmt.setString(6, estadoReserva);
                    stmt.setString(7, observacoes);
                    success = stmt.executeUpdate() > 0;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "RESERVA", "reserva", 0,
                        "Reserva " + (idReserva != null ? "atualizada" : "criada"), request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Reserva salva com sucesso!" : "Erro ao salvar reserva");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}