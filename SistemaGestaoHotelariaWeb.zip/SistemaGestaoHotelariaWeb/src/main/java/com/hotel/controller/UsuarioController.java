// src/main/java/com/hotel/controller/UsuarioController.java
package com.hotel.controller;

import com.hotel.dao.UsuarioDAO;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@MultipartConfig(maxFileSize = 5 * 1024 * 1024) // 5MB
@WebServlet(urlPatterns = {
        "/Admin/usuarios",
        "/Admin/usuarios/listar",
        "/Admin/usuarios/salvar",
        "/Admin/usuarios/editar",
        "/Admin/usuarios/excluir",
        "/Admin/usuarios/reset-senha",
        "/Admin/usuarios/alterar-status",
        "/Admin/usuarios/perfis"
})
public class UsuarioController extends HttpServlet {

    private UsuarioDAO usuarioDAO;
    private LogSistemaDAO logDAO;
    private Gson gson;

    @Override
    public void init() {
        usuarioDAO = new UsuarioDAO();
        logDAO = new LogSistemaDAO();
        gson = new Gson();
    }

    // ─────────────────────────────────────────────
    // UTILITÁRIO: ler parâmetro de texto de multipart/form-data
    // request.getParameter() pode retornar null com @MultipartConfig no Tomcat 7;
    // este método lê diretamente via Part, que é sempre confiável.
    // ─────────────────────────────────────────────
    private String getPartValue(HttpServletRequest request, String name) {
        try {
            Part part = request.getPart(name);
            if (part == null) return null;
            InputStream is = part.getInputStream();
            byte[] bytes = is.readAllBytes();
            if (bytes.length == 0) return null;
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            // fallback para getParameter (funciona em requisições normais)
            return request.getParameter(name);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/usuarios".equals(path)) {
            request.getRequestDispatcher("/Admin/usuario.jsp").forward(request, response);

        } else if ("/Admin/usuarios/listar".equals(path)) {
            listarUsuarios(request, response);

        } else if ("/Admin/usuarios/editar".equals(path)) {
            editarUsuario(request, response);

        } else if ("/Admin/usuarios/perfis".equals(path)) {
            listarPerfis(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/usuarios/salvar".equals(path)) {
            salvarUsuario(request, response);

        } else if ("/Admin/usuarios/excluir".equals(path)) {
            excluirUsuario(request, response);

        } else if ("/Admin/usuarios/reset-senha".equals(path)) {
            resetarSenha(request, response);

        } else if ("/Admin/usuarios/alterar-status".equals(path)) {
            alterarStatus(request, response);
        }
    }

    // ─────────────────────────────────────────────
    // LISTAR USUÁRIOS
    // ─────────────────────────────────────────────
    private void listarUsuarios(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try {
            String search = request.getParameter("search");
            String perfil = request.getParameter("perfil");
            String status = request.getParameter("status");
            int page  = request.getParameter("page")  != null ? Integer.parseInt(request.getParameter("page"))  : 1;
            int limit = request.getParameter("limit") != null ? Integer.parseInt(request.getParameter("limit")) : 10;

            List<Usuario> usuarios = usuarioDAO.listarComFiltros(search, perfil, status, page, limit);
            int total = usuarioDAO.contarComFiltros(search, perfil, status);

            JsonObject result = new JsonObject();
            result.add("usuarios", gson.toJsonTree(usuarios));
            result.addProperty("total", total);
            result.addProperty("page", page);
            result.addProperty("totalPages", (int) Math.ceil((double) total / limit));

            PrintWriter out = response.getWriter();
            out.print(gson.toJson(result));
            out.flush();

        } catch (Exception e) {
            e.printStackTrace();
            PrintWriter out = response.getWriter();
            out.print("{\"usuarios\":[], \"total\":0, \"page\":1, \"totalPages\":1}");
            out.flush();
        }
    }

    // ─────────────────────────────────────────────
    // LISTAR PERFIS
    // ─────────────────────────────────────────────
    private void listarPerfis(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try {
            List<com.hotel.model.Perfil> perfis = usuarioDAO.listarPerfis();
            PrintWriter out = response.getWriter();
            out.print(gson.toJson(perfis));
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
            PrintWriter out = response.getWriter();
            out.print("[]");
            out.flush();
        }
    }

    // ─────────────────────────────────────────────
    // BUSCAR USUÁRIO PARA EDITAR
    // ─────────────────────────────────────────────
    private void editarUsuario(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"error\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            Usuario usuario = usuarioDAO.buscarPorId(id);

            if (usuario != null) {
                usuario.setSenha(null); // nunca retornar senha ao front
                out.print(gson.toJson(usuario));
            } else {
                out.print("{\"error\": \"Usuário não encontrado\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
        }
        out.flush();
    }

    // ─────────────────────────────────────────────
    // SALVAR USUÁRIO (INSERT ou UPDATE)
    // ─────────────────────────────────────────────
    private void salvarUsuario(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            // ── Leitura segura dos parâmetros (funciona com multipart/form-data no Tomcat 7) ──
            String idStr       = getPartValue(request, "id");
            String nome        = getPartValue(request, "nome");
            String username    = getPartValue(request, "username");
            String email       = getPartValue(request, "email");
            String telefone    = getPartValue(request, "telefone");
            String idPerfilStr = getPartValue(request, "idPerfil");
            String estado      = getPartValue(request, "estado");
            String senha       = getPartValue(request, "senha");
            String fotoBase64  = getPartValue(request, "foto");

            // ── Validações ──
            if (nome == null || nome.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Nome é obrigatório\"}");
                out.flush();
                return;
            }
            if (username == null || username.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Username é obrigatório\"}");
                out.flush();
                return;
            }
            if (idPerfilStr == null || idPerfilStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Perfil é obrigatório\"}");
                out.flush();
                return;
            }

            int id = (idStr != null && !idStr.trim().isEmpty()) ? Integer.parseInt(idStr.trim()) : 0;
            int idPerfil = Integer.parseInt(idPerfilStr.trim());

            Usuario usuario = new Usuario();
            usuario.setIdUsuario(id);
            usuario.setNome(nome.trim());
            usuario.setUsername(username.trim());
            usuario.setEmail(email != null ? email.trim() : "");
            usuario.setTelefone(telefone != null ? telefone.trim() : "");
            usuario.setIdPerfil(idPerfil);
            usuario.setEstado(estado != null && !estado.trim().isEmpty() ? estado.trim() : "ATIVO");

            if (fotoBase64 != null && !fotoBase64.trim().isEmpty()) {
                usuario.setFoto(fotoBase64.trim());
            }

            boolean success;

            if (id == 0) {
                // ── NOVO USUÁRIO ──
                if (senha == null || senha.trim().isEmpty() || senha.trim().length() < 6) {
                    out.print("{\"success\": false, \"message\": \"Senha obrigatória (mínimo 6 caracteres)\"}");
                    out.flush();
                    return;
                }
                usuario.setSenha(senha.trim());
                success = usuarioDAO.inserir(usuario);

                if (success && usuarioLogado != null) {
                    logDAO.registrarLog(
                            usuarioLogado.getIdUsuario(),
                            "CREATE",
                            "usuario",
                            usuario.getIdUsuario(),
                            "Novo usuário criado: " + usuario.getUsername(),
                            request.getRemoteAddr(),
                            request.getHeader("User-Agent")
                    );
                }
            } else {
                // ── ATUALIZAR USUÁRIO ──
                if (senha != null && !senha.trim().isEmpty()) {
                    if (senha.trim().length() < 6) {
                        out.print("{\"success\": false, \"message\": \"Senha deve ter no mínimo 6 caracteres\"}");
                        out.flush();
                        return;
                    }
                    usuario.setSenha(senha.trim());
                }
                success = usuarioDAO.atualizar(usuario);

                if (success && usuarioLogado != null) {
                    logDAO.registrarLog(
                            usuarioLogado.getIdUsuario(),
                            "UPDATE",
                            "usuario",
                            usuario.getIdUsuario(),
                            "Usuário atualizado: " + usuario.getUsername(),
                            request.getRemoteAddr(),
                            request.getHeader("User-Agent")
                    );
                }
            }

            if (success) {
                out.print("{\"success\": true}");
            } else {
                out.print("{\"success\": false, \"message\": \"Erro ao salvar no banco de dados\"}");
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"ID ou Perfil inválido: " + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"Erro interno: " + e.getMessage() + "\"}");
        }

        out.flush();
    }

    // ─────────────────────────────────────────────
    // EXCLUIR USUÁRIO
    // ─────────────────────────────────────────────
    private void excluirUsuario(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            Usuario usuario = usuarioDAO.buscarPorId(id);

            boolean success = usuarioDAO.excluir(id);

            if (success && usuario != null && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        "DELETE",
                        "usuario",
                        id,
                        "Usuário excluído: " + usuario.getUsername(),
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
        out.flush();
    }

    // ─────────────────────────────────────────────
    // RESETAR SENHA
    // ─────────────────────────────────────────────
    private void resetarSenha(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            String novaSenha = "123456";

            boolean success = usuarioDAO.alterarSenha(id, novaSenha);

            if (success && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        "RESET_SENHA",
                        "usuario",
                        id,
                        "Senha do usuário ID " + id + " foi resetada para padrão",
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + ", \"novaSenha\": \"" + novaSenha + "\"}");

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
        out.flush();
    }

    // ─────────────────────────────────────────────
    // ALTERAR STATUS
    // ─────────────────────────────────────────────
    private void alterarStatus(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            String idStr = request.getParameter("id");
            if (idStr == null || idStr.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
                out.flush();
                return;
            }

            int id = Integer.parseInt(idStr.trim());
            String status = request.getParameter("status");

            boolean success = usuarioDAO.alterarStatus(id, status);

            if (success && usuarioLogado != null) {
                logDAO.registrarLog(
                        usuarioLogado.getIdUsuario(),
                        "UPDATE_STATUS",
                        "usuario",
                        id,
                        "Status do usuário ID " + id + " alterado para: " + status,
                        request.getRemoteAddr(),
                        request.getHeader("User-Agent")
                );
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + e.getMessage() + "\"}");
        }
        out.flush();
    }
}