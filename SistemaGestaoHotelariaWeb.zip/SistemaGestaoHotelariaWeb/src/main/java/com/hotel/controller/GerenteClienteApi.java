package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/clientes/listar",
        "/Gerente/api/clientes/stats",
        "/Gerente/api/clientes/graficos",
        "/Gerente/api/clientes/nacionalidades",
        "/Gerente/api/clientes/tipos-documento",
        "/Gerente/api/clientes/detalhes",
        "/Gerente/api/clientes/salvar"
})
public class GerenteClienteApi extends HttpServlet {

    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/clientes/listar":
                listarClientes(request, response);
                break;
            case "/Gerente/api/clientes/stats":
                getStats(response);
                break;
            case "/Gerente/api/clientes/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/clientes/nacionalidades":
                getNacionalidades(response);
                break;
            case "/Gerente/api/clientes/tipos-documento":
                getTiposDocumento(response);
                break;
            case "/Gerente/api/clientes/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/clientes/salvar".equals(request.getServletPath())) {
            salvarCliente(request, response);
        }
    }

    private void listarClientes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String sexo = request.getParameter("sexo");
        String documento = request.getParameter("documento");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT c.id_cliente, c.nome_completo, c.sexo, c.data_nascimento, ");
            sql.append("c.telefone, c.email, c.endereco, c.numero_documento, c.data_registro, ");
            sql.append("n.pais as nacionalidade, td.descricao as tipo_documento ");
            sql.append("FROM cliente c ");
            sql.append("LEFT JOIN nacionalidade n ON c.id_nacionalidade = n.id_nacionalidade ");
            sql.append("LEFT JOIN tipo_documento td ON c.id_tipo_documento = td.id_tipo_documento ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (c.nome_completo LIKE ? OR c.numero_documento LIKE ? OR c.email LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (sexo != null && !sexo.isEmpty()) {
                sql.append("AND c.sexo = ? ");
                params.add(sexo);
            }
            if (documento != null && !documento.isEmpty()) {
                sql.append("AND td.descricao = ? ");
                params.add(documento);
            }

            sql.append("ORDER BY c.id_cliente DESC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM cliente c " +
                    "LEFT JOIN tipo_documento td ON c.id_tipo_documento = td.id_tipo_documento WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND (c.nome_completo LIKE '%" + search + "%' OR c.numero_documento LIKE '%" + search + "%')";
            }
            if (sexo != null && !sexo.isEmpty()) {
                countSql += " AND c.sexo = '" + sexo + "'";
            }
            if (documento != null && !documento.isEmpty()) {
                countSql += " AND td.descricao = '" + documento + "'";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray clientesArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_cliente", rs.getInt("id_cliente"));
                        obj.addProperty("nome_completo", rs.getString("nome_completo"));
                        obj.addProperty("sexo", rs.getString("sexo"));
                        obj.addProperty("data_nascimento", rs.getString("data_nascimento"));
                        obj.addProperty("telefone", rs.getString("telefone"));
                        obj.addProperty("email", rs.getString("email"));
                        obj.addProperty("endereco", rs.getString("endereco"));
                        obj.addProperty("numero_documento", rs.getString("numero_documento"));
                        obj.addProperty("nacionalidade", rs.getString("nacionalidade"));
                        obj.addProperty("tipo_documento", rs.getString("tipo_documento"));
                        obj.addProperty("data_registro", rs.getString("data_registro"));
                        clientesArray.add(obj);
                    }
                }
            }

            result.add("clientes", clientesArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("clientes", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN sexo = 'M' THEN 1 ELSE 0 END) as homens, " +
                    "SUM(CASE WHEN sexo = 'F' THEN 1 ELSE 0 END) as mulheres, " +
                    "SUM(CASE WHEN MONTH(data_registro) = MONTH(CURDATE()) AND YEAR(data_registro) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as este_mes " +
                    "FROM cliente";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    stats.addProperty("total", rs.getInt("total"));
                    stats.addProperty("homens", rs.getInt("homens"));
                    stats.addProperty("mulheres", rs.getInt("mulheres"));
                    stats.addProperty("este_mes", rs.getInt("este_mes"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Por sexo
            String sqlSexo = "SELECT SUM(CASE WHEN sexo = 'M' THEN 1 ELSE 0 END) as homens, " +
                    "SUM(CASE WHEN sexo = 'F' THEN 1 ELSE 0 END) as mulheres FROM cliente";
            try (PreparedStatement stmt = conn.prepareStatement(sqlSexo);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("homens", rs.getInt("homens"));
                    result.addProperty("mulheres", rs.getInt("mulheres"));
                }
            }

            // Por nacionalidade
            JsonArray porNacionalidade = new JsonArray();
            String sqlNacionalidade = "SELECT n.pais, COUNT(c.id_cliente) as total " +
                    "FROM nacionalidade n " +
                    "LEFT JOIN cliente c ON n.id_nacionalidade = c.id_nacionalidade " +
                    "GROUP BY n.id_nacionalidade, n.pais " +
                    "ORDER BY total DESC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlNacionalidade);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("pais", rs.getString("pais"));
                    item.addProperty("total", rs.getInt("total"));
                    porNacionalidade.add(item);
                }
            }
            result.add("por_nacionalidade", porNacionalidade);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getNacionalidades(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray nacionalidades = new JsonArray();

        String sql = "SELECT id_nacionalidade, pais FROM nacionalidade ORDER BY pais";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_nacionalidade", rs.getInt("id_nacionalidade"));
                obj.addProperty("pais", rs.getString("pais"));
                nacionalidades.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(nacionalidades));
        out.flush();
    }

    private void getTiposDocumento(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray tipos = new JsonArray();

        String sql = "SELECT id_tipo_documento, descricao FROM tipo_documento ORDER BY descricao";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_tipo_documento", rs.getInt("id_tipo_documento"));
                obj.addProperty("descricao", rs.getString("descricao"));
                tipos.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(tipos));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT c.id_cliente, c.nome_completo, c.sexo, c.data_nascimento, " +
                "c.telefone, c.email, c.endereco, c.numero_documento, c.data_registro, " +
                "c.id_nacionalidade, c.id_tipo_documento, " +
                "n.pais as nacionalidade, td.descricao as tipo_documento " +
                "FROM cliente c " +
                "LEFT JOIN nacionalidade n ON c.id_nacionalidade = n.id_nacionalidade " +
                "LEFT JOIN tipo_documento td ON c.id_tipo_documento = td.id_tipo_documento " +
                "WHERE c.id_cliente = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_cliente", rs.getInt("id_cliente"));
                    result.addProperty("nome_completo", rs.getString("nome_completo"));
                    result.addProperty("sexo", rs.getString("sexo"));
                    result.addProperty("data_nascimento", rs.getString("data_nascimento"));
                    result.addProperty("telefone", rs.getString("telefone"));
                    result.addProperty("email", rs.getString("email"));
                    result.addProperty("endereco", rs.getString("endereco"));
                    result.addProperty("numero_documento", rs.getString("numero_documento"));
                    result.addProperty("data_registro", rs.getString("data_registro"));
                    result.addProperty("id_nacionalidade", rs.getInt("id_nacionalidade"));
                    result.addProperty("id_tipo_documento", rs.getInt("id_tipo_documento"));
                    result.addProperty("nacionalidade", rs.getString("nacionalidade"));
                    result.addProperty("tipo_documento", rs.getString("tipo_documento"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void salvarCliente(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            String idCliente = data.has("id_cliente") && !data.get("id_cliente").isJsonNull() ? data.get("id_cliente").getAsString() : null;
            String nomeCompleto = data.get("nome_completo").getAsString();
            String sexo = data.has("sexo") && !data.get("sexo").isJsonNull() ? data.get("sexo").getAsString() : null;
            String dataNascimento = data.has("data_nascimento") && !data.get("data_nascimento").isJsonNull() ? data.get("data_nascimento").getAsString() : null;
            String telefone = data.has("telefone") && !data.get("telefone").isJsonNull() ? data.get("telefone").getAsString() : null;
            String email = data.has("email") && !data.get("email").isJsonNull() ? data.get("email").getAsString() : null;
            String endereco = data.has("endereco") && !data.get("endereco").isJsonNull() ? data.get("endereco").getAsString() : null;
            String idNacionalidade = data.has("id_nacionalidade") && !data.get("id_nacionalidade").isJsonNull() ? data.get("id_nacionalidade").getAsString() : null;
            String idTipoDocumento = data.has("id_tipo_documento") && !data.get("id_tipo_documento").isJsonNull() ? data.get("id_tipo_documento").getAsString() : null;
            String numeroDocumento = data.has("numero_documento") && !data.get("numero_documento").isJsonNull() ? data.get("numero_documento").getAsString() : null;

            boolean success = false;

            if (idCliente != null && !idCliente.isEmpty()) {
                String sql = "UPDATE cliente SET nome_completo=?, sexo=?, data_nascimento=?, telefone=?, " +
                        "email=?, endereco=?, id_nacionalidade=?, id_tipo_documento=?, numero_documento=? " +
                        "WHERE id_cliente=?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, nomeCompleto);
                    stmt.setString(2, sexo);
                    stmt.setDate(3, dataNascimento != null ? java.sql.Date.valueOf(dataNascimento) : null);
                    stmt.setString(4, telefone);
                    stmt.setString(5, email);
                    stmt.setString(6, endereco);
                    stmt.setInt(7, idNacionalidade != null ? Integer.parseInt(idNacionalidade) : 0);
                    stmt.setInt(8, idTipoDocumento != null ? Integer.parseInt(idTipoDocumento) : 0);
                    stmt.setString(9, numeroDocumento);
                    stmt.setInt(10, Integer.parseInt(idCliente));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO cliente (nome_completo, sexo, data_nascimento, telefone, email, " +
                        "endereco, id_nacionalidade, id_tipo_documento, numero_documento, data_registro) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, nomeCompleto);
                    stmt.setString(2, sexo);
                    stmt.setDate(3, dataNascimento != null ? java.sql.Date.valueOf(dataNascimento) : null);
                    stmt.setString(4, telefone);
                    stmt.setString(5, email);
                    stmt.setString(6, endereco);
                    stmt.setInt(7, idNacionalidade != null ? Integer.parseInt(idNacionalidade) : 0);
                    stmt.setInt(8, idTipoDocumento != null ? Integer.parseInt(idTipoDocumento) : 0);
                    stmt.setString(9, numeroDocumento);
                    success = stmt.executeUpdate() > 0;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "CLIENTE", "cliente", 0,
                        "Cliente " + (idCliente != null ? "atualizado" : "criado") + ": " + nomeCompleto,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Cliente salvo com sucesso!" : "Erro ao salvar cliente");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}