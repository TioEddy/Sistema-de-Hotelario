package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

@WebServlet(urlPatterns = {
        "/Gerente/api/check/stats",
        "/Gerente/api/check/graficos",
        "/Gerente/api/check/pendentes",
        "/Gerente/api/check/hospedados",
        "/Gerente/api/check/checkouts",
        "/Gerente/api/check/reserva-detalhes",
        "/Gerente/api/check/checkout-detalhes",
        "/Gerente/api/check/realizar-checkin",
        "/Gerente/api/check/realizar-checkout"
})
public class GerenteCheckApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/check/stats":
                getStats(response);
                break;
            case "/Gerente/api/check/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/check/pendentes":
                getPendentes(response);
                break;
            case "/Gerente/api/check/hospedados":
                getHospedados(response);
                break;
            case "/Gerente/api/check/checkouts":
                getCheckouts(response);
                break;
            case "/Gerente/api/check/reserva-detalhes":
                getReservaDetalhes(request, response);
                break;
            case "/Gerente/api/check/checkout-detalhes":
                getCheckoutDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/check/realizar-checkin":
                realizarCheckin(request, response);
                break;
            case "/Gerente/api/check/realizar-checkout":
                realizarCheckout(request, response);
                break;
        }
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();
        String hoje = sdfData.format(new Date());

        try (Connection conn = ConexaoDB.getConexao()) {
            // Check-ins pendentes hoje
            String sqlCheckinsHoje = "SELECT COUNT(*) as total FROM reserva WHERE data_entrada = ? AND estado_reserva != 'CHECK-IN'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckinsHoje)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    stats.addProperty("checkins_hoje", rs.next() ? rs.getInt("total") : 0);
                }
            }

            // Pendentes (status PENDENTE)
            String sqlPendentes = "SELECT COUNT(*) as total FROM reserva WHERE data_entrada = ? AND estado_reserva = 'PENDENTE'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPendentes)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    stats.addProperty("pendentes_hoje", rs.next() ? rs.getInt("total") : 0);
                }
            }

            // Check-outs hoje
            String sqlCheckoutsHoje = "SELECT COUNT(*) as total FROM reserva WHERE data_saida = ? AND estado_reserva = 'CHECK-IN'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckoutsHoje)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    stats.addProperty("checkouts_hoje", rs.next() ? rs.getInt("total") : 0);
                }
            }

            // Hóspedes no hotel (CHECK-IN status)
            String sqlHospedados = "SELECT COUNT(*) as total FROM reserva WHERE estado_reserva = 'CHECK-IN'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedados);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("hospedes_hotel", rs.next() ? rs.getInt("total") : 0);
            }

            // Reservas pendentes gerais
            String sqlReservasPendentes = "SELECT COUNT(*) as total FROM reserva WHERE estado_reserva = 'PENDENTE'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlReservasPendentes);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("reservas_pendentes", rs.next() ? rs.getInt("total") : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Check-ins por hora (últimas 12h)
            JsonArray checkinsPorHora = new JsonArray();
            String sqlHoras = "SELECT HOUR(data_checkin) as hora, COUNT(*) as total FROM checkin WHERE DATE(data_checkin) = CURDATE() GROUP BY HOUR(data_checkin) ORDER BY hora";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHoras);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("hora", rs.getInt("hora"));
                    item.addProperty("total", rs.getInt("total"));
                    checkinsPorHora.add(item);
                }
            }
            result.add("checkins_por_hora", checkinsPorHora);

            // Ocupação por tipo de quarto
            JsonArray ocupacaoPorTipo = new JsonArray();
            String sqlOcupacao = "SELECT tq.nome_tipo as tipo, " +
                    "SUM(CASE WHEN q.estado = 'OCUPADO' THEN 1 ELSE 0 END) as ocupados, " +
                    "SUM(CASE WHEN q.estado = 'LIVRE' THEN 1 ELSE 0 END) as livres " +
                    "FROM tipo_quarto tq LEFT JOIN quarto q ON tq.id_tipo_quarto = q.id_tipo_quarto " +
                    "GROUP BY tq.id_tipo_quarto, tq.nome_tipo";
            try (PreparedStatement stmt = conn.prepareStatement(sqlOcupacao);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("tipo", rs.getString("tipo"));
                    item.addProperty("ocupados", rs.getInt("ocupados"));
                    item.addProperty("livres", rs.getInt("livres"));
                    ocupacaoPorTipo.add(item);
                }
            }
            result.add("ocupacao_por_tipo", ocupacaoPorTipo);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getPendentes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray pendentes = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "r.data_entrada, r.data_saida, r.numero_hospedes " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.data_entrada = ? AND r.estado_reserva NOT IN ('CHECK-IN', 'FINALIZADA') " +
                "ORDER BY r.id_reserva ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                    obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    obj.addProperty("quarto_num", rs.getString("quarto_num"));
                    obj.addProperty("data_entrada", rs.getString("data_entrada"));
                    obj.addProperty("data_saida", rs.getString("data_saida"));
                    obj.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    pendentes.add(obj);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(pendentes));
        out.flush();
    }

    private void getHospedados(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray hospedados = new JsonArray();

        String sql = "SELECT ci.id_checkin, r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "ci.data_checkin, r.data_saida as data_saida_prevista, r.numero_hospedes as quantidade_hospedes " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva = 'CHECK-IN' " +
                "ORDER BY ci.data_checkin DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_checkin", rs.getInt("id_checkin"));
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto_num", rs.getString("quarto_num"));
                obj.addProperty("data_checkin", rs.getString("data_checkin"));
                obj.addProperty("data_saida_prevista", rs.getString("data_saida_prevista"));
                obj.addProperty("quantidade_hospedes", rs.getInt("quantidade_hospedes"));
                hospedados.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(hospedados));
        out.flush();
    }

    private void getCheckouts(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray checkouts = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT ci.id_checkin, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "r.data_saida as data_saida_prevista, " +
                "DATEDIFF(r.data_saida, r.data_entrada) as diarias, " +
                "tq.preco_diaria, " +
                "COALESCE((SELECT SUM(subtotal) FROM consumo_servico WHERE id_reserva = r.id_reserva), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.data_saida = ? AND r.estado_reserva = 'CHECK-IN'";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int diarias = Math.max(rs.getInt("diarias"), 1);
                    double precoDiaria = rs.getDouble("preco_diaria");
                    double consumoTotal = rs.getDouble("consumo_total");
                    double totalQuarto = precoDiaria * diarias;
                    double total = totalQuarto + consumoTotal;

                    JsonObject obj = new JsonObject();
                    obj.addProperty("id_checkin", rs.getInt("id_checkin"));
                    obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    obj.addProperty("quarto_num", rs.getString("quarto_num"));
                    obj.addProperty("data_saida_prevista", rs.getString("data_saida_prevista"));
                    obj.addProperty("diarias", diarias);
                    obj.addProperty("preco_diaria", precoDiaria);
                    obj.addProperty("total_quarto", totalQuarto);
                    obj.addProperty("consumo_total", consumoTotal);
                    obj.addProperty("total", total);
                    checkouts.add(obj);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(checkouts));
        out.flush();
    }

    private void getReservaDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "r.data_entrada, r.data_saida, r.numero_hospedes, r.observacoes " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.id_reserva = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("quarto_num", rs.getString("quarto_num"));
                    result.addProperty("data_entrada", rs.getString("data_entrada"));
                    result.addProperty("data_saida", rs.getString("data_saida"));
                    result.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    result.addProperty("observacoes", rs.getString("observacoes"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getCheckoutDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT ci.id_checkin, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "ci.data_checkin, r.data_saida as data_saida_prevista, " +
                "DATEDIFF(r.data_saida, r.data_entrada) as diarias, " +
                "tq.preco_diaria, " +
                "COALESCE((SELECT SUM(subtotal) FROM consumo_servico WHERE id_reserva = r.id_reserva), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE ci.id_checkin = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int diarias = Math.max(rs.getInt("diarias"), 1);
                    double precoDiaria = rs.getDouble("preco_diaria");
                    double consumoTotal = rs.getDouble("consumo_total");
                    double totalQuarto = precoDiaria * diarias;
                    double total = totalQuarto + consumoTotal;

                    result.addProperty("id_checkin", rs.getInt("id_checkin"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("quarto_num", rs.getString("quarto_num"));
                    result.addProperty("data_checkin", rs.getString("data_checkin") != null ? rs.getString("data_checkin").substring(0, 10) : "");
                    result.addProperty("data_saida_prevista", rs.getString("data_saida_prevista"));
                    result.addProperty("diarias", diarias);
                    result.addProperty("preco_diaria", precoDiaria);
                    result.addProperty("total_quarto", totalQuarto);
                    result.addProperty("consumo_total", consumoTotal);
                    result.addProperty("total", total);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void realizarCheckin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            int idReserva = data.get("id_reserva").getAsInt();
            String observacoes = data.has("observacoes") ? data.get("observacoes").getAsString() : null;

            // Verificar se já tem check-in
            String sqlCheck = "SELECT COUNT(*) FROM checkin WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlCheck)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        result.addProperty("success", false);
                        result.addProperty("message", "Esta reserva já possui check-in realizado");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            // Realizar check-in e atualizar estados
            String sqlCheckin = "INSERT INTO checkin (id_reserva, data_checkin, observacoes) VALUES (?, NOW(), ?)";
            String sqlUpdateReserva = "UPDATE reserva SET estado_reserva = 'CHECK-IN' WHERE id_reserva = ?";
            String sqlUpdateQuarto = "UPDATE quarto SET estado = 'OCUPADO' WHERE id_quarto = (SELECT id_quarto FROM reserva WHERE id_reserva = ?)";

            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao()) {
                conn.setAutoCommit(false);
                try {
                    try (PreparedStatement stmt = conn.prepareStatement(sqlCheckin)) {
                        stmt.setInt(1, idReserva);
                        stmt.setString(2, observacoes);
                        stmt.executeUpdate();
                    }
                    try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateReserva)) {
                        stmt.setInt(1, idReserva);
                        stmt.executeUpdate();
                    }
                    try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateQuarto)) {
                        stmt.setInt(1, idReserva);
                        stmt.executeUpdate();
                    }
                    conn.commit();
                    success = true;
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "CHECKIN", "reserva", idReserva,
                        "Check-in realizado para reserva ID: " + idReserva,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Check-in realizado com sucesso!" : "Erro ao realizar check-in");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void realizarCheckout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            int idCheckin = data.get("id_checkin").getAsInt();
            String observacoes = data.has("observacoes") ? data.get("observacoes").getAsString() : null;

            // Buscar id_reserva
            String sqlGetReserva = "SELECT id_reserva FROM checkin WHERE id_checkin = ?";
            int idReserva = -1;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlGetReserva)) {
                stmt.setInt(1, idCheckin);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        idReserva = rs.getInt("id_reserva");
                    }
                }
            }

            if (idReserva == -1) {
                result.addProperty("success", false);
                result.addProperty("message", "Check-in não encontrado");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            // Realizar check-out
            String sqlCheckout = "INSERT INTO checkout (id_checkin, data_checkout, observacoes) VALUES (?, NOW(), ?)";
            String sqlUpdateReserva = "UPDATE reserva SET estado_reserva = 'FINALIZADA' WHERE id_reserva = ?";
            String sqlUpdateQuarto = "UPDATE quarto SET estado = 'LIVRE' WHERE id_quarto = (SELECT id_quarto FROM reserva WHERE id_reserva = ?)";

            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao()) {
                conn.setAutoCommit(false);
                try {
                    try (PreparedStatement stmt = conn.prepareStatement(sqlCheckout)) {
                        stmt.setInt(1, idCheckin);
                        stmt.setString(2, observacoes);
                        stmt.executeUpdate();
                    }
                    try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateReserva)) {
                        stmt.setInt(1, idReserva);
                        stmt.executeUpdate();
                    }
                    try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateQuarto)) {
                        stmt.setInt(1, idReserva);
                        stmt.executeUpdate();
                    }
                    conn.commit();
                    success = true;
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "CHECKOUT", "reserva", idReserva,
                        "Check-out realizado para reserva ID: " + idReserva,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Check-out realizado com sucesso!" : "Erro ao realizar check-out");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}