package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/quartos/listar",
        "/Recepcionista/api/quartos/detalhes",
        "/Recepcionista/api/quartos/estatisticas"
})
public class RecepcionistaQuartoApi extends HttpServlet {

    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/quartos/listar":
                listarQuartos(response);
                break;
            case "/Recepcionista/api/quartos/detalhes":
                detalhesQuarto(request, response);
                break;
            case "/Recepcionista/api/quartos/estatisticas":
                getEstatisticas(response);
                break;
        }
    }

    private void listarQuartos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray quartos = new JsonArray();

        String sql = "SELECT q.id_quarto, q.numero_quarto, q.piso, q.estado, " +
                "COALESCE(tq.nome_tipo, 'Standard') as tipo, " +
                "COALESCE(tq.preco_diaria, 2500) as preco_diaria, " +
                "COALESCE(tq.descricao, 'Quarto confortável') as descricao " +
                "FROM quarto q " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "ORDER BY CAST(q.numero_quarto AS UNSIGNED) ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject quarto = new JsonObject();
                quarto.addProperty("id_quarto", rs.getInt("id_quarto"));
                quarto.addProperty("numero_quarto", rs.getString("numero_quarto"));
                quarto.addProperty("tipo", rs.getString("tipo"));
                quarto.addProperty("piso", rs.getInt("piso"));
                quarto.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                quarto.addProperty("estado", rs.getString("estado"));
                quarto.addProperty("descricao", rs.getString("descricao"));
                quartos.add(quarto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(quartos));
        out.flush();
    }

    private void detalhesQuarto(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idQuarto = request.getParameter("id");
        JsonObject result = new JsonObject();

        if (idQuarto == null || idQuarto.isEmpty()) {
            result.addProperty("success", false);
            result.addProperty("error", "ID do quarto não informado");
            out.print(gson.toJson(result));
            out.flush();
            return;
        }

        String sql = "SELECT q.id_quarto, q.numero_quarto, q.piso, q.estado, " +
                "COALESCE(tq.nome_tipo, 'Standard') as tipo, " +
                "COALESCE(tq.preco_diaria, 2500) as preco_diaria, " +
                "COALESCE(tq.descricao, 'Quarto confortável') as descricao, " +
                "c.nome_completo as hospede_atual " +
                "FROM quarto q " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN reserva r ON q.id_quarto = r.id_quarto AND r.estado_reserva IN ('CONFIRMADA', 'PENDENTE') " +
                "LEFT JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "WHERE q.id_quarto = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idQuarto));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_quarto", rs.getInt("id_quarto"));
                    result.addProperty("numero_quarto", rs.getString("numero_quarto"));
                    result.addProperty("tipo", rs.getString("tipo"));
                    result.addProperty("piso", rs.getInt("piso"));
                    result.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                    result.addProperty("estado", rs.getString("estado"));
                    result.addProperty("descricao", rs.getString("descricao"));
                    String hospede = rs.getString("hospede_atual");
                    result.addProperty("hospede_atual", hospede != null ? hospede : "");
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                    result.addProperty("error", "Quarto não encontrado");
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getEstatisticas(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total de quartos
            String sqlTotal = "SELECT COUNT(*) as total FROM quarto";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("total_quartos", rs.getInt("total"));
                } else {
                    result.addProperty("total_quartos", 0);
                }
            }

            // Quartos livres
            String sqlLivres = "SELECT COUNT(*) as total FROM quarto WHERE estado = 'LIVRE'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlLivres);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("quartos_livres", rs.getInt("total"));
                } else {
                    result.addProperty("quartos_livres", 0);
                }
            }

            // Quartos ocupados
            String sqlOcupados = "SELECT COUNT(*) as total FROM quarto WHERE estado = 'OCUPADO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlOcupados);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("quartos_ocupados", rs.getInt("total"));
                } else {
                    result.addProperty("quartos_ocupados", 0);
                }
            }

            // Quartos reservados
            String sqlReservados = "SELECT COUNT(*) as total FROM quarto WHERE estado = 'RESERVADO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlReservados);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("quartos_reservados", rs.getInt("total"));
                } else {
                    result.addProperty("quartos_reservados", 0);
                }
            }

            // Quartos em manutencao
            String sqlManutencao = "SELECT COUNT(*) as total FROM quarto WHERE estado = 'MANUTENCAO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlManutencao);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("quartos_manutencao", rs.getInt("total"));
                } else {
                    result.addProperty("quartos_manutencao", 0);
                }
            }

            // Quartos em limpeza
            String sqlLimpeza = "SELECT COUNT(*) as total FROM quarto WHERE estado = 'LIMPEZA'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlLimpeza);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("quartos_limpeza", rs.getInt("total"));
                } else {
                    result.addProperty("quartos_limpeza", 0);
                }
            }

            result.addProperty("success", true);

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}