// src/main/java/com/hotel/controller/RecepcaoClienteApi.java
package com.hotel.controller;

import com.google.gson.Gson;
import com.hotel.dao.ClienteDAO;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Cliente;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

@WebServlet("/Recepcionista/api/cliente/*")
public class RecepcaoClienteApi extends HttpServlet {

    private ClienteDAO clienteDAO;
    private LogSistemaDAO logDAO;
    private Gson gson;
    private SimpleDateFormat sdf;

    @Override
    public void init() {
        clienteDAO = new ClienteDAO();
        logDAO = new LogSistemaDAO();
        gson = new Gson();
        sdf = new SimpleDateFormat("yyyy-MM-dd");
        System.out.println("✅ RecepcaoClienteApi iniciado com sucesso!");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String pathInfo = request.getPathInfo();
        System.out.println("GET - pathInfo: " + pathInfo);

        if ("/buscar".equals(pathInfo)) {
            String idParam = request.getParameter("id");
            if (idParam != null && !idParam.isEmpty()) {
                try {
                    int id = Integer.parseInt(idParam);
                    Cliente cliente = clienteDAO.buscarPorId(id);
                    if (cliente != null) {
                        out.print("{\"success\": true, \"cliente\": " + gson.toJson(cliente) + "}");
                    } else {
                        out.print("{\"success\": false, \"message\": \"Cliente não encontrado\"}");
                    }
                } catch (NumberFormatException e) {
                    out.print("{\"success\": false, \"message\": \"ID inválido\"}");
                }
            } else {
                out.print("{\"success\": false, \"message\": \"ID não informado\"}");
            }
        }
        else if ("/listar".equals(pathInfo)) {
            listarTodosClientes(response);
        }
        else {
            out.print("{\"success\": false, \"message\": \"Endpoint não encontrado\"}");
        }
        out.flush();
    }

    private void listarTodosClientes(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            java.util.List<Cliente> clientes = clienteDAO.listarTodos();
            System.out.println("Listando todos os clientes: " + clientes.size());
            String json = gson.toJson(clientes);
            out.print(json);
        } catch (Exception e) {
            System.err.println("Erro ao listar clientes: " + e.getMessage());
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String pathInfo = request.getPathInfo();
        System.out.println("POST - pathInfo: " + pathInfo);

        if ("/salvar".equals(pathInfo)) {
            StringBuilder sb = new StringBuilder();
            String line;
            try (BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }

            String jsonBody = sb.toString();
            System.out.println("JSON recebido: " + jsonBody);

            if (jsonBody == null || jsonBody.trim().isEmpty()) {
                out.print("{\"success\": false, \"message\": \"Dados não recebidos\"}");
                out.flush();
                return;
            }

            try {
                Cliente cliente = new Cliente();
                cliente.setIdCliente(extractInt(jsonBody, "id_cliente"));
                cliente.setNomeCompleto(extractString(jsonBody, "nome_completo"));
                cliente.setSexo(extractString(jsonBody, "sexo"));

                String dataNasc = extractString(jsonBody, "data_nascimento");
                if (dataNasc != null && !dataNasc.isEmpty()) {
                    cliente.setDataNascimento(sdf.parse(dataNasc));
                }

                cliente.setTelefone(extractString(jsonBody, "telefone"));
                cliente.setEmail(extractString(jsonBody, "email"));
                cliente.setEndereco(extractString(jsonBody, "endereco"));
                cliente.setIdNacionalidade(extractInt(jsonBody, "id_nacionalidade"));
                cliente.setIdTipoDocumento(extractInt(jsonBody, "id_tipo_documento"));
                cliente.setNumeroDocumento(extractString(jsonBody, "numero_documento"));

                if (cliente.getNomeCompleto() == null || cliente.getNomeCompleto().trim().isEmpty()) {
                    out.print("{\"success\": false, \"message\": \"Nome completo é obrigatório\"}");
                    out.flush();
                    return;
                }

                boolean success;
                if (cliente.getIdCliente() == 0) {
                    success = clienteDAO.inserir(cliente);
                    System.out.println("Inserindo novo cliente: " + success);
                } else {
                    success = clienteDAO.atualizar(cliente);
                    System.out.println("Atualizando cliente ID " + cliente.getIdCliente() + ": " + success);
                }

                HttpSession session = request.getSession();
                Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
                if (success && usuarioLogado != null) {
                    try {
                        logDAO.registrarLog(
                                usuarioLogado.getIdUsuario(),
                                cliente.getIdCliente() == 0 ? "CREATE" : "UPDATE",
                                "cliente",
                                cliente.getIdCliente(),
                                "Cliente " + (cliente.getIdCliente() == 0 ? "criado" : "atualizado") + ": " + cliente.getNomeCompleto(),
                                request.getRemoteAddr(),
                                request.getHeader("User-Agent")
                        );
                    } catch (Exception e) {
                        System.err.println("Erro ao registrar log: " + e.getMessage());
                    }
                }

                out.print("{\"success\": " + success + ", \"id\": " + cliente.getIdCliente() + "}");

            } catch (Exception e) {
                System.err.println("❌ Erro ao processar: " + e.getMessage());
                e.printStackTrace();
                out.print("{\"success\": false, \"message\": \"Erro interno: " + e.getMessage().replace("\"", "\\\"") + "\"}");
            }
        } else {
            out.print("{\"success\": false, \"message\": \"Endpoint não encontrado\"}");
        }
        out.flush();
    }

    private String extractString(String json, String key) {
        String search = "\"" + key + "\":";
        int start = json.indexOf(search);
        if (start == -1) return null;
        start = json.indexOf("\"", start + search.length()) + 1;
        int end = json.indexOf("\"", start);
        if (end == -1) return null;
        String value = json.substring(start, end);
        return "null".equals(value) ? null : value;
    }

    private int extractInt(String json, String key) {
        String search = "\"" + key + "\":";
        int start = json.indexOf(search);
        if (start == -1) return 0;
        start = start + search.length();
        int end = start;
        while (end < json.length() && (Character.isDigit(json.charAt(end)) || json.charAt(end) == '-')) {
            end++;
        }
        String value = json.substring(start, end);
        if (value.isEmpty() || "null".equals(value)) return 0;
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}