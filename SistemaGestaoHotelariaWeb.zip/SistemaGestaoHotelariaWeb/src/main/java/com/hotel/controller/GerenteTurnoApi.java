package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/turno/listar",
        "/Gerente/api/turno/stats",
        "/Gerente/api/turno/graficos",
        "/Gerente/api/turno/detalhes",
        "/Gerente/api/turno/salvar"
})
public class GerenteTurnoApi extends HttpServlet {

    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/turno/listar":
                listarTurnos(request, response);
                break;
            case "/Gerente/api/turno/stats":
                getStats(response);
                break;
            case "/Gerente/api/turno/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/turno/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/turno/salvar".equals(request.getServletPath())) {
            salvarTurno(request, response);
        }
    }

    private void listarTurnos(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT t.id_turno, t.nome_turno, t.hora_inicio, t.hora_fim, ");
            sql.append("COUNT(ft.id_funcionario) as total_funcionarios ");
            sql.append("FROM turno t ");
            sql.append("LEFT JOIN funcionario_turno ft ON t.id_turno = ft.id_turno ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND t.nome_turno LIKE ? ");
                params.add("%" + search + "%");
            }

            sql.append("GROUP BY t.id_turno, t.nome_turno, t.hora_inicio, t.hora_fim ");
            sql.append("ORDER BY t.id_turno ASC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM turno t WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND t.nome_turno LIKE '%" + search + "%'";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray turnosArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_turno", rs.getInt("id_turno"));
                        obj.addProperty("nome_turno", rs.getString("nome_turno"));
                        obj.addProperty("hora_inicio", rs.getString("hora_inicio"));
                        obj.addProperty("hora_fim", rs.getString("hora_fim"));
                        obj.addProperty("total_funcionarios", rs.getInt("total_funcionarios"));
                        turnosArray.add(obj);
                    }
                }
            }

            result.add("turnos", turnosArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("turnos", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total de turnos
            String sqlTotal = "SELECT COUNT(*) as total FROM turno";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_turnos", rs.next() ? rs.getInt("total") : 0);
            }

            // Funcionários por turno
            String sqlManha = "SELECT COUNT(ft.id_funcionario) as total FROM turno t " +
                    "LEFT JOIN funcionario_turno ft ON t.id_turno = ft.id_turno " +
                    "WHERE t.nome_turno = 'Manhã'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlManha);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_manha", rs.next() ? rs.getInt("total") : 0);
            }

            String sqlTarde = "SELECT COUNT(ft.id_funcionario) as total FROM turno t " +
                    "LEFT JOIN funcionario_turno ft ON t.id_turno = ft.id_turno " +
                    "WHERE t.nome_turno = 'Tarde'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTarde);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_tarde", rs.next() ? rs.getInt("total") : 0);
            }

            String sqlNoite = "SELECT COUNT(ft.id_funcionario) as total FROM turno t " +
                    "LEFT JOIN funcionario_turno ft ON t.id_turno = ft.id_turno " +
                    "WHERE t.nome_turno = 'Noite'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlNoite);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_noite", rs.next() ? rs.getInt("total") : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total_turnos", 0);
            stats.addProperty("total_manha", 0);
            stats.addProperty("total_tarde", 0);
            stats.addProperty("total_noite", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            JsonArray turnosArray = new JsonArray();
            JsonArray quantidadesArray = new JsonArray();

            String sql = "SELECT t.nome_turno, COUNT(ft.id_funcionario) as total " +
                    "FROM turno t " +
                    "LEFT JOIN funcionario_turno ft ON t.id_turno = ft.id_turno " +
                    "GROUP BY t.id_turno, t.nome_turno " +
                    "ORDER BY t.id_turno";

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    turnosArray.add(rs.getString("nome_turno"));
                    quantidadesArray.add(rs.getInt("total"));
                }
            }

            result.add("turnos", turnosArray);
            result.add("quantidades", quantidadesArray);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("turnos", new JsonArray());
            result.add("quantidades", new JsonArray());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT t.id_turno, t.nome_turno, t.hora_inicio, t.hora_fim, " +
                "COUNT(ft.id_funcionario) as total_funcionarios " +
                "FROM turno t " +
                "LEFT JOIN funcionario_turno ft ON t.id_turno = ft.id_turno " +
                "WHERE t.id_turno = ? " +
                "GROUP BY t.id_turno, t.nome_turno, t.hora_inicio, t.hora_fim";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_turno", rs.getInt("id_turno"));
                    result.addProperty("nome_turno", rs.getString("nome_turno"));
                    result.addProperty("hora_inicio", rs.getString("hora_inicio"));
                    result.addProperty("hora_fim", rs.getString("hora_fim"));
                    result.addProperty("total_funcionarios", rs.getInt("total_funcionarios"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void salvarTurno(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            String idTurno = data.has("id_turno") && !data.get("id_turno").isJsonNull() && !data.get("id_turno").getAsString().isEmpty() ?
                    data.get("id_turno").getAsString() : null;
            String nomeTurno = data.get("nome_turno").getAsString();
            String horaInicio = data.has("hora_inicio") && !data.get("hora_inicio").isJsonNull() ?
                    data.get("hora_inicio").getAsString() : null;
            String horaFim = data.has("hora_fim") && !data.get("hora_fim").isJsonNull() ?
                    data.get("hora_fim").getAsString() : null;

            boolean success = false;

            if (idTurno != null && !idTurno.isEmpty()) {
                String sql = "UPDATE turno SET nome_turno=?, hora_inicio=?, hora_fim=? WHERE id_turno=?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, nomeTurno);
                    stmt.setString(2, horaInicio);
                    stmt.setString(3, horaFim);
                    stmt.setInt(4, Integer.parseInt(idTurno));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO turno (nome_turno, hora_inicio, hora_fim) VALUES (?, ?, ?)";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, nomeTurno);
                    stmt.setString(2, horaInicio);
                    stmt.setString(3, horaFim);
                    success = stmt.executeUpdate() > 0;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "TURNO", "turno", 0,
                        "Turno " + (idTurno != null ? "atualizado" : "criado") + ": " + nomeTurno,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Turno salvo com sucesso!" : "Erro ao salvar turno");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}