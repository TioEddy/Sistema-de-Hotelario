package com.hotel.controller;

public class RecepcionistaApoioApi {
}
