// src/main/java/com/hotel/controller/FuncionarioController.java
package com.hotel.controller;

import com.hotel.dao.ConexaoDB;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.model.Usuario;

@WebServlet(urlPatterns = {
        "/Admin/funcionarios",
        "/Admin/funcionarios/listar",
        "/Admin/funcionarios/salvar",
        "/Admin/funcionarios/excluir",
        "/Admin/funcionarios/cargos",
        "/Admin/funcionarios/turnos",
        "/Admin/funcionarios/stats"
})
public class FuncionarioController extends HttpServlet {

    private Gson gson = new Gson();

    private void listarFuncionarios(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT f.id_funcionario, f.nome_completo, f.sexo, f.telefone, f.email, " +
                "f.cargo, f.salario, f.data_contratacao, f.status, ft.id_turno " +
                "FROM funcionario f " +
                "LEFT JOIN funcionario_turno ft ON f.id_funcionario = ft.id_funcionario " +
                "ORDER BY f.id_funcionario DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_funcionario", rs.getInt("id_funcionario"));
                obj.addProperty("nome_completo", rs.getString("nome_completo"));
                obj.addProperty("sexo", rs.getString("sexo"));
                obj.addProperty("telefone", rs.getString("telefone"));
                obj.addProperty("email", rs.getString("email"));
                obj.addProperty("cargo", rs.getString("cargo"));
                obj.addProperty("salario", rs.getDouble("salario"));
                obj.addProperty("data_contratacao", rs.getString("data_contratacao"));
                obj.addProperty("status", rs.getString("status"));
                obj.addProperty("id_turno", rs.getInt("id_turno"));
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    private void salvarFuncionario(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            if (usuarioLogado == null) {
                result.addProperty("success", false);
                result.addProperty("message", "Usuário não autenticado");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            int id = Integer.parseInt(request.getParameter("id_funcionario"));
            String nome = request.getParameter("nome_completo");
            String sexo = request.getParameter("sexo");
            String telefone = request.getParameter("telefone");
            String email = request.getParameter("email");
            String cargo = request.getParameter("cargo");
            double salario = Double.parseDouble(request.getParameter("salario"));
            String dataContratacao = request.getParameter("data_contratacao");
            int idTurno = request.getParameter("id_turno") != null && !request.getParameter("id_turno").isEmpty() ?
                    Integer.parseInt(request.getParameter("id_turno")) : 0;
            String status = request.getParameter("status");

            Connection conn = null;
            PreparedStatement stmt = null;
            boolean success = false;

            try {
                conn = ConexaoDB.getConexao();
                conn.setAutoCommit(false);

                if (id > 0) {
                    String sql = "UPDATE funcionario SET nome_completo=?, sexo=?, telefone=?, email=?, cargo=?, salario=?, data_contratacao=?, status=? WHERE id_funcionario=?";
                    stmt = conn.prepareStatement(sql);
                    stmt.setString(1, nome);
                    stmt.setString(2, sexo);
                    stmt.setString(3, telefone);
                    stmt.setString(4, email);
                    stmt.setString(5, cargo);
                    stmt.setDouble(6, salario);
                    stmt.setString(7, dataContratacao);
                    stmt.setString(8, status);
                    stmt.setInt(9, id);
                    stmt.executeUpdate();

                    if (idTurno > 0) {
                        String sqlTurno = "DELETE FROM funcionario_turno WHERE id_funcionario=?";
                        try (PreparedStatement stmtDel = conn.prepareStatement(sqlTurno)) {
                            stmtDel.setInt(1, id);
                            stmtDel.executeUpdate();
                        }
                        String sqlInsertTurno = "INSERT INTO funcionario_turno (id_funcionario, id_turno) VALUES (?, ?)";
                        try (PreparedStatement stmtIns = conn.prepareStatement(sqlInsertTurno)) {
                            stmtIns.setInt(1, id);
                            stmtIns.setInt(2, idTurno);
                            stmtIns.executeUpdate();
                        }
                    }
                } else {
                    String sql = "INSERT INTO funcionario (nome_completo, sexo, telefone, email, cargo, salario, data_contratacao, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                    stmt.setString(1, nome);
                    stmt.setString(2, sexo);
                    stmt.setString(3, telefone);
                    stmt.setString(4, email);
                    stmt.setString(5, cargo);
                    stmt.setDouble(6, salario);
                    stmt.setString(7, dataContratacao);
                    stmt.setString(8, status);
                    stmt.executeUpdate();

                    ResultSet rs = stmt.getGeneratedKeys();
                    int newId = 0;
                    if (rs.next()) {
                        newId = rs.getInt(1);
                    }

                    if (idTurno > 0 && newId > 0) {
                        String sqlTurno = "INSERT INTO funcionario_turno (id_funcionario, id_turno) VALUES (?, ?)";
                        try (PreparedStatement stmtTurno = conn.prepareStatement(sqlTurno)) {
                            stmtTurno.setInt(1, newId);
                            stmtTurno.setInt(2, idTurno);
                            stmtTurno.executeUpdate();
                        }
                    }
                }

                conn.commit();
                success = true;

            } catch (SQLException e) {
                if (conn != null) conn.rollback();
                throw e;
            } finally {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            }

            result.addProperty("success", success);
            if (!success) result.addProperty("message", "Erro ao salvar funcionário");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void excluirFuncionario(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            try (Connection conn = ConexaoDB.getConexao()) {
                String sqlTurno = "DELETE FROM funcionario_turno WHERE id_funcionario=?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlTurno)) {
                    stmt.setInt(1, id);
                    stmt.executeUpdate();
                }

                String sql = "DELETE FROM funcionario WHERE id_funcionario=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, id);
                    stmt.executeUpdate();
                }
            }

            result.addProperty("success", true);

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void listarCargos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT DISTINCT cargo FROM funcionario WHERE cargo IS NOT NULL AND cargo != '' ORDER BY cargo";
        JsonArray jsonArray = new JsonArray();

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                jsonArray.add(rs.getString("cargo"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(jsonArray));
        out.flush();
    }

    private void listarTurnos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT id_turno, nome_turno, hora_inicio, hora_fim FROM turno ORDER BY id_turno";
        JsonArray jsonArray = new JsonArray();

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_turno", rs.getInt("id_turno"));
                obj.addProperty("nome_turno", rs.getString("nome_turno"));
                obj.addProperty("hora_inicio", rs.getString("hora_inicio"));
                obj.addProperty("hora_fim", rs.getString("hora_fim"));
                jsonArray.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(jsonArray));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sqlTotal = "SELECT COUNT(*) FROM funcionario";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlAtivos = "SELECT COUNT(*) FROM funcionario WHERE status = 'ATIVO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlAtivos); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("ativos", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlInativos = "SELECT COUNT(*) FROM funcionario WHERE status = 'INATIVO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlInativos); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("inativos", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlMes = "SELECT COUNT(*) FROM funcionario WHERE MONTH(data_contratacao) = MONTH(CURDATE()) AND YEAR(data_contratacao) = YEAR(CURDATE())";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMes); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("contratados_mes", rs.next() ? rs.getInt(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total", 0);
            stats.addProperty("ativos", 0);
            stats.addProperty("inativos", 0);
            stats.addProperty("contratados_mes", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/funcionarios".equals(path)) {
            request.getRequestDispatcher("/Admin/funcionario.jsp").forward(request, response);
        } else if ("/Admin/funcionarios/listar".equals(path)) {
            listarFuncionarios(response);
        } else if ("/Admin/funcionarios/cargos".equals(path)) {
            listarCargos(response);
        } else if ("/Admin/funcionarios/turnos".equals(path)) {
            listarTurnos(response);
        } else if ("/Admin/funcionarios/stats".equals(path)) {
            getStats(response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/funcionarios/salvar".equals(path)) {
            salvarFuncionario(request, response);
        } else if ("/Admin/funcionarios/excluir".equals(path)) {
            excluirFuncionario(request, response);
        }
    }
}