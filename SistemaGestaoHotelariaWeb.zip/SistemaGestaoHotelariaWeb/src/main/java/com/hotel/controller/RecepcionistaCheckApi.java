package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/check/estatisticas",
        "/Recepcionista/api/check/pendentes",
        "/Recepcionista/api/check/hospedados",
        "/Recepcionista/api/check/checkouts",
        "/Recepcionista/api/check/hora",
        "/Recepcionista/api/check/realizar",
        "/Recepcionista/api/check/checkout/realizar",
        "/Recepcionista/api/check/detalhes-reserva",
        "/Recepcionista/api/check/detalhes-checkin",
        "/Recepcionista/api/cliente/lista"
})
public class RecepcionistaCheckApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat sdfDataHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/check/estatisticas":
                getEstatisticas(response);
                break;
            case "/Recepcionista/api/check/pendentes":
                getCheckinsPendentes(response);
                break;
            case "/Recepcionista/api/check/hospedados":
                getHospedados(response);
                break;
            case "/Recepcionista/api/check/checkouts":
                getCheckoutsHoje(response);
                break;
            case "/Recepcionista/api/check/hora":
                getCheckinsPorHora(response);
                break;
            case "/Recepcionista/api/check/detalhes-reserva":
                getDetalhesReserva(request, response);
                break;
            case "/Recepcionista/api/check/detalhes-checkin":
                getDetalhesCheckin(request, response);
                break;
            case "/Recepcionista/api/cliente/lista":
                getClientesLista(response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/check/realizar":
                realizarCheckin(request, response);
                break;
            case "/Recepcionista/api/check/checkout/realizar":
                realizarCheckout(request, response);
                break;
        }
    }

    private void getEstatisticas(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        String hoje = sdfData.format(new Date());

        try (Connection conn = ConexaoDB.getConexao()) {
            // Check-ins pendentes hoje
            String sqlPendentes = "SELECT COUNT(*) as total FROM reserva r " +
                    "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "WHERE DATE(r.data_entrada) = ? AND ci.id_checkin IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPendentes)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("pendentes", rs.getInt("total"));
                }
            }

            // Total check-ins hoje
            String sqlTotalCheckins = "SELECT COUNT(*) as total FROM reserva WHERE DATE(data_entrada) = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalCheckins)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("checkins_hoje", rs.getInt("total"));
                }
            }

            // Check-outs hoje
            String sqlCheckouts = "SELECT COUNT(*) as total FROM reserva WHERE DATE(data_saida) = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckouts)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("checkouts_hoje", rs.getInt("total"));
                }
            }

            // Hóspedes no hotel (check-in sem checkout)
            String sqlHospedados = "SELECT COUNT(*) as total FROM checkin ci " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE co.id_checkout IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedados);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("hospedados", rs.getInt("total"));
            }

            // Reservas pendentes (confirmadas)
            String sqlReservasPendentes = "SELECT COUNT(*) as total FROM reserva WHERE estado_reserva = 'CONFIRMADA'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlReservasPendentes);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("reservas_pendentes", rs.getInt("total"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getCheckinsPendentes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray checkins = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_entrada, '%d/%m/%Y') as data_entrada, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "r.numero_hospedes, COALESCE(r.observacoes, '') as observacoes " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                "WHERE DATE(r.data_entrada) = ? AND ci.id_checkin IS NULL " +
                "ORDER BY r.data_entrada ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("id_reserva", rs.getInt("id_reserva"));
                    item.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    item.addProperty("quarto_num", rs.getString("numero_quarto"));
                    item.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    item.addProperty("data_entrada", rs.getString("data_entrada"));
                    item.addProperty("data_saida", rs.getString("data_saida"));
                    item.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    item.addProperty("observacoes", rs.getString("observacoes"));
                    checkins.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(checkins));
        out.flush();
    }

    private void getHospedados(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray hospedes = new JsonArray();

        String sql = "SELECT ci.id_checkin, c.nome_completo, COALESCE(c.telefone, 'N/A') as telefone, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(ci.data_checkin, '%d/%m/%Y %H:%i') as data_checkin, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "COALESCE(SUM(cs.subtotal), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN consumo_servico cs ON r.id_reserva = cs.id_reserva " +
                "WHERE ci.id_checkout IS NULL " +
                "GROUP BY ci.id_checkin, c.nome_completo, c.telefone, q.numero_quarto, " +
                "tq.nome_tipo, ci.data_checkin, r.data_saida " +
                "ORDER BY ci.data_checkin DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject hospede = new JsonObject();
                hospede.addProperty("id_checkin", rs.getInt("id_checkin"));
                hospede.addProperty("nome", rs.getString("nome_completo"));
                hospede.addProperty("telefone", rs.getString("telefone"));
                hospede.addProperty("quarto_num", rs.getString("numero_quarto"));
                hospede.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                hospede.addProperty("data_checkin", rs.getString("data_checkin"));
                hospede.addProperty("data_saida", rs.getString("data_saida"));
                hospede.addProperty("consumo_total", rs.getDouble("consumo_total"));
                hospedes.add(hospede);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(hospedes));
        out.flush();
    }

    private void getCheckoutsHoje(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray checkouts = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT ci.id_checkin, c.nome_completo, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "DATEDIFF(r.data_saida, r.data_entrada) as diarias, " +
                "COALESCE(SUM(cs.subtotal), 0) as consumo_total, " +
                "COALESCE(tq.preco_diaria, 2500) as preco_diaria " +
                "FROM reserva r " +
                "JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN consumo_servico cs ON r.id_reserva = cs.id_reserva " +
                "WHERE DATE(r.data_saida) = ? AND ci.id_checkout IS NULL " +
                "GROUP BY ci.id_checkin, c.nome_completo, q.numero_quarto, tq.nome_tipo, " +
                "r.data_saida, r.data_entrada, tq.preco_diaria " +
                "ORDER BY c.nome_completo ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("id_checkin", rs.getInt("id_checkin"));
                    item.addProperty("nome", rs.getString("nome_completo"));
                    item.addProperty("quarto_num", rs.getString("numero_quarto"));
                    item.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    item.addProperty("data_saida", rs.getString("data_saida"));
                    int diarias = rs.getInt("diarias");
                    if (diarias <= 0) diarias = 1;
                    item.addProperty("diarias", diarias);
                    item.addProperty("consumo_total", rs.getDouble("consumo_total"));
                    item.addProperty("preco_diaria", rs.getDouble("preco_diaria"));

                    double totalQuarto = diarias * rs.getDouble("preco_diaria");
                    item.addProperty("total", totalQuarto + rs.getDouble("consumo_total"));
                    checkouts.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(checkouts));
        out.flush();
    }

    private void getCheckinsPorHora(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray dados = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT HOUR(ci.data_checkin) as hora, COUNT(*) as total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "WHERE DATE(ci.data_checkin) = ? " +
                "GROUP BY HOUR(ci.data_checkin) " +
                "ORDER BY hora ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                int[] checkinsPorHora = new int[24];
                while (rs.next()) {
                    int hora = rs.getInt("hora");
                    int total = rs.getInt("total");
                    if (hora >= 0 && hora < 24) {
                        checkinsPorHora[hora] = total;
                    }
                }
                for (int i = 0; i < 24; i++) {
                    JsonObject item = new JsonObject();
                    item.addProperty("hora", i);
                    item.addProperty("total", checkinsPorHora[i]);
                    dados.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            for (int i = 0; i < 24; i++) {
                JsonObject item = new JsonObject();
                item.addProperty("hora", i);
                item.addProperty("total", 0);
                dados.add(item);
            }
        }

        out.print(gson.toJson(dados));
        out.flush();
    }

    private void getDetalhesReserva(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idReserva = request.getParameter("id");
        JsonObject result = new JsonObject();

        String sql = "SELECT r.id_reserva, c.nome_completo, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_entrada, '%d/%m/%Y') as data_entrada, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "r.numero_hospedes, COALESCE(r.observacoes, '') as observacoes " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.id_reserva = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idReserva));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("cliente_nome", rs.getString("nome_completo"));
                    result.addProperty("quarto_num", rs.getString("numero_quarto"));
                    result.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    result.addProperty("data_entrada", rs.getString("data_entrada"));
                    result.addProperty("data_saida", rs.getString("data_saida"));
                    result.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    result.addProperty("observacoes", rs.getString("observacoes"));
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getDetalhesCheckin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idCheckin = request.getParameter("id");
        JsonObject result = new JsonObject();

        String sql = "SELECT ci.id_checkin, c.nome_completo, q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_entrada, '%d/%m/%Y') as data_entrada, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_saida, " +
                "DATEDIFF(r.data_saida, r.data_entrada) as diarias, " +
                "COALESCE(SUM(cs.subtotal), 0) as consumo_total, " +
                "COALESCE(tq.preco_diaria, 2500) as preco_diaria " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN consumo_servico cs ON r.id_reserva = cs.id_reserva " +
                "WHERE ci.id_checkin = ? " +
                "GROUP BY ci.id_checkin, c.nome_completo, q.numero_quarto, tq.nome_tipo, " +
                "r.data_entrada, r.data_saida, tq.preco_diaria";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idCheckin));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_checkin", rs.getInt("id_checkin"));
                    result.addProperty("cliente_nome", rs.getString("nome_completo"));
                    result.addProperty("quarto_num", rs.getString("numero_quarto"));
                    result.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    result.addProperty("data_entrada", rs.getString("data_entrada"));
                    result.addProperty("data_saida", rs.getString("data_saida"));
                    int diarias = rs.getInt("diarias");
                    if (diarias <= 0) diarias = 1;
                    result.addProperty("diarias", diarias);
                    result.addProperty("consumo_total", rs.getDouble("consumo_total"));
                    result.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getClientesLista(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray clientes = new JsonArray();

        String sql = "SELECT id_cliente, nome_completo, numero_documento FROM cliente ORDER BY nome_completo ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject cliente = new JsonObject();
                cliente.addProperty("id_cliente", rs.getInt("id_cliente"));
                cliente.addProperty("nome_completo", rs.getString("nome_completo"));
                cliente.addProperty("documento", rs.getString("numero_documento"));
                clientes.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(clientes));
        out.flush();
    }

    private void realizarCheckin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
        int quantidadeHospedes = Integer.parseInt(request.getParameter("quantidade_hospedes"));
        String observacoes = request.getParameter("observacoes");

        try (Connection conn = ConexaoDB.getConexao()) {
            conn.setAutoCommit(false);

            // Verificar se já existe check-in
            String sqlCheck = "SELECT id_checkin FROM checkin WHERE id_reserva = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheck)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        result.addProperty("success", false);
                        result.addProperty("error", "Já existe check-in para esta reserva");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            // Inserir check-in
            String sqlCheckin = "INSERT INTO checkin (id_reserva, data_checkin, quantidade_hospedes, observacoes) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckin, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, idReserva);
                stmt.setString(2, sdfDataHora.format(new Date()));
                stmt.setInt(3, quantidadeHospedes);
                stmt.setString(4, observacoes);
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    result.addProperty("id_checkin", rs.getInt(1));
                }
            }

            // Atualizar estado da reserva
            String sqlUpdateReserva = "UPDATE reserva SET estado_reserva = 'CONFIRMADA' WHERE id_reserva = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateReserva)) {
                stmt.setInt(1, idReserva);
                stmt.executeUpdate();
            }

            // Atualizar estado do quarto para OCUPADO
            String sqlUpdateQuarto = "UPDATE quarto q JOIN reserva r ON q.id_quarto = r.id_quarto SET q.estado = 'OCUPADO' WHERE r.id_reserva = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateQuarto)) {
                stmt.setInt(1, idReserva);
                stmt.executeUpdate();
            }

            conn.commit();
            result.addProperty("success", true);
            result.addProperty("message", "Check-in realizado com sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void realizarCheckout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int idCheckin = Integer.parseInt(request.getParameter("id_checkin"));
        double valorTotal = Double.parseDouble(request.getParameter("valor_total"));
        String observacoes = request.getParameter("observacoes");

        try (Connection conn = ConexaoDB.getConexao()) {
            conn.setAutoCommit(false);

            // Verificar se já existe checkout
            String sqlCheck = "SELECT id_checkout FROM checkout WHERE id_checkin = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheck)) {
                stmt.setInt(1, idCheckin);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        result.addProperty("success", false);
                        result.addProperty("error", "Já existe check-out para este check-in");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            // Inserir checkout
            String sqlCheckout = "INSERT INTO checkout (id_checkin, data_checkout, valor_total, observacoes) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckout)) {
                stmt.setInt(1, idCheckin);
                stmt.setString(2, sdfDataHora.format(new Date()));
                stmt.setDouble(3, valorTotal);
                stmt.setString(4, observacoes);
                stmt.executeUpdate();
            }

            // Obter o quarto da reserva
            String sqlGetQuarto = "SELECT q.id_quarto FROM checkin ci JOIN reserva r ON ci.id_reserva = r.id_reserva JOIN quarto q ON r.id_quarto = q.id_quarto WHERE ci.id_checkin = ?";
            int idQuarto = 0;
            try (PreparedStatement stmt = conn.prepareStatement(sqlGetQuarto)) {
                stmt.setInt(1, idCheckin);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) idQuarto = rs.getInt("id_quarto");
                }
            }

            // Atualizar estado do quarto para LIVRE
            if (idQuarto > 0) {
                String sqlUpdateQuarto = "UPDATE quarto SET estado = 'LIVRE' WHERE id_quarto = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateQuarto)) {
                    stmt.setInt(1, idQuarto);
                    stmt.executeUpdate();
                }
            }

            // Atualizar estado da reserva
            String sqlUpdateReserva = "UPDATE reserva r JOIN checkin ci ON r.id_reserva = ci.id_reserva SET r.estado_reserva = 'FINALIZADA' WHERE ci.id_checkin = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateReserva)) {
                stmt.setInt(1, idCheckin);
                stmt.executeUpdate();
            }

            conn.commit();
            result.addProperty("success", true);
            result.addProperty("message", "Check-out realizado com sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}