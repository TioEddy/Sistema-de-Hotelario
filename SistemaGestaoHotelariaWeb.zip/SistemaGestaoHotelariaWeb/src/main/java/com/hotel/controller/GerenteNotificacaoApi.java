package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/notificacoes",
        "/Gerente/api/notificacoes/contar"
})
public class GerenteNotificacaoApi extends HttpServlet {

    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/notificacoes".equals(path)) {
            listarNotificacoes(response);
        } else if ("/Gerente/api/notificacoes/contar".equals(path)) {
            contarNotificacoes(response);
        }
    }

    private void listarNotificacoes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        JsonArray notificacoes = new JsonArray();

        String sql = "SELECT ls.id_log, ls.acao, ls.descricao, ls.data_log, " +
                "u.nome as usuario_nome " +
                "FROM log_sistema ls " +
                "LEFT JOIN usuario u ON ls.id_usuario = u.id_usuario " +
                "ORDER BY ls.data_log DESC LIMIT 15";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject notif = new JsonObject();
                notif.addProperty("id", rs.getInt("id_log"));
                notif.addProperty("acao", rs.getString("acao"));
                notif.addProperty("descricao", rs.getString("descricao"));
                notif.addProperty("data", rs.getTimestamp("data_log") != null ?
                        rs.getTimestamp("data_log").toString() : "");
                notif.addProperty("usuario", rs.getString("usuario_nome") != null ?
                        rs.getString("usuario_nome") : "Sistema");
                notif.addProperty("tipo", getTipoByAcao(rs.getString("acao")));
                notif.addProperty("link", getLinkByAcao(rs.getString("acao")));
                notificacoes.add(notif);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        result.add("notificacoes", notificacoes);
        out.print(gson.toJson(result));
        out.flush();
    }

    private void contarNotificacoes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        int count = 0;

        String sql = "SELECT COUNT(*) as total FROM log_sistema WHERE data_log >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                count = rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        result.addProperty("count", count);
        out.print(gson.toJson(result));
        out.flush();
    }

    private String getTipoByAcao(String acao) {
        switch (acao) {
            case "LOGIN": return "login";
            case "LOGOUT": return "logout";
            case "CREATE": return "reserva";
            case "INSERT": return "reserva";
            case "UPDATE": return "reserva";
            case "DELETE": return "reserva";
            case "CHECKIN": return "checkin";
            case "CHECKOUT": return "checkout";
            default: return "info";
        }
    }

    private String getLinkByAcao(String acao) {
        switch (acao) {
            case "CREATE":
            case "INSERT":
            case "UPDATE":
            case "DELETE":
                return "reserva.jsp";
            case "CHECKIN":
            case "CHECKOUT":
                return "check.jsp";
            default:
                return "dashboard.jsp";
        }
    }
}