package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/qr/listar",
        "/Gerente/api/qr/stats",
        "/Gerente/api/qr/graficos",
        "/Gerente/api/qr/reservas-disponiveis",
        "/Gerente/api/qr/detalhes",
        "/Gerente/api/qr/gerar"
})
public class GerenteQrApi extends HttpServlet {

    private Gson gson = new Gson();
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/qr/listar":
                listarQrCodes(request, response);
                break;
            case "/Gerente/api/qr/stats":
                getStats(response);
                break;
            case "/Gerente/api/qr/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/qr/reservas-disponiveis":
                getReservasDisponiveis(response);
                break;
            case "/Gerente/api/qr/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/qr/gerar".equals(request.getServletPath())) {
            gerarQrCode(request, response);
        }
    }

    private void listarQrCodes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String estado = request.getParameter("estado");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT q.id_qrcode, q.id_reserva, q.codigo, q.data_geracao, q.estado, ");
            sql.append("c.nome_completo as cliente_nome, ");
            sql.append("CONCAT(qr.numero_quarto, ' - ', tq.nome_tipo) as quarto_num ");
            sql.append("FROM qr_code q ");
            sql.append("JOIN reserva r ON q.id_reserva = r.id_reserva ");
            sql.append("JOIN cliente c ON r.id_cliente = c.id_cliente ");
            sql.append("JOIN quarto qr ON r.id_quarto = qr.id_quarto ");
            sql.append("JOIN tipo_quarto tq ON qr.id_tipo_quarto = tq.id_tipo_quarto ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (c.nome_completo LIKE ? OR q.id_reserva LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (estado != null && !estado.isEmpty()) {
                sql.append("AND q.estado = ? ");
                params.add(estado);
            }

            sql.append("ORDER BY q.id_qrcode DESC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM qr_code q " +
                    "JOIN reserva r ON q.id_reserva = r.id_reserva " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND (c.nome_completo LIKE '%" + search + "%')";
            }
            if (estado != null && !estado.isEmpty()) {
                countSql += " AND q.estado = '" + estado + "'";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray qrArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_qrcode", rs.getInt("id_qrcode"));
                        obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                        obj.addProperty("codigo", rs.getString("codigo"));
                        obj.addProperty("data_geracao", rs.getString("data_geracao"));
                        obj.addProperty("estado", rs.getString("estado"));
                        obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                        obj.addProperty("quarto_num", rs.getString("quarto_num"));
                        qrArray.add(obj);
                    }
                }
            }

            result.add("qr_codes", qrArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("qr_codes", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT COUNT(*) as total, " +
                    "SUM(CASE WHEN estado = 'ATIVO' THEN 1 ELSE 0 END) as ativos, " +
                    "SUM(CASE WHEN estado = 'USADO' THEN 1 ELSE 0 END) as usados, " +
                    "SUM(CASE WHEN estado = 'EXPIRADO' THEN 1 ELSE 0 END) as expirados " +
                    "FROM qr_code";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    stats.addProperty("total", rs.getInt("total"));
                    stats.addProperty("ativos", rs.getInt("ativos"));
                    stats.addProperty("usados", rs.getInt("usados"));
                    stats.addProperty("expirados", rs.getInt("expirados"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Por estado
            String sqlEstado = "SELECT SUM(CASE WHEN estado = 'ATIVO' THEN 1 ELSE 0 END) as ativos, " +
                    "SUM(CASE WHEN estado = 'USADO' THEN 1 ELSE 0 END) as usados, " +
                    "SUM(CASE WHEN estado = 'EXPIRADO' THEN 1 ELSE 0 END) as expirados " +
                    "FROM qr_code";
            try (PreparedStatement stmt = conn.prepareStatement(sqlEstado);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("ativos", rs.getInt("ativos"));
                    result.addProperty("usados", rs.getInt("usados"));
                    result.addProperty("expirados", rs.getInt("expirados"));
                }
            }

            // Por mês (últimos 6 meses)
            JsonArray porMes = new JsonArray();
            String sqlMes = "SELECT DATE_FORMAT(data_geracao, '%b') as mes, COUNT(*) as total " +
                    "FROM qr_code WHERE data_geracao >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
                    "GROUP BY YEAR(data_geracao), MONTH(data_geracao) ORDER BY data_geracao ASC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMes);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("mes", rs.getString("mes"));
                    item.addProperty("total", rs.getInt("total"));
                    porMes.add(item);
                }
            }
            result.add("por_mes", porMes);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getReservasDisponiveis(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray reservas = new JsonArray();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "r.data_entrada, r.data_saida " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva IN ('CONFIRMADA', 'CHECK-IN') " +
                "AND NOT EXISTS (SELECT 1 FROM qr_code WHERE qr_code.id_reserva = r.id_reserva) " +
                "ORDER BY r.id_reserva DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto_num", rs.getString("quarto_num"));
                obj.addProperty("data_entrada", rs.getString("data_entrada"));
                obj.addProperty("data_saida", rs.getString("data_saida"));
                reservas.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(reservas));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT q.id_qrcode, q.id_reserva, q.codigo, q.data_geracao, q.estado, " +
                "c.nome_completo as cliente_nome, c.email as cliente_email, c.telefone as cliente_telefone, " +
                "CONCAT(qr.numero_quarto, ' - ', tq.nome_tipo) as quarto_num, " +
                "r.data_entrada, r.data_saida, r.numero_hospedes " +
                "FROM qr_code q " +
                "JOIN reserva r ON q.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto qr ON r.id_quarto = qr.id_quarto " +
                "JOIN tipo_quarto tq ON qr.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.id_qrcode = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_qrcode", rs.getInt("id_qrcode"));
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("codigo", rs.getString("codigo"));
                    result.addProperty("data_geracao", rs.getString("data_geracao"));
                    result.addProperty("estado", rs.getString("estado"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("cliente_email", rs.getString("cliente_email"));
                    result.addProperty("cliente_telefone", rs.getString("cliente_telefone"));
                    result.addProperty("quarto_num", rs.getString("quarto_num"));
                    result.addProperty("data_entrada", rs.getString("data_entrada"));
                    result.addProperty("data_saida", rs.getString("data_saida"));
                    result.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void gerarQrCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            int idReserva = data.get("id_reserva").getAsInt();

            // Verificar se já existe QR Code para esta reserva
            String sqlCheck = "SELECT COUNT(*) FROM qr_code WHERE id_reserva = ?";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlCheck)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        result.addProperty("success", false);
                        result.addProperty("message", "Esta reserva já possui um QR Code gerado");
                        out.print(gson.toJson(result));
                        out.flush();
                        return;
                    }
                }
            }

            // Gerar código único
            String codigo = "QR-" + idReserva + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            String dataGeracao = LocalDateTime.now().format(dtf);
            String estado = "ATIVO";

            String sql = "INSERT INTO qr_code (id_reserva, codigo, data_geracao, estado) VALUES (?, ?, ?, ?)";
            boolean success = false;

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idReserva);
                stmt.setString(2, codigo);
                stmt.setString(3, dataGeracao);
                stmt.setString(4, estado);
                success = stmt.executeUpdate() > 0;
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "QR_CODE", "qr_code", 0,
                        "QR Code gerado para reserva ID: " + idReserva,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "QR Code gerado com sucesso!" : "Erro ao gerar QR Code");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}