package com.hotel.controller;

import com.hotel.dao.*;
import com.hotel.model.*;
import com.hotel.util.GerenciadorNotificacoes;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/Admin/dashboard", "/Admin/logs", "/Admin/logs/listar", "/Admin/logs/tabelas", "/Admin/logs/stats",
        "/Admin/notificacoes", "/Admin/notificacoes/marcar",
        "/Admin/notificacoes/marcar-todas", "/Admin/notificacoes/contar",
        "/Admin/check", "/Admin/check/pendentes", "/Admin/check/hospedes",
        "/Admin/check/checkout-hoje", "/Admin/check/checkin", "/Admin/check/checkout",
        "/Admin/check/consumo", "/Admin/check/servicos", "/Admin/check/stats",
        "/Admin/check/detalhes", "/logout/registrar"})
public class AdminController extends HttpServlet {

    private ReservaDAO reservaDAO;
    private QuartoDAO quartoDAO;
    private ClienteDAO clienteDAO;
    private PagamentoDAO pagamentoDAO;
    private CheckinDAO checkinDAO;
    private LogSistemaDAO logDAO;
    private GerenciadorNotificacoes notifManager;
    private Gson gson;

    @Override
    public void init() {
        reservaDAO = new ReservaDAO();
        quartoDAO = new QuartoDAO();
        clienteDAO = new ClienteDAO();
        pagamentoDAO = new PagamentoDAO();
        checkinDAO = new CheckinDAO();
        logDAO = new LogSistemaDAO();
        notifManager = GerenciadorNotificacoes.getInstance();
        gson = new Gson();

        notifManager.notificarAlerta("Sistema Iniciado", "Dashboard do Administrador carregado");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/Admin/dashboard".equals(path)) {
            int totalClientes = clienteDAO.contarTotal();
            int quartosOcupados = quartoDAO.contarPorEstado("OCUPADO");
            int totalQuartos = quartoDAO.contarTotal();
            int checkinsHoje = checkinDAO.contarCheckinsHoje();
            double faturamentoMes = pagamentoDAO.somarPagamentosMes();
            int novosClientes = clienteDAO.contarNovosEsteMes();

            int reservasConfirmadas = reservaDAO.contarPorStatus("CONFIRMADA");
            int reservasPendentes = reservaDAO.contarPorStatus("PENDENTE");
            int reservasFinalizadas = reservaDAO.contarPorStatus("FINALIZADA");
            int reservasCanceladas = reservaDAO.contarPorStatus("CANCELADA");

            Map<String, Integer> estadosQuartos = quartoDAO.contarTodosEstados();
            List<Reserva> ultimasReservas = reservaDAO.listarUltimas(5);
            double totalPendente = pagamentoDAO.somarPendentes();

            request.setAttribute("totalClientes", totalClientes);
            request.setAttribute("quartosOcupados", quartosOcupados);
            request.setAttribute("totalQuartos", totalQuartos);
            request.setAttribute("checkinsHoje", checkinsHoje);
            request.setAttribute("faturamentoMes", faturamentoMes);
            request.setAttribute("novosClientes", novosClientes);
            request.setAttribute("reservasConfirmadas", reservasConfirmadas);
            request.setAttribute("reservasPendentes", reservasPendentes);
            request.setAttribute("reservasFinalizadas", reservasFinalizadas);
            request.setAttribute("reservasCanceladas", reservasCanceladas);
            request.setAttribute("estadosQuartos", estadosQuartos);
            request.setAttribute("ultimasReservas", ultimasReservas);
            request.setAttribute("totalPendente", totalPendente);

            request.getRequestDispatcher("/Admin/dashboard.jsp").forward(request, response);

        } else if ("/Admin/logs".equals(path)) {
            request.getRequestDispatcher("/Admin/logs.jsp").forward(request, response);

        } else if ("/Admin/logs/listar".equals(path)) {
            listarLogsJSON(response);

        } else if ("/Admin/logs/tabelas".equals(path)) {
            listarTabelasLogs(response);

        } else if ("/Admin/logs/stats".equals(path)) {
            getStatsLogs(response);

        } else if ("/Admin/notificacoes".equals(path)) {
            carregarNotificacoes(request, response);

        } else if ("/Admin/notificacoes/contar".equals(path)) {
            contarNotificacoes(request, response);

        } else if ("/Admin/check".equals(path)) {
            request.getRequestDispatcher("/Admin/check.jsp").forward(request, response);

        } else if ("/Admin/check/pendentes".equals(path)) {
            listarPendentes(response);

        } else if ("/Admin/check/hospedes".equals(path)) {
            listarHospedes(response);

        } else if ("/Admin/check/checkout-hoje".equals(path)) {
            listarCheckoutsHoje(response);

        } else if ("/Admin/check/servicos".equals(path)) {
            listarServicos(response);

        } else if ("/Admin/check/stats".equals(path)) {
            getStats(response);

        } else if ("/Admin/check/detalhes".equals(path)) {
            getDetalhesEstadia(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        if ("/Admin/notificacoes/marcar".equals(path)) {
            marcarNotificacaoComoLida(request, response);
        } else if ("/Admin/notificacoes/marcar-todas".equals(path)) {
            marcarTodasNotificacoes(request, response);
        } else if ("/Admin/check/checkin".equals(path)) {
            realizarCheckin(request, response);
        } else if ("/Admin/check/checkout".equals(path)) {
            realizarCheckout(request, response);
        } else if ("/Admin/check/consumo".equals(path)) {
            adicionarConsumo(request, response);
        } else if ("/logout/registrar".equals(path)) {
            registrarLogout(request, response);
        }
    }

    // ==================== LOGS METHODS ====================

    private void listarLogsJSON(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT l.id_log, l.id_usuario, l.acao, l.tabela_afetada, l.id_registro, " +
                "l.descricao, l.endereco_ip, l.navegador, l.data_log, " +
                "COALESCE(u.nome, 'Sistema') as usuario_nome " +
                "FROM log_sistema l " +
                "LEFT JOIN usuario u ON l.id_usuario = u.id_usuario " +
                "ORDER BY l.data_log DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            JsonArray jsonArray = new JsonArray();

            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_log", rs.getInt("id_log"));
                obj.addProperty("id_usuario", rs.getInt("id_usuario"));
                obj.addProperty("usuario_nome", rs.getString("usuario_nome"));
                obj.addProperty("acao", rs.getString("acao"));
                obj.addProperty("tabela_afetada", rs.getString("tabela_afetada"));
                obj.addProperty("id_registro", rs.getInt("id_registro"));
                obj.addProperty("descricao", rs.getString("descricao"));
                obj.addProperty("endereco_ip", rs.getString("endereco_ip"));
                obj.addProperty("navegador", rs.getString("navegador"));
                obj.addProperty("data_log", rs.getTimestamp("data_log") != null ? rs.getTimestamp("data_log").toString() : "");
                jsonArray.add(obj);
            }

            out.print(gson.toJson(jsonArray));

        } catch (SQLException e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    private void listarTabelasLogs(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT DISTINCT tabela_afetada FROM log_sistema WHERE tabela_afetada IS NOT NULL AND tabela_afetada != '' ORDER BY tabela_afetada";
        JsonArray jsonArray = new JsonArray();

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                jsonArray.add(rs.getString("tabela_afetada"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(jsonArray));
        out.flush();
    }

    private void getStatsLogs(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sqlTotal = "SELECT COUNT(*) FROM log_sistema";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotal); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlLoginsHoje = "SELECT COUNT(*) FROM log_sistema WHERE acao = 'LOGIN' AND DATE(data_log) = CURDATE()";
            try (PreparedStatement stmt = conn.prepareStatement(sqlLoginsHoje); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("logins_hoje", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlAlteracoesSemana = "SELECT COUNT(*) FROM log_sistema WHERE acao IN ('CREATE', 'UPDATE', 'DELETE') AND data_log >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlAlteracoesSemana); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("alteracoes_semana", rs.next() ? rs.getInt(1) : 0);
            }

            String sqlUsuariosAtivos = "SELECT COUNT(DISTINCT id_usuario) FROM log_sistema WHERE data_log >= DATE_SUB(NOW(), INTERVAL 7 DAY) AND id_usuario IS NOT NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlUsuariosAtivos); ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("usuarios_ativos", rs.next() ? rs.getInt(1) : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total", 0);
            stats.addProperty("logins_hoje", 0);
            stats.addProperty("alteracoes_semana", 0);
            stats.addProperty("usuarios_ativos", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void registrarLogout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            HttpSession session = request.getSession(false);
            if (session != null) {
                Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
                if (usuario != null) {
                    String ip = request.getHeader("X-Forwarded-For");
                    if (ip == null || ip.isEmpty()) {
                        ip = request.getRemoteAddr();
                    }
                    String navegador = request.getHeader("User-Agent");

                    logDAO.registrarLog(
                            usuario.getIdUsuario(),
                            "LOGOUT",
                            "sessao",
                            0,
                            "Usuário " + usuario.getNome() + " realizou logout do sistema",
                            ip != null ? ip : "IP não identificado",
                            navegador != null ? navegador : "Navegador não identificado"
                    );
                }
                session.invalidate();
            }
            result.addProperty("success", true);
        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    // ==================== CHECK-IN/CHECK-OUT METHODS ====================

    // 1. LISTAR CHECK-INS PENDENTES (reservas CONFIRMADAS que ainda não fizeram check-in)
    private void listarPendentes(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT r.id_reserva, r.id_cliente, c.nome_completo as cliente_nome, " +
                "r.id_quarto, q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "tq.preco_diaria, DATE(r.data_entrada) as data_entrada, " +
                "DATE(r.data_saida) as data_saida, r.numero_hospedes, " +
                "r.observacoes, r.estado_reserva " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE r.estado_reserva = 'CONFIRMADA' " +
                "AND NOT EXISTS (SELECT 1 FROM checkin ci WHERE ci.id_reserva = r.id_reserva) " +
                "ORDER BY r.data_entrada ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            StringBuilder json = new StringBuilder();
            json.append("[");

            while (rs.next()) {
                if (json.length() > 1) json.append(",");
                json.append("{");
                json.append("\"id_reserva\":").append(rs.getInt("id_reserva")).append(",");
                json.append("\"id_cliente\":").append(rs.getInt("id_cliente")).append(",");
                json.append("\"cliente_nome\":\"").append(escapeJson(rs.getString("cliente_nome"))).append("\",");
                json.append("\"id_quarto\":").append(rs.getInt("id_quarto")).append(",");
                json.append("\"numero_quarto\":\"").append(escapeJson(rs.getString("numero_quarto"))).append("\",");
                json.append("\"quarto_tipo\":\"").append(escapeJson(rs.getString("quarto_tipo"))).append("\",");
                json.append("\"preco_diaria\":").append(rs.getDouble("preco_diaria")).append(",");
                json.append("\"data_entrada\":\"").append(rs.getString("data_entrada")).append("\",");
                json.append("\"data_saida\":\"").append(rs.getString("data_saida")).append("\",");
                json.append("\"numero_hospedes\":").append(rs.getInt("numero_hospedes")).append(",");
                json.append("\"observacoes\":\"").append(escapeJson(rs.getString("observacoes"))).append("\",");
                json.append("\"estado_reserva\":\"").append(escapeJson(rs.getString("estado_reserva"))).append("\"");
                json.append("}");
            }

            json.append("]");
            out.print(json.toString());

        } catch (Exception e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // 2. LISTAR HÓSPEDES NO HOTEL (checkins sem checkout)
    private void listarHospedes(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT ci.id_checkin, ci.id_reserva, " +
                "c.nome_completo as cliente_nome, " +
                "r.id_quarto, q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "tq.preco_diaria, ci.data_checkin, DATE(r.data_saida) as data_saida_prevista, " +
                "ci.quantidade_hospedes, ci.observacoes, " +
                "COALESCE(SUM(cs.subtotal), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN consumo_servico cs ON ci.id_reserva = cs.id_reserva " +
                "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                "WHERE co.id_checkout IS NULL " +
                "GROUP BY ci.id_checkin, ci.id_reserva, c.nome_completo, " +
                "r.id_quarto, q.numero_quarto, tq.nome_tipo, tq.preco_diaria, " +
                "ci.data_checkin, r.data_saida, ci.quantidade_hospedes, ci.observacoes";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            StringBuilder json = new StringBuilder();
            json.append("[");

            while (rs.next()) {
                if (json.length() > 1) json.append(",");
                json.append("{");
                json.append("\"id_checkin\":").append(rs.getInt("id_checkin")).append(",");
                json.append("\"id_reserva\":").append(rs.getInt("id_reserva")).append(",");
                json.append("\"cliente_nome\":\"").append(escapeJson(rs.getString("cliente_nome"))).append("\",");
                json.append("\"id_quarto\":").append(rs.getInt("id_quarto")).append(",");
                json.append("\"numero_quarto\":\"").append(escapeJson(rs.getString("numero_quarto"))).append("\",");
                json.append("\"quarto_tipo\":\"").append(escapeJson(rs.getString("quarto_tipo"))).append("\",");
                json.append("\"preco_diaria\":").append(rs.getDouble("preco_diaria")).append(",");
                json.append("\"data_checkin\":\"").append(rs.getString("data_checkin")).append("\",");
                json.append("\"data_saida_prevista\":\"").append(rs.getString("data_saida_prevista")).append("\",");
                json.append("\"quantidade_hospedes\":").append(rs.getInt("quantidade_hospedes")).append(",");
                json.append("\"observacoes\":\"").append(escapeJson(rs.getString("observacoes"))).append("\",");
                json.append("\"consumo_total\":").append(rs.getDouble("consumo_total"));
                json.append("}");
            }

            json.append("]");
            out.print(json.toString());

        } catch (Exception e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // 3. LISTAR CHECK-OUTS PREVISTOS PARA HOJE
    private void listarCheckoutsHoje(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT ci.id_checkin, ci.id_reserva, " +
                "c.nome_completo as cliente_nome, " +
                "r.id_quarto, q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "tq.preco_diaria, ci.data_checkin, DATE(r.data_saida) as data_saida_prevista, " +
                "ci.quantidade_hospedes, " +
                "COALESCE(SUM(cs.subtotal), 0) as consumo_total, " +
                "DATEDIFF(r.data_saida, r.data_entrada) as dias_estadia " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN consumo_servico cs ON ci.id_reserva = cs.id_reserva " +
                "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                "WHERE DATE(r.data_saida) = CURDATE() " +
                "AND co.id_checkout IS NULL " +
                "GROUP BY ci.id_checkin, ci.id_reserva, c.nome_completo, " +
                "r.id_quarto, q.numero_quarto, tq.nome_tipo, tq.preco_diaria, " +
                "ci.data_checkin, r.data_saida, ci.quantidade_hospedes, r.data_entrada";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            StringBuilder json = new StringBuilder();
            json.append("[");

            while (rs.next()) {
                if (json.length() > 1) json.append(",");
                json.append("{");
                json.append("\"id_checkin\":").append(rs.getInt("id_checkin")).append(",");
                json.append("\"id_reserva\":").append(rs.getInt("id_reserva")).append(",");
                json.append("\"cliente_nome\":\"").append(escapeJson(rs.getString("cliente_nome"))).append("\",");
                json.append("\"id_quarto\":").append(rs.getInt("id_quarto")).append(",");
                json.append("\"numero_quarto\":\"").append(escapeJson(rs.getString("numero_quarto"))).append("\",");
                json.append("\"quarto_tipo\":\"").append(escapeJson(rs.getString("quarto_tipo"))).append("\",");
                json.append("\"preco_diaria\":").append(rs.getDouble("preco_diaria")).append(",");
                json.append("\"data_checkin\":\"").append(rs.getString("data_checkin")).append("\",");
                json.append("\"data_saida_prevista\":\"").append(rs.getString("data_saida_prevista")).append("\",");
                json.append("\"dias_estadia\":").append(rs.getInt("dias_estadia")).append(",");
                json.append("\"consumo_total\":").append(rs.getDouble("consumo_total"));
                json.append("}");
            }

            json.append("]");
            out.print(json.toString());

        } catch (Exception e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // 4. LISTAR SERVIÇOS
    private void listarServicos(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String sql = "SELECT id_servico, nome_servico, descricao, preco FROM servico ORDER BY nome_servico";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            StringBuilder json = new StringBuilder();
            json.append("[");

            while (rs.next()) {
                if (json.length() > 1) json.append(",");
                json.append("{");
                json.append("\"id_servico\":").append(rs.getInt("id_servico")).append(",");
                json.append("\"nome_servico\":\"").append(escapeJson(rs.getString("nome_servico"))).append("\",");
                json.append("\"descricao\":\"").append(escapeJson(rs.getString("descricao"))).append("\",");
                json.append("\"preco\":").append(rs.getDouble("preco"));
                json.append("}");
            }

            json.append("]");
            out.print(json.toString());

        } catch (Exception e) {
            e.printStackTrace();
            out.print("[]");
        }
        out.flush();
    }

    // 5. ESTATÍSTICAS PARA OS CARDS
    private void getStats(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        StringBuilder json = new StringBuilder();
        json.append("{");

        try (Connection conn = ConexaoDB.getConexao()) {
            // 1. Total de reservas CONFIRMADAS sem check-in (pendentes)
            String sqlCheckinsPendentes = "SELECT COUNT(*) FROM reserva WHERE estado_reserva = 'CONFIRMADA' " +
                    "AND NOT EXISTS (SELECT 1 FROM checkin ci WHERE ci.id_reserva = reserva.id_reserva)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckinsPendentes);
                 ResultSet rs = stmt.executeQuery()) {
                json.append("\"checkins_hoje\":").append(rs.next() ? rs.getInt(1) : 0).append(",");
            }

            // 2. Check-outs previstos para hoje
            String sqlCheckouts = "SELECT COUNT(*) FROM checkin ci " +
                    "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE DATE(r.data_saida) = CURDATE() AND co.id_checkout IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckouts);
                 ResultSet rs = stmt.executeQuery()) {
                json.append("\"checkouts_hoje\":").append(rs.next() ? rs.getInt(1) : 0).append(",");
            }

            // 3. Hóspedes no hotel (checkin sem checkout)
            String sqlHospedes = "SELECT COUNT(*) FROM checkin ci " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE co.id_checkout IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedes);
                 ResultSet rs = stmt.executeQuery()) {
                json.append("\"hospedes_hotel\":").append(rs.next() ? rs.getInt(1) : 0).append(",");
            }

            // 4. Total de reservas CONFIRMADAS
            String sqlPendentes = "SELECT COUNT(*) FROM reserva WHERE estado_reserva = 'CONFIRMADA'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPendentes);
                 ResultSet rs = stmt.executeQuery()) {
                json.append("\"reservas_pendentes\":").append(rs.next() ? rs.getInt(1) : 0);
            }

        } catch (Exception e) {
            e.printStackTrace();
            json.append("\"checkins_hoje\":0,\"checkouts_hoje\":0,\"hospedes_hotel\":0,\"reservas_pendentes\":0");
        }

        json.append("}");
        out.print(json.toString());
        out.flush();
    }

    private void getDetalhesEstadia(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        int idCheckin = Integer.parseInt(request.getParameter("id_checkin"));

        String sql = "SELECT ci.id_checkin, ci.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, tq.nome_tipo as quarto_tipo, " +
                "ci.data_checkin, DATE(r.data_saida) as data_saida_prevista, " +
                "ci.quantidade_hospedes, ci.observacoes, " +
                "COALESCE(SUM(cs.subtotal), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN consumo_servico cs ON ci.id_reserva = cs.id_reserva " +
                "WHERE ci.id_checkin = ? " +
                "GROUP BY ci.id_checkin, ci.id_reserva, c.nome_completo, q.numero_quarto, " +
                "tq.nome_tipo, ci.data_checkin, r.data_saida, ci.quantidade_hospedes, ci.observacoes";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCheckin);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    StringBuilder json = new StringBuilder();
                    json.append("{");
                    json.append("\"cliente_nome\":\"").append(escapeJson(rs.getString("cliente_nome"))).append("\",");
                    json.append("\"numero_quarto\":\"").append(escapeJson(rs.getString("numero_quarto"))).append("\",");
                    json.append("\"quarto_tipo\":\"").append(escapeJson(rs.getString("quarto_tipo"))).append("\",");
                    json.append("\"data_checkin\":\"").append(rs.getString("data_checkin")).append("\",");
                    json.append("\"data_saida_prevista\":\"").append(rs.getString("data_saida_prevista")).append("\",");
                    json.append("\"quantidade_hospedes\":").append(rs.getInt("quantidade_hospedes")).append(",");
                    json.append("\"consumo_total\":").append(rs.getDouble("consumo_total")).append(",");
                    json.append("\"observacoes\":\"").append(escapeJson(rs.getString("observacoes"))).append("\"");
                    json.append("}");
                    out.print(json.toString());
                } else {
                    out.print("{}");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{}");
        }
        out.flush();
    }

    // REALIZAR CHECK-IN - CORRIGIDO (REMOVI O id_quarto do INSERT)
    private void realizarCheckin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            int quantidadeHospedes = Integer.parseInt(request.getParameter("quantidade_hospedes"));
            String observacoes = request.getParameter("observacoes");

            // Buscar id_quarto da reserva para atualizar o estado do quarto depois
            String sqlBusca = "SELECT id_quarto FROM reserva WHERE id_reserva = ?";
            int idQuarto = 0;

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlBusca)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        idQuarto = rs.getInt("id_quarto");
                    }
                }
            }

            // Inserir checkin - CORRETO: tabela checkin NÃO tem coluna id_quarto
            String sqlInsert = "INSERT INTO checkin (id_reserva, data_checkin, quantidade_hospedes, observacoes) " +
                    "VALUES (?, NOW(), ?, ?)";

            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlInsert)) {
                stmt.setInt(1, idReserva);
                stmt.setInt(2, quantidadeHospedes);
                stmt.setString(3, observacoes);

                success = stmt.executeUpdate() > 0;

                if (success) {
                    // Atualizar estado do quarto para OCUPADO
                    String sqlUpdateQuarto = "UPDATE quarto SET estado = 'OCUPADO' WHERE id_quarto = ?";
                    try (PreparedStatement stmt2 = conn.prepareStatement(sqlUpdateQuarto)) {
                        stmt2.setInt(1, idQuarto);
                        stmt2.executeUpdate();
                    }

                    // Registrar log
                    if (usuarioLogado != null) {
                        logDAO.registrarLog(
                                usuarioLogado.getIdUsuario(),
                                "CHECKIN",
                                "reserva",
                                idReserva,
                                "Check-in realizado para reserva ID: " + idReserva,
                                request.getRemoteAddr(),
                                request.getHeader("User-Agent")
                        );
                    }
                }
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    private void realizarCheckout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            int idCheckin = Integer.parseInt(request.getParameter("id_checkin"));
            double valorTotal = Double.parseDouble(request.getParameter("valor_total"));
            String observacoes = request.getParameter("observacoes");

            // Buscar id_reserva e id_quarto
            String sqlBusca = "SELECT ci.id_reserva, r.id_quarto FROM checkin ci " +
                    "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                    "WHERE ci.id_checkin = ?";
            int idReserva = 0, idQuarto = 0;

            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlBusca)) {
                stmt.setInt(1, idCheckin);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        idReserva = rs.getInt("id_reserva");
                        idQuarto = rs.getInt("id_quarto");
                    }
                }
            }

            boolean success = false;

            try (Connection conn = ConexaoDB.getConexao()) {
                conn.setAutoCommit(false);

                // Inserir checkout
                String sqlInsertCheckout = "INSERT INTO checkout (id_checkin, data_checkout, valor_total, observacoes) " +
                        "VALUES (?, NOW(), ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sqlInsertCheckout)) {
                    stmt.setInt(1, idCheckin);
                    stmt.setDouble(2, valorTotal);
                    stmt.setString(3, observacoes);
                    stmt.executeUpdate();
                }

                // Atualizar estado da reserva para FINALIZADA
                String sqlUpdateReserva = "UPDATE reserva SET estado_reserva = 'FINALIZADA' WHERE id_reserva = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateReserva)) {
                    stmt.setInt(1, idReserva);
                    stmt.executeUpdate();
                }

                // Atualizar estado do quarto para LIVRE
                String sqlUpdateQuarto = "UPDATE quarto SET estado = 'LIVRE' WHERE id_quarto = ?";
                try (PreparedStatement stmt = conn.prepareStatement(sqlUpdateQuarto)) {
                    stmt.setInt(1, idQuarto);
                    stmt.executeUpdate();
                }

                conn.commit();
                success = true;

                // Registrar log
                if (success && usuarioLogado != null) {
                    logDAO.registrarLog(
                            usuarioLogado.getIdUsuario(),
                            "CHECKOUT",
                            "checkin",
                            idCheckin,
                            "Check-out realizado para checkin ID: " + idCheckin + " - Valor total: " + valorTotal,
                            request.getRemoteAddr(),
                            request.getHeader("User-Agent")
                    );
                }

            } catch (SQLException e) {
                e.printStackTrace();
                success = false;
            }

            out.print("{\"success\": " + success + "}");

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    private void adicionarConsumo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            HttpSession session = request.getSession();
            Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");

            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            int idServico = Integer.parseInt(request.getParameter("id_servico"));
            int quantidade = Integer.parseInt(request.getParameter("quantidade"));
            double preco = Double.parseDouble(request.getParameter("preco"));
            double subtotal = preco * quantidade;

            String sql = "INSERT INTO consumo_servico (id_reserva, id_servico, quantidade, subtotal, data_consumo, id_usuario) " +
                    "VALUES (?, ?, ?, ?, NOW(), ?)";

            boolean success = false;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idReserva);
                stmt.setInt(2, idServico);
                stmt.setInt(3, quantidade);
                stmt.setDouble(4, subtotal);
                stmt.setInt(5, usuarioLogado != null ? usuarioLogado.getIdUsuario() : 1);
                success = stmt.executeUpdate() > 0;

                if (success && usuarioLogado != null) {
                    logDAO.registrarLog(
                            usuarioLogado.getIdUsuario(),
                            "CONSUMO",
                            "consumo_servico",
                            0,
                            "Adicionado consumo: " + quantidade + "x serviço ID " + idServico + " - Subtotal: " + subtotal,
                            request.getRemoteAddr(),
                            request.getHeader("User-Agent")
                    );
                }
            }

            out.print("{\"success\": " + success + ", \"subtotal\": " + subtotal + "}");

        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"success\": false, \"message\": \"" + escapeJson(e.getMessage()) + "\"}");
        }
        out.flush();
    }

    // ==================== NOTIFICATION METHODS ====================

    private void carregarNotificacoes(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        List<Notificacao> notificacoes = notifManager.getNotificacoes(usuario.getIdUsuario(), 50);

        StringBuilder json = new StringBuilder();
        json.append("{\"notificacoes\":[");

        for (int i = 0; i < notificacoes.size(); i++) {
            Notificacao n = notificacoes.get(i);
            if (i > 0) json.append(",");
            json.append("{");
            json.append("\"id\":").append(n.getId()).append(",");
            json.append("\"titulo\":\"").append(escapeJson(n.getTitulo())).append("\",");
            json.append("\"mensagem\":\"").append(escapeJson(n.getMensagem())).append("\",");
            json.append("\"tipo\":\"").append(escapeJson(n.getTipo())).append("\",");
            json.append("\"icone\":\"").append(escapeJson(n.getIcone())).append("\",");
            json.append("\"cor\":\"").append(escapeJson(n.getCor())).append("\",");
            json.append("\"data\":\"").append(escapeJson(n.getData().toString())).append("\",");
            json.append("\"lida\":").append(n.isLida());
            json.append("}");
        }

        int naoLidas = notifManager.getNotificacoesNaoLidas(usuario.getIdUsuario());
        json.append("],\"naoLidas\":").append(naoLidas).append("}");

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(json.toString());
        out.flush();
    }

    private void contarNotificacoes(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        int count = notifManager.getNotificacoesNaoLidas(usuario.getIdUsuario());

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print("{\"count\": " + count + "}");
        out.flush();
    }

    private void marcarNotificacaoComoLida(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");
        int id = Integer.parseInt(request.getParameter("id"));

        notifManager.marcarComoLida(usuario.getIdUsuario(), id);

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.print("{\"success\": true}");
        out.flush();
    }

    private void marcarTodasNotificacoes(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        notifManager.marcarTodasComoLidas(usuario.getIdUsuario());

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        out.print("{\"success\": true}");
        out.flush();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}