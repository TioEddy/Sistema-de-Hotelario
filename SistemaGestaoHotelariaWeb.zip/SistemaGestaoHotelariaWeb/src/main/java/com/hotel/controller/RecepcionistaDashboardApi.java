package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/dashboard",
        "/Recepcionista/api/checkins/pendentes",
        "/Recepcionista/api/quartos/disponiveis",
        "/Recepcionista/api/hospedes/ativos",
        "/Recepcionista/api/checkins/hora"
})
public class RecepcionistaDashboardApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfData = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/dashboard":
                getDashboardData(response);
                break;
            case "/Recepcionista/api/checkins/pendentes":
                getCheckinsPendentes(response);
                break;
            case "/Recepcionista/api/quartos/disponiveis":
                getQuartosDisponiveis(response);
                break;
            case "/Recepcionista/api/hospedes/ativos":
                getHospedesAtivos(response);
                break;
            case "/Recepcionista/api/checkins/hora":
                getCheckinsPorHora(response);
                break;
        }
    }

    private void getDashboardData(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();
        String hoje = sdfData.format(new Date());

        try (Connection conn = ConexaoDB.getConexao()) {

            // Check-ins pendentes hoje
            String sqlCheckinsPendentes = "SELECT COUNT(*) as total FROM reserva r " +
                    "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "WHERE DATE(r.data_entrada) = ? AND ci.id_checkin IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckinsPendentes)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("checkins_pendentes", rs.getInt("total"));
                    else result.addProperty("checkins_pendentes", 0);
                }
            }

            // Total check-ins hoje
            String sqlTotalCheckins = "SELECT COUNT(*) as total FROM reserva WHERE DATE(data_entrada) = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalCheckins)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("checkins_hoje", rs.getInt("total"));
                    else result.addProperty("checkins_hoje", 0);
                }
            }

            // Check-outs pendentes hoje
            String sqlCheckoutsPendentes = "SELECT COUNT(*) as total FROM reserva r " +
                    "JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE DATE(r.data_saida) = ? AND co.id_checkout IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCheckoutsPendentes)) {
                stmt.setString(1, hoje);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) result.addProperty("checkouts_pendentes", rs.getInt("total"));
                    else result.addProperty("checkouts_pendentes", 0);
                }
            }

            // Quartos disponíveis
            String sqlQuartosDisponiveis = "SELECT COUNT(*) as total FROM quarto WHERE estado = 'LIVRE'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlQuartosDisponiveis);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("quartos_disponiveis", rs.getInt("total"));
                else result.addProperty("quartos_disponiveis", 0);
            }

            // Total de quartos
            String sqlTotalQuartos = "SELECT COUNT(*) as total FROM quarto";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalQuartos);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("total_quartos", rs.getInt("total"));
                else result.addProperty("total_quartos", 0);
            }

            // Quartos ocupados
            String sqlQuartosOcupados = "SELECT COUNT(*) as total FROM quarto WHERE estado = 'OCUPADO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlQuartosOcupados);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int ocupados = rs.getInt("total");
                    result.addProperty("quartos_ocupados", ocupados);
                    int total = result.get("total_quartos").getAsInt();
                    double taxa = total > 0 ? (ocupados * 100.0 / total) : 0;
                    result.addProperty("taxa_ocupacao", Math.round(taxa));
                } else {
                    result.addProperty("quartos_ocupados", 0);
                    result.addProperty("taxa_ocupacao", 0);
                }
            }

            // Hóspedes ativos
            String sqlHospedesAtivos = "SELECT COUNT(DISTINCT ci.id_checkin) as total FROM checkin ci " +
                    "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                    "WHERE co.id_checkout IS NULL";
            try (PreparedStatement stmt = conn.prepareStatement(sqlHospedesAtivos);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) result.addProperty("hospedes_ativos", rs.getInt("total"));
                else result.addProperty("hospedes_ativos", 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getCheckinsPendentes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray checkins = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(r.data_entrada, '%H:%i') as hora_entrada, " +
                "r.numero_hospedes, COALESCE(r.observacoes, '') as observacoes " +
                "FROM reserva r " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN checkin ci ON r.id_reserva = ci.id_reserva " +
                "WHERE DATE(r.data_entrada) = ? AND ci.id_checkin IS NULL AND r.estado_reserva = 'CONFIRMADA' " +
                "ORDER BY r.data_entrada ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("id_reserva", rs.getInt("id_reserva"));
                    item.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    item.addProperty("quarto_num", rs.getString("numero_quarto"));
                    item.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                    item.addProperty("hora_entrada", rs.getString("hora_entrada"));
                    item.addProperty("numero_hospedes", rs.getInt("numero_hospedes"));
                    item.addProperty("observacoes", rs.getString("observacoes"));
                    checkins.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(checkins));
        out.flush();
    }

    private void getQuartosDisponiveis(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray quartos = new JsonArray();

        String sql = "SELECT q.id_quarto, q.numero_quarto, q.piso, " +
                "COALESCE(tq.nome_tipo, 'Standard') as tipo, " +
                "COALESCE(tq.preco_diaria, 2500) as preco_diaria, " +
                "COALESCE(tq.descricao, 'Quarto confortável') as descricao " +
                "FROM quarto q " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "WHERE q.estado = 'LIVRE' " +
                "ORDER BY q.numero_quarto ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject quarto = new JsonObject();
                quarto.addProperty("id_quarto", rs.getInt("id_quarto"));
                quarto.addProperty("numero", rs.getString("numero_quarto"));
                quarto.addProperty("tipo", rs.getString("tipo"));
                quarto.addProperty("piso", rs.getInt("piso"));
                quarto.addProperty("preco_diaria", rs.getDouble("preco_diaria"));
                quarto.addProperty("descricao", rs.getString("descricao"));
                quartos.add(quarto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(quartos));
        out.flush();
    }

    private void getHospedesAtivos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray hospedes = new JsonArray();

        String sql = "SELECT c.nome_completo, COALESCE(c.telefone, 'N/A') as telefone, " +
                "q.numero_quarto, COALESCE(tq.nome_tipo, 'Standard') as tipo_quarto, " +
                "DATE_FORMAT(ci.data_checkin, '%d/%m/%Y %H:%i') as data_checkin, " +
                "DATE_FORMAT(r.data_saida, '%d/%m/%Y') as data_checkout, " +
                "COALESCE((SELECT SUM(cs2.subtotal) FROM consumo_servico cs2 WHERE cs2.id_reserva = r.id_reserva), 0) as consumo_total " +
                "FROM checkin ci " +
                "JOIN reserva r ON ci.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "LEFT JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN checkout co ON ci.id_checkin = co.id_checkin " +
                "WHERE co.id_checkout IS NULL " +
                "GROUP BY ci.id_checkin, c.nome_completo, c.telefone, q.numero_quarto, " +
                "tq.nome_tipo, ci.data_checkin, r.data_saida " +
                "ORDER BY ci.data_checkin DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject hospede = new JsonObject();
                hospede.addProperty("nome", rs.getString("nome_completo"));
                hospede.addProperty("telefone", rs.getString("telefone"));
                hospede.addProperty("quarto_num", rs.getString("numero_quarto"));
                hospede.addProperty("tipo_quarto", rs.getString("tipo_quarto"));
                hospede.addProperty("data_checkin", rs.getString("data_checkin"));
                hospede.addProperty("data_checkout", rs.getString("data_checkout"));
                hospede.addProperty("consumo_total", rs.getDouble("consumo_total"));
                hospedes.add(hospede);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(hospedes));
        out.flush();
    }

    private void getCheckinsPorHora(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray dados = new JsonArray();
        String hoje = sdfData.format(new Date());

        String sql = "SELECT HOUR(ci.data_checkin) as hora, COUNT(*) as total " +
                "FROM checkin ci " +
                "WHERE DATE(ci.data_checkin) = ? " +
                "GROUP BY HOUR(ci.data_checkin) " +
                "ORDER BY hora ASC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hoje);
            try (ResultSet rs = stmt.executeQuery()) {
                int[] checkinsPorHora = new int[24];
                while (rs.next()) {
                    int hora = rs.getInt("hora");
                    int total = rs.getInt("total");
                    if (hora >= 0 && hora < 24) {
                        checkinsPorHora[hora] = total;
                    }
                }
                for (int i = 0; i < 24; i++) {
                    JsonObject item = new JsonObject();
                    item.addProperty("hora", i);
                    item.addProperty("total", checkinsPorHora[i]);
                    dados.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            for (int i = 0; i < 24; i++) {
                JsonObject item = new JsonObject();
                item.addProperty("hora", i);
                item.addProperty("total", 0);
                dados.add(item);
            }
        }

        out.print(gson.toJson(dados));
        out.flush();
    }
}