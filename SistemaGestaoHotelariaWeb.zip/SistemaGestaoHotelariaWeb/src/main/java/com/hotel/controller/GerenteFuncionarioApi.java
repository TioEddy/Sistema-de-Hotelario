package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/funcionario/listar",
        "/Gerente/api/funcionario/stats",
        "/Gerente/api/funcionario/graficos",
        "/Gerente/api/funcionario/turnos",
        "/Gerente/api/funcionario/detalhes",
        "/Gerente/api/funcionario/salvar"
})
public class GerenteFuncionarioApi extends HttpServlet {

    private Gson gson = new Gson();
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/funcionario/listar":
                listarFuncionarios(request, response);
                break;
            case "/Gerente/api/funcionario/stats":
                getStats(response);
                break;
            case "/Gerente/api/funcionario/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/funcionario/turnos":
                getTurnos(response);
                break;
            case "/Gerente/api/funcionario/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/funcionario/salvar".equals(request.getServletPath())) {
            salvarFuncionario(request, response);
        }
    }

    private void listarFuncionarios(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String cargo = request.getParameter("cargo");
        String status = request.getParameter("status");

        if (request.getParameter("page") != null) {
            try {
                page = Integer.parseInt(request.getParameter("page"));
            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT f.id_funcionario, f.nome_completo as nome, f.sexo, f.telefone, f.email, ");
            sql.append("f.cargo, f.salario, f.data_contratacao, f.status, ");
            sql.append("COALESCE(ft.id_turno, 0) as id_turno, ");
            sql.append("COALESCE(t.nome_turno, 'Não definido') as nome_turno ");
            sql.append("FROM funcionario f ");
            sql.append("LEFT JOIN funcionario_turno ft ON f.id_funcionario = ft.id_funcionario ");
            sql.append("LEFT JOIN turno t ON ft.id_turno = t.id_turno ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (f.nome_completo LIKE ? OR f.cargo LIKE ? OR f.email LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (cargo != null && !cargo.isEmpty()) {
                sql.append("AND f.cargo = ? ");
                params.add(cargo);
            }
            if (status != null && !status.isEmpty()) {
                sql.append("AND f.status = ? ");
                params.add(status);
            }

            sql.append("ORDER BY f.id_funcionario DESC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM funcionario f WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND (f.nome_completo LIKE '%" + search + "%' OR f.cargo LIKE '%" + search + "%')";
            }
            if (cargo != null && !cargo.isEmpty()) {
                countSql += " AND f.cargo = '" + cargo + "'";
            }
            if (status != null && !status.isEmpty()) {
                countSql += " AND f.status = '" + status + "'";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray funcionariosArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_funcionario", rs.getInt("id_funcionario"));
                        obj.addProperty("nome", rs.getString("nome") != null ? rs.getString("nome") : "");
                        obj.addProperty("sexo", rs.getString("sexo") != null ? rs.getString("sexo") : "");
                        obj.addProperty("telefone", rs.getString("telefone") != null ? rs.getString("telefone") : "");
                        obj.addProperty("email", rs.getString("email") != null ? rs.getString("email") : "");
                        obj.addProperty("cargo", rs.getString("cargo") != null ? rs.getString("cargo") : "");
                        obj.addProperty("salario", rs.getDouble("salario"));
                        obj.addProperty("data_contratacao", rs.getString("data_contratacao") != null ? rs.getString("data_contratacao") : "");
                        obj.addProperty("status", rs.getString("status") != null ? rs.getString("status") : "");
                        obj.addProperty("id_turno", rs.getInt("id_turno"));
                        obj.addProperty("turno_nome", rs.getString("nome_turno") != null ? rs.getString("nome_turno") : "Não definido");
                        funcionariosArray.add(obj);
                    }
                }
            }

            result.add("funcionarios", funcionariosArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", Math.max(1, (int) Math.ceil(totalCount / (double) rowsPerPage)));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("funcionarios", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
            result.addProperty("total_count", 0);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            String sql = "SELECT " +
                    "COUNT(*) as total, " +
                    "SUM(CASE WHEN status = 'ATIVO' THEN 1 ELSE 0 END) as ativos, " +
                    "SUM(CASE WHEN status = 'INATIVO' THEN 1 ELSE 0 END) as inativos, " +
                    "SUM(CASE WHEN MONTH(data_contratacao) = MONTH(CURDATE()) AND YEAR(data_contratacao) = YEAR(CURDATE()) THEN 1 ELSE 0 END) as contratados_mes " +
                    "FROM funcionario";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    stats.addProperty("total", rs.getInt("total"));
                    stats.addProperty("ativos", rs.getInt("ativos"));
                    stats.addProperty("inativos", rs.getInt("inativos"));
                    stats.addProperty("contratados_mes", rs.getInt("contratados_mes"));
                } else {
                    stats.addProperty("total", 0);
                    stats.addProperty("ativos", 0);
                    stats.addProperty("inativos", 0);
                    stats.addProperty("contratados_mes", 0);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            stats.addProperty("total", 0);
            stats.addProperty("ativos", 0);
            stats.addProperty("inativos", 0);
            stats.addProperty("contratados_mes", 0);
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Por sexo
            String sqlSexo = "SELECT " +
                    "SUM(CASE WHEN sexo = 'M' THEN 1 ELSE 0 END) as homens, " +
                    "SUM(CASE WHEN sexo = 'F' THEN 1 ELSE 0 END) as mulheres " +
                    "FROM funcionario";
            try (PreparedStatement stmt = conn.prepareStatement(sqlSexo);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("homens", rs.getInt("homens"));
                    result.addProperty("mulheres", rs.getInt("mulheres"));
                } else {
                    result.addProperty("homens", 0);
                    result.addProperty("mulheres", 0);
                }
            }

            // Por cargo
            JsonArray porCargo = new JsonArray();
            String sqlCargo = "SELECT cargo, COUNT(*) as total FROM funcionario WHERE cargo IS NOT NULL GROUP BY cargo ORDER BY total DESC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlCargo);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("cargo", rs.getString("cargo"));
                    item.addProperty("total", rs.getInt("total"));
                    porCargo.add(item);
                }
            }
            result.add("por_cargo", porCargo);

        } catch (SQLException e) {
            e.printStackTrace();
            result.addProperty("homens", 0);
            result.addProperty("mulheres", 0);
            result.add("por_cargo", new JsonArray());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getTurnos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray turnos = new JsonArray();

        String sql = "SELECT id_turno, nome_turno, hora_inicio, hora_fim FROM turno ORDER BY id_turno";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            boolean hasData = false;
            while (rs.next()) {
                hasData = true;
                JsonObject obj = new JsonObject();
                obj.addProperty("id_turno", rs.getInt("id_turno"));
                obj.addProperty("nome_turno", rs.getString("nome_turno"));
                obj.addProperty("hora_inicio", rs.getString("hora_inicio"));
                obj.addProperty("hora_fim", rs.getString("hora_fim"));
                turnos.add(obj);
            }

            // Se não houver turnos no banco, adicionar turnos padrão
            if (!hasData) {
                // Turno Manhã
                JsonObject manha = new JsonObject();
                manha.addProperty("id_turno", 1);
                manha.addProperty("nome_turno", "Manhã");
                manha.addProperty("hora_inicio", "06:00:00");
                manha.addProperty("hora_fim", "14:00:00");
                turnos.add(manha);

                // Turno Tarde
                JsonObject tarde = new JsonObject();
                tarde.addProperty("id_turno", 2);
                tarde.addProperty("nome_turno", "Tarde");
                tarde.addProperty("hora_inicio", "14:00:00");
                tarde.addProperty("hora_fim", "22:00:00");
                turnos.add(tarde);

                // Turno Noite
                JsonObject noite = new JsonObject();
                noite.addProperty("id_turno", 3);
                noite.addProperty("nome_turno", "Noite");
                noite.addProperty("hora_inicio", "22:00:00");
                noite.addProperty("hora_fim", "06:00:00");
                turnos.add(noite);

                // Turno Administrativo
                JsonObject administrativo = new JsonObject();
                administrativo.addProperty("id_turno", 4);
                administrativo.addProperty("nome_turno", "Administrativo");
                administrativo.addProperty("hora_inicio", "08:00:00");
                administrativo.addProperty("hora_fim", "17:00:00");
                turnos.add(administrativo);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Retornar turnos padrão em caso de erro
            JsonObject manha = new JsonObject();
            manha.addProperty("id_turno", 1);
            manha.addProperty("nome_turno", "Manhã");
            manha.addProperty("hora_inicio", "06:00:00");
            manha.addProperty("hora_fim", "14:00:00");
            turnos.add(manha);

            JsonObject tarde = new JsonObject();
            tarde.addProperty("id_turno", 2);
            tarde.addProperty("nome_turno", "Tarde");
            tarde.addProperty("hora_inicio", "14:00:00");
            tarde.addProperty("hora_fim", "22:00:00");
            turnos.add(tarde);

            JsonObject noite = new JsonObject();
            noite.addProperty("id_turno", 3);
            noite.addProperty("nome_turno", "Noite");
            noite.addProperty("hora_inicio", "22:00:00");
            noite.addProperty("hora_fim", "06:00:00");
            turnos.add(noite);
        }

        out.print(gson.toJson(turnos));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT f.id_funcionario, f.nome_completo as nome, f.sexo, f.telefone, f.email, " +
                "f.cargo, f.salario, f.data_contratacao, f.status, " +
                "COALESCE(ft.id_turno, 0) as id_turno, " +
                "COALESCE(t.nome_turno, 'Não definido') as turno_nome " +
                "FROM funcionario f " +
                "LEFT JOIN funcionario_turno ft ON f.id_funcionario = ft.id_funcionario " +
                "LEFT JOIN turno t ON ft.id_turno = t.id_turno " +
                "WHERE f.id_funcionario = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_funcionario", rs.getInt("id_funcionario"));
                    result.addProperty("nome", rs.getString("nome") != null ? rs.getString("nome") : "");
                    result.addProperty("sexo", rs.getString("sexo") != null ? rs.getString("sexo") : "");
                    result.addProperty("telefone", rs.getString("telefone") != null ? rs.getString("telefone") : "");
                    result.addProperty("email", rs.getString("email") != null ? rs.getString("email") : "");
                    result.addProperty("cargo", rs.getString("cargo") != null ? rs.getString("cargo") : "");
                    result.addProperty("salario", rs.getDouble("salario"));
                    result.addProperty("data_contratacao", rs.getString("data_contratacao") != null ? rs.getString("data_contratacao") : "");
                    result.addProperty("status", rs.getString("status") != null ? rs.getString("status") : "");
                    result.addProperty("id_turno", rs.getInt("id_turno"));
                    result.addProperty("turno_nome", rs.getString("turno_nome") != null ? rs.getString("turno_nome") : "Não definido");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void salvarFuncionario(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }

            if (sb.toString().isEmpty()) {
                result.addProperty("success", false);
                result.addProperty("message", "Dados não recebidos");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            String idFuncionario = data.has("id_funcionario") && !data.get("id_funcionario").isJsonNull() && !data.get("id_funcionario").getAsString().isEmpty() ?
                    data.get("id_funcionario").getAsString() : null;
            String nome = data.has("nome") && !data.get("nome").isJsonNull() ? data.get("nome").getAsString() : null;
            String sexo = data.has("sexo") && !data.get("sexo").isJsonNull() && !data.get("sexo").getAsString().isEmpty() ?
                    data.get("sexo").getAsString() : null;
            String telefone = data.has("telefone") && !data.get("telefone").isJsonNull() ? data.get("telefone").getAsString() : null;
            String email = data.has("email") && !data.get("email").isJsonNull() ? data.get("email").getAsString() : null;
            String cargo = data.has("cargo") && !data.get("cargo").isJsonNull() ? data.get("cargo").getAsString() : null;
            double salario = 0;
            if (data.has("salario") && !data.get("salario").isJsonNull()) {
                try {
                    salario = data.get("salario").getAsDouble();
                } catch (NumberFormatException e) {
                    salario = 0;
                }
            }
            String dataContratacao = null;
            if (data.has("data_contratacao") && !data.get("data_contratacao").isJsonNull() && !data.get("data_contratacao").getAsString().isEmpty()) {
                dataContratacao = data.get("data_contratacao").getAsString();
            }
            String idTurno = data.has("id_turno") && !data.get("id_turno").isJsonNull() && data.get("id_turno").getAsInt() > 0 ?
                    data.get("id_turno").getAsString() : null;
            String status = data.has("status") && !data.get("status").isJsonNull() ?
                    data.get("status").getAsString() : "ATIVO";

            // Validação básica
            if (nome == null || nome.trim().isEmpty()) {
                result.addProperty("success", false);
                result.addProperty("message", "Nome do funcionário é obrigatório");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            if (cargo == null || cargo.trim().isEmpty()) {
                result.addProperty("success", false);
                result.addProperty("message", "Cargo é obrigatório");
                out.print(gson.toJson(result));
                out.flush();
                return;
            }

            // Se data de contratação não foi fornecida, usar data atual
            if (dataContratacao == null || dataContratacao.isEmpty()) {
                dataContratacao = LocalDate.now().format(dtf);
            }

            boolean success = false;

            if (idFuncionario != null && !idFuncionario.isEmpty()) {
                // UPDATE funcionario
                String sql = "UPDATE funcionario SET nome_completo=?, sexo=?, telefone=?, email=?, cargo=?, salario=?, data_contratacao=?, status=? WHERE id_funcionario=?";
                try (Connection conn = ConexaoDB.getConexao()) {
                    conn.setAutoCommit(false);
                    try {
                        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                            stmt.setString(1, nome);
                            stmt.setString(2, sexo);
                            stmt.setString(3, telefone);
                            stmt.setString(4, email);
                            stmt.setString(5, cargo);
                            stmt.setDouble(6, salario);
                            stmt.setDate(7, java.sql.Date.valueOf(dataContratacao));
                            stmt.setString(8, status);
                            stmt.setInt(9, Integer.parseInt(idFuncionario));
                            success = stmt.executeUpdate() > 0;
                        }

                        // UPDATE turno
                        if (idTurno != null && !idTurno.isEmpty()) {
                            // Remover turno antigo
                            String sqlDeleteTurno = "DELETE FROM funcionario_turno WHERE id_funcionario=?";
                            try (PreparedStatement stmt = conn.prepareStatement(sqlDeleteTurno)) {
                                stmt.setInt(1, Integer.parseInt(idFuncionario));
                                stmt.executeUpdate();
                            }

                            // Inserir novo turno
                            String sqlInsertTurno = "INSERT INTO funcionario_turno (id_funcionario, id_turno) VALUES (?, ?)";
                            try (PreparedStatement stmt = conn.prepareStatement(sqlInsertTurno)) {
                                stmt.setInt(1, Integer.parseInt(idFuncionario));
                                stmt.setInt(2, Integer.parseInt(idTurno));
                                stmt.executeUpdate();
                            }
                        }
                        conn.commit();
                    } catch (SQLException e) {
                        conn.rollback();
                        throw e;
                    }
                }
            } else {
                // INSERT funcionario
                String sql = "INSERT INTO funcionario (nome_completo, sexo, telefone, email, cargo, salario, data_contratacao, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                try (Connection conn = ConexaoDB.getConexao()) {
                    conn.setAutoCommit(false);
                    try {
                        int generatedId = -1;
                        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                            stmt.setString(1, nome);
                            stmt.setString(2, sexo);
                            stmt.setString(3, telefone);
                            stmt.setString(4, email);
                            stmt.setString(5, cargo);
                            stmt.setDouble(6, salario);
                            stmt.setDate(7, java.sql.Date.valueOf(dataContratacao));
                            stmt.setString(8, status);
                            success = stmt.executeUpdate() > 0;

                            if (success) {
                                try (ResultSet rs = stmt.getGeneratedKeys()) {
                                    if (rs.next()) {
                                        generatedId = rs.getInt(1);
                                    }
                                }
                            }
                        }

                        // INSERT turno
                        if (success && idTurno != null && !idTurno.isEmpty() && generatedId > 0) {
                            String sqlInsertTurno = "INSERT INTO funcionario_turno (id_funcionario, id_turno) VALUES (?, ?)";
                            try (PreparedStatement stmt = conn.prepareStatement(sqlInsertTurno)) {
                                stmt.setInt(1, generatedId);
                                stmt.setInt(2, Integer.parseInt(idTurno));
                                stmt.executeUpdate();
                            }
                        }
                        conn.commit();
                    } catch (SQLException e) {
                        conn.rollback();
                        throw e;
                    }
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "FUNCIONARIO", "funcionario", 0,
                        "Funcionário " + (idFuncionario != null ? "atualizado" : "criado") + ": " + nome,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Funcionário salvo com sucesso!" : "Erro ao salvar funcionário");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}