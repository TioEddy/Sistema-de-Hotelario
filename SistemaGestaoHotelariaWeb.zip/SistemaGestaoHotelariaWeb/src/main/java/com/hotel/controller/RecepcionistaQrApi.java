package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

@WebServlet(urlPatterns = {
        "/Recepcionista/api/qr/listar",
        "/Recepcionista/api/qr/detalhes",
        "/Recepcionista/api/qr/gerar"
})
public class RecepcionistaQrApi extends HttpServlet {

    private Gson gson = new Gson();
    private SimpleDateFormat sdfDataHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/qr/listar":
                listarQRCodes(response);
                break;
            case "/Recepcionista/api/qr/detalhes":
                detalhesQRCode(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Recepcionista/api/qr/gerar":
                gerarQRCode(request, response);
                break;
        }
    }

    private void listarQRCodes(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray qrCodes = new JsonArray();

        String sql = "SELECT q.id_qrcode, q.id_reserva, q.codigo, q.data_geracao, q.estado, " +
                "c.nome_completo as hospede_nome, q.numero_quarto " +
                "FROM qr_code q " +
                "LEFT JOIN reserva r ON q.id_reserva = r.id_reserva " +
                "LEFT JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "ORDER BY q.data_geracao DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                JsonObject qr = new JsonObject();
                qr.addProperty("id_qrcode", rs.getInt("id_qrcode"));
                qr.addProperty("id_reserva", rs.getInt("id_reserva"));
                qr.addProperty("codigo", rs.getString("codigo"));
                qr.addProperty("data_geracao", rs.getString("data_geracao"));
                qr.addProperty("estado", rs.getString("estado"));
                qr.addProperty("hospede_nome", rs.getString("hospede_nome"));
                qr.addProperty("quarto_num", rs.getString("numero_quarto"));
                qrCodes.add(qr);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(qrCodes));
        out.flush();
    }

    private void detalhesQRCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        String idQr = request.getParameter("id");
        JsonObject result = new JsonObject();

        String sql = "SELECT q.id_qrcode, q.id_reserva, q.codigo, q.data_geracao, q.estado, " +
                "c.nome_completo as hospede_nome, q.numero_quarto " +
                "FROM qr_code q " +
                "LEFT JOIN reserva r ON q.id_reserva = r.id_reserva " +
                "LEFT JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "WHERE q.id_qrcode = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(idQr));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_qrcode", rs.getInt("id_qrcode"));
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("codigo", rs.getString("codigo"));
                    result.addProperty("data_geracao", rs.getString("data_geracao"));
                    result.addProperty("estado", rs.getString("estado"));
                    result.addProperty("hospede_nome", rs.getString("hospede_nome"));
                    result.addProperty("quarto_num", rs.getString("numero_quarto"));
                    result.addProperty("success", true);
                } else {
                    result.addProperty("success", false);
                }
            }
        } catch (SQLException | NumberFormatException e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void gerarQRCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try {
            int idReserva = Integer.parseInt(request.getParameter("id_reserva"));
            String codigo = "QR-" + idReserva + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            String dataGeracao = sdfDataHora.format(new Date());

            // Buscar número do quarto da reserva
            String sqlQuarto = "SELECT q.numero_quarto FROM reserva r JOIN quarto q ON r.id_quarto = q.id_quarto WHERE r.id_reserva = ?";
            String numeroQuarto = null;
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sqlQuarto)) {
                stmt.setInt(1, idReserva);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        numeroQuarto = rs.getString("numero_quarto");
                    }
                }
            }

            String sql = "INSERT INTO qr_code (id_reserva, codigo, data_geracao, estado, numero_quarto) VALUES (?, ?, ?, 'ATIVO', ?)";
            try (Connection conn = ConexaoDB.getConexao();
                 PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, idReserva);
                stmt.setString(2, codigo);
                stmt.setString(3, dataGeracao);
                stmt.setString(4, numeroQuarto);
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    result.addProperty("id_qrcode", rs.getInt(1));
                }
            }

            result.addProperty("success", true);
            result.addProperty("message", "QR Code gerado com sucesso!");

        } catch (Exception e) {
            result.addProperty("success", false);
            result.addProperty("error", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}