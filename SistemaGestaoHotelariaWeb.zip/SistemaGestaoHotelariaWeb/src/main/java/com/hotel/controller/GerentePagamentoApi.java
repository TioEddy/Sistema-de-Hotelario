package com.hotel.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hotel.dao.ConexaoDB;
import com.hotel.dao.LogSistemaDAO;
import com.hotel.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet(urlPatterns = {
        "/Gerente/api/pagamento/listar",
        "/Gerente/api/pagamento/stats",
        "/Gerente/api/pagamento/graficos",
        "/Gerente/api/pagamento/reservas",
        "/Gerente/api/pagamento/metodos",
        "/Gerente/api/pagamento/detalhes",
        "/Gerente/api/pagamento/salvar"
})
public class GerentePagamentoApi extends HttpServlet {

    private Gson gson = new Gson();
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        switch (path) {
            case "/Gerente/api/pagamento/listar":
                listarPagamentos(request, response);
                break;
            case "/Gerente/api/pagamento/stats":
                getStats(response);
                break;
            case "/Gerente/api/pagamento/graficos":
                getGraficos(response);
                break;
            case "/Gerente/api/pagamento/reservas":
                getReservasComSaldo(response);
                break;
            case "/Gerente/api/pagamento/metodos":
                getMetodosPagamento(response);
                break;
            case "/Gerente/api/pagamento/detalhes":
                getDetalhes(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if ("/Gerente/api/pagamento/salvar".equals(request.getServletPath())) {
            salvarPagamento(request, response);
        }
    }

    private void listarPagamentos(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int page = 1;
        int rowsPerPage = 10;
        String search = request.getParameter("search");
        String estado = request.getParameter("estado");
        String metodo = request.getParameter("metodo");
        String data = request.getParameter("data");

        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        int offset = (page - 1) * rowsPerPage;

        try (Connection conn = ConexaoDB.getConexao()) {
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT p.id_pagamento, p.id_reserva, p.id_metodo_pagamento, p.valor, ");
            sql.append("p.data_pagamento, p.referencia_pagamento, p.estado_pagamento, ");
            sql.append("c.nome_completo as cliente_nome, mp.nome_metodo as metodo_nome ");
            sql.append("FROM pagamento p ");
            sql.append("JOIN reserva r ON p.id_reserva = r.id_reserva ");
            sql.append("JOIN cliente c ON r.id_cliente = c.id_cliente ");
            sql.append("LEFT JOIN metodo_pagamento mp ON p.id_metodo_pagamento = mp.id_metodo_pagamento ");
            sql.append("WHERE 1=1 ");

            List<Object> params = new ArrayList<>();

            if (search != null && !search.isEmpty()) {
                sql.append("AND (c.nome_completo LIKE ? OR p.id_reserva LIKE ?) ");
                params.add("%" + search + "%");
                params.add("%" + search + "%");
            }
            if (estado != null && !estado.isEmpty()) {
                sql.append("AND p.estado_pagamento = ? ");
                params.add(estado);
            }
            if (metodo != null && !metodo.isEmpty()) {
                sql.append("AND mp.nome_metodo = ? ");
                params.add(metodo);
            }
            if (data != null && !data.isEmpty()) {
                sql.append("AND DATE(p.data_pagamento) = ? ");
                params.add(data);
            }

            sql.append("ORDER BY p.id_pagamento DESC LIMIT ? OFFSET ?");
            params.add(rowsPerPage);
            params.add(offset);

            // Contar total
            String countSql = "SELECT COUNT(*) as total FROM pagamento p " +
                    "JOIN reserva r ON p.id_reserva = r.id_reserva " +
                    "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                    "LEFT JOIN metodo_pagamento mp ON p.id_metodo_pagamento = mp.id_metodo_pagamento WHERE 1=1";
            if (search != null && !search.isEmpty()) {
                countSql += " AND (c.nome_completo LIKE '%" + search + "%')";
            }
            if (estado != null && !estado.isEmpty()) {
                countSql += " AND p.estado_pagamento = '" + estado + "'";
            }
            if (metodo != null && !metodo.isEmpty()) {
                countSql += " AND mp.nome_metodo = '" + metodo + "'";
            }
            if (data != null && !data.isEmpty()) {
                countSql += " AND DATE(p.data_pagamento) = '" + data + "'";
            }

            int totalCount = 0;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(countSql)) {
                if (rs.next()) totalCount = rs.getInt("total");
            }

            JsonArray pagamentosArray = new JsonArray();
            try (PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i));
                }
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        JsonObject obj = new JsonObject();
                        obj.addProperty("id_pagamento", rs.getInt("id_pagamento"));
                        obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                        obj.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                        obj.addProperty("valor", rs.getDouble("valor"));
                        obj.addProperty("data_pagamento", rs.getString("data_pagamento"));
                        obj.addProperty("referencia_pagamento", rs.getString("referencia_pagamento"));
                        obj.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                        obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                        obj.addProperty("metodo_nome", rs.getString("metodo_nome"));
                        pagamentosArray.add(obj);
                    }
                }
            }

            result.add("pagamentos", pagamentosArray);
            result.addProperty("current_page", page);
            result.addProperty("total_pages", (int) Math.ceil(totalCount / (double) rowsPerPage));
            result.addProperty("total_count", totalCount);

        } catch (SQLException e) {
            e.printStackTrace();
            result.add("pagamentos", new JsonArray());
            result.addProperty("current_page", 1);
            result.addProperty("total_pages", 1);
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getStats(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject stats = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Total arrecadado
            String sqlTotalArrecadado = "SELECT COALESCE(SUM(valor), 0) as total FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalArrecadado);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_arrecadado", rs.next() ? rs.getDouble("total") : 0);
            }

            // Total pendente (soma dos saldos das faturas)
            String sqlTotalPendente = "SELECT COALESCE(SUM(f.total - COALESCE(p.pago, 0)), 0) as total " +
                    "FROM fatura f " +
                    "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento WHERE estado_pagamento = 'PAGO' GROUP BY id_reserva) p " +
                    "ON f.id_reserva = p.id_reserva " +
                    "WHERE (f.total - COALESCE(p.pago, 0)) > 0";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTotalPendente);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("total_pendente", rs.next() ? rs.getDouble("total") : 0);
            }

            // Pagamentos hoje
            String sqlPagamentosHoje = "SELECT COUNT(*) as total FROM pagamento WHERE DATE(data_pagamento) = CURDATE() AND estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlPagamentosHoje);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("pagamentos_hoje", rs.next() ? rs.getInt("total") : 0);
            }

            // Ticket médio
            String sqlTicketMedio = "SELECT COALESCE(AVG(valor), 0) as media FROM pagamento WHERE estado_pagamento = 'PAGO'";
            try (PreparedStatement stmt = conn.prepareStatement(sqlTicketMedio);
                 ResultSet rs = stmt.executeQuery()) {
                stats.addProperty("ticket_medio", rs.next() ? rs.getDouble("media") : 0);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(stats));
        out.flush();
    }

    private void getGraficos(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        try (Connection conn = ConexaoDB.getConexao()) {
            // Por método de pagamento
            JsonArray porMetodo = new JsonArray();
            String sqlMetodo = "SELECT mp.nome_metodo as metodo, COALESCE(SUM(p.valor), 0) as total " +
                    "FROM metodo_pagamento mp " +
                    "LEFT JOIN pagamento p ON mp.id_metodo_pagamento = p.id_metodo_pagamento AND p.estado_pagamento = 'PAGO' " +
                    "GROUP BY mp.id_metodo_pagamento, mp.nome_metodo " +
                    "HAVING total > 0";
            try (PreparedStatement stmt = conn.prepareStatement(sqlMetodo);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("metodo", rs.getString("metodo"));
                    item.addProperty("total", rs.getDouble("total"));
                    porMetodo.add(item);
                }
            }
            result.add("por_metodo", porMetodo);

            // Evolução mensal (últimos 6 meses)
            JsonArray evolucaoMensal = new JsonArray();
            String sqlEvolucao = "SELECT DATE_FORMAT(data_pagamento, '%b') as mes, COALESCE(SUM(valor), 0) as total " +
                    "FROM pagamento WHERE data_pagamento >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
                    "AND estado_pagamento = 'PAGO' " +
                    "GROUP BY YEAR(data_pagamento), MONTH(data_pagamento) " +
                    "ORDER BY data_pagamento ASC";
            try (PreparedStatement stmt = conn.prepareStatement(sqlEvolucao);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    JsonObject item = new JsonObject();
                    item.addProperty("mes", rs.getString("mes"));
                    item.addProperty("total", rs.getDouble("total"));
                    evolucaoMensal.add(item);
                }
            }
            result.add("evolucao_mensal", evolucaoMensal);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void getReservasComSaldo(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray reservas = new JsonArray();

        String sql = "SELECT r.id_reserva, c.nome_completo as cliente_nome, " +
                "CONCAT(q.numero_quarto, ' - ', tq.nome_tipo) as quarto, " +
                "f.total, COALESCE(p.pago, 0) as total_pago, " +
                "(f.total - COALESCE(p.pago, 0)) as saldo_pendente " +
                "FROM fatura f " +
                "JOIN reserva r ON f.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "JOIN quarto q ON r.id_quarto = q.id_quarto " +
                "JOIN tipo_quarto tq ON q.id_tipo_quarto = tq.id_tipo_quarto " +
                "LEFT JOIN (SELECT id_reserva, SUM(valor) as pago FROM pagamento WHERE estado_pagamento = 'PAGO' GROUP BY id_reserva) p " +
                "ON f.id_reserva = p.id_reserva " +
                "WHERE (f.total - COALESCE(p.pago, 0)) > 0 " +
                "ORDER BY saldo_pendente DESC";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_reserva", rs.getInt("id_reserva"));
                obj.addProperty("cliente_nome", rs.getString("cliente_nome"));
                obj.addProperty("quarto", rs.getString("quarto"));
                obj.addProperty("total", rs.getDouble("total"));
                obj.addProperty("total_pago", rs.getDouble("total_pago"));
                obj.addProperty("saldo_pendente", rs.getDouble("saldo_pendente"));
                reservas.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(reservas));
        out.flush();
    }

    private void getMetodosPagamento(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonArray metodos = new JsonArray();

        String sql = "SELECT id_metodo_pagamento, nome_metodo FROM metodo_pagamento ORDER BY nome_metodo";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                obj.addProperty("nome_metodo", rs.getString("nome_metodo"));
                metodos.add(obj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(metodos));
        out.flush();
    }

    private void getDetalhes(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "SELECT p.id_pagamento, p.id_reserva, p.id_metodo_pagamento, p.valor, " +
                "p.data_pagamento, p.referencia_pagamento, p.estado_pagamento, " +
                "c.nome_completo as cliente_nome, mp.nome_metodo as metodo_nome " +
                "FROM pagamento p " +
                "JOIN reserva r ON p.id_reserva = r.id_reserva " +
                "JOIN cliente c ON r.id_cliente = c.id_cliente " +
                "LEFT JOIN metodo_pagamento mp ON p.id_metodo_pagamento = mp.id_metodo_pagamento " +
                "WHERE p.id_pagamento = ?";

        try (Connection conn = ConexaoDB.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    result.addProperty("id_pagamento", rs.getInt("id_pagamento"));
                    result.addProperty("id_reserva", rs.getInt("id_reserva"));
                    result.addProperty("id_metodo_pagamento", rs.getInt("id_metodo_pagamento"));
                    result.addProperty("valor", rs.getDouble("valor"));
                    result.addProperty("data_pagamento", rs.getString("data_pagamento"));
                    result.addProperty("referencia_pagamento", rs.getString("referencia_pagamento"));
                    result.addProperty("estado_pagamento", rs.getString("estado_pagamento"));
                    result.addProperty("cliente_nome", rs.getString("cliente_nome"));
                    result.addProperty("metodo_nome", rs.getString("metodo_nome"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private void salvarPagamento(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        JsonObject result = new JsonObject();

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogado");

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (java.io.BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JsonObject data = gson.fromJson(sb.toString(), JsonObject.class);

            String idPagamento = data.has("id_pagamento") && !data.get("id_pagamento").isJsonNull() ? data.get("id_pagamento").getAsString() : null;
            int idReserva = data.get("id_reserva").getAsInt();
            int idMetodoPagamento = data.get("id_metodo_pagamento").getAsInt();
            double valor = data.get("valor").getAsDouble();
            String referencia = data.has("referencia_pagamento") && !data.get("referencia_pagamento").isJsonNull() ? data.get("referencia_pagamento").getAsString() : null;
            String estado = data.get("estado_pagamento").getAsString();
            String dataPagamento = data.has("data_pagamento") && !data.get("data_pagamento").isJsonNull() ? data.get("data_pagamento").getAsString() : null;

            if (dataPagamento == null || dataPagamento.isEmpty()) {
                dataPagamento = LocalDateTime.now().format(dtf);
            } else {
                dataPagamento = dataPagamento.replace('T', ' ') + ":00";
            }

            boolean success = false;

            if (idPagamento != null && !idPagamento.isEmpty()) {
                String sql = "UPDATE pagamento SET id_reserva=?, id_metodo_pagamento=?, valor=?, data_pagamento=?, referencia_pagamento=?, estado_pagamento=? WHERE id_pagamento=?";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, idReserva);
                    stmt.setInt(2, idMetodoPagamento);
                    stmt.setDouble(3, valor);
                    stmt.setTimestamp(4, Timestamp.valueOf(dataPagamento));
                    stmt.setString(5, referencia);
                    stmt.setString(6, estado);
                    stmt.setInt(7, Integer.parseInt(idPagamento));
                    success = stmt.executeUpdate() > 0;
                }
            } else {
                String sql = "INSERT INTO pagamento (id_reserva, id_metodo_pagamento, valor, data_pagamento, referencia_pagamento, estado_pagamento) VALUES (?, ?, ?, ?, ?, ?)";
                try (Connection conn = ConexaoDB.getConexao();
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, idReserva);
                    stmt.setInt(2, idMetodoPagamento);
                    stmt.setDouble(3, valor);
                    stmt.setTimestamp(4, Timestamp.valueOf(dataPagamento));
                    stmt.setString(5, referencia);
                    stmt.setString(6, estado);
                    success = stmt.executeUpdate() > 0;
                }
            }

            if (success && usuario != null) {
                LogSistemaDAO logDAO = new LogSistemaDAO();
                logDAO.registrarLog(usuario.getIdUsuario(), "PAGAMENTO", "pagamento", 0,
                        "Pagamento " + (idPagamento != null ? "atualizado" : "registrado") + " no valor de " + valor + " MZN para reserva ID: " + idReserva,
                        request.getRemoteAddr(), request.getHeader("User-Agent"));
            }

            result.addProperty("success", success);
            result.addProperty("message", success ? "Pagamento registrado com sucesso!" : "Erro ao registrar pagamento");

        } catch (Exception e) {
            e.printStackTrace();
            result.addProperty("success", false);
            result.addProperty("message", e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
}