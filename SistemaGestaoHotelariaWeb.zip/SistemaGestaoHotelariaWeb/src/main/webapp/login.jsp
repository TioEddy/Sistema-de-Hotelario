<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login · Sistema de Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0B2B40 0%, #1A4B6E 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
        }
        body::before { content: "🏨"; position: absolute; bottom: 20px; left: 20px; font-size: 90px; opacity: 0.08; pointer-events: none; }
        body::after { content: "🔑"; position: absolute; top: 20px; right: 20px; font-size: 80px; opacity: 0.08; pointer-events: none; }
        .login-container { width: 100%; max-width: 460px; animation: fadeInUp 0.6s ease-out; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .login-card { background: white; border-radius: 32px; padding: 44px 36px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35); border: 1px solid rgba(255, 184, 0, 0.2); }
        .logo-area { text-align: center; margin-bottom: 32px; }
        .logo-img { width: 100px; height: 100px; object-fit: contain; margin-bottom: 16px; border-radius: 50%; background: #F5F5F5; padding: 12px; }
        .logo-area h2 { font-size: 1.7rem; font-weight: 700; color: #0B2B40; margin-top: 8px; }
        .logo-area p { color: #6C8D9C; font-size: 0.8rem; }
        .alert-message { display: none; padding: 12px 16px; border-radius: 16px; margin-bottom: 24px; font-size: 0.85rem; align-items: center; gap: 10px; }
        .alert-message.show { display: flex; }
        .alert-message.error { background: #FEF3F2; color: #D9534F; border-left: 4px solid #D9534F; }
        .alert-message.success { background: #E8F5E9; color: #2E7D32; border-left: 4px solid #2E7D32; }
        .form-group { margin-bottom: 22px; }
        .form-group label { display: block; font-weight: 600; color: #0B2B40; margin-bottom: 8px; font-size: 0.85rem; }
        .input-wrapper { position: relative; }
        .input-wrapper i.input-icon { position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: #FFB800; font-size: 1.1rem; }
        .input-wrapper input { width: 100%; padding: 14px 16px 14px 46px; border: 1.5px solid #E2EAEF; border-radius: 40px; font-size: 0.9rem; transition: all 0.2s; }
        .input-wrapper input:focus { outline: none; border-color: #FFB800; box-shadow: 0 0 0 3px rgba(255, 184, 0, 0.1); }
        .input-wrapper .toggle-password { position: absolute; right: 18px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #A0B8C4; }
        .form-options { display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; }
        .form-check { display: flex; align-items: center; gap: 8px; }
        .form-check input { accent-color: #FFB800; }
        .forgot-password { font-size: 0.8rem; color: #FFB800; text-decoration: none; cursor: pointer; }
        .forgot-password:hover { color: #0B2B40; }
        .btn-login { width: 100%; padding: 14px; background: #0B2B40; color: white; border: none; border-radius: 40px; font-size: 1rem; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 10px; cursor: pointer; transition: all 0.2s; margin-bottom: 24px; }
        .btn-login:hover { background: #FFB800; color: #0B2B40; transform: translateY(-2px); }
        .loading-spinner { display: none; width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.3); border-top-color: white; border-radius: 50%; animation: spin 0.8s linear infinite; }
        .btn-login.loading .btn-text { display: none; }
        .btn-login.loading .loading-spinner { display: inline-block; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .register-link { text-align: center; font-size: 0.8rem; color: #8AA6B5; padding-top: 16px; border-top: 1px solid #E2EAEF; }
        .register-link a { color: #FFB800; text-decoration: none; font-weight: 600; cursor: pointer; }
        .modal-content-custom { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 16px 20px; }
        .code-digit { width: 50px; height: 60px; font-size: 24px; text-align: center; border: 2px solid #E2EAEF; border-radius: 12px; margin: 0 4px; }
        .code-digit:focus { border-color: #FFB800; outline: none; }
        .timer-text { font-size: 13px; margin-top: 10px; }
        .timer-text i { margin-right: 5px; }
        .timer-warning { color: #D9534F; font-weight: bold; }
        @media (max-width: 480px) { .login-card { padding: 32px 24px; } .logo-img { width: 80px; height: 80px; } .code-digit { width: 40px; height: 50px; font-size: 20px; } }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-card">
        <div class="logo-area">
            <img src="${pageContext.request.contextPath}/assets/images/logotipo.png"
                 alt="Logotipo Hotelaria"
                 class="logo-img"
                 onerror="this.onerror=null; this.src='https://cdn-icons-png.flaticon.com/512/3183/3183461.png'">
            <h2>Sistema Hotelaria</h2>
            <p>Gestão Integrada · Reservas · Check-in/out</p>
        </div>

        <%
            String erro = (String) request.getAttribute("erro");
            String sucesso = (String) request.getAttribute("sucesso");
            if (erro != null && !erro.isEmpty()) {
        %>
            <div class="alert-message error show" id="alertError"><i class="bi bi-exclamation-triangle-fill"></i><span><%= erro %></span></div>
        <% } else if (sucesso != null && !sucesso.isEmpty()) { %>
            <div class="alert-message success show" id="alertSuccess"><i class="bi bi-check-circle-fill"></i><span><%= sucesso %></span></div>
        <% } else { %>
            <div id="alertError" class="alert-message error" style="display: none;"><i class="bi bi-exclamation-triangle-fill"></i><span id="errorMessage"></span></div>
            <div id="alertSuccess" class="alert-message success" style="display: none;"><i class="bi bi-check-circle-fill"></i><span id="successMessage"></span></div>
        <% } %>

        <form id="loginForm" action="${pageContext.request.contextPath}/login" method="post">
            <div class="form-group">
                <label>Usuário</label>
                <div class="input-wrapper">
                    <i class="input-icon bi bi-person"></i>
                    <input type="text" id="username" name="username" class="form-control" placeholder="Digite seu usuário" required autofocus>
                </div>
            </div>
            <div class="form-group">
                <label>Senha</label>
                <div class="input-wrapper">
                    <i class="input-icon bi bi-lock"></i>
                    <input type="password" id="password" name="senha" class="form-control" placeholder="Digite sua senha" required>
                    <i class="toggle-password bi bi-eye-slash" onclick="togglePassword()"></i>
                </div>
            </div>
            <div class="form-options">
                <label class="form-check"><input type="checkbox" id="rememberMe" name="rememberMe"><span>Lembrar-me</span></label>
                <a class="forgot-password" onclick="showForgotPassword()">Esqueceu a senha?</a>
            </div>
            <button type="submit" class="btn-login" id="btnLogin"><span class="btn-text">Aceder ao Sistema</span><span class="loading-spinner"></span><i class="bi bi-box-arrow-in-right"></i></button>
            <div class="register-link"><i class="bi bi-person-plus"></i> Novo acesso? <a onclick="showRegister()">Solicitar criação de usuário</a></div>
        </form>
    </div>
</div>

<!-- MODAL: Recuperar Senha - Passo 1 (Email) -->
<div class="modal fade" id="modalForgotPassword" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-custom">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-envelope"></i> Recuperar senha</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <p>Digite o e-mail cadastrado no sistema para receber o código de verificação.</p>
                <input type="email" id="resetEmail" class="form-control" placeholder="seuemail@hotelaria.com">
                <div id="resetMessage" class="mt-3" style="display: none;"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button class="btn btn-primary" style="background: #FFB800; border: none; color: #0B2B40;" onclick="sendResetCode()">Enviar código</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Recuperar Senha - Passo 2 (Código de verificação com TIMER) -->
<div class="modal fade" id="modalVerifyCode" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-custom">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-shield-lock"></i> Verificar código</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <p>Digite o código de 6 dígitos enviado para seu e-mail.</p>
                <div class="text-center mb-3">
                    <input type="text" maxlength="1" class="code-digit" id="code1" onkeyup="moveToNext(this, 'code2')">
                    <input type="text" maxlength="1" class="code-digit" id="code2" onkeyup="moveToNext(this, 'code3')">
                    <input type="text" maxlength="1" class="code-digit" id="code3" onkeyup="moveToNext(this, 'code4')">
                    <input type="text" maxlength="1" class="code-digit" id="code4" onkeyup="moveToNext(this, 'code5')">
                    <input type="text" maxlength="1" class="code-digit" id="code5" onkeyup="moveToNext(this, 'code6')">
                    <input type="text" maxlength="1" class="code-digit" id="code6" onkeyup="verifyCodeOnComplete()">
                </div>
                <!-- TIMER DE EXPIRAÇÃO DO CÓDIGO -->
                <div id="timerContainer" class="text-center" style="display: none;">
                    <p class="timer-text" id="timerDisplay">
                        <i class="bi bi-hourglass-split"></i>
                        Código expira em: <strong id="timerValue">05:00</strong>
                    </p>
                </div>
                <div id="verifyMessage" class="mt-3" style="display: none;"></div>
                <p class="text-muted small mt-3"><i class="bi bi-clock"></i> O código expira em 5 minutos.</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="backToEmail()">Voltar</button>
                <button class="btn btn-primary" id="verifyCodeBtn" style="background: #FFB800; border: none; color: #0B2B40;" onclick="verifyCode()">Verificar código</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Recuperar Senha - Passo 3 (Redefinir senha) -->
<div class="modal fade" id="modalResetPassword" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-custom">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-key"></i> Redefinir senha</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <p>Digite sua nova senha</p>
                <input type="password" id="novaSenha" class="form-control mb-3" placeholder="Nova senha">
                <input type="password" id="confirmarSenha" class="form-control" placeholder="Confirmar nova senha">
                <div id="resetPasswordMessage" class="mt-3" style="display: none;"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button class="btn btn-primary" style="background: #FFB800; border: none; color: #0B2B40;" onclick="resetPassword()">Redefinir senha</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Solicitar Acesso -->
<div class="modal fade" id="modalRegister" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-custom">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-person-badge"></i> Solicitar acesso</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center p-4">
                <i class="bi bi-building" style="font-size: 3rem; color: #FFB800;"></i>
                <p class="mt-3">Contacte o administrador do sistema para criar seu usuário e definir seu perfil de acesso.</p>
                <hr>
                <p><strong>Email do Administrador:</strong> admin@hotelaria.co.mz</p>
                <button class="btn btn-primary mt-3" style="background: #0B2B40; border: none;" onclick="copyAdminEmail()">📧 Copiar e-mail</button>
            </div>
            <div class="modal-footer justify-content-center">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentEmail = '';

    // ========== VARIÁVEIS DO TIMER ==========
    let countdownInterval = null;
    let remainingSeconds = 300; // 5 minutos em segundos

    // ========== FUNÇÕES DO TIMER ==========
    function startCountdown() {
        // Limpar intervalo anterior se existir
        if (countdownInterval) {
            clearInterval(countdownInterval);
        }

        remainingSeconds = 300; // Reset para 5 minutos
        updateCountdownDisplay();

        // Mostrar o timer
        const timerContainer = document.getElementById('timerContainer');
        if (timerContainer) timerContainer.style.display = 'block';

        // Habilitar botão de verificação
        const verifyBtn = document.getElementById('verifyCodeBtn');
        if (verifyBtn) verifyBtn.disabled = false;

        countdownInterval = setInterval(function() {
            if (remainingSeconds <= 0) {
                // Código expirou
                clearInterval(countdownInterval);
                countdownInterval = null;

                const msgDiv = document.getElementById('verifyMessage');
                showModalMessage(msgDiv, '⏰ O código expirou! Solicite um novo código clicando em "Voltar" e reenviando o e-mail.', 'error');

                // Desabilitar botão de verificação
                const verifyBtn = document.getElementById('verifyCodeBtn');
                if (verifyBtn) verifyBtn.disabled = true;

                // Mudar estilo do timer para vermelho
                const timerValue = document.getElementById('timerValue');
                if (timerValue) {
                    timerValue.innerHTML = '00:00';
                    timerValue.style.color = '#D9534F';
                }
            } else {
                remainingSeconds--;
                updateCountdownDisplay();
            }
        }, 1000);
    }

    function updateCountdownDisplay() {
        const minutes = Math.floor(remainingSeconds / 60);
        const seconds = remainingSeconds % 60;
        const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

        const timerValue = document.getElementById('timerValue');
        if (timerValue) {
            timerValue.textContent = timeString;

            // Mudar cor quando faltar 1 minuto (60 segundos)
            if (remainingSeconds <= 60 && remainingSeconds > 0) {
                timerValue.style.color = '#D9534F';
                timerValue.style.fontWeight = 'bold';
            } else if (remainingSeconds > 60) {
                timerValue.style.color = '';
                timerValue.style.fontWeight = '';
            }
        }
    }

    function stopCountdown() {
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }
        // Esconder o timer
        const timerContainer = document.getElementById('timerContainer');
        if (timerContainer) timerContainer.style.display = 'none';
    }

    function togglePassword() {
        const pwd = document.getElementById('password');
        const icon = document.querySelector('.toggle-password');
        if (pwd.type === 'password') {
            pwd.type = 'text';
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
        } else {
            pwd.type = 'password';
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
        }
    }

    function showAlert(message, type) {
        const alertDiv = type === 'error' ? document.getElementById('alertError') : document.getElementById('alertSuccess');
        const msgSpan = type === 'error' ? document.getElementById('errorMessage') : document.getElementById('successMessage');
        if (alertDiv && msgSpan) {
            msgSpan.textContent = message;
            alertDiv.style.display = 'flex';
            setTimeout(() => alertDiv.style.display = 'none', 5000);
        }
    }

    document.getElementById('loginForm').addEventListener('submit', function(e) {
        document.getElementById('btnLogin').classList.add('loading');
        setTimeout(() => document.getElementById('btnLogin').classList.remove('loading'), 5000);
    });

    // ========== RECUPERAÇÃO DE SENHA ==========
    function showForgotPassword() {
        // Resetar campos ao abrir o modal
        document.getElementById('resetEmail').value = '';
        const msgDiv = document.getElementById('resetMessage');
        msgDiv.style.display = 'none';
        msgDiv.innerHTML = '';
        new bootstrap.Modal(document.getElementById('modalForgotPassword')).show();
    }

    function showRegister() {
        new bootstrap.Modal(document.getElementById('modalRegister')).show();
    }

    function copyAdminEmail() {
        navigator.clipboard.writeText('admin@hotelaria.co.mz');
        showAlert('E-mail copiado!', 'success');
    }

    function sendResetCode() {
        const email = document.getElementById('resetEmail').value.trim();
        const msgDiv = document.getElementById('resetMessage');
        if (!email) { showModalMessage(msgDiv, 'Digite um e-mail válido', 'error'); return; }

        msgDiv.style.display = 'block';
        msgDiv.innerHTML = '<div class="text-center"><div class="loading-spinner" style="display: inline-block;"></div> Enviando...</div>';
        msgDiv.className = 'alert alert-info';

        fetch(contextPath + '/recuperarSenha', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'email=' + encodeURIComponent(email)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                currentEmail = email;
                showModalMessage(msgDiv, data.message, 'success');
                setTimeout(() => {
                    bootstrap.Modal.getInstance(document.getElementById('modalForgotPassword')).hide();
                    document.getElementById('resetEmail').value = '';
                    msgDiv.style.display = 'none';
                    openVerifyCodeModal();
                }, 2000);
            } else {
                showModalMessage(msgDiv, data.message, 'error');
            }
        })
        .catch(() => showModalMessage(msgDiv, 'Erro ao enviar solicitação', 'error'));
    }

    function openVerifyCodeModal() {
        clearCodeInputs();
        startCountdown(); // INICIAR O TIMER AQUI
        new bootstrap.Modal(document.getElementById('modalVerifyCode')).show();
    }

    function backToEmail() {
        stopCountdown(); // PARAR O TIMER
        bootstrap.Modal.getInstance(document.getElementById('modalVerifyCode')).hide();
        new bootstrap.Modal(document.getElementById('modalForgotPassword')).show();
    }

    function moveToNext(current, nextId) {
        if (current.value.length === 1) {
            const next = document.getElementById(nextId);
            if (next) next.focus();
        }
    }

    function getCode() {
        let code = '';
        for (let i = 1; i <= 6; i++) {
            const input = document.getElementById('code' + i);
            if (input) code += input.value;
        }
        return code;
    }

    function clearCodeInputs() {
        for (let i = 1; i <= 6; i++) {
            const input = document.getElementById('code' + i);
            if (input) input.value = '';
        }
        const firstInput = document.getElementById('code1');
        if (firstInput) firstInput.focus();
    }

    function verifyCodeOnComplete() {
        const code = getCode();
        if (code.length === 6) verifyCode();
    }

    function verifyCode() {
        const code = getCode();
        const msgDiv = document.getElementById('verifyMessage');
        if (code.length !== 6) {
            showModalMessage(msgDiv, 'Digite o código completo de 6 dígitos', 'error');
            return;
        }

        msgDiv.style.display = 'block';
        msgDiv.innerHTML = '<div class="text-center"><div class="loading-spinner" style="display: inline-block;"></div> Verificando...</div>';
        msgDiv.className = 'alert alert-info';

        fetch(contextPath + '/validarCodigo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'email=' + encodeURIComponent(currentEmail) + '&codigo=' + encodeURIComponent(code)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showModalMessage(msgDiv, data.message, 'success');
                setTimeout(() => {
                    bootstrap.Modal.getInstance(document.getElementById('modalVerifyCode')).hide();
                    openResetPasswordModal();
                }, 1500);
            } else {
                showModalMessage(msgDiv, data.message, 'error');
            }
        })
        .catch(() => showModalMessage(msgDiv, 'Erro ao verificar código', 'error'));
    }

    function openResetPasswordModal() {
        stopCountdown(); // PARAR O TIMER AO ABRIR REDEFINIÇÃO
        document.getElementById('novaSenha').value = '';
        document.getElementById('confirmarSenha').value = '';
        const msgDiv = document.getElementById('resetPasswordMessage');
        msgDiv.style.display = 'none';
        msgDiv.innerHTML = '';
        new bootstrap.Modal(document.getElementById('modalResetPassword')).show();
    }

    function resetPassword() {
        const novaSenha = document.getElementById('novaSenha').value;
        const confirmarSenha = document.getElementById('confirmarSenha').value;
        const msgDiv = document.getElementById('resetPasswordMessage');
        const code = getCode();

        if (!novaSenha || !confirmarSenha) {
            showModalMessage(msgDiv, 'Preencha todos os campos', 'error');
            return;
        }
        if (novaSenha.length < 4) {
            showModalMessage(msgDiv, 'A senha deve ter no mínimo 4 caracteres', 'error');
            return;
        }
        if (novaSenha !== confirmarSenha) {
            showModalMessage(msgDiv, 'As senhas não coincidem', 'error');
            return;
        }

        msgDiv.style.display = 'block';
        msgDiv.innerHTML = '<div class="text-center"><div class="loading-spinner" style="display: inline-block;"></div> Redefinindo senha...</div>';
        msgDiv.className = 'alert alert-info';

        fetch(contextPath + '/redefinirSenha', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'email=' + encodeURIComponent(currentEmail) + '&codigo=' + encodeURIComponent(code) + '&nova_senha=' + encodeURIComponent(novaSenha)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showModalMessage(msgDiv, data.message, 'success');
                setTimeout(() => {
                    bootstrap.Modal.getInstance(document.getElementById('modalResetPassword')).hide();
                    showAlert('Senha redefinida com sucesso! Faça login com sua nova senha.', 'success');
                    // Limpar campos de código
                    clearCodeInputs();
                }, 2000);
            } else {
                showModalMessage(msgDiv, data.message, 'error');
            }
        })
        .catch(() => showModalMessage(msgDiv, 'Erro ao redefinir senha', 'error'));
    }

    function showModalMessage(msgDiv, message, type) {
        msgDiv.style.display = 'block';
        msgDiv.className = 'alert alert-' + (type === 'error' ? 'danger' : 'success');
        msgDiv.innerHTML = '<i class="bi bi-' + (type === 'error' ? 'exclamation-triangle' : 'check-circle') + '"></i> ' + message;
        if (type === 'success') setTimeout(() => msgDiv.style.display = 'none', 3000);
    }

    // Salvar credenciais no localStorage
    document.addEventListener('DOMContentLoaded', function() {
        const savedUsername = localStorage.getItem('savedUsername');
        const savedPassword = localStorage.getItem('savedPassword');
        const rememberMe = localStorage.getItem('rememberMe');
        if (rememberMe === 'true' && savedUsername && savedPassword) {
            document.getElementById('username').value = savedUsername;
            document.getElementById('password').value = savedPassword;
            document.getElementById('rememberMe').checked = true;
        }
        document.getElementById('loginForm').addEventListener('submit', function() {
            const remember = document.getElementById('rememberMe').checked;
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            if (remember) {
                localStorage.setItem('savedUsername', username);
                localStorage.setItem('savedPassword', password);
                localStorage.setItem('rememberMe', 'true');
            } else {
                localStorage.removeItem('savedUsername');
                localStorage.removeItem('savedPassword');
                localStorage.removeItem('rememberMe');
            }
        });
    });
</script>
</body>
</html>