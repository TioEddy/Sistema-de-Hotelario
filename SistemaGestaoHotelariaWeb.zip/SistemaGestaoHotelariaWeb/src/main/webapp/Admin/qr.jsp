<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-success-custom { background: #2E7D32; border: none; padding: 8px 20px; border-radius: 30px; font-weight: 500; color: white; }
        .btn-success-custom:hover { background: #1B5E20; }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }

        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.7rem; font-weight: 500; }
        .badge-status.ATIVO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.USADO { background: #E3F2FD; color: #1976D2; }
        .badge-status.EXPIRADO { background: #FFEBEE; color: #D9534F; }

        .qr-code-small { width: 40px; height: 40px; background: #f0f4f8; border-radius: 8px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .qr-code-small img { border-radius: 6px; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.download { color: #2E7D32; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #0B2B40; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2EAEF; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #FFB800; border-color: #FFB800; color: #0B2B40; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; opacity: 0.5; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .qr-container { background: white; padding: 30px; border-radius: 20px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .qr-code-large { display: flex; justify-content: center; margin: 20px 0; }
        .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2EAEF; padding: 10px 14px; }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .filters-bar { flex-direction: column; align-items: stretch; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-building"></i><div class="logo-text">Sistema Hotelaria<span>QR Code · Acesso Digital</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-qr-code"></i> Total QR Codes</h4><div class="value" id="totalQr">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-check-circle"></i> Ativos</h4><div class="value" id="qrAtivos">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-check2-all"></i> Utilizados</h4><div class="value" id="qrUsados">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-hourglass-split"></i> Expirados</h4><div class="value" id="qrExpirados">0</div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por hóspede ou reserva..."></div>
        <div><select class="filter-select" id="estadoFilter"><option value="">Todos os estados</option><option value="ATIVO">ATIVO</option><option value="USADO">USADO</option><option value="EXPIRADO">EXPIRADO</option></select></div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalGerarQR"><i class="bi bi-plus-lg"></i> Gerar QR Code</button>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr><th>Hóspede</th><th>Reserva</th><th>Quarto</th><th>Data Geração</th><th>Estado</th><th>QR Code</th><th>Ações</th></tr>
                </thead>
                <tbody id="qrTableBody">
                    <tr><td colspan="7" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Gerar QR Code -->
<div class="modal fade modal-custom" id="modalGerarQR" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-qr-code"></i> Gerar QR Code</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formGerarQR">
                    <div class="mb-3"><label class="form-label">Selecione a Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaSelect" required><option value="">Carregando reservas...</option></select>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Gerar QR Code</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Visualizar QR Code com informações completas -->
<div class="modal fade modal-custom" id="modalVisualizarQR" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-qr-code"></i> Informações da Reserva</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="row">
                    <div class="col-md-6">
                        <div class="qr-container" style="padding: 20px;">
                            <div class="qr-code-large" id="qrCodeContainer"></div>
                            <button class="btn-success-custom" id="downloadQRBtn" style="margin-top: 15px; width: 100%;"><i class="bi bi-download"></i> Baixar QR Code</button>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5 class="mb-3"><i class="bi bi-info-circle"></i> Detalhes da Reserva</h5>
                        <div class="detail-row"><div class="detail-label">Reserva:</div><div class="detail-value" id="qrReservaId">-</div></div>
                        <div class="detail-row"><div class="detail-label">Hóspede:</div><div class="detail-value" id="qrHospede">-</div></div>
                        <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="qrQuarto">-</div></div>
                        <div class="detail-row"><div class="detail-label">Check-in:</div><div class="detail-value" id="qrCheckin">-</div></div>
                        <div class="detail-row"><div class="detail-label">Check-out:</div><div class="detail-value" id="qrCheckout">-</div></div>
                        <div class="detail-row"><div class="detail-label">Estado Reserva:</div><div class="detail-value" id="qrEstadoReserva">-</div></div>
                        <div class="detail-row"><div class="detail-label">Estado QR:</div><div class="detail-value" id="qrEstado">-</div></div>
                        <div class="detail-row"><div class="detail-label">Data Geração:</div><div class="detail-value" id="qrDataGeracao">-</div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 5, currentFilter = "", currentEstadoFilter = "";
    let todosQRCodes = [], currentQrCode = null;

    function formatDateTime(dt) {
        if (!dt) return "";
        if (dt.includes('/')) return dt;
        var parts = dt.split(/[- :]/);
        if (parts.length >= 5) {
            return parts[2] + '/' + parts[1] + '/' + parts[0] + ' ' + parts[3] + ':' + parts[4];
        }
        return dt;
    }

    function formatDate(dt) {
        if (!dt) return "";
        if (dt.includes('/')) return dt;
        var parts = dt.split("-");
        if (parts.length === 3) return parts[2] + '/' + parts[1] + '/' + parts[0];
        return dt;
    }

    function escapeHtml(s) {
        if (!s) return "";
        return String(s).replace(/[&<>]/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m;
        });
    }

    function showAlert(type, msg) {
        Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false });
    }

    function generateQRCodeImage(data) {
        return "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" + encodeURIComponent(data);
    }

    function downloadQRCodeImage(url, filename) {
        fetch(url)
            .then(response => response.blob())
            .then(blob => {
                const link = document.createElement('a');
                const objectUrl = URL.createObjectURL(blob);
                link.href = objectUrl;
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(objectUrl);
                showAlert('success', 'QR Code baixado com sucesso!');
            })
            .catch(error => {
                console.error('Erro ao baixar:', error);
                window.open(url, '_blank');
            });
    }

    function loadStats() {
        $.ajax({ url: contextPath + '/Admin/qr/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalQr').text(d.total || 0);
                $('#qrAtivos').text(d.ativos || 0);
                $('#qrUsados').text(d.usados || 0);
                $('#qrExpirados').text(d.expirados || 0);
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function loadReservas() {
        $.ajax({ url: contextPath + '/Admin/qr/reservas', method: 'GET', dataType: 'json',
            success: function(d) {
                var select = $('#reservaSelect');
                select.html('<option value="">Selecione uma reserva</option>');
                $.each(d, function(i, r) {
                    var statusBadge = '';
                    if (r.estado_reserva === 'CONFIRMADA') statusBadge = '✅ ';
                    else if (r.estado_reserva === 'PENDENTE') statusBadge = '⏳ ';
                    else if (r.estado_reserva === 'FINALIZADA') statusBadge = '✔️ ';
                    else if (r.estado_reserva === 'CANCELADA') statusBadge = '❌ ';
                    select.append('<option value="' + r.id_reserva + '">' + statusBadge + '#' + r.id_reserva + ' - ' + escapeHtml(r.cliente_nome) + ' - ' + escapeHtml(r.quarto) + ' (' + r.periodo + ') - ' + r.estado_reserva + '</option>');
                });
                if (d.length === 0) select.html('<option value="">Nenhuma reserva disponível</option>');
            }, error: function() { console.error('Erro ao carregar reservas'); }
        });
    }

    function loadQRCodes() {
        $.ajax({ url: contextPath + '/Admin/qr/listar', method: 'GET', dataType: 'json',
            success: function(d) {
                todosQRCodes = d;
                console.log('QR Codes carregados:', d.length);
                aplicarFiltros();
            },
            error: function() {
                $('#qrTableBody').html('<tr><td colspan="7" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
            }
        });
    }

    function aplicarFiltros() {
        var filtrados = todosQRCodes.filter(function(q) {
            var matchSearch = !currentFilter || (q.hospede_nome && q.hospede_nome.toLowerCase().includes(currentFilter)) || (q.id_reserva && q.id_reserva.toString().includes(currentFilter));
            var matchEstado = !currentEstadoFilter || q.estado === currentEstadoFilter;
            return matchSearch && matchEstado;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
    }

    function renderizarTabela(qrcodes) {
        var tbody = $('#qrTableBody');
        tbody.empty();
        if (qrcodes.length === 0) {
            tbody.html('<tr><td colspan="7" class="text-center py-4">Nenhum QR Code encontrado</td></tr>');
            return;
        }
        $.each(qrcodes, function(i, q) {
            var qrPreview = generateQRCodeImage(q.codigo);
            var row = '<tr>' +
                '<td><strong>' + escapeHtml(q.hospede_nome) + '</strong></td>' +
                '<td><span class="badge bg-secondary">#' + q.id_reserva + '</span></td>' +
                '<td>' + escapeHtml(q.quarto_num) + '</td>' +
                '<td>' + formatDateTime(q.data_geracao) + '</td>' +
                '<td><span class="badge-status ' + q.estado + '">' + q.estado + '</span></td>' +
                '<td><div class="qr-code-small" data-id="' + q.id_qrcode + '"><img src="' + qrPreview + '" width="40" height="40" style="border-radius: 6px;"></div></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn download" data-id="' + q.id_qrcode + '" title="Baixar"><i class="bi bi-download"></i></button>' +
                    '<button class="action-btn view" data-id="' + q.id_qrcode + '" title="Visualizar"><i class="bi bi-eye"></i></button>' +
                '</td>' +
            '</tr>';
            tbody.append(row);
        });

        $('.action-btn.download').off('click').on('click', function() { downloadQRCode($(this).data('id')); });
        $('.action-btn.view').off('click').on('click', function() { viewQRCode($(this).data('id')); });
        $('.qr-code-small').off('click').on('click', function() { viewQRCode($(this).data('id')); });
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); return false; }

    function viewQRCode(id) {
        var qr = null;
        for (var i = 0; i < todosQRCodes.length; i++) {
            if (todosQRCodes[i].id_qrcode === id) {
                qr = todosQRCodes[i];
                break;
            }
        }
        if (qr) {
            $('#qrReservaId').html('#' + qr.id_reserva);
            $('#qrHospede').html('<strong>' + escapeHtml(qr.hospede_nome) + '</strong>');
            $('#qrQuarto').html(escapeHtml(qr.quarto_num));
            $('#qrCheckin').html(formatDate(qr.data_entrada) || '-');
            $('#qrCheckout').html(formatDate(qr.data_saida) || '-');
            $('#qrEstadoReserva').html(qr.estado_reserva || '-');
            $('#qrEstado').html('<span class="badge-status ' + qr.estado + '">' + qr.estado + '</span>');
            $('#qrDataGeracao').html(formatDateTime(qr.data_geracao));
            $('#qrCodeContainer').html('<img src="' + generateQRCodeImage(qr.codigo) + '" style="width:200px;height:200px;">');
            currentQrCode = qr;
            new bootstrap.Modal(document.getElementById('modalVisualizarQR')).show();
        } else {
            showAlert('error', 'QR Code não encontrado!');
        }
    }

    function downloadQRCode(id) {
        var qr = null;
        for (var i = 0; i < todosQRCodes.length; i++) {
            if (todosQRCodes[i].id_qrcode === id) {
                qr = todosQRCodes[i];
                break;
            }
        }
        if (qr) {
            downloadQRCodeImage(generateQRCodeImage(qr.codigo), 'qrcode_reserva_' + qr.id_reserva + '.png');
        } else {
            showAlert('error', 'QR Code não encontrado!');
        }
    }

    $('#downloadQRBtn').on('click', function() {
        if (currentQrCode) {
            downloadQRCodeImage(generateQRCodeImage(currentQrCode.codigo), 'qrcode_reserva_' + currentQrCode.id_reserva + '.png');
        }
    });

    $('#formGerarQR').on('submit', function(e) {
        e.preventDefault();
        var idReserva = $('#reservaSelect').val();
        if (!idReserva) { showAlert('warning', 'Selecione uma reserva!'); return; }
        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Gerando...');
        $.ajax({ url: contextPath + '/Admin/qr/gerar', method: 'POST', data: { id_reserva: idReserva }, dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Gerar QR Code');
                if (r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalGerarQR')).hide();
                    $('#formGerarQR')[0].reset();
                    loadReservas();
                    loadQRCodes();
                    showAlert('success', 'QR Code gerado com sucesso!');
                } else showAlert('error', r.message || 'Erro ao gerar QR Code');
            }, error: function() { btn.prop('disabled', false).text('Gerar QR Code'); showAlert('error', 'Erro ao gerar QR Code'); }
        });
    });

    $('#modalGerarQR').on('hidden.bs.modal', function() { $('#formGerarQR')[0].reset(); });
    $('#searchInput').on('input', function() { currentFilter = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });
    $('#estadoFilter').on('change', function() { currentEstadoFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    loadReservas();
    loadQRCodes();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>