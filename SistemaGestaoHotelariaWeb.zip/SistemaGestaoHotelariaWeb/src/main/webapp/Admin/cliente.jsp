<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Clientes · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 280px;
            height: 100vh;
            background: #0B2B40;
            color: #E8E8E8;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 15px rgba(0, 0, 0, 0.08);
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 184, 0, 0.2);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFB800;
            margin-bottom: 12px;
            object-fit: cover;
            background: #0B2B40;
        }
        .sidebar .profile h3 {
            font-size: 1.15rem;
            font-weight: 600;
            color: #FFB800;
        }
        .sidebar .profile p {
            font-size: 0.75rem;
            opacity: 0.7;
            margin: 0;
        }
        .sidebar ul {
            list-style: none;
            padding: 0 16px;
        }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255, 184, 0, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active a { color: #0B2B40; }
        .sidebar li a {
            color: #E8E8E8;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
        }
        .sidebar .menu-section {
            color: #FFB800;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper {
            margin-left: 280px;
            height: 100vh;
            overflow-y: auto;
            padding: 20px 28px;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area img { height: 45px; width: auto; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }
        .btn-primary-custom {
            background: #FFB800;
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: #0B2B40;
            transition: all 0.2s;
        }
        .btn-primary-custom:hover {
            background: #0B2B40;
            color: #FFB800;
            transform: translateY(-2px);
        }
        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 16px 24px;
            margin-bottom: 24px;
            border: 1px solid #E2EAEF;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #F0F4F8;
            padding: 8px 16px;
            border-radius: 40px;
        }
        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            width: 250px;
        }
        .filter-select {
            padding: 8px 16px;
            border-radius: 40px;
            border: 1px solid #E2EAEF;
            background: white;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 16px;
            border: 1px solid #E2EAEF;
            transition: all 0.2s;
        }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 {
            font-size: 0.7rem;
            color: #8AA6B5;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .stat-card .value {
            font-size: 1.6rem;
            font-weight: 700;
            color: #0B2B40;
        }
        .table-container {
            background: white;
            border-radius: 20px;
            padding: 20px;
            border: 1px solid #E2EAEF;
        }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th {
            border-bottom: 2px solid #FFB800;
            color: #0B2B40;
            font-weight: 600;
            padding: 12px 8px;
        }
        .table td { padding: 12px 8px; vertical-align: middle; }
        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 5px;
            border-radius: 8px;
            transition: all 0.2s;
        }
        .action-btn.edit { color: #FFB800; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }
        .pagination { margin-top: 20px; justify-content: flex-end; gap: 5px; list-style: none; display: flex; }
        .page-link {
            color: #0B2B40;
            border-radius: 8px;
            padding: 8px 12px;
            text-decoration: none;
            border: 1px solid #E2EAEF;
            background: white;
            cursor: pointer;
        }
        .page-item.active .page-link {
            background: #FFB800;
            border-color: #FFB800;
            color: #0B2B40;
        }
        .page-item.disabled .page-link {
            color: #A0AD9B;
            cursor: not-allowed;
            opacity: 0.5;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 20px;
            margin-top: 20px;
            border: 1px solid #E2EAEF;
        }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }
        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom {
            background: #0B2B40;
            color: white;
            border-radius: 24px 24px 0 0;
            padding: 20px 24px;
        }
        .detail-row { display: flex; padding: 12px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E2EAEF;
            padding: 10px 14px;
        }
        .form-control-custom:focus, .form-select-custom:focus {
            border-color: #FFB800;
            box-shadow: 0 0 0 3px rgba(255, 184, 0, 0.1);
        }
        @media (max-width: 1000px) {
            .sidebar { width: 250px; }
            .main-wrapper { margin-left: 250px; }
            .filters-bar { flex-direction: column; align-items: stretch; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>

    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in/out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <img src="${pageContext.request.contextPath}/assets/images/logotipo.png" alt="Logotipo" onerror="this.src='https://placehold.co/45x45/0B2B40/FFB800?text=🏨'">
            <div class="logo-text">Sistema Hotelaria<span>Gestão de Clientes</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <!-- Cards Estatísticos -->
    <div class="stats-grid">
        <div class="stat-card">
            <h4><i class="bi bi-people"></i> Total Clientes</h4>
            <div class="value" id="totalClientes">0</div>
        </div>
        <div class="stat-card">
            <h4><i class="bi bi-gender-male"></i> Homens</h4>
            <div class="value" id="totalHomens">0</div>
        </div>
        <div class="stat-card">
            <h4><i class="bi bi-gender-female"></i> Mulheres</h4>
            <div class="value" id="totalMulheres">0</div>
        </div>
        <div class="stat-card">
            <h4><i class="bi bi-calendar"></i> Este Mês</h4>
            <div class="value" id="totalMes">0</div>
        </div>
    </div>

    <!-- Barra de Filtros -->
    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por nome, documento ou email...">
        </div>
        <div>
            <select class="filter-select" id="sexoFilter">
                <option value="">Todos os sexos</option>
                <option value="M">Masculino</option>
                <option value="F">Feminino</option>
            </select>
            <select class="filter-select" id="documentoFilter">
                <option value="">Todos os documentos</option>
                <option value="BI">BI</option>
                <option value="Passaporte">Passaporte</option>
                <option value="DIRE">DIRE</option>
            </select>
        </div>
        <button class="btn-primary-custom rounded-pill" data-bs-toggle="modal" data-bs-target="#modalCliente">
            <i class="bi bi-plus-lg"></i> Novo Cliente
        </button>
    </div>

    <!-- Tabela de Clientes -->
    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Nome Completo</th>
                        <th>Sexo</th>
                        <th>Telefone</th>
                        <th>Email</th>
                        <th>Documento</th>
                        <th>Nacionalidade</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="clientesTableBody">
                    <tr>
                        <td colspan="7" class="text-center py-4">
                            <div class="spinner-border text-warning" role="status">
                                <span class="visually-hidden">Carregando...</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div id="infoRegistros" class="text-muted small"></div>
            <nav>
                <ul class="pagination pagination-sm mb-0" id="pagination"></ul>
            </nav>
        </div>
    </div>

    <div class="footer">
        <p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p>
    </div>
</div>

<!-- MODAL: Novo/Editar Cliente -->
<div class="modal fade modal-custom" id="modalCliente" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-person-plus"></i> Novo Cliente</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formCliente">
                    <input type="hidden" id="editId" value="0">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Nome Completo <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-custom" id="nomeCompleto" required placeholder="Ex: João Silva">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Sexo</label>
                            <select class="form-select form-select-custom" id="sexo">
                                <option value="">Selecione</option>
                                <option value="M">Masculino (M)</option>
                                <option value="F">Feminino (F)</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Data de Nascimento</label>
                            <input type="date" class="form-control form-control-custom" id="dataNascimento">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Telefone</label>
                            <input type="tel" class="form-control form-control-custom" id="telefone" placeholder="+258 84 123 4567">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control form-control-custom" id="email" placeholder="cliente@email.com">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Endereço</label>
                            <textarea class="form-control form-control-custom" id="endereco" rows="2" placeholder="Endereço completo"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nacionalidade</label>
                            <select class="form-select form-select-custom" id="nacionalidade">
                                <option value="">Selecione</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tipo de Documento</label>
                            <select class="form-select form-select-custom" id="tipoDocumento">
                                <option value="">Selecione</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Número do Documento</label>
                        <input type="text" class="form-control form-control-custom" id="numeroDocumento" placeholder="Número do BI/Passaporte/DIRE">
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-secondary rounded-pill" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary rounded-pill" style="background: #FFB800; border: none; color: #0B2B40;">Salvar Cliente</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Cliente -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Cliente</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Nome:</div><div class="detail-value" id="detailNome">-</div></div>
                <div class="detail-row"><div class="detail-label">Sexo:</div><div class="detail-value" id="detailSexo">-</div></div>
                <div class="detail-row"><div class="detail-label">Data Nasc.:</div><div class="detail-value" id="detailNascimento">-</div></div>
                <div class="detail-row"><div class="detail-label">Telefone:</div><div class="detail-value" id="detailTelefone">-</div></div>
                <div class="detail-row"><div class="detail-label">Email:</div><div class="detail-value" id="detailEmail">-</div></div>
                <div class="detail-row"><div class="detail-label">Endereço:</div><div class="detail-value" id="detailEndereco">-</div></div>
                <div class="detail-row"><div class="detail-label">Nacionalidade:</div><div class="detail-value" id="detailNacionalidade">-</div></div>
                <div class="detail-row"><div class="detail-label">Documento:</div><div class="detail-value" id="detailDocumento">-</div></div>
                <div class="detail-row"><div class="detail-label">Nº Documento:</div><div class="detail-value" id="detailNumDocumento">-</div></div>
                <div class="detail-row"><div class="detail-label">Data Registro:</div><div class="detail-value" id="detailDataRegistro">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                <button class="btn-primary-custom rounded-pill" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // ============================================
    // VARIÁVEIS GLOBAIS
    // ============================================
    let currentPage = 1;
    let totalPages = 1;
    let currentSearch = '';
    let currentSexo = '';
    let currentDocumento = '';
    let todosClientes = [];
    let nacionalidades = [];
    let tiposDocumento = [];

    // ============================================
    // FUNÇÕES AUXILIARES
    // ============================================
    function formatarData(data) {
        if (!data) return '-';
        let dateObj = new Date(data);
        if (!isNaN(dateObj.getTime())) {
            let dia = String(dateObj.getDate()).padStart(2, '0');
            let mes = String(dateObj.getMonth() + 1).padStart(2, '0');
            let ano = dateObj.getFullYear();
            return dia + '/' + mes + '/' + ano;
        }
        return data;
    }

    function formatarDataHora(data) {
        if (!data) return '-';
        let dateObj = new Date(data);
        if (!isNaN(dateObj.getTime())) {
            let dia = String(dateObj.getDate()).padStart(2, '0');
            let mes = String(dateObj.getMonth() + 1).padStart(2, '0');
            let ano = dateObj.getFullYear();
            let hora = String(dateObj.getHours()).padStart(2, '0');
            let min = String(dateObj.getMinutes()).padStart(2, '0');
            return dia + '/' + mes + '/' + ano + ' ' + hora + ':' + min;
        }
        return data;
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function getSexoTexto(sexo) {
        if (sexo === 'M') return 'Masculino';
        if (sexo === 'F') return 'Feminino';
        return '-';
    }

    function getSexoIcon(sexo) {
        if (sexo === 'M') return '<i class="bi bi-gender-male" style="color: #1976D2;"></i>';
        if (sexo === 'F') return '<i class="bi bi-gender-female" style="color: #D9534F;"></i>';
        return '';
    }

    // ============================================
    // CARREGAR DADOS DO BACKEND
    // ============================================
    function carregarNacionalidades() {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/nacionalidades/listar',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                nacionalidades = data.nacionalidades || [];
                let select = $('#nacionalidade');
                select.html('<option value="">Selecione</option>');
                $.each(nacionalidades, function(i, n) {
                    select.append('<option value="' + n.idNacionalidade + '">' + escapeHtml(n.pais) + '</option>');
                });
            },
            error: function(xhr) {
                console.error('Erro ao carregar nacionalidades:', xhr.responseText);
            }
        });
    }

    function carregarTiposDocumento() {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/tipos-documento/listar',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                tiposDocumento = data.tiposDocumento || [];
                let select = $('#tipoDocumento');
                select.html('<option value="">Selecione</option>');
                $.each(tiposDocumento, function(i, t) {
                    select.append('<option value="' + t.idTipoDocumento + '">' + escapeHtml(t.descricao) + '</option>');
                });
            },
            error: function(xhr) {
                console.error('Erro ao carregar tipos documento:', xhr.responseText);
            }
        });
    }

    function carregarClientes() {
        console.log("🔄 Carregando clientes...");
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/clientes/listar',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data && data.clientes) {
                    todosClientes = data.clientes;
                    console.log("📊 Clientes carregados:", todosClientes.length);
                    atualizarStats();
                    aplicarFiltros();
                } else {
                    todosClientes = [];
                    $('#clientesTableBody').html('<tr><td colspan="7" class="text-center py-4">⚠️ Nenhum cliente encontrado</td></tr>');
                }
            },
            error: function(xhr) {
                console.error('❌ Erro ao carregar clientes:', xhr.responseText);
                $('#clientesTableBody').html('<tr><td colspan="7" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
                Swal.fire('Erro', 'Não foi possível carregar os clientes', 'error');
            }
        });
    }

    // ============================================
    // ESTATÍSTICAS
    // ============================================
    function atualizarStats() {
        let total = todosClientes.length;
        let homens = 0, mulheres = 0;
        let esteMes = 0;
        let hoje = new Date();
        let mesAtual = hoje.getMonth() + 1;
        let anoAtual = hoje.getFullYear();

        for (let i = 0; i < todosClientes.length; i++) {
            if (todosClientes[i].sexo === 'M') homens++;
            if (todosClientes[i].sexo === 'F') mulheres++;

            let dataReg = todosClientes[i].dataRegistro;
            if (dataReg) {
                let data = new Date(dataReg);
                if (data.getMonth() + 1 === mesAtual && data.getFullYear() === anoAtual) {
                    esteMes++;
                }
            }
        }

        $('#totalClientes').text(total);
        $('#totalHomens').text(homens);
        $('#totalMulheres').text(mulheres);
        $('#totalMes').text(esteMes);
    }

    // ============================================
    // FILTROS
    // ============================================
    function aplicarFiltros() {
        let filtrados = [...todosClientes];

        if (currentSearch) {
            filtrados = filtrados.filter(c =>
                c.nomeCompleto.toLowerCase().includes(currentSearch) ||
                (c.numeroDocumento && c.numeroDocumento.toLowerCase().includes(currentSearch)) ||
                (c.email && c.email.toLowerCase().includes(currentSearch))
            );
        }

        if (currentSexo) {
            filtrados = filtrados.filter(c => c.sexo === currentSexo);
        }

        if (currentDocumento) {
            filtrados = filtrados.filter(c => c.tipoDocumento === currentDocumento);
        }

        const limit = 10;
        totalPages = Math.ceil(filtrados.length / limit);
        if (totalPages === 0) totalPages = 1;
        if (currentPage > totalPages) currentPage = totalPages;

        const start = (currentPage - 1) * limit;
        const paginados = filtrados.slice(start, start + limit);

        renderizarTabela(paginados);
        renderizarPaginacao();
        $('#infoRegistros').html('Mostrando ' + paginados.length + ' de ' + filtrados.length + ' registros');
    }

    // ============================================
    // RENDERIZAÇÃO
    // ============================================
    function renderizarTabela(clientes) {
        let html = '';
        if (clientes.length === 0) {
            html = '<tr><td colspan="7" class="text-center py-4">Nenhum cliente encontrado</td></tr>';
        } else {
            for (let i = 0; i < clientes.length; i++) {
                let c = clientes[i];
                html += '<tr>' +
                    '<td><strong>' + escapeHtml(c.nomeCompleto) + '</strong> ' + getSexoIcon(c.sexo) + '</td>' +
                    '<td>' + getSexoTexto(c.sexo) + '</td>' +
                    '<td>' + (c.telefone ? escapeHtml(c.telefone) : '-') + '</td>' +
                    '<td>' + (c.email ? escapeHtml(c.email) : '-') + '</td>' +
                    '<td>' + (c.tipoDocumento ? escapeHtml(c.tipoDocumento) : '-') + ': ' + (c.numeroDocumento ? escapeHtml(c.numeroDocumento) : '-') + '</td>' +
                    '<td>' + (c.pais ? escapeHtml(c.pais) : '-') + '</td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" onclick="editarCliente(' + c.idCliente + ')" title="Editar"><i class="bi bi-pencil"></i></button>' +
                        '<button class="action-btn view" onclick="verDetalhes(' + c.idCliente + ')" title="Detalhes"><i class="bi bi-eye"></i></button>' +
                    '<\/td>' +
                '</tr>';
            }
        }
        $('#clientesTableBody').html(html);
    }

    function renderizarPaginacao() {
        let html = '';
        if (currentPage > 1) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + ')">«</a></li>';
        }
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                let activeClass = (i === currentPage) ? 'active' : '';
                html += '<li class="page-item ' + activeClass + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + ')">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + ')">»</a></li>';
        }
        $('#pagination').html(html);
    }

    function mudarPagina(page) {
        currentPage = page;
        aplicarFiltros();
    }

    // ============================================
    // CRUD OPERATIONS
    // ============================================
    function editarCliente(id) {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/clientes/editar',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(cliente) {
                if (!cliente || cliente.error) {
                    Swal.fire('Erro', 'Cliente não encontrado', 'error');
                    return;
                }
                $('#editId').val(cliente.idCliente);
                $('#nomeCompleto').val(cliente.nomeCompleto);
                $('#sexo').val(cliente.sexo || '');
                $('#dataNascimento').val(cliente.dataNascimento || '');
                $('#telefone').val(cliente.telefone || '');
                $('#email').val(cliente.email || '');
                $('#endereco').val(cliente.endereco || '');
                $('#nacionalidade').val(cliente.idNacionalidade || '');
                $('#tipoDocumento').val(cliente.idTipoDocumento || '');
                $('#numeroDocumento').val(cliente.numeroDocumento || '');

                $('#modalCliente .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Cliente');
                new bootstrap.Modal(document.getElementById('modalCliente')).show();
            },
            error: function(xhr) {
                console.error('Erro editar cliente:', xhr.responseText);
                Swal.fire('Erro', 'Não foi possível carregar os dados do cliente', 'error');
            }
        });
    }

    function verDetalhes(id) {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/clientes/editar',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(cliente) {
                if (!cliente || cliente.error) {
                    Swal.fire('Erro', 'Cliente não encontrado', 'error');
                    return;
                }
                $('#detailNome').html('<strong>' + escapeHtml(cliente.nomeCompleto) + '</strong>');
                $('#detailSexo').html(getSexoTexto(cliente.sexo));
                $('#detailNascimento').html(formatarData(cliente.dataNascimento));
                $('#detailTelefone').html(cliente.telefone || '-');
                $('#detailEmail').html(cliente.email || '-');
                $('#detailEndereco').html(cliente.endereco || '-');
                $('#detailNacionalidade').html(cliente.pais || '-');
                $('#detailDocumento').html(cliente.tipoDocumento || '-');
                $('#detailNumDocumento').html(cliente.numeroDocumento || '-');
                $('#detailDataRegistro').html(formatarDataHora(cliente.dataRegistro));
                new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
            },
            error: function(xhr) {
                console.error('Erro detalhes:', xhr.responseText);
                Swal.fire('Erro', 'Não foi possível carregar os detalhes', 'error');
            }
        });
    }

    // ============================================
    // FORM SUBMIT - SALVAR CLIENTE
    // ============================================
    $('#formCliente').on('submit', function(e) {
        e.preventDefault();

        let id = $('#editId').val();
        let nomeCompleto = $('#nomeCompleto').val().trim();
        let sexo = $('#sexo').val();
        let dataNascimento = $('#dataNascimento').val();
        let telefone = $('#telefone').val().trim();
        let email = $('#email').val().trim();
        let endereco = $('#endereco').val().trim();
        let idNacionalidade = $('#nacionalidade').val();
        let idTipoDocumento = $('#tipoDocumento').val();
        let numeroDocumento = $('#numeroDocumento').val().trim();

        if (!nomeCompleto) {
            Swal.fire('Atenção', 'Nome completo é obrigatório', 'warning');
            return;
        }

        let btnSalvar = $(this).find('button[type="submit"]');
        btnSalvar.prop('disabled', true).text('Salvando...');

        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/clientes/salvar',
            method: 'POST',
            data: {
                id: id,
                nomeCompleto: nomeCompleto,
                sexo: sexo,
                dataNascimento: dataNascimento,
                telefone: telefone,
                email: email,
                endereco: endereco,
                idNacionalidade: idNacionalidade,
                idTipoDocumento: idTipoDocumento,
                numeroDocumento: numeroDocumento
            },
            dataType: 'json',
            success: function(response) {
                btnSalvar.prop('disabled', false).text('Salvar Cliente');
                if (response && response.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalCliente')).hide();
                    Swal.fire('Sucesso', 'Cliente salvo com sucesso!', 'success');
                    $('#formCliente')[0].reset();
                    $('#editId').val('0');
                    $('#modalCliente .modal-title').html('<i class="bi bi-person-plus"></i> Novo Cliente');
                    carregarClientes();
                } else {
                    Swal.fire('Erro', (response && response.message) || 'Erro ao salvar cliente', 'error');
                }
            },
            error: function(xhr) {
                btnSalvar.prop('disabled', false).text('Salvar Cliente');
                console.error('Erro:', xhr.responseText);
                Swal.fire('Erro', 'Erro ao salvar cliente', 'error');
            }
        });
    });

    // Reset modal
    $('#modalCliente').on('hidden.bs.modal', function() {
        $('#formCliente')[0].reset();
        $('#editId').val('0');
        $('#modalCliente .modal-title').html('<i class="bi bi-person-plus"></i> Novo Cliente');
    });

    // ============================================
    // FILTROS UI
    // ============================================
    $('#searchInput').on('input', function() {
        currentSearch = $(this).val().toLowerCase();
        currentPage = 1;
        aplicarFiltros();
    });

    $('#sexoFilter').on('change', function() {
        currentSexo = $(this).val();
        currentPage = 1;
        aplicarFiltros();
    });

    $('#documentoFilter').on('change', function() {
        currentDocumento = $(this).val();
        currentPage = 1;
        aplicarFiltros();
    });

    // ============================================
    // RELÓGIO
    // ============================================
    function updateClock() {
        let now = new Date();
        $('#horaAtual').text(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').text(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
        $('#anoAtual').text(now.getFullYear());
    }

    setInterval(updateClock, 1000);
    updateClock();

    // ============================================
    // INICIALIZAÇÃO
    // ============================================
    $(document).ready(function() {
        carregarNacionalidades();
        carregarTiposDocumento();
        carregarClientes();
    });
</script>
</body>
</html>