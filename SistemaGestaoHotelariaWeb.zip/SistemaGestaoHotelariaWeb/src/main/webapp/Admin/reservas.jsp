<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Reservas · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }
        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }
        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }
        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }
        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }
        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }
        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }
        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.edit { color: #FFB800; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }
        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #0B2B40; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2EAEF; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #FFB800; border-color: #FFB800; color: #0B2B40; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; opacity: 0.5; }
        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }
        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 120px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2EAEF; padding: 10px 14px; }
        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.7rem; font-weight: 500; }
        .badge-status.CONFIRMADA { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.CANCELADA { background: #FFEBEE; color: #D9534F; }
        .badge-status.FINALIZADA { background: #E3F2FD; color: #1976D2; }
        .preco-info { font-size: 0.75rem; color: #2E7D32; margin-top: 5px; }
        .error-message { color: #D9534F; font-size: 0.75rem; margin-top: 5px; display: none; }
        .is-invalid { border-color: #D9534F !important; }
        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .filters-bar { flex-direction: column; align-items: stretch; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in/out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Sistema Hotelaria<span>Gestão de Reservas</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-calendar-check"></i> Total Reservas</h4><div class="value" id="totalReservas">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-check-circle"></i> Confirmadas</h4><div class="value" id="totalConfirmadas">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-clock-history"></i> Pendentes</h4><div class="value" id="totalPendentes">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-cash-stack"></i> Faturamento Estimado</h4><div class="value" id="faturamentoEstimado">0 MZN</div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por cliente, quarto..."></div>
        <div>
            <select class="filter-select" id="statusFilter">
                <option value="">Todos os estados</option>
                <option value="PENDENTE">Pendente</option>
                <option value="CONFIRMADA">Confirmada</option>
                <option value="FINALIZADA">Finalizada</option>
                <option value="CANCELADA">Cancelada</option>
            </select>
            <input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por período" style="width: 250px;">
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalReserva"><i class="bi bi-plus-lg"></i> Nova Reserva</button>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr><th>ID</th><th>Cliente</th><th>Quarto</th><th>Entrada</th><th>Saída</th><th>Hóspedes</th><th>Status</th><th>Ações</th></tr>
                </thead>
                <tbody id="reservasTableBody">
                    <tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Nova Reserva -->
<div class="modal fade modal-custom" id="modalReserva" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-calendar-plus"></i> Nova Reserva</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formReserva">
                    <input type="hidden" id="editId" value="0">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cliente <span class="text-danger">*</span></label>
                            <select class="form-select form-select-custom" id="clienteId" required>
                                <option value="">Selecione o cliente</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Quarto <span class="text-danger">*</span></label>
                            <select class="form-select form-select-custom" id="quartoId" required>
                                <option value="">Selecione o quarto</option>
                            </select>
                            <div id="precoQuartoInfo" class="preco-info"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Data Entrada <span class="text-danger">*</span></label>
                            <input type="date" class="form-control form-control-custom" id="dataEntrada" required>
                            <div class="error-message" id="erroDataEntrada"></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Data Saída <span class="text-danger">*</span></label>
                            <input type="date" class="form-control form-control-custom" id="dataSaida" required>
                            <div class="error-message" id="erroDataSaida"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Número de Hóspedes</label>
                            <input type="number" class="form-control form-control-custom" id="numHospedes" value="1" min="1" max="10">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Estado da Reserva</label>
                            <select class="form-select form-select-custom" id="estadoReserva">
                                <option value="PENDENTE">Pendente</option>
                                <option value="CONFIRMADA">Confirmada</option>
                                <option value="FINALIZADA">Finalizada</option>
                                <option value="CANCELADA">Cancelada</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Observações</label>
                        <textarea class="form-control form-control-custom" id="observacoes" rows="2" placeholder="Alguma observação especial..."></textarea>
                    </div>
                    <div id="resumoEstadia" class="alert alert-info" style="display: none;">
                        <strong>Resumo da Estadia:</strong> <span id="diasEstadia">0</span> diária(s) |
                        Valor Total: <span id="valorTotal">0 MZN</span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Salvar Reserva</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes da Reserva</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="detCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="detQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Data Entrada:</div><div class="detail-value" id="detEntrada">-</div></div>
                <div class="detail-row"><div class="detail-label">Data Saída:</div><div class="detail-value" id="detSaida">-</div></div>
                <div class="detail-row"><div class="detail-label">Hóspedes:</div><div class="detail-value" id="detHospedes">-</div></div>
                <div class="detail-row"><div class="detail-label">Status:</div><div class="detail-value" id="detStatus">-</div></div>
                <div class="detail-row"><div class="detail-label">Observações:</div><div class="detail-value" id="detObs">-</div></div>
                <div class="detail-row"><div class="detail-label">Data Registro:</div><div class="detail-value" id="detDataRegistro">-</div></div>
            </div>
            <div class="modal-footer" style="border:none;padding:16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 10, currentSearch = "", currentStatus = "", currentDateRange = { start: "", end: "" };
    let todasReservas = [], clientes = [], quartos = [], precosQuartos = {};

    function formatMoney(v) { return Number(v).toLocaleString('pt-MZ') + " MZN"; }
    function formatDate(d) { if (!d) return "-"; let parts = d.split('-'); return parts.length === 3 ? parts[2] + '/' + parts[1] + '/' + parts[0] : d; }
    function formatDateTime(dt) { if (!dt) return "-"; return dt.replace('T', ' ').substring(0, 16); }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    // Função para obter a data atual sem hora
    function getHojeSemHora() {
        let hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        return hoje;
    }

    // VALIDAÇÃO DE DATAS NO FRONT-END
    function validarDatasFrontend() {
        let dataEntrada = new Date($('#dataEntrada').val());
        let dataSaida = new Date($('#dataSaida').val());
        let hoje = getHojeSemHora();
        let isValid = true;

        // Limpar mensagens de erro
        $('#erroDataEntrada').hide().text('');
        $('#erroDataSaida').hide().text('');
        $('#dataEntrada').removeClass('is-invalid');
        $('#dataSaida').removeClass('is-invalid');

        // 1. Validar se as datas foram preenchidas
        if (!$('#dataEntrada').val()) {
            $('#erroDataEntrada').text('Data de entrada é obrigatória').show();
            $('#dataEntrada').addClass('is-invalid');
            isValid = false;
        }

        if (!$('#dataSaida').val()) {
            $('#erroDataSaida').text('Data de saída é obrigatória').show();
            $('#dataSaida').addClass('is-invalid');
            isValid = false;
        }

        if (!isValid) return false;

        // 2. Validar data de entrada não anterior a hoje
        if (dataEntrada < hoje) {
            $('#erroDataEntrada').text('Data de entrada não pode ser anterior a hoje').show();
            $('#dataEntrada').addClass('is-invalid');
            isValid = false;
        }

        // 3. Validar data de saída após data de entrada (mínimo 1 dia)
        let diffTime = dataSaida - dataEntrada;
        let diffDays = diffTime / (1000 * 60 * 60 * 24);

        if (diffDays < 1) {
            $('#erroDataSaida').text('A saída deve ser pelo menos 1 dia após a entrada').show();
            $('#dataSaida').addClass('is-invalid');
            isValid = false;
        }

        // 4. Validar período máximo de 30 dias
        if (diffDays > 30) {
            $('#erroDataSaida').text('Período máximo de estadia é de 30 dias').show();
            $('#dataSaida').addClass('is-invalid');
            isValid = false;
        }

        return isValid;
    }

    // Calcular e mostrar resumo da estadia
    function calcularResumoEstadia() {
        if (!validarDatasFrontend()) {
            $('#resumoEstadia').hide();
            return;
        }

        let dataEntrada = new Date($('#dataEntrada').val());
        let dataSaida = new Date($('#dataSaida').val());
        let diffTime = dataSaida - dataEntrada;
        let diffDays = diffTime / (1000 * 60 * 60 * 24);

        let quartoId = $('#quartoId').val();
        let precoDiaria = precosQuartos[quartoId] || 0;
        let valorTotal = precoDiaria * diffDays;

        $('#diasEstadia').text(diffDays);
        $('#valorTotal').text(formatMoney(valorTotal));
        $('#resumoEstadia').show();
    }

    function calcularDiasRestantes(dataSaida) {
        if (!dataSaida) return { dias: null, status: 'normal' };
        let hoje = new Date(); hoje.setHours(0,0,0,0);
        let saida = new Date(dataSaida); saida.setHours(0,0,0,0);
        let diffDays = Math.ceil((saida - hoje) / (1000 * 60 * 60 * 24));
        if (diffDays < 0) return { dias: Math.abs(diffDays), status: 'expirado' };
        if (diffDays === 0) return { dias: 0, status: 'hoje' };
        return { dias: diffDays, status: 'normal' };
    }

    function formatarDataComExpiracao(dataSaida, estadoReserva) {
        if (estadoReserva === 'FINALIZADA' || estadoReserva === 'CANCELADA') {
            return { html: formatDate(dataSaida), classe: '' };
        }
        let info = calcularDiasRestantes(dataSaida);
        if (info.status === 'expirado') {
            return { html: formatDate(dataSaida) + ' <span class="badge bg-danger">⚠️ Expirado há ' + info.dias + ' dias</span>', classe: 'text-danger' };
        } else if (info.status === 'hoje') {
            return { html: formatDate(dataSaida) + ' <span class="badge bg-warning">🗓️ Hoje!</span>', classe: 'text-warning' };
        } else {
            return { html: formatDate(dataSaida) + ' <span class="badge bg-info">⏳ ' + info.dias + ' dias</span>', classe: '' };
        }
    }

    function getBadgeClass(estado) {
        switch(estado) {
            case 'CONFIRMADA': return 'CONFIRMADA';
            case 'PENDENTE': return 'PENDENTE';
            case 'CANCELADA': return 'CANCELADA';
            case 'FINALIZADA': return 'FINALIZADA';
            default: return 'PENDENTE';
        }
    }

    function loadStats() {
        let total = todasReservas.length;
        let confirmadas = todasReservas.filter(r => r.estadoReserva === 'CONFIRMADA').length;
        let pendentes = todasReservas.filter(r => r.estadoReserva === 'PENDENTE').length;
        let faturamento = todasReservas.reduce((sum, r) => sum + (r.precoDiaria || 0), 0);
        $('#totalReservas').text(total);
        $('#totalConfirmadas').text(confirmadas);
        $('#totalPendentes').text(pendentes);
        $('#faturamentoEstimado').html(formatMoney(faturamento));
    }

    function loadClientes() {
        $.ajax({ url: contextPath + '/Admin/clientes/listar', method: 'GET', dataType: 'json',
            success: function(d) {
                clientes = d.clientes || [];
                let select = $('#clienteId');
                select.html('<option value="">Selecione o cliente</option>');
                $.each(clientes, function(i, c) { select.append('<option value="' + c.idCliente + '">' + escapeHtml(c.nomeCompleto) + '</option>'); });
            }, error: function() { console.error('Erro ao carregar clientes'); }
        });
    }

    function loadQuartosDisponiveis() {
        if (!validarDatasFrontend()) {
            $('#quartoId').html('<option value="">Selecione o quarto</option>');
            $('#precoQuartoInfo').html('⚠️ Preencha as datas corretamente primeiro');
            return;
        }

        let dataEntrada = $('#dataEntrada').val();
        let dataSaida = $('#dataSaida').val();
        let editId = $('#editId').val();

        let url = contextPath + '/Admin/reservas/quartos/disponiveis?dataEntrada=' + dataEntrada + '&dataSaida=' + dataSaida;
        if (editId && editId !== '0') url += '&idReservaAtual=' + editId;

        $.ajax({ url: url, method: 'GET', dataType: 'json',
            success: function(d) {
                quartos = d.quartos || [];
                let select = $('#quartoId');
                select.html('<option value="">Selecione o quarto</option>');
                if (quartos.length === 0) {
                    select.html('<option value="">❌ Nenhum quarto disponível</option>');
                    $('#precoQuartoInfo').html('⚠️ Não há quartos disponíveis no período selecionado');
                    return;
                }
                $.each(quartos, function(i, q) {
                    select.append('<option value="' + q.idQuarto + '" data-preco="' + q.precoDiaria + '">' + q.numeroQuarto + ' - ' + q.tipoQuarto + ' (' + formatMoney(q.precoDiaria) + '/diária)</option>');
                    precosQuartos[q.idQuarto] = q.precoDiaria;
                });
                $('#precoQuartoInfo').html('✅ ' + quartos.length + ' quarto(s) disponível(eis) no período');
                calcularResumoEstadia();
            }, error: function() { console.error('Erro ao carregar quartos disponíveis'); }
        });
    }

    function loadReservas() {
        $.ajax({ url: contextPath + '/Admin/reservas/listar', method: 'GET', dataType: 'json',
            success: function(d) { todasReservas = d.reservas || []; aplicarFiltros(); loadStats(); },
            error: function() { $('#reservasTableBody').html('<td><td colspan="8" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function aplicarFiltros() {
        let filtrados = todasReservas.filter(r => {
            let matchSearch = !currentSearch || (r.nomeCliente && r.nomeCliente.toLowerCase().includes(currentSearch)) ||
                             (r.numeroQuarto && r.numeroQuarto.toLowerCase().includes(currentSearch));
            let matchStatus = !currentStatus || r.estadoReserva === currentStatus;
            let matchDate = true;

            // Filtro por intervalo de datas
            if (currentDateRange.start && currentDateRange.end) {
                let dataReserva = new Date(r.dataEntrada);
                let start = new Date(currentDateRange.start);
                let end = new Date(currentDateRange.end);
                matchDate = dataReserva >= start && dataReserva <= end;
            }

            return matchSearch && matchStatus && matchDate;
        });

        let totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        let start = (currentPage - 1) * rowsPerPage;
        let paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
    }

    function renderizarTabela(reservas) {
        let tbody = $('#reservasTableBody');
        tbody.empty();
        if (reservas.length === 0) { tbody.html('<tr><td colspan="8" class="text-center py-4">Nenhuma reserva encontrada</td></tr>'); return; }
        $.each(reservas, function(i, r) {
            let dataSaidaInfo = formatarDataComExpiracao(r.dataSaida, r.estadoReserva);
            tbody.append('<tr>' +
                '<td>' + r.idReserva + '</td>' +
                '<td><strong>' + escapeHtml(r.nomeCliente) + '</strong></td>' +
                '<td>' + escapeHtml(r.numeroQuarto) + ' - ' + escapeHtml(r.tipoQuarto) + '</td>' +
                '<td>' + formatDate(r.dataEntrada) + '</td>' +
                '<td class="' + dataSaidaInfo.classe + '">' + dataSaidaInfo.html + '</td>' +
                '<td class="text-center">' + (r.numeroHospedes || 1) + '</td>' +
                '<td><span class="badge-status ' + getBadgeClass(r.estadoReserva) + '">' + (r.estadoReserva || 'PENDENTE') + '</span></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn edit" onclick="editarReserva(' + r.idReserva + ')"><i class="bi bi-pencil"></i></button>' +
                    '<button class="action-btn view" onclick="verDetalhes(' + r.idReserva + ')"><i class="bi bi-eye"></i></button>' +
                '</td></tr>');
        });
    }

    function renderizarPaginacao(totalPages) {
        let html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + ')">«</a></li>';
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + ')">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + ')">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); }

    function editarReserva(id) {
        let reserva = todasReservas.find(r => r.idReserva === id);
        if (reserva) {
            $('#editId').val(reserva.idReserva);
            $('#clienteId').val(reserva.idCliente);
            $('#dataEntrada').val(reserva.dataEntrada);
            $('#dataSaida').val(reserva.dataSaida);
            $('#numHospedes').val(reserva.numeroHospedes || 1);
            $('#estadoReserva').val(reserva.estadoReserva);
            $('#observacoes').val(reserva.observacoes || '');
            loadQuartosDisponiveis();
            setTimeout(() => {
                $('#quartoId').val(reserva.idQuarto);
                calcularResumoEstadia();
            }, 500);
            $('#modalReserva .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Reserva');
            new bootstrap.Modal(document.getElementById('modalReserva')).show();
        }
    }

    function verDetalhes(id) {
        let reserva = todasReservas.find(r => r.idReserva === id);
        if (reserva) {
            $('#detCliente').html('<strong>' + escapeHtml(reserva.nomeCliente) + '</strong>');
            $('#detQuarto').html(escapeHtml(reserva.numeroQuarto) + ' - ' + escapeHtml(reserva.tipoQuarto));
            $('#detEntrada').html(formatDate(reserva.dataEntrada));
            $('#detSaida').html(formatDate(reserva.dataSaida));
            $('#detHospedes').html(reserva.numeroHospedes || 1);
            $('#detStatus').html('<span class="badge-status ' + getBadgeClass(reserva.estadoReserva) + '">' + (reserva.estadoReserva || 'PENDENTE') + '</span>');
            $('#detObs').html(reserva.observacoes || 'Nenhuma observação');
            $('#detDataRegistro').html(formatDateTime(reserva.dataRegistro));
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        }
    }

    $('#formReserva').on('submit', function(e) {
        e.preventDefault();

        // VALIDAÇÃO ANTES DE ENVIAR
        if (!validarDatasFrontend()) {
            showAlert('error', 'Por favor, corrija as datas antes de salvar');
            return;
        }

        let formData = new FormData();
        formData.append('id', $('#editId').val());
        formData.append('idCliente', $('#clienteId').val());
        formData.append('idQuarto', $('#quartoId').val());
        formData.append('dataEntrada', $('#dataEntrada').val());
        formData.append('dataSaida', $('#dataSaida').val());
        formData.append('numeroHospedes', $('#numHospedes').val());
        formData.append('estadoReserva', $('#estadoReserva').val());
        formData.append('observacoes', $('#observacoes').val());

        $.ajax({ url: contextPath + '/Admin/reservas/salvar', method: 'POST', data: formData, processData: false, contentType: false, dataType: 'json',
            success: function(r) {
                if (r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalReserva')).hide();
                    showAlert('success', 'Reserva salva com sucesso!');
                    $('#formReserva')[0].reset(); $('#editId').val('0');
                    loadReservas();
                } else showAlert('error', r.message || 'Erro ao salvar');
            }, error: function(xhr) {
                let msg = xhr.responseJSON?.message || 'Erro ao salvar reserva';
                showAlert('error', msg);
            }
        });
    });

    $('#modalReserva').on('hidden.bs.modal', function() {
        $('#formReserva')[0].reset();
        $('#editId').val('0');
        $('#modalReserva .modal-title').html('<i class="bi bi-calendar-plus"></i> Nova Reserva');
        $('#precoQuartoInfo').html('');
        $('#resumoEstadia').hide();
        $('#erroDataEntrada, #erroDataSaida').hide();
        $('#dataEntrada, #dataSaida').removeClass('is-invalid');
    });

    // Eventos de validação em tempo real
    $('#dataEntrada, #dataSaida').on('change', function() {
        validarDatasFrontend();
        loadQuartosDisponiveis();
    });

    $('#quartoId').on('change', function() {
        calcularResumoEstadia();
    });

    $('#searchInput').on('input', function() { currentSearch = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });
    $('#statusFilter').on('change', function() { currentStatus = $(this).val(); currentPage = 1; aplicarFiltros(); });

    // Filtro por intervalo de datas com Flatpickr
    flatpickr("#dateFilter", {
        mode: "range",
        dateFormat: "Y-m-d",
        locale: "pt",
        onChange: function(selectedDates, dateStr, instance) {
            if (selectedDates.length === 2) {
                currentDateRange.start = selectedDates[0].toISOString().split('T')[0];
                currentDateRange.end = selectedDates[1].toISOString().split('T')[0];
            } else {
                currentDateRange.start = "";
                currentDateRange.end = "";
            }
            currentPage = 1;
            aplicarFiltros();
        }
    });

    // Configurar datas mínimas nos inputs de data
    let hojeStr = new Date().toISOString().split('T')[0];
    $('#dataEntrada').attr('min', hojeStr);

    $('#dataEntrada').on('change', function() {
        let dataEntrada = $(this).val();
        if (dataEntrada) {
            let minSaida = new Date(dataEntrada);
            minSaida.setDate(minSaida.getDate() + 1);
            let minSaidaStr = minSaida.toISOString().split('T')[0];
            $('#dataSaida').attr('min', minSaidaStr);

            // Limitar máximo de 30 dias
            let maxSaida = new Date(dataEntrada);
            maxSaida.setDate(maxSaida.getDate() + 30);
            let maxSaidaStr = maxSaida.toISOString().split('T')[0];
            $('#dataSaida').attr('max', maxSaidaStr);
        }
    });

    function updateClock() { let now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    loadClientes();
    loadReservas();
</script>
</body>
</html>