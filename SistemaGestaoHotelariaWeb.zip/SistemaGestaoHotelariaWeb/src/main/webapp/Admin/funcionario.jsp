<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funcionários · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }
        .btn-danger-custom { background: #D9534F; border: none; padding: 8px 20px; border-radius: 30px; font-weight: 500; color: white; }
        .btn-danger-custom:hover { background: #C9302C; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }

        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.7rem; font-weight: 500; }
        .badge-status.ATIVO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.INATIVO { background: #FFEBEE; color: #D9534F; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.edit { color: #FFB800; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #0B2B40; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2EAEF; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #FFB800; border-color: #FFB800; color: #0B2B40; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; opacity: 0.5; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2EAEF; padding: 10px 14px; }
        .form-control-custom:focus, .form-select-custom:focus { border-color: #FFB800; box-shadow: 0 0 0 3px rgba(255,184,0,0.1); }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .filters-bar { flex-direction: column; align-items: stretch; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-building"></i><div class="logo-text">Sistema Hotelaria<span>Gestão de Funcionários</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-people"></i> Total Funcionários</h4><div class="value" id="totalFuncionarios">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-check-circle"></i> Ativos</h4><div class="value" id="funcionariosAtivos">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-x-circle"></i> Inativos</h4><div class="value" id="funcionariosInativos">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-calendar"></i> Contratados Este Mês</h4><div class="value" id="contratadosMes">0</div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por nome, cargo ou email..."></div>
        <div>
            <select class="filter-select" id="cargoFilter"><option value="">Todos os cargos</option></select>
            <select class="filter-select" id="statusFilter"><option value="">Todos os status</option><option value="ATIVO">ATIVO</option><option value="INATIVO">INATIVO</option></select>
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalFuncionario"><i class="bi bi-plus-lg"></i> Novo Funcionário</button>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr><th>Nome</th><th>Cargo</th><th>Telefone</th><th>Email</th><th>Salário</th><th>Contratação</th><th>Status</th><th>Ações</th></tr>
                </thead>
                <tbody id="funcionariosTableBody"><tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr></tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Novo/Editar Funcionário -->
<div class="modal fade modal-custom" id="modalFuncionario" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-person-badge"></i> Funcionário</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formFuncionario">
                    <input type="hidden" id="editId" value="">
                    <div class="mb-3"><label class="form-label">Nome Completo <span class="text-danger">*</span></label><input type="text" class="form-control form-control-custom" id="nomeCompleto" required placeholder="Ex: Ana Oliveira"></div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Sexo</label><select class="form-select form-select-custom" id="sexo"><option value="">Selecione</option><option value="M">Masculino</option><option value="F">Feminino</option></select></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Telefone</label><input type="tel" class="form-control form-control-custom" id="telefone" placeholder="+258 84 123 4567"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Email</label><input type="email" class="form-control form-control-custom" id="email" placeholder="funcionario@hotelaria.co.mz"></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Cargo</label><select class="form-select form-select-custom" id="cargo"><option value="">Selecione</option></select></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Salário (MZN)</label><input type="number" class="form-control form-control-custom" id="salario" step="0.01" placeholder="0.00"></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Data Contratação</label><input type="date" class="form-control form-control-custom" id="dataContratacao"></div>
                    </div>
                    <div class="mb-3"><label class="form-label">Turno</label><select class="form-select form-select-custom" id="turno"><option value="">Selecione o turno</option></select></div>
                    <div class="mb-3"><label class="form-label">Status</label><select class="form-select form-select-custom" id="status"><option value="ATIVO">ATIVO</option><option value="INATIVO">INATIVO</option></select></div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Salvar Funcionário</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Funcionário -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Funcionário</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Nome:</div><div class="detail-value" id="detNome">-</div></div>
                <div class="detail-row"><div class="detail-label">Sexo:</div><div class="detail-value" id="detSexo">-</div></div>
                <div class="detail-row"><div class="detail-label">Telefone:</div><div class="detail-value" id="detTelefone">-</div></div>
                <div class="detail-row"><div class="detail-label">Email:</div><div class="detail-value" id="detEmail">-</div></div>
                <div class="detail-row"><div class="detail-label">Cargo:</div><div class="detail-value" id="detCargo">-</div></div>
                <div class="detail-row"><div class="detail-label">Salário:</div><div class="detail-value" id="detSalario">-</div></div>
                <div class="detail-row"><div class="detail-label">Contratação:</div><div class="detail-value" id="detContratacao">-</div></div>
                <div class="detail-row"><div class="detail-label">Turno:</div><div class="detail-value" id="detTurno">-</div></div>
                <div class="detail-row"><div class="detail-label">Status:</div><div class="detail-value" id="detStatus">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 5, currentFilter = "", currentCargoFilter = "", currentStatusFilter = "";
    let todosFuncionarios = [], cargosLista = [], turnosLista = [];

    function formatMoney(v) { if (v === undefined || v === null || isNaN(v)) return "0 MZN"; return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN"; }
    function formatDate(dateStr) { if (!dateStr) return "-"; var parts = dateStr.split("-"); return parts[2] + "/" + parts[1] + "/" + parts[0]; }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }
    function getSexoIcon(sexo) { if (sexo === 'M') return '<i class="bi bi-gender-male" style="color:#1976D2;"></i>'; if (sexo === 'F') return '<i class="bi bi-gender-female" style="color:#D9534F;"></i>'; return ''; }
    function getSexoTexto(sexo) { if (sexo === 'M') return 'Masculino'; if (sexo === 'F') return 'Feminino'; return '-'; }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    function getTurnoNome(idTurno) {
        for (var i = 0; i < turnosLista.length; i++) {
            if (turnosLista[i].id_turno === idTurno) {
                return turnosLista[i].nome_turno + " (" + turnosLista[i].hora_inicio + " - " + turnosLista[i].hora_fim + ")";
            }
        }
        return "-";
    }

    function loadStats() {
        $.ajax({ url: contextPath + '/Admin/funcionarios/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalFuncionarios').text(d.total || 0);
                $('#funcionariosAtivos').text(d.ativos || 0);
                $('#funcionariosInativos').text(d.inativos || 0);
                $('#contratadosMes').text(d.contratados_mes || 0);
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function loadCargos() {
        $.ajax({ url: contextPath + '/Admin/funcionarios/cargos', method: 'GET', dataType: 'json',
            success: function(d) {
                cargosLista = d;
                var selectFiltro = $('#cargoFilter');
                var selectModal = $('#cargo');
                selectFiltro.html('<option value="">Todos os cargos</option>');
                selectModal.html('<option value="">Selecione</option>');
                $.each(d, function(i, cargo) {
                    selectFiltro.append('<option value="' + escapeHtml(cargo) + '">' + escapeHtml(cargo) + '</option>');
                    selectModal.append('<option value="' + escapeHtml(cargo) + '">' + escapeHtml(cargo) + '</option>');
                });
            }, error: function() { console.error('Erro ao carregar cargos'); }
        });
    }

    function loadTurnos() {
        $.ajax({ url: contextPath + '/Admin/funcionarios/turnos', method: 'GET', dataType: 'json',
            success: function(d) {
                turnosLista = d;
                var select = $('#turno');
                select.html('<option value="">Selecione o turno</option>');
                $.each(d, function(i, turno) {
                    select.append('<option value="' + turno.id_turno + '">' + escapeHtml(turno.nome_turno) + ' (' + turno.hora_inicio + ' - ' + turno.hora_fim + ')</option>');
                });
            }, error: function() { console.error('Erro ao carregar turnos'); }
        });
    }

    function loadFuncionarios() {
        $.ajax({ url: contextPath + '/Admin/funcionarios/listar', method: 'GET', dataType: 'json',
            success: function(d) { todosFuncionarios = d; aplicarFiltros(); },
            error: function() { $('#funcionariosTableBody').html('<tr><td colspan="8" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function aplicarFiltros() {
        var filtrados = todosFuncionarios.filter(function(f) {
            var matchSearch = !currentFilter || (f.nome_completo && f.nome_completo.toLowerCase().includes(currentFilter)) || (f.cargo && f.cargo.toLowerCase().includes(currentFilter)) || (f.email && f.email.toLowerCase().includes(currentFilter));
            var matchCargo = !currentCargoFilter || f.cargo === currentCargoFilter;
            var matchStatus = !currentStatusFilter || f.status === currentStatusFilter;
            return matchSearch && matchCargo && matchStatus;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
    }

    function renderizarTabela(funcionarios) {
        var tbody = $('#funcionariosTableBody');
        tbody.empty();
        if (funcionarios.length === 0) { tbody.html('<tr><td colspan="8" class="text-center py-4">Nenhum funcionário encontrado</td></tr>'); return; }
        $.each(funcionarios, function(i, f) {
            tbody.append('<tr>' +
                '<td><strong>' + escapeHtml(f.nome_completo) + '</strong> ' + getSexoIcon(f.sexo) + '</td>' +
                '<td>' + escapeHtml(f.cargo) + '</td>' +
                '<td>' + (f.telefone || '-') + '</td>' +
                '<td>' + (f.email || '-') + '</td>' +
                '<td>' + formatMoney(f.salario) + '</td>' +
                '<td>' + formatDate(f.data_contratacao) + '</td>' +
                '<td><span class="badge-status ' + (f.status === 'ATIVO' ? 'ATIVO' : 'INATIVO') + '">' + f.status + '</span></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn edit" data-id="' + f.id_funcionario + '" title="Editar"><i class="bi bi-pencil"></i></button>' +
                    '<button class="action-btn view" data-id="' + f.id_funcionario + '" title="Detalhes"><i class="bi bi-eye"></i></button>' +
                '</td>' +
            '</tr>');
        });
        $('.action-btn.edit').off('click').on('click', function() { editFuncionario($(this).data('id')); });
        $('.action-btn.view').off('click').on('click', function() { viewFuncionario($(this).data('id')); });
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); return false; }

    function editFuncionario(id) {
        var f = todosFuncionarios.find(function(func) { return func.id_funcionario === id; });
        if (f) {
            $('#editId').val(f.id_funcionario);
            $('#nomeCompleto').val(f.nome_completo);
            $('#sexo').val(f.sexo || "");
            $('#telefone').val(f.telefone || "");
            $('#email').val(f.email || "");
            $('#cargo').val(f.cargo);
            $('#salario').val(f.salario);
            $('#dataContratacao').val(f.data_contratacao);
            $('#status').val(f.status);
            $('#turno').val(f.id_turno || "");
            $('#modalFuncionario .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Funcionário');
            new bootstrap.Modal(document.getElementById('modalFuncionario')).show();
        }
    }

    function viewFuncionario(id) {
        var f = todosFuncionarios.find(function(func) { return func.id_funcionario === id; });
        if (f) {
            $('#detNome').html('<strong>' + escapeHtml(f.nome_completo) + '</strong>');
            $('#detSexo').text(getSexoTexto(f.sexo));
            $('#detTelefone').text(f.telefone || '-');
            $('#detEmail').text(f.email || '-');
            $('#detCargo').text(f.cargo);
            $('#detSalario').text(formatMoney(f.salario));
            $('#detContratacao').text(formatDate(f.data_contratacao));
            $('#detTurno').text(getTurnoNome(f.id_turno));
            $('#detStatus').html('<span class="badge-status ' + (f.status === 'ATIVO' ? 'ATIVO' : 'INATIVO') + '">' + f.status + '</span>');
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        }
    }

    $('#formFuncionario').on('submit', function(e) {
        e.preventDefault();
        var editId = $('#editId').val();
        var funcionarioData = {
            id_funcionario: editId ? parseInt(editId) : 0,
            nome_completo: $('#nomeCompleto').val(),
            sexo: $('#sexo').val(),
            telefone: $('#telefone').val(),
            email: $('#email').val(),
            cargo: $('#cargo').val(),
            salario: parseFloat($('#salario').val()) || 0,
            data_contratacao: $('#dataContratacao').val(),
            id_turno: parseInt($('#turno').val()) || null,
            status: $('#status').val()
        };
        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Salvando...');
        $.ajax({ url: contextPath + '/Admin/funcionarios/salvar', method: 'POST', data: funcionarioData, dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Salvar Funcionário');
                if (r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalFuncionario')).hide();
                    $('#formFuncionario')[0].reset();
                    $('#editId').val("");
                    $('#modalFuncionario .modal-title').html('<i class="bi bi-person-badge"></i> Funcionário');
                    loadFuncionarios();
                    showAlert('success', 'Funcionário ' + (editId ? 'atualizado' : 'cadastrado') + ' com sucesso!');
                } else { showAlert('error', r.message || 'Erro ao salvar'); }
            }, error: function() { btn.prop('disabled', false).text('Salvar Funcionário'); showAlert('error', 'Erro ao salvar funcionário'); }
        });
    });

    $('#modalFuncionario').on('hidden.bs.modal', function() {
        $('#formFuncionario')[0].reset();
        $('#editId').val("");
        $('#modalFuncionario .modal-title').html('<i class="bi bi-person-badge"></i> Funcionário');
    });

    $('#searchInput').on('input', function() { currentFilter = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });
    $('#cargoFilter').on('change', function() { currentCargoFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });
    $('#statusFilter').on('change', function() { currentStatusFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    loadCargos();
    loadTurnos();
    loadFuncionarios();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>