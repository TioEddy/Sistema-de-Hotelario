<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    // Verificar permissão (apenas Admin e Gerente podem acessar)
    String perfil = usuarioLogado.getNomePerfil();
    if (!"Administrador".equals(perfil) && !"Gerente".equals(perfil)) {
        response.sendRedirect(request.getContextPath() + "/dashboard.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 280px;
            height: 100vh;
            background: #0B2B40;
            color: #E8E8E8;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 15px rgba(0, 0, 0, 0.08);
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 184, 0, 0.2);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFB800;
            margin-bottom: 12px;
            object-fit: cover;
            background: #0B2B40;
        }
        .sidebar .profile h3 {
            font-size: 1.15rem;
            font-weight: 600;
            color: #FFB800;
        }
        .sidebar .profile p {
            font-size: 0.75rem;
            opacity: 0.7;
            margin: 0;
        }
        .sidebar ul {
            list-style: none;
            padding: 0 16px;
        }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255, 184, 0, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active a { color: #0B2B40; }
        .sidebar li a {
            color: #E8E8E8;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
        }
        .sidebar .menu-section {
            color: #FFB800;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper {
            margin-left: 280px;
            height: 100vh;
            overflow-y: auto;
            padding: 20px 28px;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area img { height: 45px; width: auto; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }
        .btn-primary-custom {
            background: #FFB800;
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: #0B2B40;
            transition: all 0.2s;
        }
        .btn-primary-custom:hover {
            background: #0B2B40;
            color: #FFB800;
            transform: translateY(-2px);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            transition: all 0.3s;
            border: 1px solid #E2EAEF;
            cursor: pointer;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            border-color: #FFB800;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        }
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .stat-header h3 {
            font-size: 0.75rem;
            font-weight: 600;
            color: #8AA6B5;
            text-transform: uppercase;
        }
        .stat-header i {
            font-size: 1.6rem;
            color: #FFB800;
            opacity: 0.7;
        }
        .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: #0B2B40;
            margin-bottom: 6px;
        }
        .stat-footer {
            font-size: 0.7rem;
            color: #A0B8C4;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .table-container {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid #E2EAEF;
        }
        .badge-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 500;
        }
        .badge-status.ATIVO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.INATIVO { background: #FFEBEE; color: #D9534F; }
        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 5px;
            border-radius: 8px;
            transition: all 0.2s;
        }
        .action-btn.edit { color: #FFB800; }
        .action-btn.reset { color: #F57C00; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }
        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom {
            background: #0B2B40;
            color: white;
            border-radius: 24px 24px 0 0;
            padding: 20px 24px;
        }
        .detail-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #E2EAEF;
        }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .photo-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #FFB800;
            margin-bottom: 10px;
            cursor: pointer;
        }
        .user-photo-small {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 20px;
            margin-top: 20px;
            border: 1px solid #E2EAEF;
        }
        .footer p {
            margin: 0;
            font-size: 0.75rem;
            color: #6C8D9C;
        }
        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quarto.jsp"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/cliente.jsp"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>

    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr.jsp"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/fatura.jsp"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionario.jsp"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <img src="${pageContext.request.contextPath}/assets/images/logotipo.png" alt="Logotipo" onerror="this.src='https://placehold.co/45x45/0B2B40/FFB800?text=🏨'">
            <div class="logo-text">Sistema Hotelaria<span>Gestão de Usuários</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <!-- CARDS ESTATÍSTICOS -->
    <div class="stats-grid">
        <div class="stat-card" id="cardTotal">
            <div class="stat-header"><h3>Total Usuários</h3><i class="bi bi-people-fill"></i></div>
            <div class="stat-value" id="totalUsuarios">0</div>
            <div class="stat-footer"><i class="bi bi-database"></i><span> Registrados</span></div>
        </div>
        <div class="stat-card" id="cardAtivos">
            <div class="stat-header"><h3>Ativos</h3><i class="bi bi-check-circle-fill"></i></div>
            <div class="stat-value" id="usuariosAtivos">0</div>
            <div class="stat-footer"><i class="bi bi-graph-up"></i><span> Com acesso</span></div>
        </div>
        <div class="stat-card" id="cardInativos">
            <div class="stat-header"><h3>Inativos</h3><i class="bi bi-x-circle-fill"></i></div>
            <div class="stat-value" id="usuariosInativos">0</div>
            <div class="stat-footer"><i class="bi bi-clock"></i><span> Bloqueados</span></div>
        </div>
        <div class="stat-card" id="cardAdmins">
            <div class="stat-header"><h3>Administradores</h3><i class="bi bi-shield-check"></i></div>
            <div class="stat-value" id="totalAdmins">0</div>
            <div class="stat-footer"><i class="bi bi-star-fill"></i><span> Nível máximo</span></div>
        </div>
    </div>

    <!-- BARRA DE FILTROS -->
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
        <div class="d-flex gap-2 flex-wrap">
            <div class="d-flex align-items-center bg-light rounded-pill px-3 py-1">
                <i class="bi bi-search"></i>
                <input type="text" id="searchInput" class="border-0 bg-transparent py-2 px-2" placeholder="Buscar..." style="width: 250px; outline: none;">
            </div>
            <select id="perfilFilter" class="form-select rounded-pill" style="width: 150px;">
                <option value="">Todos perfis</option>
            </select>
            <select id="statusFilter" class="form-select rounded-pill" style="width: 130px;">
                <option value="">Todos status</option>
                <option value="ATIVO">ATIVO</option>
                <option value="INATIVO">INATIVO</option>
            </select>
        </div>
        <button class="btn-primary-custom rounded-pill" data-bs-toggle="modal" data-bs-target="#modalUsuario">
            <i class="bi bi-plus-lg"></i> Novo Usuário
        </button>
    </div>

    <!-- TABELA DE USUÁRIOS -->
    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Nome</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Telefone</th>
                        <th>Perfil</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="usuariosTableBody">
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <div class="spinner-border text-warning" role="status">
                                <span class="visually-hidden">Carregando...</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div id="infoRegistros" class="text-muted small"></div>
            <nav>
                <ul class="pagination pagination-sm mb-0" id="pagination"></ul>
            </nav>
        </div>
    </div>

    <div class="footer">
        <p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p>
    </div>
</div>

<!-- MODAL: NOVO/EDITAR USUÁRIO -->
<div class="modal fade modal-custom" id="modalUsuario" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-person-plus"></i> Usuário</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formUsuario">
                    <input type="hidden" id="editId" value="0">

                    <div class="text-center mb-3">
                        <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
                             alt="Foto" class="photo-preview" id="photoPreview"
                             onclick="document.getElementById('photoInput').click()"
                             style="cursor: pointer;">
                        <div class="mt-2">
                            <input type="file" id="photoInput" accept="image/*" style="display: none;">
                            <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill" onclick="document.getElementById('photoInput').click()">
                                <i class="bi bi-camera"></i> Escolher Foto
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger rounded-pill" onclick="removerFoto()">
                                <i class="bi bi-trash"></i> Remover
                            </button>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nome Completo <span class="text-danger">*</span></label>
                        <input type="text" class="form-control rounded-pill" id="nome" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Username <span class="text-danger">*</span></label>
                            <input type="text" class="form-control rounded-pill" id="username" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Senha <span class="text-danger" id="senhaRequired">*</span></label>
                            <input type="password" class="form-control rounded-pill" id="senha" placeholder="******">
                            <small class="text-muted">Mínimo 6 caracteres</small>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control rounded-pill" id="email">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Telefone</label>
                            <input type="tel" class="form-control rounded-pill" id="telefone">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Perfil <span class="text-danger">*</span></label>
                            <select class="form-select rounded-pill" id="idPerfil" required>
                                <option value="">Selecione</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Estado</label>
                            <select class="form-select rounded-pill" id="estado">
                                <option value="ATIVO">ATIVO</option>
                                <option value="INATIVO">INATIVO</option>
                            </select>
                        </div>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-secondary rounded-pill" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary rounded-pill" style="background: #FFB800; border: none; color: #0B2B40;">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: DETALHES DO USUÁRIO -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Usuário</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="text-center mb-3">
                    <img src="" alt="Foto" id="detFoto" class="rounded-circle" style="width: 80px; height: 80px; object-fit: cover; border: 3px solid #FFB800;">
                </div>
                <div class="detail-row"><div class="detail-label">Nome:</div><div class="detail-value" id="detNome">-</div></div>
                <div class="detail-row"><div class="detail-label">Username:</div><div class="detail-value" id="detUsername">-</div></div>
                <div class="detail-row"><div class="detail-label">Email:</div><div class="detail-value" id="detEmail">-</div></div>
                <div class="detail-row"><div class="detail-label">Telefone:</div><div class="detail-value" id="detTelefone">-</div></div>
                <div class="detail-row"><div class="detail-label">Perfil:</div><div class="detail-value" id="detPerfil">-</div></div>
                <div class="detail-row"><div class="detail-label">Estado:</div><div class="detail-value" id="detEstado">-</div></div>
                <div class="detail-row"><div class="detail-label">Data Registro:</div><div class="detail-value" id="detDataRegistro">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                <button class="btn-primary-custom rounded-pill" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    let currentPage = 1;
    let totalPages = 1;
    let currentSearch = '';
    let currentPerfil = '';
    let currentStatus = '';
    let currentFotoData = '';
    let todosUsuarios = [];
    let perfis = [];

    // Foto padrão por perfil
    function getFotoPerfilPadrao(idPerfil) {
        const fotos = {
            1: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png',
            2: 'https://cdn-icons-png.flaticon.com/512/3135/3135761.png',
            3: 'https://cdn-icons-png.flaticon.com/512/3135/3135790.png',
            4: 'https://cdn-icons-png.flaticon.com/512/3135/3135789.png'
        };
        return fotos[idPerfil] || fotos[1];
    }

    // Carregar perfis
    function carregarPerfis() {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/usuarios/perfis',
            method: 'GET',
            success: function(data) {
                if (typeof data === 'string') {
                    try { data = JSON.parse(data); } catch(e) { data = []; }
                }
                perfis = data;
                let filterSelect = $('#perfilFilter');
                let modalSelect  = $('#idPerfil');

                filterSelect.html('<option value="">Todos perfis</option>');
                modalSelect.html('<option value="">Selecione</option>');

                $.each(perfis, function(i, p) {
                    filterSelect.append('<option value="' + p.idPerfil + '">' + p.nomePerfil + '</option>');
                    modalSelect.append('<option value="' + p.idPerfil + '">' + p.nomePerfil + '</option>');
                });
            },
            error: function(xhr) {
                console.error('Erro ao carregar perfis:', xhr.responseText);
                Swal.fire('Erro', 'Não foi possível carregar os perfis', 'error');
            }
        });
    }

    // Carregar usuários
    function carregarUsuarios() {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/usuarios/listar',
            method: 'GET',
            data: { limit: 100 },
            success: function(data) {
                if (typeof data === 'string') {
                    try { data = JSON.parse(data); } catch(e) { data = { usuarios: [] }; }
                }
                todosUsuarios = data.usuarios || [];
                aplicarFiltros();
            },
            error: function(xhr) {
                console.error('Erro ao carregar usuários:', xhr.responseText);
                $('#usuariosTableBody').html('<tr><td colspan="8" class="text-center text-danger py-4"><i class="bi bi-exclamation-triangle"></i> Erro ao carregar dados</td></tr>');
                Swal.fire('Erro', 'Não foi possível carregar os usuários', 'error');
            }
        });
    }

    // Aplicar filtros
    function aplicarFiltros() {
        let filtrados = [...todosUsuarios];

        if (currentSearch) {
            filtrados = filtrados.filter(u =>
                u.nome.toLowerCase().includes(currentSearch) ||
                u.username.toLowerCase().includes(currentSearch) ||
                (u.email && u.email.toLowerCase().includes(currentSearch))
            );
        }

        if (currentPerfil) {
            filtrados = filtrados.filter(u => u.idPerfil == currentPerfil);
        }

        if (currentStatus) {
            filtrados = filtrados.filter(u => u.estado === currentStatus);
        }

        atualizarStats(filtrados);

        const limit = 10;
        totalPages = Math.ceil(filtrados.length / limit);
        if (totalPages === 0) totalPages = 1;
        if (currentPage > totalPages) currentPage = totalPages;

        const start = (currentPage - 1) * limit;
        const paginados = filtrados.slice(start, start + limit);

        renderizarTabela(paginados);
        renderizarPaginacao();
        $('#infoRegistros').html('Mostrando ' + paginados.length + ' de ' + filtrados.length + ' registros');
    }

    // Atualizar estatísticas
    function atualizarStats(usuarios) {
        let ativos = 0, inativos = 0, admins = 0;
        $.each(usuarios, function(i, u) {
            if (u.estado === 'ATIVO')   ativos++;
            if (u.estado === 'INATIVO') inativos++;
            if (u.idPerfil === 1)       admins++;
        });
        $('#totalUsuarios').text(usuarios.length);
        $('#usuariosAtivos').text(ativos);
        $('#usuariosInativos').text(inativos);
        $('#totalAdmins').text(admins);
    }

    // Escape HTML
    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    // Renderizar tabela
    function renderizarTabela(usuarios) {
        let html = '';
        if (usuarios.length === 0) {
            html = '<tr><td colspan="8" class="text-center py-4">Nenhum usuário encontrado</td></tr>';
        } else {
            for (let i = 0; i < usuarios.length; i++) {
                let u = usuarios[i];
                let fotoUrl = u.foto || getFotoPerfilPadrao(u.idPerfil);
                let perfilNome = '';
                for (let j = 0; j < perfis.length; j++) {
                    if (perfis[j].idPerfil === u.idPerfil) {
                        perfilNome = perfis[j].nomePerfil;
                        break;
                    }
                }
                html += '<tr>' +
                    '<td><img src="' + fotoUrl + '" class="user-photo-small" onerror="this.src=\'' + getFotoPerfilPadrao(u.idPerfil) + '\'"></td>' +
                    '<td><strong>' + escapeHtml(u.nome) + '</strong></td>' +
                    '<td>' + escapeHtml(u.username) + '</td>' +
                    '<td>' + (u.email ? escapeHtml(u.email) : '-') + '</td>' +
                    '<td>' + (u.telefone ? escapeHtml(u.telefone) : '-') + '</td>' +
                    '<td>' + perfilNome + '</td>' +
                    '<td><span class="badge-status ' + u.estado + '">' + u.estado + '</span></td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" onclick="editarUsuario(' + u.idUsuario + ')" title="Editar"><i class="bi bi-pencil"></i></button>' +
                        '<button class="action-btn reset" onclick="resetarSenha(' + u.idUsuario + ', \'' + escapeHtml(u.nome) + '\')" title="Resetar Senha"><i class="bi bi-key"></i></button>' +
                        '<button class="action-btn view" onclick="verDetalhes(' + u.idUsuario + ')" title="Detalhes"><i class="bi bi-eye"></i></button>' +
                    '</td>' +
                '</tr>';
            }
        }
        $('#usuariosTableBody').html(html);
    }

    // Paginação
    function renderizarPaginacao() {
        let html = '';
        if (currentPage > 1) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + ')">«</a></li>';
        }
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                let activeClass = (i === currentPage) ? 'active' : '';
                html += '<li class="page-item ' + activeClass + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + ')">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + ')">»</a></li>';
        }
        $('#pagination').html(html);
    }

    function mudarPagina(page) {
        currentPage = page;
        aplicarFiltros();
    }

    // CRUD - Editar
    function editarUsuario(id) {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/usuarios/editar',
            method: 'GET',
            data: { id: id },
            success: function(data) {
                if (typeof data === 'string') {
                    try { data = JSON.parse(data); } catch(e) {
                        Swal.fire('Erro', 'Resposta inválida do servidor', 'error');
                        return;
                    }
                }
                if (data.error) {
                    Swal.fire('Erro', data.error, 'error');
                    return;
                }
                let usuario = data;
                $('#editId').val(usuario.idUsuario);
                $('#nome').val(usuario.nome);
                $('#username').val(usuario.username);
                $('#email').val(usuario.email || '');
                $('#telefone').val(usuario.telefone || '');
                $('#idPerfil').val(usuario.idPerfil);
                $('#estado').val(usuario.estado);
                $('#senha').val('');
                $('#senha').prop('required', false);
                $('#senhaRequired').html('(opcional)');

                let fotoUrl = usuario.foto || getFotoPerfilPadrao(usuario.idPerfil);
                $('#photoPreview').attr('src', fotoUrl);
                currentFotoData = usuario.foto || '';

                $('#modalUsuario .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Usuário');
                new bootstrap.Modal(document.getElementById('modalUsuario')).show();
            },
            error: function(xhr) {
                console.error('Erro editar:', xhr.responseText);
                Swal.fire('Erro', 'Não foi possível carregar os dados do usuário', 'error');
            }
        });
    }

    // Resetar Senha
    function resetarSenha(id, nome) {
        Swal.fire({
            title: 'Resetar Senha',
            html: 'Tem certeza que deseja resetar a senha do usuário <strong>' + nome + '</strong>?<br><small>A nova senha será: <strong>123456</strong></small>',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#F57C00',
            confirmButtonText: 'Sim, resetar',
            cancelButtonText: 'Cancelar'
        }).then(function(result) {
            if (result.isConfirmed) {
                $.ajax({
                    url: '${pageContext.request.contextPath}/Admin/usuarios/reset-senha',
                    method: 'POST',
                    data: { id: id },
                    success: function(data) {
                        if (typeof data === 'string') {
                            try { data = JSON.parse(data); } catch(e) { data = { success: false }; }
                        }
                        if (data.success) {
                            Swal.fire('Sucesso', 'Senha resetada para 123456', 'success');
                        } else {
                            Swal.fire('Erro', data.message || 'Não foi possível resetar a senha', 'error');
                        }
                    },
                    error: function(xhr) {
                        console.error('Erro reset senha:', xhr.responseText);
                        Swal.fire('Erro', 'Erro ao resetar senha', 'error');
                    }
                });
            }
        });
    }

    // Ver Detalhes
    function verDetalhes(id) {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/usuarios/editar',
            method: 'GET',
            data: { id: id },
            success: function(data) {
                if (typeof data === 'string') {
                    try { data = JSON.parse(data); } catch(e) {
                        Swal.fire('Erro', 'Resposta inválida do servidor', 'error');
                        return;
                    }
                }
                let usuario = data;
                let perfilNome = '';
                for (let i = 0; i < perfis.length; i++) {
                    if (perfis[i].idPerfil === usuario.idPerfil) {
                        perfilNome = perfis[i].nomePerfil;
                        break;
                    }
                }
                let fotoUrl = usuario.foto || getFotoPerfilPadrao(usuario.idPerfil);
                $('#detFoto').attr('src', fotoUrl);
                $('#detNome').html(usuario.nome);
                $('#detUsername').html(usuario.username);
                $('#detEmail').html(usuario.email || '-');
                $('#detTelefone').html(usuario.telefone || '-');
                $('#detPerfil').html(perfilNome);
                $('#detEstado').html('<span class="badge-status ' + usuario.estado + '">' + usuario.estado + '</span>');
                $('#detDataRegistro').html(usuario.dataRegistro || '-');
                new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
            },
            error: function(xhr) {
                console.error('Erro detalhes:', xhr.responseText);
                Swal.fire('Erro', 'Não foi possível carregar os detalhes', 'error');
            }
        });
    }

    // Form Submit - Salvar
    $('#formUsuario').on('submit', function(e) {
        e.preventDefault();

        let id    = $('#editId').val();
        let senha = $('#senha').val();

        if (id == '0' && (!senha || senha.length < 6)) {
            Swal.fire('Atenção', 'A senha é obrigatória e deve ter no mínimo 6 caracteres', 'warning');
            return;
        }

        let perfilVal = $('#idPerfil').val();
        if (!perfilVal || perfilVal === '') {
            Swal.fire('Atenção', 'Selecione um perfil para o usuário', 'warning');
            return;
        }

        let nomeVal = $('#nome').val().trim();
        if (!nomeVal) {
            Swal.fire('Atenção', 'O nome é obrigatório', 'warning');
            return;
        }

        let usernameVal = $('#username').val().trim();
        if (!usernameVal) {
            Swal.fire('Atenção', 'O username é obrigatório', 'warning');
            return;
        }

        let formData = new FormData();
        formData.append('id',       id);
        formData.append('nome',     nomeVal);
        formData.append('username', usernameVal);
        formData.append('email',    $('#email').val().trim());
        formData.append('telefone', $('#telefone').val().trim());
        formData.append('idPerfil', perfilVal);
        formData.append('estado',   $('#estado').val() || 'ATIVO');
        if (senha) formData.append('senha', senha);
        if (currentFotoData) formData.append('foto', currentFotoData);

        let btnSalvar = $(this).find('button[type="submit"]');
        btnSalvar.prop('disabled', true).text('Salvando...');

        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/usuarios/salvar',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(data) {
                btnSalvar.prop('disabled', false).text('Salvar');

                if (typeof data === 'string') {
                    try { data = JSON.parse(data); } catch(e) {
                        Swal.fire('Erro', 'Resposta inesperada do servidor', 'error');
                        return;
                    }
                }

                if (data.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalUsuario')).hide();
                    Swal.fire('Sucesso', 'Usuário salvo com sucesso!', 'success');
                    resetFormUsuario();
                    carregarUsuarios();
                } else {
                    Swal.fire('Erro', data.message || 'Erro ao salvar usuário', 'error');
                }
            },
            error: function(xhr, status, error) {
                btnSalvar.prop('disabled', false).text('Salvar');
                console.error('Erro HTTP ' + xhr.status + ':', xhr.responseText);
                let msg = 'Erro HTTP ' + xhr.status;
                try {
                    let resp = JSON.parse(xhr.responseText);
                    if (resp.message) msg = resp.message;
                } catch(e) {}
                Swal.fire('Erro', msg, 'error');
            }
        });
    });

    function resetFormUsuario() {
        $('#formUsuario')[0].reset();
        $('#editId').val('0');
        $('#senha').prop('required', true);
        $('#senhaRequired').html('*');
        $('#photoPreview').attr('src', getFotoPerfilPadrao(1));
        currentFotoData = '';
        $('#modalUsuario .modal-title').html('<i class="bi bi-person-plus"></i> Usuário');
    }

    // Upload de foto
    $('#photoInput').on('change', function(e) {
        let file = e.target.files[0];
        if (file) {
            let reader = new FileReader();
            reader.onload = function(event) {
                $('#photoPreview').attr('src', event.target.result);
                currentFotoData = event.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    function removerFoto() {
        let perfilId = parseInt($('#idPerfil').val()) || 1;
        $('#photoPreview').attr('src', getFotoPerfilPadrao(perfilId));
        currentFotoData = '';
    }

    // Filtros
    $('#searchInput').on('input', function() {
        currentSearch = $(this).val().toLowerCase();
        currentPage = 1;
        aplicarFiltros();
    });

    $('#perfilFilter').on('change', function() {
        currentPerfil = $(this).val();
        currentPage = 1;
        aplicarFiltros();
    });

    $('#statusFilter').on('change', function() {
        currentStatus = $(this).val();
        currentPage = 1;
        aplicarFiltros();
    });

    $('#modalUsuario').on('hidden.bs.modal', function() {
        resetFormUsuario();
    });

    // Relógio
    function updateClock() {
        let now = new Date();
        $('#horaAtual').text(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').text(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
        $('#anoAtual').text(now.getFullYear());
    }

    setInterval(updateClock, 1000);
    updateClock();

    // Inicialização
    carregarPerfis();
    carregarUsuarios();
</script>
</body>
</html>