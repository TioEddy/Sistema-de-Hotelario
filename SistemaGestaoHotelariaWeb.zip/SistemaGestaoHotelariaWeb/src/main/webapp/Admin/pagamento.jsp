<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamentos · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }
        .btn-danger-custom { background: #D9534F; border: none; padding: 6px 16px; border-radius: 30px; font-weight: 500; color: white; font-size: 0.75rem; }
        .btn-danger-custom:hover { background: #c9302c; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }

        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.7rem; font-weight: 500; }
        .badge-status.PAGO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.PARCIAL { background: #E3F2FD; color: #1976D2; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.edit { color: #FFB800; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #0B2B40; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2EAEF; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #FFB800; border-color: #FFB800; color: #0B2B40; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; opacity: 0.5; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2EAEF; padding: 10px 14px; }
        .form-control-readonly { background-color: #F0F4F8; cursor: not-allowed; }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .filters-bar { flex-direction: column; align-items: stretch; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-building"></i><div class="logo-text">Sistema Hotelaria<span>Gestão de Pagamentos</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-cash-stack"></i> Total Arrecadado</h4><div class="value" id="totalArrecadado">0 MZN</div></div>
        <div class="stat-card"><h4><i class="bi bi-hourglass-split"></i> Pendentes</h4><div class="value" id="totalPendente">0 MZN</div></div>
        <div class="stat-card"><h4><i class="bi bi-check-circle"></i> Pagamentos Hoje</h4><div class="value" id="pagamentosHoje">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-credit-card"></i> Ticket Médio</h4><div class="value" id="ticketMedio">0 MZN</div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por cliente, reserva ou referência..."></div>
        <div><select class="filter-select" id="estadoFilter"><option value="">Todos os estados</option><option value="PAGO">PAGO</option><option value="PENDENTE">PENDENTE</option><option value="PARCIAL">PARCIAL</option></select>
        <select class="filter-select" id="metodoFilter"><option value="">Todos os métodos</option></select></div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalPagamento"><i class="bi bi-plus-lg"></i> Novo Pagamento</button>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead><tr><th>Reserva</th><th>Cliente</th><th>Valor</th><th>Método</th><th>Referência</th><th>Data</th><th>Estado</th><th>Ações</th></tr></thead>
                <tbody id="pagamentosTableBody"><tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr></tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Novo Pagamento -->
<div class="modal fade modal-custom" id="modalPagamento" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-cash"></i> Registrar Pagamento</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formPagamento">
                    <input type="hidden" id="editId" value="">
                    <div class="mb-3"><label class="form-label">Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaPagamento" required><option value="">Selecione a reserva</option></select>
                    </div>
                    <div class="mb-3"><label class="form-label">Valor do Pagamento <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-readonly" id="valorPagamento" readonly placeholder="0.00">
                    </div>
                    <div class="mb-3"><label class="form-label">Método de Pagamento <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="metodoPagamento" required><option value="">Selecione</option></select>
                    </div>
                    <div class="mb-3"><label class="form-label">Referência (opcional)</label>
                        <input type="text" class="form-control form-control-custom" id="referenciaPagamento" placeholder="Nº transação, comprovativo...">
                    </div>
                    <div class="mb-3" id="infoReserva" style="background:#F0F4F8; padding:10px; border-radius:12px; display:none;">
                        <small><i class="bi bi-info-circle"></i> <span id="infoReservaTexto"></span></small>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Registrar Pagamento</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Pagamento -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Pagamento</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Reserva:</div><div class="detail-value" id="detReserva">-</div></div>
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="detCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="detQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Valor:</div><div class="detail-value" id="detValor">-</div></div>
                <div class="detail-row"><div class="detail-label">Método:</div><div class="detail-value" id="detMetodo">-</div></div>
                <div class="detail-row"><div class="detail-label">Referência:</div><div class="detail-value" id="detReferencia">-</div></div>
                <div class="detail-row"><div class="detail-label">Data:</div><div class="detail-value" id="detData">-</div></div>
                <div class="detail-row"><div class="detail-label">Estado:</div><div class="detail-value" id="detEstado">-</div></div>
            </div>
            <div class="modal-footer" style="border:none;padding:16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 5, currentFilter = "", currentEstadoFilter = "", currentMetodoFilter = "";
    let todosPagamentos = [], metodosList = [];

    function formatDateTime(dt) { if (!dt) return ""; return dt; }
    function formatMoney(v) { return Number(v).toLocaleString('pt-MZ') + " MZN"; }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    function loadStats() {
        $.ajax({ url: contextPath + '/Admin/pagamentos/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalArrecadado').html(formatMoney(d.total_arrecadado || 0));
                $('#totalPendente').html(formatMoney(d.total_pendente || 0));
                $('#pagamentosHoje').text(d.pagamentos_hoje || 0);
                $('#ticketMedio').html(formatMoney(d.ticket_medio || 0));
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function loadMetodos() {
        $.ajax({ url: contextPath + '/Admin/pagamentos/metodos', method: 'GET', dataType: 'json',
            success: function(d) {
                metodosList = d;
                var selectFiltro = $('#metodoFilter');
                var selectModal = $('#metodoPagamento');
                selectFiltro.html('<option value="">Todos os métodos</option>');
                selectModal.html('<option value="">Selecione</option>');
                $.each(d, function(i, m) {
                    selectFiltro.append('<option value="' + m.nome_metodo + '">' + m.nome_metodo + '</option>');
                    selectModal.append('<option value="' + m.id_metodo_pagamento + '">' + m.nome_metodo + '</option>');
                });
            }, error: function() { console.error('Erro ao carregar métodos'); }
        });
    }

    function loadReservas() {
        $.ajax({ url: contextPath + '/Admin/pagamentos/reservas', method: 'GET', dataType: 'json',
            success: function(d) {
                var select = $('#reservaPagamento');
                select.html('<option value="">Selecione a reserva</option>');
                $.each(d, function(i, r) {
                    var saldo = r.saldo_pendente > 0 ? r.saldo_pendente : r.valor_total;
                    var statusIcon = r.estado_reserva === 'CONFIRMADA' ? '✅' : (r.estado_reserva === 'PENDENTE' ? '⏳' : '✔️');
                    select.append('<option value="' + r.id_reserva + '" data-valor-total="' + r.valor_total + '" data-saldo="' + saldo + '" data-cliente="' + escapeHtml(r.cliente_nome) + '" data-quarto="' + escapeHtml(r.quarto) + '">' + statusIcon + ' #' + r.id_reserva + ' - ' + escapeHtml(r.cliente_nome) + ' - ' + escapeHtml(r.quarto) + ' - Total: ' + formatMoney(r.valor_total) + ' - Saldo: ' + formatMoney(saldo) + '</option>');
                });
            }, error: function() { console.error('Erro ao carregar reservas'); }
        });
    }

    function loadPagamentos() {
        $.ajax({ url: contextPath + '/Admin/pagamentos/listar', method: 'GET', dataType: 'json',
            success: function(d) { todosPagamentos = d; aplicarFiltros(); },
            error: function() { $('#pagamentosTableBody').html('<tr><td colspan="8" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function aplicarFiltros() {
        var filtrados = todosPagamentos.filter(function(p) {
            var matchSearch = !currentFilter || (p.cliente_nome && p.cliente_nome.toLowerCase().includes(currentFilter)) || (p.id_reserva && p.id_reserva.toString().includes(currentFilter));
            var matchEstado = !currentEstadoFilter || p.estado_pagamento === currentEstadoFilter;
            var matchMetodo = !currentMetodoFilter || p.metodo === currentMetodoFilter;
            return matchSearch && matchEstado && matchMetodo;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
    }

    function renderizarTabela(pagamentos) {
        var tbody = $('#pagamentosTableBody');
        tbody.empty();
        if (pagamentos.length === 0) { tbody.html('<tr><td colspan="8" class="text-center py-4">Nenhum pagamento encontrado</td></tr>'); return; }
        $.each(pagamentos, function(i, p) {
            tbody.append('<tr>' +
                '<td><span class="badge bg-secondary">#' + p.id_reserva + '</span></td>' +
                '<td><strong>' + escapeHtml(p.cliente_nome) + '</strong></td>' +
                '<td><strong>' + formatMoney(p.valor) + '</strong></td>' +
                '<td>' + escapeHtml(p.metodo) + '</td>' +
                '<td>' + (p.referencia && p.referencia !== '-' ? escapeHtml(p.referencia) : '-') + '</td>' +
                '<td>' + p.data_pagamento + '</td>' +
                '<td><span class="badge-status ' + p.estado_pagamento + '">' + p.estado_pagamento + '</span></td>' +
                '<td class="action-buttons"><button class="action-btn view" data-id="' + p.id_pagamento + '"><i class="bi bi-eye"></i></button></td>' +
            '</tr>');
        });
        $('.action-btn.view').off('click').on('click', function() { verDetalhes($(this).data('id')); });
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); return false; }

    $('#reservaPagamento').on('change', function() {
        var selected = $(this).find('option:selected');
        var saldo = selected.data('saldo');
        var valorTotal = selected.data('valor-total');
        if (saldo !== undefined) {
            $('#infoReserva').show();
            $('#infoReservaTexto').html('Valor total da reserva: ' + formatMoney(valorTotal) + ' | Saldo pendente: ' + formatMoney(saldo));
            $('#valorPagamento').val(formatMoney(saldo > 0 ? saldo : valorTotal));
        } else {
            $('#infoReserva').hide();
        }
    });

    function verDetalhes(id) {
        var p = todosPagamentos.find(function(pag) { return pag.id_pagamento === id; });
        if (p) {
            $('#detReserva').html('#' + p.id_reserva);
            $('#detCliente').html(escapeHtml(p.cliente_nome));
            $('#detQuarto').html(escapeHtml(p.quarto_num));
            $('#detValor').html(formatMoney(p.valor));
            $('#detMetodo').html(escapeHtml(p.metodo));
            $('#detReferencia').html(p.referencia && p.referencia !== '-' ? escapeHtml(p.referencia) : '-');
            $('#detData').html(p.data_pagamento);
            $('#detEstado').html('<span class="badge-status ' + p.estado_pagamento + '">' + p.estado_pagamento + '</span>');
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        } else { showAlert('error', 'Pagamento não encontrado!'); }
    }

    $('#formPagamento').on('submit', function(e) {
        e.preventDefault();
        var idReserva = $('#reservaPagamento').val();
        var valorText = $('#valorPagamento').val();
        var valor = parseFloat(valorText.replace(' MZN', '').replace(/\./g, '').replace(',', '.'));
        var idMetodo = $('#metodoPagamento').val();

        if (!idReserva || !valor || valor <= 0 || !idMetodo) {
            showAlert('warning', 'Preencha os campos obrigatórios!');
            return;
        }

        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Salvando...');

        $.ajax({ url: contextPath + '/Admin/pagamentos/salvar', method: 'POST',
            data: { id: $('#editId').val(), id_reserva: idReserva, valor: valor, id_metodo_pagamento: idMetodo, referencia: $('#referenciaPagamento').val(), estado_pagamento: 'PAGO' },
            dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Registrar Pagamento');
                if (r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalPagamento')).hide();
                    $('#formPagamento')[0].reset();
                    $('#editId').val('');
                    $('#infoReserva').hide();
                    $('#modalPagamento .modal-title').html('<i class="bi bi-cash"></i> Registrar Pagamento');
                    loadPagamentos();
                    loadReservas();
                    showAlert('success', 'Pagamento registrado com sucesso!');
                } else showAlert('error', r.message || 'Erro ao salvar');
            }, error: function() { btn.prop('disabled', false).text('Registrar Pagamento'); showAlert('error', 'Erro ao salvar pagamento'); }
        });
    });

    $('#modalPagamento').on('hidden.bs.modal', function() {
        $('#formPagamento')[0].reset();
        $('#editId').val('');
        $('#infoReserva').hide();
        $('#modalPagamento .modal-title').html('<i class="bi bi-cash"></i> Registrar Pagamento');
    });

    $('#searchInput').on('input', function() { currentFilter = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });
    $('#estadoFilter').on('change', function() { currentEstadoFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });
    $('#metodoFilter').on('change', function() { currentMetodoFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    loadMetodos();
    loadReservas();
    loadPagamentos();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>