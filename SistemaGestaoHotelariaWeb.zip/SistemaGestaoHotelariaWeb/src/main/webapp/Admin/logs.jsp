<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs do Sistema · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>

    <!-- jsPDF para PDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }

        .badge-acao { padding: 4px 12px; border-radius: 30px; font-size: 0.7rem; font-weight: 500; }
        .badge-acao.LOGIN { background: #E8F5E9; color: #2E7D32; }
        .badge-acao.LOGOUT { background: #FFEBEE; color: #D9534F; }
        .badge-acao.CREATE { background: #E3F2FD; color: #1976D2; }
        .badge-acao.UPDATE { background: #FFF8E1; color: #F57C00; }
        .badge-acao.DELETE { background: #FFEBEE; color: #D9534F; }
        .badge-acao.VIEW { background: #F3E5F5; color: #7B1FA2; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #0B2B40; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2EAEF; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #FFB800; border-color: #FFB800; color: #0B2B40; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; opacity: 0.5; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }

        .export-buttons { display: flex; gap: 10px; }
        .btn-export { background: transparent; border: 1px solid #E2EAEF; padding: 6px 12px; border-radius: 30px; font-size: 0.75rem; transition: all 0.2s; }
        .btn-export:hover { border-color: #FFB800; color: #FFB800; background: #FFF8E1; }
        .btn-export-pdf { border-color: #D9534F; color: #D9534F; }
        .btn-export-pdf:hover { background: #FFEBEE; border-color: #D9534F; color: #D9534F; }
        .btn-export-csv { border-color: #2E7D32; color: #2E7D32; }
        .btn-export-csv:hover { background: #E8F5E9; border-color: #2E7D32; color: #2E7D32; }

        @media print {
            .sidebar, .topbar, .filters-bar, .pagination, .footer, .action-buttons, .btn, .stats-grid { display: none !important; }
            .main-wrapper { margin-left: 0 !important; padding: 0 !important; }
            .table-container { box-shadow: none; border: none; padding: 0; }
            body { background: white; overflow: visible; }
        }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .filters-bar { flex-direction: column; align-items: stretch; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-building"></i><div class="logo-text">Sistema Hotelaria<span>Logs do Sistema</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-journal-text"></i> Total Logs</h4><div class="value" id="totalLogs">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-box-arrow-in-right"></i> Logins Hoje</h4><div class="value" id="loginsHoje">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-pencil"></i> Alterações (7d)</h4><div class="value" id="alteracoesSemana">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-people"></i> Usuários Ativos</h4><div class="value" id="usuariosAtivos">0</div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por usuário, ação ou tabela..."></div>
        <div>
            <select class="filter-select" id="acaoFilter"><option value="">Todas as ações</option><option value="LOGIN">LOGIN</option><option value="LOGOUT">LOGOUT</option><option value="CREATE">CREATE</option><option value="UPDATE">UPDATE</option><option value="DELETE">DELETE</option><option value="VIEW">VIEW</option></select>
            <select class="filter-select" id="tabelaFilter"><option value="">Todas as tabelas</option></select>
            <input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por data" style="width: 130px;">
        </div>
        <div class="export-buttons">
            <button class="btn-export btn-export-pdf" onclick="exportLogsPDF()"><i class="bi bi-filetype-pdf"></i> PDF</button>
            <button class="btn-export btn-export-csv" onclick="exportLogsCSV()"><i class="bi bi-filetype-csv"></i> CSV</button>
            <button class="btn-export" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir</button>
        </div>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr><th>Data/Hora</th><th>Usuário</th><th>Ação</th><th>Tabela</th><th>ID Registro</th><th>Descrição</th><th>IP</th><th>Ações</th></tr>
                </thead>
                <tbody id="logsTableBody"><tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr></tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Detalhes do Log -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Log</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Data/Hora:</div><div class="detail-value" id="detData">-</div></div>
                <div class="detail-row"><div class="detail-label">Usuário:</div><div class="detail-value" id="detUsuario">-</div></div>
                <div class="detail-row"><div class="detail-label">Ação:</div><div class="detail-value" id="detAcao">-</div></div>
                <div class="detail-row"><div class="detail-label">Tabela:</div><div class="detail-value" id="detTabela">-</div></div>
                <div class="detail-row"><div class="detail-label">ID Registro:</div><div class="detail-value" id="detIdRegistro">-</div></div>
                <div class="detail-row"><div class="detail-label">Descrição:</div><div class="detail-value" id="detDescricao">-</div></div>
                <div class="detail-row"><div class="detail-label">Endereço IP:</div><div class="detail-value" id="detIp">-</div></div>
                <div class="detail-row"><div class="detail-label">Navegador:</div><div class="detail-value" id="detNavegador">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 6, currentFilter = "", currentAcaoFilter = "", currentTabelaFilter = "", currentDateFilter = "";
    let todosLogs = [], tabelasLista = [];

    function formatDateTime(dateTimeStr) { if (!dateTimeStr) return "-"; return dateTimeStr.replace('T', ' ').substring(0, 16); }
    function formatMoney(v) { if (v === undefined || v === null || isNaN(v)) return "0 MZN"; return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN"; }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    function getAcaoIcon(acao) {
        switch(acao) {
            case 'LOGIN': return '<i class="bi bi-box-arrow-in-right"></i>';
            case 'LOGOUT': return '<i class="bi bi-box-arrow-right"></i>';
            case 'CREATE': return '<i class="bi bi-plus-circle"></i>';
            case 'UPDATE': return '<i class="bi bi-pencil-square"></i>';
            case 'DELETE': return '<i class="bi bi-trash"></i>';
            case 'VIEW': return '<i class="bi bi-eye"></i>';
            default: return '<i class="bi bi-record-circle"></i>';
        }
    }

    function loadStats() {
        $.ajax({ url: contextPath + '/Admin/logs/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalLogs').text(d.total || 0);
                $('#loginsHoje').text(d.logins_hoje || 0);
                $('#alteracoesSemana').text(d.alteracoes_semana || 0);
                $('#usuariosAtivos').text(d.usuarios_ativos || 0);
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function carregarTabelas() {
        $.ajax({ url: contextPath + '/Admin/logs/tabelas', method: 'GET', dataType: 'json',
            success: function(d) {
                tabelasLista = d;
                var select = $('#tabelaFilter');
                select.html('<option value="">Todas as tabelas</option>');
                $.each(d, function(i, tabela) {
                    select.append('<option value="' + escapeHtml(tabela) + '">' + escapeHtml(tabela) + '</option>');
                });
            }, error: function() { console.error('Erro ao carregar tabelas'); }
        });
    }

    function loadLogs() {
        $.ajax({ url: contextPath + '/Admin/logs/listar', method: 'GET', dataType: 'json',
            success: function(d) { todosLogs = d; aplicarFiltros(); },
            error: function() { $('#logsTableBody').html('<tr><td colspan="8" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function aplicarFiltros() {
        var filtrados = todosLogs.filter(function(l) {
            var matchSearch = !currentFilter ||
                (l.usuario_nome && l.usuario_nome.toLowerCase().includes(currentFilter)) ||
                (l.acao && l.acao.toLowerCase().includes(currentFilter)) ||
                (l.tabela_afetada && l.tabela_afetada.toLowerCase().includes(currentFilter)) ||
                (l.descricao && l.descricao.toLowerCase().includes(currentFilter));
            var matchAcao = !currentAcaoFilter || l.acao === currentAcaoFilter;
            var matchTabela = !currentTabelaFilter || l.tabela_afetada === currentTabelaFilter;
            var matchDate = !currentDateFilter || (l.data_log && l.data_log.split('T')[0] === currentDateFilter);
            return matchSearch && matchAcao && matchTabela && matchDate;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
    }

    function renderizarTabela(logs) {
        var tbody = $('#logsTableBody');
        tbody.empty();
        if (logs.length === 0) { tbody.html('<tr><td colspan="8" class="text-center py-4">Nenhum log encontrado</td></tr>'); return; }
        $.each(logs, function(i, l) {
            tbody.append('<tr>' +
                '<td>' + formatDateTime(l.data_log) + '</td>' +
                '<td><strong>' + escapeHtml(l.usuario_nome) + '</strong></td>' +
                '<td><span class="badge-acao ' + l.acao + '">' + getAcaoIcon(l.acao) + ' ' + l.acao + '</span></td>' +
                '<td>' + (l.tabela_afetada || '-') + '</td>' +
                '<td>' + (l.id_registro || '-') + '</td>' +
                '<td style="max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="' + escapeHtml(l.descricao || '') + '">' + (l.descricao || '-') + '</td>' +
                '<td>' + (l.endereco_ip || '-') + '</td>' +
                '<td class="action-buttons"><button class="action-btn view" data-id="' + l.id_log + '" title="Detalhes"><i class="bi bi-eye"></i></button></td>' +
            '</td>');
        });
        $('.action-btn.view').off('click').on('click', function() { viewLog($(this).data('id')); });
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); return false; }

    function viewLog(id) {
        var l = todosLogs.find(function(log) { return log.id_log === id; });
        if (l) {
            $('#detData').text(formatDateTime(l.data_log));
            $('#detUsuario').html('<strong>' + escapeHtml(l.usuario_nome) + '</strong>');
            $('#detAcao').html('<span class="badge-acao ' + l.acao + '">' + l.acao + '</span>');
            $('#detTabela').text(l.tabela_afetada || '-');
            $('#detIdRegistro').text(l.id_registro || '-');
            $('#detDescricao').text(l.descricao || '-');
            $('#detIp').text(l.endereco_ip || '-');
            $('#detNavegador').text(l.navegador || '-');
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        }
    }

    function exportLogsCSV() {
        var filtrados = todosLogs.filter(function(l) {
            var matchAcao = !currentAcaoFilter || l.acao === currentAcaoFilter;
            var matchTabela = !currentTabelaFilter || l.tabela_afetada === currentTabelaFilter;
            var matchDate = !currentDateFilter || (l.data_log && l.data_log.split('T')[0] === currentDateFilter);
            return matchAcao && matchTabela && matchDate;
        });
        var headers = ['Data', 'Usuario', 'Acao', 'Tabela', 'ID_Registro', 'Descricao', 'IP', 'Navegador'];
        var csvRows = [headers.join(',')];
        for (var i = 0; i < filtrados.length; i++) {
            var log = filtrados[i];
            csvRows.push([
                '"' + formatDateTime(log.data_log) + '"',
                '"' + (log.usuario_nome || '') + '"',
                '"' + (log.acao || '') + '"',
                '"' + (log.tabela_afetada || '') + '"',
                '"' + (log.id_registro || '') + '"',
                '"' + ((log.descricao || '').replace(/"/g, '""')) + '"',
                '"' + (log.endereco_ip || '') + '"',
                '"' + (log.navegador || '') + '"'
            ].join(','));
        }
        var blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'logs_sistema_' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        showAlert('success', 'Logs exportados para CSV com sucesso!');
    }

    function exportLogsPDF() {
        var filtrados = todosLogs.filter(function(l) {
            var matchAcao = !currentAcaoFilter || l.acao === currentAcaoFilter;
            var matchTabela = !currentTabelaFilter || l.tabela_afetada === currentTabelaFilter;
            var matchDate = !currentDateFilter || (l.data_log && l.data_log.split('T')[0] === currentDateFilter);
            return matchAcao && matchTabela && matchDate;
        });
        var now = new Date();
        var dataAtual = now.toLocaleDateString('pt-PT') + ' ' + now.toLocaleTimeString('pt-PT');
        var { jsPDF } = window.jspdf;
        var doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
        doc.setFontSize(16);
        doc.setTextColor(11, 43, 64);
        doc.text('Sistema Hotelaria - Relatório de Logs', 20, 20);
        doc.setFontSize(10);
        doc.setTextColor(108, 141, 156);
        doc.text('Emitido em: ' + dataAtual, 20, 30);
        doc.text('Total de registros: ' + filtrados.length, 20, 37);
        var tableData = [];
        for (var i = 0; i < filtrados.length; i++) {
            var log = filtrados[i];
            tableData.push([
                formatDateTime(log.data_log),
                log.usuario_nome || '-',
                log.acao || '-',
                log.tabela_afetada || '-',
                log.id_registro || '-',
                (log.descricao || '-').substring(0, 60),
                log.endereco_ip || '-',
                log.navegador || '-'
            ]);
        }
        doc.autoTable({
            head: [['Data/Hora', 'Usuário', 'Ação', 'Tabela', 'ID', 'Descrição', 'IP', 'Navegador']],
            body: tableData,
            startY: 45,
            margin: { top: 45, left: 15, right: 15, bottom: 15 },
            theme: 'striped',
            headStyles: { fillColor: [11, 43, 64], textColor: [255, 184, 0], fontStyle: 'bold' },
            alternateRowStyles: { fillColor: [240, 244, 248] },
            styles: { fontSize: 8, cellPadding: 2 },
            columnStyles: { 0: { cellWidth: 30 }, 1: { cellWidth: 30 }, 2: { cellWidth: 25 }, 3: { cellWidth: 25 }, 4: { cellWidth: 15 }, 5: { cellWidth: 55 }, 6: { cellWidth: 25 }, 7: { cellWidth: 35 } }
        });
        var pageCount = doc.internal.getNumberOfPages();
        for (var i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.setTextColor(150, 150, 150);
            doc.text('Página ' + i + ' de ' + pageCount, doc.internal.pageSize.getWidth() - 30, doc.internal.pageSize.getHeight() - 10);
            doc.text('Hotelaria Systems - Todos os direitos reservados', 20, doc.internal.pageSize.getHeight() - 10);
        }
        doc.save('logs_sistema_' + new Date().toISOString().split('T')[0] + '.pdf');
        showAlert('success', 'Logs exportados para PDF com sucesso!');
    }

    $('#searchInput').on('input', function() { currentFilter = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });
    $('#acaoFilter').on('change', function() { currentAcaoFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });
    $('#tabelaFilter').on('change', function() { currentTabelaFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });

    flatpickr("#dateFilter", { dateFormat: "Y-m-d", locale: "pt", onChange: function(selectedDates, dateStr) { currentDateFilter = dateStr; currentPage = 1; aplicarFiltros(); } });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    carregarTabelas();
    loadLogs();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>