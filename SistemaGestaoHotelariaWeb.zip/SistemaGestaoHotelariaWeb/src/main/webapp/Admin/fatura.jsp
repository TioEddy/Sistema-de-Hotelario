<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faturas · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }
        .btn-success-custom { background: #2E7D32; border: none; padding: 8px 20px; border-radius: 30px; font-weight: 500; color: white; }
        .btn-success-custom:hover { background: #1B5E20; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.pdf { color: #D9534F; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #0B2B40; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2EAEF; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #FFB800; border-color: #FFB800; color: #0B2B40; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; opacity: 0.5; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2EAEF; padding: 10px 14px; }
        .form-control-readonly { background-color: #F0F4F8; cursor: not-allowed; }

        @media print {
            .sidebar, .topbar, .filters-bar, .pagination, .footer, .action-buttons, .btn, .modal { display: none !important; }
            .main-wrapper { margin-left: 0 !important; padding: 0 !important; }
            .table-container { box-shadow: none; border: none; }
        }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .filters-bar { flex-direction: column; align-items: stretch; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }

        .badge-secondary { background-color: #6c757d; }
        .badge-warning { background-color: #ffc107; color: #000; }
        .text-warning { color: #FFB800 !important; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-building"></i><div class="logo-text">Sistema Hotelaria<span>Gestão de Faturas</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-receipt"></i> Total Faturas</h4><div class="value" id="totalFaturas">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-cash-stack"></i> Faturamento Total</h4><div class="value" id="faturamentoTotal">0 MZN</div></div>
        <div class="stat-card"><h4><i class="bi bi-calendar"></i> Este Mês</h4><div class="value" id="faturasMes">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-graph-up"></i> Ticket Médio</h4><div class="value" id="ticketMedio">0 MZN</div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por cliente, nº fatura ou reserva..."></div>
        <div><input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por data" style="width: 150px;"></div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalFatura"><i class="bi bi-plus-lg"></i> Nova Fatura</button>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nº Fatura</th>
                        <th>Cliente</th>
                        <th>Reserva</th>
                        <th>Subtotal</th>
                        <th>IVA (16%)</th>
                        <th>Total</th>
                        <th>Data Emissão</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="faturasTableBody">
                    <tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Nova Fatura -->
<div class="modal fade modal-custom" id="modalFatura" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-receipt"></i> Emitir Fatura</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formFatura">
                    <div class="mb-3"><label class="form-label">Selecione a Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaFatura" required>
                            <option value="">Carregando reservas...</option>
                        </select>
                    </div>
                    <div class="mb-3"><label class="form-label">Subtotal (sem IVA)</label>
                        <input type="text" class="form-control form-control-readonly" id="subtotalFatura" readonly>
                    </div>
                    <div class="mb-3"><label class="form-label">IVA (16%)</label>
                        <input type="text" class="form-control form-control-readonly" id="ivaFatura" readonly>
                    </div>
                    <div class="mb-3"><label class="form-label">Total a Pagar</label>
                        <input type="text" class="form-control form-control-readonly" id="totalFatura" readonly style="font-weight: bold; background: #FFF8E1;">
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Emitir Fatura</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Visualizar Fatura -->
<div class="modal fade modal-custom" id="modalVisualizarFatura" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-receipt"></i> Fatura #<span id="faturaNumeroModal">-</span></h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4" id="faturaPrintContent">
                <div style="text-align: center; margin-bottom: 30px;">
                    <i class="bi bi-building" style="font-size: 2rem; color: #FFB800;"></i>
                    <h2 style="margin: 10px 0 5px; color: #0B2B40;">Hotelaria Systems</h2>
                    <p style="color: #6C8D9C; margin: 0;">Av. Marginal, 1234 - Maputo | Tel: +258 84 123 4567</p>
                    <p style="color: #6C8D9C;">NUIT: 123456789 | Email: facturacao@hotelaria.co.mz</p>
                    <hr style="border-top: 2px solid #FFB800; width: 100px;">
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
                    <div><strong>FATURA Nº:</strong> <span id="printNumero">-</span><br><strong>Data Emissão:</strong> <span id="printData">-</span></div>
                    <div><strong>Cliente:</strong> <span id="printCliente">-</span><br><strong>Reserva:</strong> <span id="printReserva">-</span><br><strong>Quarto:</strong> <span id="printQuarto">-</span></div>
                </div>
                <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                    <thead>
                        <tr style="background: #F0F4F8; border-bottom: 2px solid #FFB800;">
                            <th style="padding: 10px; text-align: left;">Descrição</th>
                            <th style="padding: 10px; text-align: right;">Valor (MZN)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td style="padding: 10px;">Hospedagem - Diárias</td><td style="padding: 10px; text-align: right;"><span id="printSubtotal">-</span></td></tr>
                        <tr style="border-top: 1px solid #E2EAEF;"><td style="padding: 10px;">IVA (16%)</td><td style="padding: 10px; text-align: right;"><span id="printIva">-</span></td></tr>
                        <tr style="border-top: 2px solid #FFB800; background: #FFF8E1;"><td style="padding: 10px;"><strong>TOTAL</strong></td><td style="padding: 10px; text-align: right;"><strong id="printTotal">-</strong></td></tr>
                    </tbody>
                </table>
                <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px dashed #E2EAEF;">
                    <p style="color: #6C8D9C; font-size: 0.8rem;">Obrigado pela preferência! · Pagamento confirmado via sistema</p>
                </div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px; justify-content: center; gap: 12px;">
                <button class="btn-success-custom" id="printFaturaBtn"><i class="bi bi-printer"></i> Imprimir / Salvar PDF</button>
                <button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1;
    let rowsPerPage = 5;
    let currentFilter = "";
    let currentDateFilter = "";
    let todasFaturas = [];

    // Funções auxiliares
    function formatDateTime(dt) {
        if (!dt) return "-";
        return dt;
    }

    function formatMoney(v) {
        if (v === undefined || v === null || isNaN(v)) return "0 MZN";
        return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " MZN";
    }

    function escapeHtml(s) {
        if (!s) return "";
        return s.replace(/[&<>]/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m;
        });
    }

    function showAlert(type, msg) {
        Swal.fire({
            icon: type,
            title: type === 'success' ? 'Sucesso' : (type === 'error' ? 'Erro' : 'Atenção'),
            text: msg,
            timer: 3000,
            showConfirmButton: false
        });
    }

    function loadStats() {
        $.ajax({
            url: contextPath + '/Admin/faturas/stats',
            method: 'GET',
            dataType: 'json',
            success: function(d) {
                $('#totalFaturas').text(d.total || 0);
                $('#faturamentoTotal').html(formatMoney(d.faturamento_total || 0));
                $('#faturasMes').text(d.faturas_mes || 0);
                $('#ticketMedio').html(formatMoney(d.ticket_medio || 0));
            },
            error: function() {
                console.error('Erro ao carregar stats');
            }
        });
    }

    function loadReservas() {
        $.ajax({
            url: contextPath + '/Admin/faturas/reservas',
            method: 'GET',
            dataType: 'json',
            success: function(d) {
                var select = $('#reservaFatura');
                select.html('<option value="">Selecione uma reserva</option>');
                if (d.length === 0) {
                    select.html('<option value="">Nenhuma reserva disponível para faturamento</option>');
                } else {
                    $.each(d, function(i, r) {
                        var statusIcon = r.estado_reserva === 'CONFIRMADA' ? '✅' : '✔️';
                        select.append('<option value="' + r.id_reserva + '" data-valor="' + r.valor_total + '" data-cliente="' + escapeHtml(r.cliente_nome) + '" data-quarto="' + escapeHtml(r.quarto) + '">' +
                            statusIcon + ' #' + r.id_reserva + ' - ' + escapeHtml(r.cliente_nome) + ' - ' + escapeHtml(r.quarto) + ' - ' + formatMoney(r.valor_total) +
                            ' (' + r.dias + ' diárias)' +
                        '</option>');
                    });
                }
            },
            error: function() {
                console.error('Erro ao carregar reservas');
                $('#reservaFatura').html('<option value="">Erro ao carregar reservas</option>');
            }
        });
    }

    function loadFaturas() {
        $.ajax({
            url: contextPath + '/Admin/faturas/listar',
            method: 'GET',
            dataType: 'json',
            success: function(d) {
                todasFaturas = d;
                aplicarFiltros();
            },
            error: function() {
                $('#faturasTableBody').html('<td><td colspan="8" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
            }
        });
    }

    function aplicarFiltros() {
        var filtrados = todasFaturas.filter(function(f) {
            var matchSearch = !currentFilter ||
                (f.cliente_nome && f.cliente_nome.toLowerCase().includes(currentFilter)) ||
                (f.numero_fatura && f.numero_fatura.toLowerCase().includes(currentFilter));

            var matchDate = !currentDateFilter;
            if (!matchDate && f.data_emissao_timestamp) {
                var dataFatura = new Date(f.data_emissao_timestamp);
                var dataFaturaStr = dataFatura.getFullYear() + '-' +
                    String(dataFatura.getMonth() + 1).padStart(2, '0') + '-' +
                    String(dataFatura.getDate()).padStart(2, '0');
                matchDate = dataFaturaStr === currentDateFilter;
            }
            return matchSearch && matchDate;
        });

        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
    }

    function renderizarTabela(faturas) {
        var tbody = $('#faturasTableBody');
        tbody.empty();
        if (faturas.length === 0) {
            tbody.html('<tr><td colspan="8" class="text-center py-4">Nenhuma fatura encontrada</td></tr>');
            return;
        }
        $.each(faturas, function(i, f) {
            tbody.append(
                '<tr>' +
                    '<td><strong>' + escapeHtml(f.numero_fatura) + '</strong></td>' +
                    '<td>' + escapeHtml(f.cliente_nome) + '</td>' +
                    '<td><span class="badge bg-secondary">#' + f.id_reserva + '</span></td>' +
                    '<td>' + formatMoney(f.subtotal) + '</td>' +
                    '<td>' + formatMoney(f.iva) + '</td>' +
                    '<td><strong>' + formatMoney(f.total) + '</strong></td>' +
                    '<td>' + f.data_emissao + '</td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn pdf" data-id="' + f.id_fatura + '" title="Baixar PDF"><i class="bi bi-file-pdf"></i></button>' +
                        '<button class="action-btn view" data-id="' + f.id_fatura + '" title="Visualizar"><i class="bi bi-eye"></i></button>' +
                    '</td>' +
                '</tr>'
            );
        });

        $('.action-btn.pdf').off('click').on('click', function() {
            downloadFaturaPDF($(this).data('id'));
        });
        $('.action-btn.view').off('click').on('click', function() {
            viewFatura($(this).data('id'));
        });
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        }

        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }

        if (currentPage < totalPages) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        }
        $('#pagination').html(html);
    }

    function mudarPagina(page) {
        currentPage = page;
        aplicarFiltros();
        return false;
    }

    // Eventos do formulário
    $('#reservaFatura').on('change', function() {
        var selected = $(this).find('option:selected');
        var valor = parseFloat(selected.data('valor')) || 0;
        var iva = valor * 0.16;
        var total = valor + iva;
        $('#subtotalFatura').val(formatMoney(valor));
        $('#ivaFatura').val(formatMoney(iva));
        $('#totalFatura').val(formatMoney(total));
    });

    function viewFatura(id) {
        var f = todasFaturas.find(function(fat) { return fat.id_fatura === id; });
        if (f) {
            $('#faturaNumeroModal').text(f.numero_fatura);
            $('#printNumero').text(f.numero_fatura);
            $('#printData').text(f.data_emissao);
            $('#printCliente').text(f.cliente_nome);
            $('#printReserva').text('#' + f.id_reserva);
            $('#printQuarto').text(f.quarto);
            $('#printSubtotal').text(formatMoney(f.subtotal));
            $('#printIva').text(formatMoney(f.iva));
            $('#printTotal').text(formatMoney(f.total));
            new bootstrap.Modal(document.getElementById('modalVisualizarFatura')).show();
        } else {
            showAlert('error', 'Fatura não encontrada!');
        }
    }

    // ==================== FUNÇÃO PARA BAIXAR PDF DIRETAMENTE ====================
    function downloadFaturaPDF(id) {
        // Abre o PDF diretamente do servidor
        window.open(contextPath + '/Admin/faturas/pdf?id=' + id, '_blank');
    }

    // ==================== FUNÇÃO PARA IMPRIMIR (a partir do modal) ====================
    $('#printFaturaBtn').on('click', function() {
        var idFatura = null;
        // Tenta encontrar o ID da fatura atual
        for (var i = 0; i < todasFaturas.length; i++) {
            if (todasFaturas[i].numero_fatura === $('#faturaNumeroModal').text()) {
                idFatura = todasFaturas[i].id_fatura;
                break;
            }
        }

        if (idFatura) {
            // Abre o PDF em nova aba para impressão
            window.open(contextPath + '/Admin/faturas/pdf?id=' + idFatura, '_blank');
        } else {
            // Fallback: usa o método de impressão via HTML
            var printContent = document.getElementById('faturaPrintContent').cloneNode(true);
            var win = window.open('', '_blank');
            win.document.write('<!DOCTYPE html><html><head><title>Fatura_' + $('#faturaNumeroModal').text() + '</title>' +
                '<style>' +
                'body{font-family:"Segoe UI",sans-serif;padding:40px;margin:0;}' +
                'table{width:100%;border-collapse:collapse;margin:20px 0;}' +
                'th,td{padding:10px;text-align:left;}' +
                'th{background:#F0F4F8;border-bottom:2px solid #FFB800;}' +
                '.text-right{text-align:right;}' +
                '.total-row{background:#FFF8E1;border-top:2px solid #FFB800;font-weight:bold;}' +
                '.header{text-align:center;margin-bottom:30px;}' +
                '.header h2{color:#0B2B40;margin:10px 0 5px;}' +
                '.header p{color:#6C8D9C;margin:0;}' +
                '.info{display:flex;justify-content:space-between;margin-bottom:30px;}' +
                '.footer{text-align:center;margin-top:40px;padding-top:20px;border-top:1px dashed #ccc;color:#6C8D9C;}' +
                '@media print{' +
                '  body{margin:0;padding:0;}' +
                '}' +
                '</style>' +
                '</head><body>');
            win.document.write(printContent.outerHTML);
            win.document.write('</body></html>');
            win.document.close();
            win.print();
        }
    });

    $('#formFatura').on('submit', function(e) {
        e.preventDefault();
        var idReserva = $('#reservaFatura').val();
        if (!idReserva) {
            showAlert('warning', 'Selecione uma reserva!');
            return;
        }

        // Parse do valor total - CORRIGIDO
        var totalText = $('#totalFatura').val();
        var valorTotal = parseFloat(totalText.replace(/[^\d,.-]/g, '').replace(',', '.'));

        if (isNaN(valorTotal) || valorTotal <= 0) {
            showAlert('error', 'Erro ao calcular o valor total da fatura');
            return;
        }

        var subtotal = valorTotal / 1.16;
        var iva = valorTotal - subtotal;

        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Emitindo...');

        $.ajax({
            url: contextPath + '/Admin/faturas/emitir',
            method: 'POST',
            data: {
                id_reserva: idReserva,
                subtotal: subtotal.toFixed(2),
                iva: iva.toFixed(2),
                total: valorTotal.toFixed(2)
            },
            dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Emitir Fatura');
                if (r.success) {
                    var modal = bootstrap.Modal.getInstance(document.getElementById('modalFatura'));
                    if (modal) modal.hide();
                    $('#formFatura')[0].reset();
                    $('#subtotalFatura').val('');
                    $('#ivaFatura').val('');
                    $('#totalFatura').val('');
                    loadFaturas();
                    loadReservas();
                    showAlert('success', 'Fatura ' + (r.numero_fatura || '') + ' emitida com sucesso!');
                } else {
                    showAlert('error', r.message || 'Erro ao emitir fatura');
                }
            },
            error: function(xhr, status, error) {
                btn.prop('disabled', false).text('Emitir Fatura');
                console.error('Erro:', error);
                console.error('Status:', status);
                console.error('Resposta:', xhr.responseText);
                showAlert('error', 'Erro ao emitir fatura: ' + (xhr.responseText || error));
            }
        });
    });

    $('#modalFatura').on('hidden.bs.modal', function() {
        $('#formFatura')[0].reset();
        $('#subtotalFatura').val('');
        $('#ivaFatura').val('');
        $('#totalFatura').val('');
    });

    $('#searchInput').on('input', function() {
        currentFilter = $(this).val().toLowerCase();
        currentPage = 1;
        aplicarFiltros();
    });

    // Inicializar flatpickr
    flatpickr("#dateFilter", {
        dateFormat: "Y-m-d",
        locale: "pt",
        onChange: function(selectedDates, dateStr) {
            currentDateFilter = dateStr;
            currentPage = 1;
            aplicarFiltros();
        },
        allowInput: true
    });

    // Atualizar relógio
    function updateClock() {
        var now = new Date();
        $('#horaAtual').html(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' }));
        $('#anoAtual').html(now.getFullYear());
    }

    setInterval(updateClock, 1000);
    updateClock();

    // Carregar dados iniciais
    loadReservas();
    loadFaturas();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>