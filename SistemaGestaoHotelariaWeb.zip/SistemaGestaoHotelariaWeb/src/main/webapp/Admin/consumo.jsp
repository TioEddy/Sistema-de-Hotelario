<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consumo de Serviços · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }
        .btn-danger-custom { background: #D9534F; border: none; padding: 6px 16px; border-radius: 30px; font-weight: 500; color: white; font-size: 0.75rem; }
        .btn-danger-custom:hover { background: #c9302c; }
        .btn-success-custom { background: #28a745; border: none; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: white; }
        .btn-success-custom:hover { background: #218838; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }
        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.edit { color: #FFB800; }
        .action-btn.view { color: #1976D2; }
        .action-btn.delete { color: #D9534F; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #0B2B40; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2EAEF; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #FFB800; border-color: #FFB800; color: #0B2B40; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; opacity: 0.5; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 120px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2EAEF; padding: 10px 14px; }
        .form-control-custom:focus, .form-select-custom:focus { border-color: #FFB800; box-shadow: 0 0 0 3px rgba(255,184,0,0.1); }

        .servico-item { background: #F8F9FA; border-radius: 12px; padding: 15px; margin-bottom: 15px; border: 1px solid #E2EAEF; }
        .servico-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .servico-header select { flex: 1; margin-right: 10px; }
        .servico-header input { width: 100px; }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .filters-bar { flex-direction: column; align-items: stretch; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr.jsp"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Sistema Hotelaria<span>Consumo de Serviços</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <!-- Cards Estatísticos -->
    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-cup-straw"></i> Total Consumos</h4><div class="value" id="totalConsumos">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-cash-stack"></i> Faturação Serviços</h4><div class="value" id="totalFaturado">0 MZN</div></div>
        <div class="stat-card"><h4><i class="bi bi-door-open"></i> Hóspedes Ativos</h4><div class="value" id="hospedesAtivos">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-trophy"></i> Serviço + Consumido</h4><div class="value" id="topServico" style="font-size: 1rem;">-</div></div>
    </div>

    <!-- Barra de Filtros -->
    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por hóspede ou serviço..."></div>
        <div>
            <select class="filter-select" id="servicoFilter">
                <option value="">Todos os serviços</option>
            </select>
        </div>
        <div>
            <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalConsumo"><i class="bi bi-plus-lg"></i> Novo Consumo</button>
            <button class="btn-success-custom" data-bs-toggle="modal" data-bs-target="#modalServicos"><i class="bi bi-plus-circle"></i> Novo Serviço</button>
        </div>
    </div>

    <!-- Tabela de Consumos -->
    <div class="table-container">
        <table class="table">
            <thead>
                <tr><th>Data/Hora</th><th>Hóspede</th><th>Quarto</th><th>Serviço</th><th>Quantidade</th><th>Subtotal</th><th>Ações</th></tr>
            </thead>
            <tbody id="consumosTableBody">
                <tr><td colspan="7" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
            </tbody>
        </table>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Adicionar Consumo -->
<div class="modal fade modal-custom" id="modalConsumo" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Adicionar Consumo</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formConsumoMultiplo">
                    <div class="mb-3">
                        <label class="form-label">Hóspede <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="clienteId" required>
                            <option value="">Selecione o hóspede</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Data/Hora do Consumo</label>
                        <input type="text" class="form-control form-control-custom" id="dataConsumoMultiplo" placeholder="Selecione a data e hora">
                    </div>

                    <hr>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <strong><i class="bi bi-cart-plus"></i> Serviços</strong>
                        <button type="button" class="btn btn-outline-custom btn-sm" id="addServicoBtn"><i class="bi bi-plus-lg"></i> Adicionar Serviço</button>
                    </div>

                    <div id="servicosContainer">
                        <div class="servico-item" data-index="0">
                            <div class="servico-header">
                                <select class="form-select servico-select" style="flex: 1;" required>
                                    <option value="">Selecione o serviço</option>
                                </select>
                                <input type="number" class="form-control quantidade-input" value="1" min="1" style="width: 100px; margin-left: 10px;" placeholder="Qtd">
                            </div>
                            <div class="small text-muted mt-2">
                                Preço: <span class="preco-display">0.00 MZN</span>
                            </div>
                            <button type="button" class="btn btn-sm btn-danger mt-2" onclick="$(this).closest('.servico-item').remove()"><i class="bi bi-trash"></i> Remover</button>
                        </div>
                    </div>

                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Registrar Consumos</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Gerenciar Serviços -->
<div class="modal fade modal-custom" id="modalServicos" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-grid"></i> Gerenciar Serviços</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formServico" class="mb-4">
                    <input type="hidden" id="editServicoId" value="">
                    <div class="row g-3">
                        <div class="col-md-5">
                            <input type="text" class="form-control form-control-custom" id="nomeServico" placeholder="Nome do serviço" required>
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control form-control-custom" id="descricaoServico" placeholder="Descrição (opcional)">
                        </div>
                        <div class="col-md-2">
                            <input type="number" step="0.01" class="form-control form-control-custom" id="precoServico" placeholder="Preço" required>
                        </div>
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-primary-custom w-100"><i class="bi bi-save"></i></button>
                        </div>
                    </div>
                </form>

                <hr>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr><th>Serviço</th><th>Descrição</th><th>Preço</th><th>Consumido</th><th>Ações</th></tr>
                        </thead>
                        <tbody id="servicosTableBody">
                            <tr><td colspan="5" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Consumo -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Consumo</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Data/Hora:</div><div class="detail-value" id="detData">-</div></div>
                <div class="detail-row"><div class="detail-label">Hóspede:</div><div class="detail-value" id="detHospede">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="detQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Serviço:</div><div class="detail-value" id="detServico">-</div></div>
                <div class="detail-row"><div class="detail-label">Quantidade:</div><div class="detail-value" id="detQuantidade">-</div></div>
                <div class="detail-row"><div class="detail-label">Preço Unit.:</div><div class="detail-value" id="detPreco">-</div></div>
                <div class="detail-row"><div class="detail-label">Subtotal:</div><div class="detail-value" id="detSubtotal">-</div></div>
                <div class="detail-row"><div class="detail-label">Registrado por:</div><div class="detail-value" id="detUsuario">-</div></div>
            </div>
            <div class="modal-footer" style="border:none;padding:16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 6, currentFilter = "", currentServicoFilter = "";
    let todosConsumos = [], servicosList = [], flatpickrMultiplo = null;
    let nextServicoIndex = 1;
    let servicosDisponiveis = [];

    function formatDateTime(dt) { if (!dt) return ""; return dt.replace(/-/g, '/').substring(0, 16); }
    function formatMoney(v) { return Number(v).toLocaleString('pt-MZ') + " MZN"; }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    function loadStats() {
        $.ajax({ url: contextPath + '/Admin/consumos/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalConsumos').text(d.total_consumos || 0);
                $('#totalFaturado').html(formatMoney(d.total_faturado || 0));
                $('#hospedesAtivos').text(d.hospedes_ativos || 0);
                $('#topServico').text(d.top_servico || '-');
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function loadServicosList() {
        $.ajax({ url: contextPath + '/Admin/consumos/servicos/listar', method: 'GET', dataType: 'json',
            success: function(d) {
                servicosDisponiveis = d;
                var tbody = $('#servicosTableBody');
                tbody.empty();
                $.each(d, function(i, s) {
                    tbody.append('<tr>' +
                        '<td><strong>' + escapeHtml(s.nome_servico) + '</strong></td>' +
                        '<td>' + escapeHtml(s.descricao) + '</td>' +
                        '<td>' + formatMoney(s.preco) + '</td>' +
                        '<td><span class="badge bg-secondary">' + s.total_consumido + '</span></td>' +
                        '<td class="action-buttons">' +
                            '<button class="action-btn edit" onclick="editarServico(' + s.id_servico + ')"><i class="bi bi-pencil"></i></button>' +
                            '<button class="action-btn delete" onclick="excluirServico(' + s.id_servico + ')"><i class="bi bi-trash"></i></button>' +
                        '</td>' +
                    '</tr>');
                });
            }, error: function() { console.error('Erro ao carregar serviços'); }
        });
    }

    function loadServicosSelect() {
        $.ajax({ url: contextPath + '/Admin/consumos/servicos', method: 'GET', dataType: 'json',
            success: function(d) {
                servicosList = d;
                atualizarSelectsServicos();
            }, error: function() { console.error('Erro ao carregar serviços para select'); }
        });
    }

    function atualizarSelectsServicos() {
        $('.servico-select').each(function() {
            var $select = $(this);
            var currentVal = $select.val();
            $select.html('<option value="">Selecione o serviço</option>');
            $.each(servicosList, function(i, s) {
                $select.append('<option value="' + s.id_servico + '" data-preco="' + s.preco + '">' + escapeHtml(s.nome_servico) + ' - ' + formatMoney(s.preco) + '</option>');
            });
            if (currentVal) $select.val(currentVal);
            $select.trigger('change');
        });
    }

    function loadHospedes() {
        $.ajax({ url: contextPath + '/Admin/consumos/hospedes', method: 'GET', dataType: 'json',
            success: function(d) {
                var select = $('#clienteId');
                select.html('<option value="">Selecione o hóspede</option>');
                $.each(d, function(i, h) {
                    select.append('<option value="' + h.id_cliente + '">' + escapeHtml(h.cliente_nome) + '</option>');
                });
            }, error: function() { console.error('Erro ao carregar hóspedes'); }
        });
    }

    function loadConsumos() {
        $.ajax({ url: contextPath + '/Admin/consumos/listar', method: 'GET', dataType: 'json',
            success: function(d) { todosConsumos = d; aplicarFiltros(); },
            error: function() { $('#consumosTableBody').html('<tr><td colspan="7" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function aplicarFiltros() {
        var filtrados = todosConsumos.filter(function(c) {
            var matchSearch = !currentFilter || c.hospede_nome.toLowerCase().includes(currentFilter) || c.servico_nome.toLowerCase().includes(currentFilter);
            var matchServico = !currentServicoFilter || c.servico_nome === currentServicoFilter;
            return matchSearch && matchServico;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
    }

    function renderizarTabela(consumos) {
        var tbody = $('#consumosTableBody');
        tbody.empty();
        if (consumos.length === 0) { tbody.html('<tr><td colspan="7" class="text-center py-4">Nenhum consumo encontrado</td></tr>'); return; }
        $.each(consumos, function(i, c) {
            tbody.append('<tr>' +
                '<td>' + formatDateTime(c.data_consumo) + '</td>' +
                '<td><strong>' + escapeHtml(c.hospede_nome) + '</strong></td>' +
                '<td>' + escapeHtml(c.quarto_num) + '</td>' +
                '<td>' + escapeHtml(c.servico_nome) + '</td>' +
                '<td class="text-center">' + c.quantidade + '</td>' +
                '<td><strong>' + formatMoney(c.subtotal) + '</strong></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn edit" onclick="editarConsumo(' + c.id_consumo + ')"><i class="bi bi-pencil"></i></button>' +
                    '<button class="action-btn view" onclick="verDetalhes(' + c.id_consumo + ')"><i class="bi bi-eye"></i></button>' +
                '</td>' +
            '</tr>');
        });
    }
    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" onclick="mudarPagina(' + (currentPage - 1) + ')">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" onclick="mudarPagina(' + i + ')">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" onclick="mudarPagina(' + (currentPage + 1) + ')">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); }

    function atualizarPrecoServico($select) {
        var selected = $select.find('option:selected');
        var preco = selected.data('preco') || 0;
        $select.closest('.servico-item').find('.preco-display').text(formatMoney(preco));
    }

    $('#addServicoBtn').on('click', function() {
        var newIndex = nextServicoIndex++;
        var newItem = $('<div class="servico-item" data-index="' + newIndex + '">' +
            '<div class="servico-header">' +
                '<select class="form-select servico-select" style="flex: 1;" required>' +
                    '<option value="">Selecione o serviço</option>' +
                '</select>' +
                '<input type="number" class="form-control quantidade-input" value="1" min="1" style="width: 100px; margin-left: 10px;" placeholder="Qtd">' +
            '</div>' +
            '<div class="small text-muted mt-2">Preço: <span class="preco-display">0.00 MZN</span></div>' +
            '<button type="button" class="btn btn-sm btn-danger mt-2" onclick="$(this).closest(\'.servico-item\').remove()"><i class="bi bi-trash"></i> Remover</button>' +
        '</div>');

        $('#servicosContainer').append(newItem);

        var $select = newItem.find('.servico-select');
        $select.html('<option value="">Selecione o serviço</option>');
        $.each(servicosList, function(i, s) {
            $select.append('<option value="' + s.id_servico + '" data-preco="' + s.preco + '">' + escapeHtml(s.nome_servico) + ' - ' + formatMoney(s.preco) + '</option>');
        });

        $select.on('change', function() { atualizarPrecoServico($(this)); });
        newItem.find('.quantidade-input').on('input', function() {
            var $parent = $(this).closest('.servico-item');
            var $sel = $parent.find('.servico-select');
            atualizarPrecoServico($sel);
        });
    });

    $(document).on('change', '.servico-select', function() { atualizarPrecoServico($(this)); });
    $(document).on('input', '.quantidade-input', function() {
        var $parent = $(this).closest('.servico-item');
        var $sel = $parent.find('.servico-select');
        atualizarPrecoServico($sel);
    });

    $('#formConsumoMultiplo').on('submit', function(e) {
        e.preventDefault();
        var idCliente = $('#clienteId').val();
        if (!idCliente) { showAlert('warning', 'Selecione um hóspede!'); return; }

        var dataConsumo = $('#dataConsumoMultiplo').val();
        if (!dataConsumo) { var now = new Date(); dataConsumo = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0') + 'T' + String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0'); }

        var servicos = [];
        var hasError = false;

        $('.servico-item').each(function() {
            var $select = $(this).find('.servico-select');
            var idServico = $select.val();
            var quantidade = $(this).find('.quantidade-input').val();
            var preco = $select.find('option:selected').data('preco');

            if (!idServico) {
                showAlert('warning', 'Selecione um serviço para todos os itens');
                hasError = true;
                return false;
            }
            if (!quantidade || quantidade < 1) quantidade = 1;

            servicos.push({ id_servico: idServico, quantidade: parseInt(quantidade), preco: preco });
        });

        if (hasError) return;
        if (servicos.length === 0) { showAlert('warning', 'Adicione pelo menos um serviço'); return; }

        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Salvando...');

        $.ajax({ url: contextPath + '/Admin/consumos/salvar-multiplo', method: 'POST', data: { id_cliente: idCliente, data_consumo: dataConsumo, servicos: JSON.stringify(servicos) }, dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Registrar Consumos');
                if (r.success) {
                    var modal = bootstrap.Modal.getInstance(document.getElementById('modalConsumo'));
                    if (modal) modal.hide();
                    $('#formConsumoMultiplo')[0].reset();
                    $('#servicosContainer').html('<div class="servico-item" data-index="0">' +
                        '<div class="servico-header">' +
                            '<select class="form-select servico-select" style="flex: 1;" required><option value="">Selecione o serviço</option></select>' +
                            '<input type="number" class="form-control quantidade-input" value="1" min="1" style="width: 100px; margin-left: 10px;" placeholder="Qtd">' +
                        '</div>' +
                        '<div class="small text-muted mt-2">Preço: <span class="preco-display">0.00 MZN</span></div>' +
                    '</div>');
                    nextServicoIndex = 1;
                    atualizarSelectsServicos();
                    loadConsumos();
                    showAlert('success', r.totalInseridos + ' consumo(s) registrado(s) com sucesso!');
                } else showAlert('error', r.message || 'Erro ao salvar');
            }, error: function() { btn.prop('disabled', false).text('Registrar Consumos'); showAlert('error', 'Erro ao salvar consumo'); }
        });
    });

    function editarConsumo(id) {
        var consumo = todosConsumos.find(function(c) { return c.id_consumo === id; });
        if (consumo) {
            $('#detData').html(formatDateTime(consumo.data_consumo));
            $('#detHospede').html(escapeHtml(consumo.hospede_nome));
            $('#detQuarto').html(escapeHtml(consumo.quarto_num));
            $('#detServico').html(escapeHtml(consumo.servico_nome));
            $('#detQuantidade').html(consumo.quantidade);
            $('#detPreco').html(formatMoney(consumo.preco_unitario));
            $('#detSubtotal').html(formatMoney(consumo.subtotal));
            $('#detUsuario').html(consumo.usuario_nome || 'Sistema');
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        }
    }

    function verDetalhes(id) {
        var consumo = todosConsumos.find(function(c) { return c.id_consumo === id; });
        if (consumo) {
            $('#detData').html(formatDateTime(consumo.data_consumo));
            $('#detHospede').html(escapeHtml(consumo.hospede_nome));
            $('#detQuarto').html(escapeHtml(consumo.quarto_num));
            $('#detServico').html(escapeHtml(consumo.servico_nome));
            $('#detQuantidade').html(consumo.quantidade);
            $('#detPreco').html(formatMoney(consumo.preco_unitario));
            $('#detSubtotal').html(formatMoney(consumo.subtotal));
            $('#detUsuario').html(consumo.usuario_nome || 'Sistema');
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        }
    }

    function editarServico(id) {
        var servico = servicosDisponiveis.find(function(s) { return s.id_servico === id; });
        if (servico) {
            $('#editServicoId').val(servico.id_servico);
            $('#nomeServico').val(servico.nome_servico);
            $('#descricaoServico').val(servico.descricao);
            $('#precoServico').val(servico.preco);
            $('#modalServicos .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Serviço');
            $('html, body').animate({ scrollTop: 0 }, 300);
        }
    }

    function excluirServico(id) {
        Swal.fire({ title: 'Confirmar', text: 'Tem certeza que deseja excluir este serviço?', icon: 'warning', showCancelButton: true, confirmButtonColor: '#D9534F', confirmButtonText: 'Sim, excluir' }).then(function(result) {
            if (result.isConfirmed) {
                $.ajax({ url: contextPath + '/Admin/consumos/servicos/excluir', method: 'POST', data: { id: id }, dataType: 'json',
                    success: function(r) { if (r.success) { loadServicosList(); loadServicosSelect(); showAlert('success', 'Serviço excluído!'); } else showAlert('error', r.message || 'Erro ao excluir'); },
                    error: function() { showAlert('error', 'Erro ao excluir serviço'); }
                });
            }
        });
    }

    $('#formServico').on('submit', function(e) {
        e.preventDefault();
        var nomeServico = $('#nomeServico').val();
        var preco = $('#precoServico').val();
        if (!nomeServico || !preco) { showAlert('warning', 'Preencha nome e preço do serviço!'); return; }

        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true);

        $.ajax({ url: contextPath + '/Admin/consumos/servicos/salvar', method: 'POST', data: { id: $('#editServicoId').val(), nome_servico: nomeServico, descricao: $('#descricaoServico').val(), preco: preco }, dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false);
                if (r.success) {
                    $('#formServico')[0].reset();
                    $('#editServicoId').val('');
                    $('#modalServicos .modal-title').html('<i class="bi bi-grid"></i> Gerenciar Serviços');
                    loadServicosList();
                    loadServicosSelect();
                    showAlert('success', 'Serviço salvo com sucesso!');
                } else showAlert('error', r.message || 'Erro ao salvar');
            }, error: function() { btn.prop('disabled', false); showAlert('error', 'Erro ao salvar serviço'); }
        });
    });

    $('#modalServicos').on('hidden.bs.modal', function() {
        $('#formServico')[0].reset();
        $('#editServicoId').val('');
        $('#modalServicos .modal-title').html('<i class="bi bi-grid"></i> Gerenciar Serviços');
    });

    $('#modalConsumo').on('hidden.bs.modal', function() {
        $('#formConsumoMultiplo')[0].reset();
        $('#servicosContainer').html('<div class="servico-item" data-index="0">' +
            '<div class="servico-header">' +
                '<select class="form-select servico-select" style="flex: 1;" required><option value="">Selecione o serviço</option></select>' +
                '<input type="number" class="form-control quantidade-input" value="1" min="1" style="width: 100px; margin-left: 10px;" placeholder="Qtd">' +
            '</div>' +
            '<div class="small text-muted mt-2">Preço: <span class="preco-display">0.00 MZN</span></div>' +
        '</div>');
        nextServicoIndex = 1;
        atualizarSelectsServicos();
    });

    $('#searchInput').on('input', function() { currentFilter = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });

    function popularFiltroServicos() {
        $.ajax({ url: contextPath + '/Admin/consumos/servicos', method: 'GET', dataType: 'json',
            success: function(d) {
                var select = $('#servicoFilter');
                select.html('<option value="">Todos os serviços</option>');
                $.each(d, function(i, s) {
                    select.append('<option value="' + escapeHtml(s.nome_servico) + '">' + escapeHtml(s.nome_servico) + '</option>');
                });
            }, error: function() { console.error('Erro ao carregar serviços para filtro'); }
        });
    }

    $('#servicoFilter').on('change', function() {
        currentServicoFilter = $(this).val();
        currentPage = 1;
        aplicarFiltros();
    });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    flatpickrMultiplo = flatpickr("#dataConsumoMultiplo", { enableTime: true, dateFormat: "Y-m-d H:i", locale: "pt", time_24hr: true, defaultDate: new Date() });

    loadServicosList();
    loadServicosSelect();
    loadHospedes();
    loadConsumos();
    popularFiltroServicos();

    setTimeout(function() {
        atualizarSelectsServicos();
        $('.servico-select').each(function() { atualizarPrecoServico($(this)); });
    }, 500);
</script>
</body>
</html>