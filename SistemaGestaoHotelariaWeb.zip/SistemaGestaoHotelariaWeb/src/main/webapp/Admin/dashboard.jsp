<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active a { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; }
        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area img { height: 45px; width: auto; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }
        .notification-icon { position: relative; cursor: pointer; background: #F0F4F8; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: all 0.2s; }
        .notification-icon:hover { background: #FFB800; }
        .notification-icon i { font-size: 1.2rem; color: #FFB800; }
        .notification-icon:hover i { color: #0B2B40; }
        .notification-badge { position: absolute; top: -2px; right: -2px; background: #D9534F; color: white; border-radius: 50%; width: 18px; height: 18px; font-size: 0.65rem; display: flex; align-items: center; justify-content: center; font-weight: bold; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px; transition: all 0.3s; border: 1px solid #E2EAEF; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFB800; box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.75rem; font-weight: 600; color: #8AA6B5; text-transform: uppercase; }
        .stat-header i { font-size: 1.6rem; color: #FFB800; opacity: 0.7; }
        .stat-value { font-size: 1.8rem; font-weight: 700; color: #0B2B40; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0B8C4; display: flex; align-items: center; gap: 6px; }

        .charts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2EAEF; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #0B2B40; margin-bottom: 15px; }
        .chart-box h3 i { color: #FFB800; }
        .chart-container { height: 170px; }

        .table-section { background: white; border-radius: 20px; padding: 18px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .table { font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; }
        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.7rem; }
        .badge-status.confirmada { background: #E8F5E9; color: #2E7D32; }
        .badge-status.pendente { background: #FFF8E1; color: #F57C00; }
        .badge-status.cancelada { background: #FFEBEE; color: #D9534F; }
        .badge-status.finalizada { background: #E3F2FD; color: #1976D2; }

        .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .info-card { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2EAEF; cursor: pointer; }
        .info-card:hover { border-color: #FFB800; }
        .info-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #E2EAEF; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: 10px; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .notification-list { max-height: 400px; overflow-y: auto; }
        .notification-item { padding: 12px; border-bottom: 1px solid #E2EAEF; cursor: pointer; transition: background 0.2s; }
        .notification-item:hover { background: #F0F4F8; }
        .notification-item.unread { background: #FFF8E1; }
        .notification-icon-sm { width: 35px; height: 35px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }

        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .info-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quarto.jsp"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/cliente.jsp"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>

    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr.jsp"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/fatura.jsp"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionario.jsp"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuario.jsp"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
         <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <img src="${pageContext.request.contextPath}/assets/images/logotipo.png" alt="Logotipo" onerror="this.src='https://placehold.co/45x45/0B2B40/FFB800?text=🏨'">
            <div class="logo-text">Sistema Hotelaria<span>Gestão Integrada</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
            <div class="notification-icon" data-bs-toggle="modal" data-bs-target="#notificationsModal">
                <i class="bi bi-bell-fill"></i>
                <span class="notification-badge" id="notifCount">0</span>
            </div>
        </div>
    </div>

    <!-- CARDS DINÂMICOS -->
    <div class="stats-grid">
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Admin/cliente.jsp'">
            <div class="stat-header"><h3>Total Clientes</h3><i class="bi bi-people-fill"></i></div>
            <div class="stat-value">${totalClientes}</div>
            <div class="stat-footer"><i class="bi bi-graph-up trend-up"></i><span> +${novosClientes} este mês</span></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Admin/quarto.jsp'">
            <div class="stat-header"><h3>Quartos Ocupados</h3><i class="bi bi-door-open-fill"></i></div>
            <div class="stat-value">${quartosOcupados} / ${totalQuartos}</div>
            <div class="stat-footer"><i class="bi bi-percent"></i><span> ${quartosOcupados > 0 ? Math.round(quartosOcupados * 100.0 / totalQuartos) : 0}% ocupação</span></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Admin/check.jsp'">
            <div class="stat-header"><h3>Check-ins Hoje</h3><i class="bi bi-person-arms-up"></i></div>
            <div class="stat-value">${checkinsHoje}</div>
            <div class="stat-footer"><i class="bi bi-clock"></i><span> Hoje</span></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Admin/pagamento.jsp'">
            <div class="stat-header"><h3>Faturamento Mês</h3><i class="bi bi-cash-stack"></i></div>
            <div class="stat-value"><fmt:formatNumber value="${faturamentoMes}" type="number" groupingUsed="true"/> MZN</div>
            <div class="stat-footer"><i class="bi bi-trending-up trend-up"></i><span> Atualizado</span></div>
        </div>
    </div>

    <!-- GRÁFICOS -->
    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Reservas por Estado</h3>
            <div class="chart-container"><canvas id="reservasEstadoChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Consumo de Serviços</h3>
            <div class="chart-container"><canvas id="servicosChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-graph-up"></i> Ocupação Semanal</h3>
            <div class="chart-container"><canvas id="ocupacaoChart"></canvas></div>
        </div>
    </div>

    <!-- TABELA ÚLTIMAS RESERVAS -->
    <div class="table-section">
        <h3><i class="bi bi-calendar-check"></i> Últimas Reservas</h3>
        <table class="table">
            <thead>
                <tr><th>Cliente</th><th>Quarto</th><th>Entrada</th><th>Saída</th><th>Hóspedes</th><th>Estado</th></tr>
            </thead>
            <tbody>
                <c:forEach items="${ultimasReservas}" var="reserva">
                    <tr onclick="location.href='${pageContext.request.contextPath}/Admin/reservas?id=${reserva.idReserva}'">
                        <td><strong>${reserva.nomeCliente}</strong></td>
                        <td>${reserva.numeroQuarto} - ${reserva.tipoQuarto}</td>
                        <td><fmt:formatDate value="${reserva.dataEntrada}" pattern="dd/MM"/></td>
                        <td><fmt:formatDate value="${reserva.dataSaida}" pattern="dd/MM"/></td>
                        <td class="text-center">${reserva.numeroHospedes}</td>
                        <td><span class="badge-status ${reserva.estadoReserva.toLowerCase()}">${reserva.estadoReserva}</span></td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
    </div>

    <!-- CARDS ADICIONAIS -->
    <div class="info-grid">
        <div class="info-card" onclick="location.href='${pageContext.request.contextPath}/Admin/quarto.jsp'">
            <h4><i class="bi bi-door-closed"></i> Estado dos Quartos</h4>
            <c:forEach items="${estadosQuartos}" var="entry">
                <div class="info-item">
                    <span>${entry.key}</span>
                    <strong>${entry.value}</strong>
                </div>
            </c:forEach>
        </div>
        <div class="info-card" onclick="location.href='${pageContext.request.contextPath}/Admin/pagamento.jsp'">
            <h4><i class="bi bi-currency-dollar"></i> Pagamentos</h4>
            <div class="info-item">
                <span><strong>Total Pendente</strong></span>
                <strong class="text-danger"><fmt:formatNumber value="${totalPendente}" type="number" groupingUsed="true"/> MZN</strong>
            </div>
        </div>
        <div class="info-card" onclick="location.href='${pageContext.request.contextPath}/Admin/funcionario.jsp'">
            <h4><i class="bi bi-person-badge"></i> Sistema</h4>
            <div class="info-item">
                <span>Usuário Ativo</span>
                <strong>${sessionScope.usuarioLogado.nome}</strong>
            </div>
            <div class="info-item">
                <span>Perfil</span>
                <strong>${sessionScope.usuarioLogado.nomePerfil}</strong>
            </div>
        </div>
    </div>

    <!-- FOOTER COM COPYRIGHT DINÂMICO -->
    <div class="footer">
        <p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p>
    </div>
</div>

<!-- MODAL DE NOTIFICAÇÕES -->
<div class="modal fade" id="notificationsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content" style="border-radius: 20px;">
            <div class="modal-header" style="background: #0B2B40; color: white; border-radius: 20px 20px 0 0;">
                <h5 class="modal-title"><i class="bi bi-bell-fill me-2"></i> Notificações do Sistema</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div class="notification-list" id="notificationList">
                    <div class="text-center p-4">
                        <div class="spinner-border text-warning" role="status">
                            <span class="visually-hidden">Carregando...</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Dados para gráficos
    const reservasConfirmadas = ${reservasConfirmadas};
    const reservasPendentes = ${reservasPendentes};
    const reservasFinalizadas = ${reservasFinalizadas};
    const reservasCanceladas = ${reservasCanceladas};
    const totalQuartos = ${totalQuartos};

    // Gráfico 1: Reservas por Estado (PIZZA)
    new Chart(document.getElementById('reservasEstadoChart'), {
        type: 'pie',
        data: {
            labels: ['CONFIRMADA', 'PENDENTE', 'FINALIZADA', 'CANCELADA'],
            datasets: [{
                data: [reservasConfirmadas, reservasPendentes, reservasFinalizadas, reservasCanceladas],
                backgroundColor: ['#2E7D32', '#F57C00', '#1976D2', '#D9534F'],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { font: { size: 10 } }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = reservasConfirmadas + reservasPendentes + reservasFinalizadas + reservasCanceladas;
                            const percentage = total > 0 ? ((context.raw / total) * 100).toFixed(1) : 0;
                            return `${context.label}: ${context.raw} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });

    // Gráfico 2: Consumo de Serviços
    new Chart(document.getElementById('servicosChart'), {
        type: 'bar',
        data: {
            labels: ['Lavandaria', 'Room Service', 'SPA', 'Translado', 'Frigobar'],
            datasets: [{
                label: 'Consumos',
                data: [12, 8, 15, 5, 10],
                backgroundColor: '#FFB800',
                borderRadius: 8
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });

    // Gráfico 3: Ocupação Semanal
    new Chart(document.getElementById('ocupacaoChart'), {
        type: 'line',
        data: {
            labels: ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
            datasets: [{
                label: 'Quartos Ocupados',
                data: [28, 30, 32, 35, 38, 42, 40],
                borderColor: '#0B2B40',
                backgroundColor: 'rgba(11, 43, 64, 0.05)',
                tension: 0.3,
                fill: true,
                pointBackgroundColor: '#FFB800',
                pointBorderColor: '#fff',
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: totalQuartos,
                    title: { display: true, text: 'Quartos Ocupados' }
                }
            }
        }
    });

    // Função para atualizar o ano no copyright
    function atualizarAnoCopyright() {
        const anoAtual = new Date().getFullYear();
        document.getElementById('anoAtual').textContent = anoAtual;
    }

    // Relógio
    function updateClock() {
        const now = new Date();
        document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT');
        document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
        atualizarAnoCopyright();
    }

    setInterval(updateClock, 1000);
    updateClock();
    atualizarAnoCopyright();

    // Carregar notificações via AJAX
    function carregarNotificacoes() {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/notificacoes',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                const lista = $('#notificationList');
                lista.empty();

                if (data.notificacoes && data.notificacoes.length > 0) {
                    data.notificacoes.forEach(function(notif) {
                        const icon = getIconByAcao(notif.acao);
                        lista.append(`
                            <div class="notification-item">
                                <div class="d-flex align-items-center gap-3">
                                    <div class="notification-icon-sm bg-warning bg-opacity-10">
                                        <i class="bi ${icon} text-warning"></i>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="fw-bold">${notif.acao}</div>
                                        <small class="text-muted">${notif.descricao}</small>
                                        <div><small class="text-muted">${notif.data} - ${notif.usuario}</small></div>
                                    </div>
                                </div>
                            </div>
                        `);
                    });
                    $('#notifCount').text(data.notificacoes.length);
                } else {
                    lista.html('<div class="text-center p-4 text-muted"><i class="bi bi-inbox fs-1"></i><p class="mt-2">Nenhuma notificação</p></div>');
                    $('#notifCount').text('0');
                }
            },
            error: function(xhr, status, error) {
                console.error('Erro:', error);
                $('#notificationList').html('<div class="text-center p-4 text-danger">Erro ao carregar notificações</div>');
            }
        });
    }

    function getIconByAcao(acao) {
        const icons = {
            'LOGIN': 'bi-box-arrow-in-right',
            'LOGOUT': 'bi-box-arrow-right',
            'INSERT': 'bi-plus-circle',
            'UPDATE': 'bi-pencil-square',
            'DELETE': 'bi-trash'
        };
        return icons[acao] || 'bi-info-circle';
    }

    // Carregar notificações ao abrir modal
    $('#notificationsModal').on('show.bs.modal', function() {
        carregarNotificacoes();
    });

    // Atualizar contador de notificações a cada 30 segundos
    function atualizarContador() {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/notificacoes/contar',
            method: 'GET',
            success: function(data) {
                $('#notifCount').text(data.count || 0);
            }
        });
    }

    setInterval(atualizarContador, 30000);
    atualizarContador();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>