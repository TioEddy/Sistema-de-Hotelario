<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check-in / Check-out · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-success-custom { background: #2E7D32; border: none; padding: 6px 16px; border-radius: 30px; font-weight: 500; color: white; font-size: 0.75rem; }
        .btn-success-custom:hover { background: #1B5E20; }
        .btn-danger-custom { background: #D9534F; border: none; padding: 6px 16px; border-radius: 30px; font-weight: 500; color: white; font-size: 0.75rem; }
        .btn-danger-custom:hover { background: #c9302c; }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 6px 16px; border-radius: 30px; font-weight: 500; color: #6C8D9C; font-size: 0.75rem; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #F0F4F8; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2EAEF; background: white; }

        .nav-tabs-custom { border-bottom: 2px solid #E2EAEF; margin-bottom: 20px; }
        .nav-tabs-custom .nav-link { border: none; color: #8AA6B5; font-weight: 600; padding: 12px 24px; border-radius: 0; }
        .nav-tabs-custom .nav-link:hover { color: #FFB800; }
        .nav-tabs-custom .nav-link.active { color: #FFB800; border-bottom: 3px solid #FFB800; background: transparent; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }
        .action-buttons { display: flex; gap: 5px; flex-wrap: wrap; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #0B2B40; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2EAEF; padding: 10px 14px; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr.jsp"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Sistema Hotelaria<span>Check-in / Check-out</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <!-- Cards Estatísticos -->
    <div class="stats-grid">
        <div class="stat-card"><h4><i class="bi bi-person-arms-up"></i> Check-ins Hoje</h4><div class="value" id="checkinsHoje">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-luggage"></i> Check-outs Hoje</h4><div class="value" id="checkoutsHoje">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-door-open"></i> Hóspedes no Hotel</h4><div class="value" id="hospedesHotel">0</div></div>
        <div class="stat-card"><h4><i class="bi bi-calendar-check"></i> Reservas Pendentes</h4><div class="value" id="reservasPendentes">0</div></div>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs-custom" id="myTab" role="tablist">
        <li class="nav-item"><button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button">📋 Check-ins Pendentes</button></li>
        <li class="nav-item"><button class="nav-link" id="checkedin-tab" data-bs-toggle="tab" data-bs-target="#checkedin" type="button">🏨 Hóspedes no Hotel</button></li>
        <li class="nav-item"><button class="nav-link" id="checkout-tab" data-bs-toggle="tab" data-bs-target="#checkout" type="button">🚪 Check-outs Hoje</button></li>
    </ul>

    <div class="tab-content">
        <!-- TAB 1: Check-ins Pendentes -->
        <div class="tab-pane fade show active" id="pending" role="tabpanel">
            <div class="filters-bar">
                <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchPending" placeholder="Buscar por cliente ou quarto..."></div>
                <div><select class="filter-select" id="quartoFilter"><option value="">Todos os quartos</option></select></div>
            </div>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr><th>Cliente</th><th>Quarto</th><th>Entrada</th><th>Saída</th><th>Hóspedes</th><th>Ações</th></tr>
                    </thead>
                    <tbody id="pendingTableBody">
                        <tr><td colspan="6" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TAB 2: Hóspedes no Hotel -->
        <div class="tab-pane fade" id="checkedin" role="tabpanel">
            <div class="filters-bar">
                <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchHospedes" placeholder="Buscar por cliente ou quarto..."></div>
                <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalAdicionarConsumo" style="padding: 6px 20px;"><i class="bi bi-plus-lg"></i> Adicionar Consumo</button>
            </div>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr><th>Cliente</th><th>Quarto</th><th>Check-in</th><th>Saída Prevista</th><th>Consumo</th><th>Ações</th></tr>
                    </thead>
                    <tbody id="hospedesTableBody">
                        <tr><td colspan="6" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TAB 3: Check-outs Hoje -->
        <div class="tab-pane fade" id="checkout" role="tabpanel">
            <div class="filters-bar">
                <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchCheckout" placeholder="Buscar por cliente ou quarto..."></div>
            </div>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr><th>Cliente</th><th>Quarto</th><th>Saída Prevista</th><th>Valor Total</th><th>Ações</th></tr>
                    </thead>
                    <tbody id="checkoutTableBody">
                        <tr><td colspan="5" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- FOOTER - Último elemento -->
    <div class="footer">
        <p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p>
    </div>
</div>

<!-- MODAL: Realizar Check-in -->
<div class="modal fade modal-custom" id="modalCheckin" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-person-arms-up"></i> Realizar Check-in</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <input type="hidden" id="checkinReservaId">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="modalCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="modalQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Período:</div><div class="detail-value" id="modalPeriodo">-</div></div>
                <div class="detail-row"><div class="detail-label">Preço Diária:</div><div class="detail-value" id="modalPrecoDiaria">-</div></div>
                <div class="mb-3 mt-3"><label class="form-label">Quantidade de Hóspedes</label><input type="number" class="form-control form-control-custom" id="quantidadeHospedes" value="1" min="1" max="10"></div>
                <div class="mb-3"><label class="form-label">Observações</label><textarea class="form-control form-control-custom" id="checkinObservacoes" rows="2"></textarea></div>
                <hr><div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="button" class="btn-primary-custom" id="confirmCheckinBtn">Confirmar Check-in</button></div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Realizar Check-out -->
<div class="modal fade modal-custom" id="modalCheckout" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-luggage"></i> Realizar Check-out</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <input type="hidden" id="checkoutCheckinId">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="checkoutCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="checkoutQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Período:</div><div class="detail-value" id="checkoutPeriodo">-</div></div>
                <div class="detail-row"><div class="detail-label">Diárias:</div><div class="detail-value" id="checkoutDiarias">-</div></div>
                <div class="detail-row"><div class="detail-label">Consumo extra:</div><div class="detail-value" id="checkoutConsumo">0 MZN</div></div>
                <div class="detail-row" style="background:#FFF8E1;margin-top:10px;border-radius:12px;"><div class="detail-label"><strong>Valor Total:</strong></div><div class="detail-value"><strong id="checkoutTotal">0 MZN</strong></div></div>
                <div class="mb-3 mt-3"><label class="form-label">Observações</label><textarea class="form-control form-control-custom" id="checkoutObservacoes" rows="2"></textarea></div>
                <hr><div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="button" class="btn-primary-custom" id="confirmCheckoutBtn">Confirmar Check-out</button></div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Adicionar Consumo -->
<div class="modal fade modal-custom" id="modalAdicionarConsumo" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-cup-straw"></i> Adicionar Consumo</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <input type="hidden" id="consumoReservaId">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="consumoCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="consumoQuarto">-</div></div>
                <div class="mb-3"><label class="form-label">Serviço</label><select class="form-select form-select-custom" id="servicoSelect"></select></div>
                <div class="mb-3"><label class="form-label">Quantidade</label><input type="number" class="form-control form-control-custom" id="consumoQuantidade" value="1" min="1"></div>
                <div class="mb-3"><label class="form-label">Subtotal</label><input type="text" class="form-control form-control-custom" id="consumoSubtotal" readonly style="background:#F0F4F8;"></div>
                <hr><div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="button" class="btn-primary-custom" id="confirmConsumoBtn">Adicionar Consumo</button></div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes da Estadia</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="detCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="detQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Check-in:</div><div class="detail-value" id="detCheckin">-</div></div>
                <div class="detail-row"><div class="detail-label">Saída Prevista:</div><div class="detail-value" id="detSaida">-</div></div>
                <div class="detail-row"><div class="detail-label">Hóspedes:</div><div class="detail-value" id="detHospedes">-</div></div>
                <div class="detail-row"><div class="detail-label">Consumo Total:</div><div class="detail-value" id="detConsumo">-</div></div>
                <div class="detail-row"><div class="detail-label">Observações:</div><div class="detail-value" id="detObs">-</div></div>
            </div>
            <div class="modal-footer" style="border:none;padding:16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';

    // Funções utilitárias
    function formatDate(dateStr) {
        if (!dateStr) return "";
        var parts = dateStr.split("-");
        return parts[2] + "/" + parts[1] + "/" + parts[0];
    }

    function formatDateTime(dateTimeStr) {
        if (!dateTimeStr) return "";
        return dateTimeStr.replace(/-/g, '/').substring(0, 16);
    }

    function formatMoney(value) {
        return Number(value).toLocaleString('pt-MZ') + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function showAlert(type, message) {
        var alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-' + (type === 'success' ? 'success' : 'danger') + ' position-fixed bottom-0 end-0 m-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.style.background = type === 'success' ? '#2E7D32' : '#D9534F';
        alertDiv.style.color = 'white';
        alertDiv.style.borderRadius = '12px';
        alertDiv.style.padding = '12px 20px';
        alertDiv.innerHTML = '<i class="bi bi-' + (type === 'success' ? 'check-circle' : 'exclamation-triangle') + '"></i> ' + message;
        document.body.appendChild(alertDiv);
        setTimeout(function() { alertDiv.remove(); }, 3000);
    }

    // Carregar estatísticas
    function loadStats() {
        $.ajax({
            url: contextPath + '/Admin/check/stats',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                $('#checkinsHoje').text(data.checkins_hoje || 0);
                $('#checkoutsHoje').text(data.checkouts_hoje || 0);
                $('#hospedesHotel').text(data.hospedes_hotel || 0);
                $('#reservasPendentes').text(data.reservas_pendentes || 0);
            },
            error: function(xhr) { console.error('Erro ao carregar stats:', xhr.responseText); }
        });
    }

    // Carregar serviços
    function loadServicos() {
        $.ajax({
            url: contextPath + '/Admin/check/servicos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var select = $('#servicoSelect');
                select.html('<option value="">Selecione um serviço</option>');
                $.each(data, function(i, s) {
                    select.append('<option value="' + s.id_servico + '" data-preco="' + s.preco + '">' + escapeHtml(s.nome_servico) + ' - ' + formatMoney(s.preco) + '</option>');
                });
            },
            error: function(xhr) { console.error('Erro ao carregar serviços:', xhr.responseText); }
        });
    }

    // Calcular subtotal consumo
    function calcularSubtotal() {
        var select = document.getElementById('servicoSelect');
        var selected = select.options[select.selectedIndex];
        var preco = selected.getAttribute('data-preco');
        var quantidade = document.getElementById('consumoQuantidade').value;
        if (preco && quantidade) {
            var subtotal = parseFloat(preco) * parseInt(quantidade);
            document.getElementById('consumoSubtotal').value = formatMoney(subtotal);
        } else {
            document.getElementById('consumoSubtotal').value = "";
        }
    }

    document.getElementById('servicoSelect').addEventListener('change', calcularSubtotal);
    document.getElementById('consumoQuantidade').addEventListener('input', calcularSubtotal);

    // Renderizar Check-ins Pendentes
    function renderPending() {
        var search = $('#searchPending').val().toLowerCase() || "";
        var quartoFiltro = $('#quartoFilter').val() || "";

        $.ajax({
            url: contextPath + '/Admin/check/pendentes',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var filtered = data.filter(function(r) {
                    return (r.cliente_nome.toLowerCase().includes(search) || r.numero_quarto.includes(search)) &&
                           (quartoFiltro === "" || r.numero_quarto === quartoFiltro);
                });

                var tbody = $('#pendingTableBody');
                tbody.empty();

                if (filtered.length === 0) {
                    tbody.html('<tr><td colspan="6" class="text-center py-4">Nenhum check-in pendente para hoje</td></tr>');
                } else {
                    $.each(filtered, function(i, r) {
                        var row = '<tr>' +
                            '<td><strong>' + escapeHtml(r.cliente_nome) + '</strong></td>' +
                            '<td>' + r.numero_quarto + ' - ' + r.quarto_tipo + '</td>' +
                            '<td>' + formatDate(r.data_entrada) + '</td>' +
                            '<td>' + formatDate(r.data_saida) + '</td>' +
                            '<td class="text-center">' + r.numero_hospedes + '</td>' +
                            '<td><button class="btn-success-custom" onclick="openCheckinModal(' + r.id_reserva + ', \'' + escapeHtml(r.cliente_nome) + '\', \'' + r.numero_quarto + ' - ' + r.quarto_tipo + '\', \'' + r.data_entrada + '\', \'' + r.data_saida + '\', ' + r.preco_diaria + ', ' + r.numero_hospedes + ', \'' + escapeHtml(r.observacoes) + '\')"><i class="bi bi-person-check"></i> Check-in</button></td>' +
                        '</tr>';
                        tbody.append(row);
                    });
                }
                loadStats();
            },
            error: function(xhr) {
                console.error('Erro ao carregar pendentes:', xhr.responseText);
                $('#pendingTableBody').html('<tr><td colspan="6" class="text-center text-danger py-4">Erro ao carregar dados</td></tr>');
            }
        });
    }

    // Renderizar Hóspedes no Hotel
    function renderHospedes() {
        var search = $('#searchHospedes').val().toLowerCase() || "";

        $.ajax({
            url: contextPath + '/Admin/check/hospedes',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                console.log('Hóspedes carregados:', data);

                var filtered = data.filter(function(c) {
                    return c.cliente_nome.toLowerCase().includes(search) || c.numero_quarto.includes(search);
                });

                var tbody = $('#hospedesTableBody');
                tbody.empty();

                if (filtered.length === 0) {
                    tbody.html('<tr><td colspan="6" class="text-center py-4">Nenhum hóspede no hotel no momento</td></tr>');
                } else {
                    $.each(filtered, function(i, c) {
                        var row = '<tr>' +
                            '<td><strong>' + escapeHtml(c.cliente_nome) + '</strong></td>' +
                            '<td>' + c.numero_quarto + ' - ' + c.quarto_tipo + '</td>' +
                            '<td>' + formatDateTime(c.data_checkin) + '</td>' +
                            '<td>' + formatDate(c.data_saida_prevista) + '</td>' +
                            '<td>' + formatMoney(c.consumo_total || 0) + '</td>' +
                            '<td class="action-buttons">' +
                                '<button class="btn-danger-custom" onclick="openCheckoutModal(' + c.id_checkin + ', \'' + escapeHtml(c.cliente_nome) + '\', \'' + c.numero_quarto + ' - ' + c.quarto_tipo + '\', \'' + c.data_checkin + '\', \'' + c.data_saida_prevista + '\', ' + (c.preco_diaria || 0) + ', ' + (c.consumo_total || 0) + ')"><i class="bi bi-luggage"></i> Check-out</button>' +
                                '<button class="btn-outline-custom" onclick="openConsumoModal(' + c.id_reserva + ', \'' + escapeHtml(c.cliente_nome) + '\', \'' + c.numero_quarto + ' - ' + c.quarto_tipo + '\')"><i class="bi bi-plus-lg"></i> Consumo</button>' +
                                '<button class="btn-outline-custom" onclick="viewDetails(' + c.id_checkin + ')"><i class="bi bi-eye"></i></button>' +
                            '</td>' +
                        '</tr>';
                        tbody.append(row);
                    });
                }
            },
            error: function(xhr) {
                console.error('Erro ao carregar hóspedes:', xhr.responseText);
                $('#hospedesTableBody').html('<tr><td colspan="6" class="text-center text-danger py-4">Erro ao carregar dados</td></tr>');
            }
        });
    }

    // Renderizar Check-outs Hoje
    function renderCheckout() {
        var search = $('#searchCheckout').val().toLowerCase() || "";

        $.ajax({
            url: contextPath + '/Admin/check/checkout-hoje',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var filtered = data.filter(function(c) {
                    return c.cliente_nome.toLowerCase().includes(search) || c.numero_quarto.includes(search);
                });

                var tbody = $('#checkoutTableBody');
                tbody.empty();

                if (filtered.length === 0) {
                    tbody.html('<tr><td colspan="5" class="text-center py-4">Nenhum check-out previsto para hoje</td></tr>');
                } else {
                    $.each(filtered, function(i, c) {
                        var totalQuarto = c.preco_diaria * c.dias_estadia;
                        var total = totalQuarto + (c.consumo_total || 0);
                        var row = '<tr>' +
                            '<td><strong>' + escapeHtml(c.cliente_nome) + '</strong></td>' +
                            '<td>' + c.numero_quarto + ' - ' + c.quarto_tipo + '</td>' +
                            '<td>' + formatDate(c.data_saida_prevista) + '</td>' +
                            '<td>' + formatMoney(total) + '</td>' +
                            '<td><button class="btn-danger-custom" onclick="openCheckoutModal(' + c.id_checkin + ', \'' + escapeHtml(c.cliente_nome) + '\', \'' + c.numero_quarto + ' - ' + c.quarto_tipo + '\', \'' + c.data_checkin + '\', \'' + c.data_saida_prevista + '\', ' + c.preco_diaria + ', ' + c.consumo_total + ')"><i class="bi bi-check2-circle"></i> Finalizar</button></td>' +
                        '</tr>';
                        tbody.append(row);
                    });
                }
            },
            error: function(xhr) {
                console.error('Erro ao carregar checkouts:', xhr.responseText);
                $('#checkoutTableBody').html('<tr><td colspan="5" class="text-center text-danger py-4">Erro ao carregar dados</td></tr>');
            }
        });
    }

    // Carregar filtro de quartos
    function carregarFiltroQuartos() {
        $.ajax({
            url: contextPath + '/Admin/check/pendentes',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var quartosMap = new Map();
                $.each(data, function(i, r) {
                    if (!quartosMap.has(r.numero_quarto)) {
                        quartosMap.set(r.numero_quarto, {numero: r.numero_quarto, tipo: r.quarto_tipo});
                    }
                });

                var select = $('#quartoFilter');
                select.html('<option value="">Todos os quartos</option>');
                quartosMap.forEach(function(q) {
                    select.append('<option value="' + q.numero + '">' + q.numero + ' - ' + q.tipo + '</option>');
                });
            },
            error: function(xhr) { console.error('Erro ao carregar filtro de quartos:', xhr.responseText); }
        });
    }

    // Check-in Modal
    window.openCheckinModal = function(idReserva, cliente, quarto, entrada, saida, preco, hospedes, obs) {
        $('#checkinReservaId').val(idReserva);
        $('#modalCliente').html('<strong>' + escapeHtml(cliente) + '</strong>');
        $('#modalQuarto').html(quarto);
        $('#modalPeriodo').html(formatDate(entrada) + ' a ' + formatDate(saida));
        $('#modalPrecoDiaria').html(formatMoney(preco));
        $('#quantidadeHospedes').val(hospedes);
        $('#checkinObservacoes').val(obs);
        new bootstrap.Modal(document.getElementById('modalCheckin')).show();
    };

    $('#confirmCheckinBtn').on('click', function() {
        var idReserva = $('#checkinReservaId').val();
        var quantidade = $('#quantidadeHospedes').val();
        var observacoes = $('#checkinObservacoes').val();

        $.ajax({
            url: contextPath + '/Admin/check/checkin',
            method: 'POST',
            data: { id_reserva: idReserva, quantidade_hospedes: quantidade, observacoes: observacoes },
            dataType: 'json',
            success: function(result) {
                if (result.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalCheckin')).hide();
                    renderPending();
                    renderHospedes();
                    renderCheckout();
                    loadStats();
                    showAlert('success', 'Check-in realizado com sucesso!');
                } else {
                    showAlert('danger', result.message || 'Erro ao realizar check-in');
                }
            },
            error: function(xhr) { showAlert('danger', 'Erro ao realizar check-in'); }
        });
    });

    // Check-out Modal
    window.openCheckoutModal = function(idCheckin, cliente, quarto, checkinData, saidaData, precoDiaria, consumoTotal) {
        var entrada = new Date(checkinData.split(' ')[0]);
        var saida = new Date(saidaData);
        var diffTime = Math.abs(saida - entrada);
        var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1;
        var totalQuarto = precoDiaria * diffDays;
        var total = totalQuarto + (consumoTotal || 0);

        $('#checkoutCheckinId').val(idCheckin);
        $('#checkoutCliente').html('<strong>' + escapeHtml(cliente) + '</strong>');
        $('#checkoutQuarto').html(quarto);
        $('#checkoutPeriodo').html(formatDate(checkinData.split(' ')[0]) + ' a ' + formatDate(saidaData));
        $('#checkoutDiarias').html(diffDays + ' diárias x ' + formatMoney(precoDiaria) + ' = ' + formatMoney(totalQuarto));
        $('#checkoutConsumo').html(formatMoney(consumoTotal || 0));
        $('#checkoutTotal').html(formatMoney(total));
        $('#checkoutObservacoes').val("");
        new bootstrap.Modal(document.getElementById('modalCheckout')).show();
    };

    $('#confirmCheckoutBtn').on('click', function() {
        var idCheckin = $('#checkoutCheckinId').val();
        var totalText = $('#checkoutTotal').html();
        var valorTotal = parseFloat(totalText.replace(' MZN', '').replace(/\./g, '').replace(',', '.'));
        var observacoes = $('#checkoutObservacoes').val();

        $.ajax({
            url: contextPath + '/Admin/check/checkout',
            method: 'POST',
            data: { id_checkin: idCheckin, valor_total: valorTotal, observacoes: observacoes },
            dataType: 'json',
            success: function(result) {
                if (result.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalCheckout')).hide();
                    renderHospedes();
                    renderCheckout();
                    loadStats();
                    showAlert('success', 'Check-out realizado com sucesso!');
                } else {
                    showAlert('danger', result.message || 'Erro ao realizar check-out');
                }
            },
            error: function(xhr) { showAlert('danger', 'Erro ao realizar check-out'); }
        });
    });

    // Consumo Modal
    window.openConsumoModal = function(idReserva, cliente, quarto) {
        $('#consumoReservaId').val(idReserva);
        $('#consumoCliente').html('<strong>' + escapeHtml(cliente) + '</strong>');
        $('#consumoQuarto').html(quarto);
        $('#servicoSelect').val("");
        $('#consumoQuantidade').val(1);
        $('#consumoSubtotal').val("");
        new bootstrap.Modal(document.getElementById('modalAdicionarConsumo')).show();
    };

    $('#confirmConsumoBtn').on('click', function() {
        var idReserva = $('#consumoReservaId').val();
        var idServico = $('#servicoSelect').val();
        var quantidade = $('#consumoQuantidade').val();
        var selectedOption = $('#servicoSelect option:selected');
        var preco = selectedOption.data('preco');

        if (!idServico || quantidade < 1) {
            showAlert('danger', 'Selecione um serviço e quantidade válida!');
            return;
        }

        $.ajax({
            url: contextPath + '/Admin/check/consumo',
            method: 'POST',
            data: { id_reserva: idReserva, id_servico: idServico, quantidade: quantidade, preco: preco },
            dataType: 'json',
            success: function(result) {
                if (result.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalAdicionarConsumo')).hide();
                    renderHospedes();
                    renderCheckout();
                    showAlert('success', 'Consumo adicionado! Subtotal: ' + formatMoney(result.subtotal));
                } else {
                    showAlert('danger', result.message || 'Erro ao adicionar consumo');
                }
            },
            error: function(xhr) { showAlert('danger', 'Erro ao adicionar consumo'); }
        });
    });

    // Detalhes
    window.viewDetails = function(idCheckin) {
        $.ajax({
            url: contextPath + '/Admin/check/detalhes',
            method: 'GET',
            data: { id_checkin: idCheckin },
            dataType: 'json',
            success: function(data) {
                $('#detCliente').html(data.cliente_nome || "-");
                $('#detQuarto').html((data.numero_quarto || "") + " - " + (data.quarto_tipo || ""));
                $('#detCheckin').html(formatDateTime(data.data_checkin));
                $('#detSaida').html(formatDate(data.data_saida_prevista));
                $('#detHospedes').html(data.quantidade_hospedes || "-");
                $('#detConsumo').html(formatMoney(data.consumo_total || 0));
                $('#detObs').html(data.observacoes || "Nenhuma");
                new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
            },
            error: function(xhr) { showAlert('danger', 'Erro ao carregar detalhes'); }
        });
    };

    // Event listeners
    $('#searchPending').on('input', renderPending);
    $('#quartoFilter').on('change', renderPending);
    $('#searchHospedes').on('input', renderHospedes);
    $('#searchCheckout').on('input', renderCheckout);

    // Relógio e Copyright
    function updateClock() {
        var now = new Date();
        $('#horaAtual').html(now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
        $('#anoAtual').html(now.getFullYear());
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Inicializar
    loadServicos();
    carregarFiltroQuartos();
    renderPending();
    renderHospedes();
    renderCheckout();
    loadStats();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>