<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Quartos · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 280px;
            height: 100vh;
            background: #0B2B40;
            color: #E8E8E8;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 15px rgba(0, 0, 0, 0.08);
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 184, 0, 0.2);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFB800;
            margin-bottom: 12px;
            object-fit: cover;
            background: #0B2B40;
        }
        .sidebar .profile h3 {
            font-size: 1.15rem;
            font-weight: 600;
            color: #FFB800;
        }
        .sidebar .profile p {
            font-size: 0.75rem;
            opacity: 0.7;
            margin: 0;
        }
        .sidebar ul {
            list-style: none;
            padding: 0 16px;
        }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255, 184, 0, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active a { color: #0B2B40; }
        .sidebar li a {
            color: #E8E8E8;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
        }
        .sidebar .menu-section {
            color: #FFB800;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper {
            margin-left: 280px;
            height: 100vh;
            overflow-y: auto;
            padding: 20px 28px;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area img { height: 45px; width: auto; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }
        .btn-primary-custom {
            background: #FFB800;
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: #0B2B40;
            transition: all 0.2s;
        }
        .btn-primary-custom:hover {
            background: #0B2B40;
            color: #FFB800;
            transform: translateY(-2px);
        }
        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 16px 24px;
            margin-bottom: 24px;
            border: 1px solid #E2EAEF;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #F0F4F8;
            padding: 8px 16px;
            border-radius: 40px;
        }
        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            width: 250px;
        }
        .filter-select {
            padding: 8px 16px;
            border-radius: 40px;
            border: 1px solid #E2EAEF;
            background: white;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 16px;
            border: 1px solid #E2EAEF;
            transition: all 0.2s;
        }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 {
            font-size: 0.7rem;
            color: #8AA6B5;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .stat-card .value {
            font-size: 1.6rem;
            font-weight: 700;
            color: #0B2B40;
        }
        .table-container {
            background: white;
            border-radius: 20px;
            padding: 20px;
            border: 1px solid #E2EAEF;
        }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th {
            border-bottom: 2px solid #FFB800;
            color: #0B2B40;
            font-weight: 600;
            padding: 12px 8px;
        }
        .table td { padding: 12px 8px; vertical-align: middle; }
        .badge-estado {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 500;
        }
        .badge-estado.LIVRE { background: #E8F5E9; color: #2E7D32; }
        .badge-estado.OCUPADO { background: #FFEBEE; color: #D9534F; }
        .badge-estado.RESERVADO { background: #FFF8E1; color: #F57C00; }
        .badge-estado.MANUTENCAO { background: #E3F2FD; color: #1976D2; }
        .badge-estado.LIMPEZA { background: #F3E5F5; color: #7B1FA2; }
        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 5px;
            border-radius: 8px;
            transition: all 0.2s;
        }
        .action-btn.edit { color: #FFB800; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F0F4F8; transform: scale(1.1); }
        .pagination { margin-top: 20px; justify-content: flex-end; }
        .page-link { color: #0B2B40; border-radius: 8px; }
        .page-item.active .page-link {
            background: #FFB800;
            border-color: #FFB800;
            color: #0B2B40;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 20px;
            margin-top: 20px;
            border: 1px solid #E2EAEF;
        }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }
        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom {
            background: #0B2B40;
            color: white;
            border-radius: 24px 24px 0 0;
            padding: 20px 24px;
        }
        .detail-row { display: flex; padding: 12px 0; border-bottom: 1px solid #E2EAEF; }
        .detail-label { width: 130px; font-weight: 600; color: #0B2B40; }
        .detail-value { flex: 1; color: #6C8D9C; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E2EAEF;
            padding: 10px 14px;
        }
        .form-control-custom:focus, .form-select-custom:focus {
            border-color: #FFB800;
            box-shadow: 0 0 0 3px rgba(255, 184, 0, 0.1);
        }
        .nav-tabs-custom {
            border-bottom: 2px solid #E2EAEF;
            margin-bottom: 20px;
        }
        .nav-tabs-custom .nav-link {
            border: none;
            color: #6C8D9C;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 0;
        }
        .nav-tabs-custom .nav-link:hover {
            color: #FFB800;
            background: transparent;
        }
        .nav-tabs-custom .nav-link.active {
            color: #FFB800;
            border-bottom: 3px solid #FFB800;
            background: transparent;
        }
        @media (max-width: 1000px) {
            .sidebar { width: 250px; }
            .main-wrapper { margin-left: 250px; }
            .filters-bar { flex-direction: column; align-items: stretch; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>

    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in/out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs</a></li>
        <li ><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <img src="${pageContext.request.contextPath}/assets/images/logotipo.png" alt="Logotipo" onerror="this.src='https://placehold.co/45x45/0B2B40/FFB800?text=🏨'">
            <div class="logo-text">Sistema Hotelaria<span>Gestão de Quartos</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <!-- TABS: Quartos | Tipos de Quarto -->
    <ul class="nav nav-tabs nav-tabs-custom" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="quartos-tab" data-bs-toggle="tab" data-bs-target="#quartos" type="button" role="tab">
                <i class="bi bi-door-open"></i> Quartos
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="tipos-tab" data-bs-toggle="tab" data-bs-target="#tipos" type="button" role="tab">
                <i class="bi bi-tags"></i> Tipos de Quarto
            </button>
        </li>
    </ul>

    <div class="tab-content">
        <!-- TAB QUARTOS -->
        <div class="tab-pane fade show active" id="quartos" role="tabpanel">
            <!-- Cards Estatísticos -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h4><i class="bi bi-building"></i> Total Quartos</h4>
                    <div class="value" id="totalQuartos">0</div>
                </div>
                <div class="stat-card">
                    <h4><i class="bi bi-door-open"></i> Livres</h4>
                    <div class="value" id="totalLivres">0</div>
                </div>
                <div class="stat-card">
                    <h4><i class="bi bi-person-fill"></i> Ocupados</h4>
                    <div class="value" id="totalOcupados">0</div>
                </div>
                <div class="stat-card">
                    <h4><i class="bi bi-percent"></i> Taxa Ocupação</h4>
                    <div class="value" id="taxaOcupacao">0%</div>
                </div>
            </div>

            <!-- Barra de Filtros Quartos -->
            <div class="filters-bar">
                <div class="search-box">
                    <i class="bi bi-search"></i>
                    <input type="text" id="searchInput" placeholder="Buscar por número ou tipo...">
                </div>
                <div>
                    <select class="filter-select" id="estadoFilter">
                        <option value="">Todos os estados</option>
                        <option value="LIVRE">LIVRE</option>
                        <option value="OCUPADO">OCUPADO</option>
                        <option value="RESERVADO">RESERVADO</option>
                        <option value="MANUTENCAO">MANUTENÇÃO</option>
                        <option value="LIMPEZA">LIMPEZA</option>
                    </select>
                </div>
                <button class="btn-primary-custom rounded-pill" data-bs-toggle="modal" data-bs-target="#modalQuarto">
                    <i class="bi bi-plus-lg"></i> Novo Quarto
                </button>
            </div>

            <!-- Tabela de Quartos -->
            <div class="table-container">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Nº Quarto</th>
                                <th>Tipo</th>
                                <th>Piso</th>
                                <th>Diária (MZN)</th>
                                <th>Estado</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody id="quartosTableBody">
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <div class="spinner-border text-warning" role="status">
                                        <span class="visually-hidden">Carregando...</span>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div id="infoRegistrosQuartos" class="text-muted small"></div>
                    <nav>
                        <ul class="pagination pagination-sm mb-0" id="paginationQuartos"></ul>
                    </nav>
                </div>
            </div>
        </div>

        <!-- TAB TIPOS DE QUARTO -->
        <div class="tab-pane fade" id="tipos" role="tabpanel">
            <!-- Cards Estatísticos Tipos -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h4><i class="bi bi-tags"></i> Total Tipos</h4>
                    <div class="value" id="totalTipos">0</div>
                </div>
                <div class="stat-card">
                    <h4><i class="bi bi-currency-dollar"></i> Preço Médio</h4>
                    <div class="value" id="precoMedio">0 MZN</div>
                </div>
                <div class="stat-card">
                    <h4><i class="bi bi-star-fill"></i> Mais Caro</h4>
                    <div class="value" id="maisCaro">0 MZN</div>
                </div>
                <div class="stat-card">
                    <h4><i class="bi bi-arrow-trend-down"></i> Mais Barato</h4>
                    <div class="value" id="maisBarato">0 MZN</div>
                </div>
            </div>

            <!-- Barra de Filtros Tipos -->
            <div class="filters-bar">
                <div class="search-box">
                    <i class="bi bi-search"></i>
                    <input type="text" id="searchTipoInput" placeholder="Buscar por tipo...">
                </div>
                <div></div>
                <button class="btn-primary-custom rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTipoQuarto">
                    <i class="bi bi-plus-lg"></i> Novo Tipo de Quarto
                </button>
            </div>

            <!-- Tabela de Tipos de Quarto -->
            <div class="table-container">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Nome do Tipo</th>
                                <th>Descrição</th>
                                <th>Preço Diária (MZN)</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody id="tiposTableBody">
                            <tr>
                                <td colspan="4" class="text-center py-4">
                                    <div class="spinner-border text-warning" role="status">
                                        <span class="visually-hidden">Carregando...</span>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div id="infoRegistrosTipos" class="text-muted small"></div>
                    <nav>
                        <ul class="pagination pagination-sm mb-0" id="paginationTipos"></ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p>
    </div>
</div>

<!-- MODAL: Novo/Editar Quarto -->
<div class="modal fade modal-custom" id="modalQuarto" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-door-open"></i> Novo Quarto</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formQuarto">
                    <input type="hidden" id="editId" value="0">
                    <div class="mb-3">
                        <label class="form-label">Número do Quarto <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-custom" id="numeroQuarto" required placeholder="Ex: 101, 204, 312">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tipo de Quarto <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="idTipoQuarto" required>
                            <option value="">Selecione</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Piso</label>
                        <input type="number" class="form-control form-control-custom" id="piso" placeholder="Ex: 1, 2, 3">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Estado</label>
                        <select class="form-select form-select-custom" id="estado">
                            <option value="LIVRE">LIVRE</option>
                            <option value="OCUPADO">OCUPADO</option>
                            <option value="RESERVADO">RESERVADO</option>
                            <option value="MANUTENCAO">MANUTENÇÃO</option>
                            <option value="LIMPEZA">LIMPEZA</option>
                        </select>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-secondary rounded-pill" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary rounded-pill" style="background: #FFB800; border: none; color: #0B2B40;">Salvar Quarto</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Quarto -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Quarto</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Número:</div><div class="detail-value" id="detailNumero">-</div></div>
                <div class="detail-row"><div class="detail-label">Tipo:</div><div class="detail-value" id="detailTipo">-</div></div>
                <div class="detail-row"><div class="detail-label">Piso:</div><div class="detail-value" id="detailPiso">-</div></div>
                <div class="detail-row"><div class="detail-label">Diária:</div><div class="detail-value" id="detailDiaria">-</div></div>
                <div class="detail-row"><div class="detail-label">Estado:</div><div class="detail-value" id="detailEstado">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                <button class="btn-primary-custom rounded-pill" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Novo/Editar Tipo de Quarto -->
<div class="modal fade modal-custom" id="modalTipoQuarto" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-tag"></i> Tipo de Quarto</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formTipoQuarto">
                    <input type="hidden" id="editTipoId" value="0">
                    <div class="mb-3">
                        <label class="form-label">Nome do Tipo <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-custom" id="nomeTipo" required placeholder="Ex: Standard, Luxo, Família, Master">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Descrição</label>
                        <textarea class="form-control form-control-custom" id="descricaoTipo" rows="3" placeholder="Descrição do tipo de quarto..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Preço Diária (MZN) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control form-control-custom" id="precoDiariaTipo" step="0.01" required placeholder="0.00">
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-secondary rounded-pill" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary rounded-pill" style="background: #FFB800; border: none; color: #0B2B40;">Salvar Tipo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // ============================================
    // VARIÁVEIS GLOBAIS
    // ============================================
    let currentPageQuartos = 1;
    let totalPagesQuartos = 1;
    let currentSearchQuartos = '';
    let currentEstado = '';
    let todosQuartos = [];

    let currentPageTipos = 1;
    let totalPagesTipos = 1;
    let currentSearchTipos = '';
    let todosTipos = [];

    // ============================================
    // FUNÇÕES AUXILIARES
    // ============================================
    function formatarMoeda(valor) {
        if (!valor && valor !== 0) return '0 MZN';
        return valor.toLocaleString('pt-PT', { style: 'currency', currency: 'MZN' });
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    // ============================================
    // GESTÃO DE QUARTOS
    // ============================================
    function carregarTiposQuartoSelect() {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/quartos/tipos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                let tipos = data.tipos || [];
                let select = $('#idTipoQuarto');
                select.html('<option value="">Selecione o tipo</option>');
                $.each(tipos, function(i, t) {
                    select.append('<option value="' + t.idTipoQuarto + '">' + escapeHtml(t.nomeTipo) + ' - ' + formatarMoeda(t.precoDiaria) + '/diária</option>');
                });
            },
            error: function(xhr) {
                console.error('Erro ao carregar tipos:', xhr.responseText);
            }
        });
    }

    function carregarQuartos() {
        console.log("🔄 Carregando quartos...");
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/quartos/listar',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data && data.quartos) {
                    todosQuartos = data.quartos;
                    console.log("📊 Quartos carregados:", todosQuartos.length);
                    atualizarStatsQuartos();
                    aplicarFiltrosQuartos();
                } else {
                    todosQuartos = [];
                    $('#quartosTableBody').html('<td><td colspan="6" class="text-center py-4">⚠️ Nenhum quarto encontrado</td></tr>');
                }
            },
            error: function(xhr) {
                console.error('❌ Erro ao carregar quartos:', xhr.responseText);
                $('#quartosTableBody').html('<tr><td colspan="6" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
                Swal.fire('Erro', 'Não foi possível carregar os quartos', 'error');
            }
        });
    }

    function atualizarStatsQuartos() {
        let total = todosQuartos.length;
        let livres = 0, ocupados = 0;
        for (let i = 0; i < todosQuartos.length; i++) {
            if (todosQuartos[i].estado === 'LIVRE') livres++;
            if (todosQuartos[i].estado === 'OCUPADO') ocupados++;
        }
        let taxa = total > 0 ? Math.round((ocupados / total) * 100) : 0;
        $('#totalQuartos').text(total);
        $('#totalLivres').text(livres);
        $('#totalOcupados').text(ocupados);
        $('#taxaOcupacao').text(taxa + '%');
    }

    function aplicarFiltrosQuartos() {
        let filtrados = [...todosQuartos];

        if (currentSearchQuartos) {
            filtrados = filtrados.filter(q =>
                q.numeroQuarto.toLowerCase().includes(currentSearchQuartos) ||
                (q.tipoQuarto && q.tipoQuarto.toLowerCase().includes(currentSearchQuartos))
            );
        }

        if (currentEstado) {
            filtrados = filtrados.filter(q => q.estado === currentEstado);
        }

        const limit = 10;
        totalPagesQuartos = Math.ceil(filtrados.length / limit);
        if (totalPagesQuartos === 0) totalPagesQuartos = 1;
        if (currentPageQuartos > totalPagesQuartos) currentPageQuartos = totalPagesQuartos;

        const start = (currentPageQuartos - 1) * limit;
        const paginados = filtrados.slice(start, start + limit);

        renderizarTabelaQuartos(paginados);
        renderizarPaginacaoQuartos();
        $('#infoRegistrosQuartos').html('Mostrando ' + paginados.length + ' de ' + filtrados.length + ' registros');
    }

    function renderizarTabelaQuartos(quartos) {
        let html = '';
        if (quartos.length === 0) {
            html = '<tr><td colspan="6" class="text-center py-4">Nenhum quarto encontrado</td></tr>';
        } else {
            for (let i = 0; i < quartos.length; i++) {
                let q = quartos[i];
                html += '<tr>' +
                    '<td><strong>' + escapeHtml(q.numeroQuarto) + '</strong></td>' +
                    '<td>' + escapeHtml(q.tipoQuarto) + '</td>' +
                    '<td>' + (q.piso ? q.piso + 'º' : '-') + '</td>' +
                    '<td>' + formatarMoeda(q.precoDiaria) + '</td>' +
                    '<td><span class="badge-estado ' + q.estado + '">' + q.estado + '</span></td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" onclick="editarQuarto(' + q.idQuarto + ')" title="Editar"><i class="bi bi-pencil"></i></button>' +
                        '<button class="action-btn view" onclick="verDetalhesQuarto(' + q.idQuarto + ')" title="Detalhes"><i class="bi bi-eye"></i></button>' +
                    '</td>' +
                '</tr>';
            }
        }
        $('#quartosTableBody').html(html);
    }

    function renderizarPaginacaoQuartos() {
        let html = '';
        if (currentPageQuartos > 1) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPaginaQuartos(' + (currentPageQuartos - 1) + ')">«</a></li>';
        }
        for (let i = 1; i <= totalPagesQuartos; i++) {
            if (i === 1 || i === totalPagesQuartos || (i >= currentPageQuartos - 2 && i <= currentPageQuartos + 2)) {
                let activeClass = (i === currentPageQuartos) ? 'active' : '';
                html += '<li class="page-item ' + activeClass + '"><a class="page-link" href="#" onclick="mudarPaginaQuartos(' + i + ')">' + i + '</a></li>';
            } else if (i === currentPageQuartos - 3 || i === currentPageQuartos + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPageQuartos < totalPagesQuartos) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPaginaQuartos(' + (currentPageQuartos + 1) + ')">»</a></li>';
        }
        $('#paginationQuartos').html(html);
    }

    function mudarPaginaQuartos(page) {
        currentPageQuartos = page;
        aplicarFiltrosQuartos();
    }

    function editarQuarto(id) {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/quartos/editar',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(quarto) {
                if (!quarto || quarto.error) {
                    Swal.fire('Erro', 'Quarto não encontrado', 'error');
                    return;
                }
                $('#editId').val(quarto.idQuarto);
                $('#numeroQuarto').val(quarto.numeroQuarto);
                $('#idTipoQuarto').val(quarto.idTipoQuarto);
                $('#piso').val(quarto.piso || '');
                $('#estado').val(quarto.estado || 'LIVRE');

                $('#modalQuarto .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Quarto');
                new bootstrap.Modal(document.getElementById('modalQuarto')).show();
            },
            error: function(xhr) {
                console.error('Erro editar quarto:', xhr.responseText);
                Swal.fire('Erro', 'Não foi possível carregar os dados do quarto', 'error');
            }
        });
    }

    function verDetalhesQuarto(id) {
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/quartos/editar',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(quarto) {
                if (!quarto || quarto.error) {
                    Swal.fire('Erro', 'Quarto não encontrado', 'error');
                    return;
                }
                $('#detailNumero').html('<strong>' + escapeHtml(quarto.numeroQuarto) + '</strong>');
                $('#detailTipo').html(escapeHtml(quarto.tipoQuarto));
                $('#detailPiso').html(quarto.piso ? quarto.piso + 'º' : 'Não definido');
                $('#detailDiaria').html(formatarMoeda(quarto.precoDiaria));
                $('#detailEstado').html('<span class="badge-estado ' + quarto.estado + '">' + quarto.estado + '</span>');
                new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
            },
            error: function(xhr) {
                console.error('Erro detalhes:', xhr.responseText);
                Swal.fire('Erro', 'Não foi possível carregar os detalhes', 'error');
            }
        });
    }

    // Form Submit Quarto
    $('#formQuarto').on('submit', function(e) {
        e.preventDefault();

        let id = $('#editId').val();
        let numeroQuarto = $('#numeroQuarto').val().trim();
        let idTipoQuarto = $('#idTipoQuarto').val();
        let piso = $('#piso').val();
        let estado = $('#estado').val();

        if (!numeroQuarto) {
            Swal.fire('Atenção', 'Número do quarto é obrigatório', 'warning');
            return;
        }
        if (!idTipoQuarto) {
            Swal.fire('Atenção', 'Selecione o tipo de quarto', 'warning');
            return;
        }

        let btnSalvar = $(this).find('button[type="submit"]');
        btnSalvar.prop('disabled', true).text('Salvando...');

        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/quartos/salvar',
            method: 'POST',
            data: {
                id: id,
                numeroQuarto: numeroQuarto,
                idTipoQuarto: idTipoQuarto,
                piso: piso,
                estado: estado
            },
            dataType: 'json',
            success: function(response) {
                btnSalvar.prop('disabled', false).text('Salvar Quarto');
                if (response && response.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalQuarto')).hide();
                    Swal.fire('Sucesso', 'Quarto salvo com sucesso!', 'success');
                    $('#formQuarto')[0].reset();
                    $('#editId').val('0');
                    $('#modalQuarto .modal-title').html('<i class="bi bi-door-open"></i> Novo Quarto');
                    carregarQuartos();
                    carregarTiposQuartoSelect();
                } else {
                    Swal.fire('Erro', (response && response.message) || 'Erro ao salvar quarto', 'error');
                }
            },
            error: function(xhr) {
                btnSalvar.prop('disabled', false).text('Salvar Quarto');
                console.error('Erro:', xhr.responseText);
                Swal.fire('Erro', 'Erro ao salvar quarto', 'error');
            }
        });
    });

    $('#modalQuarto').on('hidden.bs.modal', function() {
        $('#formQuarto')[0].reset();
        $('#editId').val('0');
        $('#modalQuarto .modal-title').html('<i class="bi bi-door-open"></i> Novo Quarto');
    });

    // ============================================
    // GESTÃO DE TIPOS DE QUARTO
    // ============================================
    function carregarTiposQuarto() {
        console.log("🔄 Carregando tipos de quarto...");
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/quartos/tipos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data && data.tipos) {
                    todosTipos = data.tipos;
                    console.log("📊 Tipos carregados:", todosTipos.length);
                    atualizarStatsTipos();
                    aplicarFiltrosTipos();
                } else {
                    todosTipos = [];
                    $('#tiposTableBody').html('<tr><td colspan="4" class="text-center py-4">⚠️ Nenhum tipo encontrado<html><td>');
                }
            },
            error: function(xhr) {
                console.error('❌ Erro ao carregar tipos:', xhr.responseText);
                $('#tiposTableBody').html('<tr><td colspan="4" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
            }
        });
    }

    function atualizarStatsTipos() {
        let total = todosTipos.length;
        let somaPrecos = 0;
        let maiorPreco = 0;
        let menorPreco = Infinity;

        for (let i = 0; i < todosTipos.length; i++) {
            let preco = todosTipos[i].precoDiaria;
            somaPrecos += preco;
            if (preco > maiorPreco) maiorPreco = preco;
            if (preco < menorPreco) menorPreco = preco;
        }

        let precoMedio = total > 0 ? somaPrecos / total : 0;

        $('#totalTipos').text(total);
        $('#precoMedio').text(formatarMoeda(precoMedio));
        $('#maisCaro').text(formatarMoeda(maiorPreco));
        $('#maisBarato').text(formatarMoeda(menorPreco === Infinity ? 0 : menorPreco));
    }

    function aplicarFiltrosTipos() {
        let filtrados = [...todosTipos];

        if (currentSearchTipos) {
            filtrados = filtrados.filter(t =>
                t.nomeTipo.toLowerCase().includes(currentSearchTipos) ||
                (t.descricao && t.descricao.toLowerCase().includes(currentSearchTipos))
            );
        }

        const limit = 10;
        totalPagesTipos = Math.ceil(filtrados.length / limit);
        if (totalPagesTipos === 0) totalPagesTipos = 1;
        if (currentPageTipos > totalPagesTipos) currentPageTipos = totalPagesTipos;

        const start = (currentPageTipos - 1) * limit;
        const paginados = filtrados.slice(start, start + limit);

        renderizarTabelaTipos(paginados);
        renderizarPaginacaoTipos();
        $('#infoRegistrosTipos').html('Mostrando ' + paginados.length + ' de ' + filtrados.length + ' registros');
    }

    // TABELA DE TIPOS - SEM COLUNA ID
    function renderizarTabelaTipos(tipos) {
        let html = '';
        if (tipos.length === 0) {
            html = '<tr><td colspan="4" class="text-center py-4">Nenhum tipo encontrado</td></tr>';
        } else {
            for (let i = 0; i < tipos.length; i++) {
                let t = tipos[i];
                html += '<tr>' +
                    '<td><strong>' + escapeHtml(t.nomeTipo) + '</strong></td>' +
                    '<td>' + (t.descricao ? escapeHtml(t.descricao.substring(0, 50)) : '-') + (t.descricao && t.descricao.length > 50 ? '...' : '') + '</td>' +
                    '<td class="text-end">' + formatarMoeda(t.precoDiaria) + '</td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" onclick="editarTipoQuarto(' + t.idTipoQuarto + ')" title="Editar"><i class="bi bi-pencil"></i></button>' +
                    '</td>' +
                '</tr>';
            }
        }
        $('#tiposTableBody').html(html);
    }

    function renderizarPaginacaoTipos() {
        let html = '';
        if (currentPageTipos > 1) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPaginaTipos(' + (currentPageTipos - 1) + ')">«</a></li>';
        }
        for (let i = 1; i <= totalPagesTipos; i++) {
            if (i === 1 || i === totalPagesTipos || (i >= currentPageTipos - 2 && i <= currentPageTipos + 2)) {
                let activeClass = (i === currentPageTipos) ? 'active' : '';
                html += '<li class="page-item ' + activeClass + '"><a class="page-link" href="#" onclick="mudarPaginaTipos(' + i + ')">' + i + '</a></li>';
            } else if (i === currentPageTipos - 3 || i === currentPageTipos + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPageTipos < totalPagesTipos) {
            html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPaginaTipos(' + (currentPageTipos + 1) + ')">»</a></li>';
        }
        $('#paginationTipos').html(html);
    }

    function mudarPaginaTipos(page) {
        currentPageTipos = page;
        aplicarFiltrosTipos();
    }

   // ============================================
   // EDITAR TIPO DE QUARTO - URL CORRIGIDA
   // ============================================
   function editarTipoQuarto(id) {
       console.log("📝 Editando tipo ID:", id);

       $.ajax({
           url: '${pageContext.request.contextPath}/Admin/tipos-quarto/editar',  // ← URL CORRETA
           method: 'GET',
           data: { id: id },
           dataType: 'json',
           success: function(response) {
               console.log("✅ Resposta do servidor:", response);

               if (!response || response.error) {
                   Swal.fire('Erro', response?.error || 'Tipo não encontrado', 'error');
                   return;
               }

               // Preencher o formulário do modal com os dados
               $('#editTipoId').val(response.idTipoQuarto);
               $('#nomeTipo').val(response.nomeTipo);
               $('#descricaoTipo').val(response.descricao || '');
               $('#precoDiariaTipo').val(response.precoDiaria);

               // Mudar o título do modal
               $('#modalTipoQuarto .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Tipo de Quarto');

               // Abrir o modal
               new bootstrap.Modal(document.getElementById('modalTipoQuarto')).show();
           },
           error: function(xhr, status, error) {
               console.error('❌ Erro ao editar tipo:', error);
               console.error('Resposta:', xhr.responseText);
               Swal.fire('Erro', 'Não foi possível carregar os dados do tipo', 'error');
           }
       });
   }

    // SALVAR TIPO DE QUARTO - URL CORRIGIDA
    $('#formTipoQuarto').on('submit', function(e) {
        e.preventDefault();

        let id = $('#editTipoId').val();
        let nomeTipo = $('#nomeTipo').val().trim();
        let descricao = $('#descricaoTipo').val().trim();
        let precoDiaria = $('#precoDiariaTipo').val();

        if (!nomeTipo) {
            Swal.fire('Atenção', 'Nome do tipo é obrigatório', 'warning');
            return;
        }
        if (!precoDiaria || precoDiaria <= 0) {
            Swal.fire('Atenção', 'Preço diária é obrigatório e deve ser maior que zero', 'warning');
            return;
        }

        let btnSalvar = $(this).find('button[type="submit"]');
        btnSalvar.prop('disabled', true).text('Salvando...');

        // URL CORRETA para Tipo de Quarto
        $.ajax({
            url: '${pageContext.request.contextPath}/Admin/tipos-quarto/salvar',
            method: 'POST',
            data: {
                id: id,
                nomeTipo: nomeTipo,
                descricao: descricao,
                precoDiaria: precoDiaria
            },
            dataType: 'json',
            success: function(response) {
                btnSalvar.prop('disabled', false).text('Salvar Tipo');
                if (response && response.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalTipoQuarto')).hide();
                    Swal.fire('Sucesso', 'Tipo salvo com sucesso!', 'success');
                    $('#formTipoQuarto')[0].reset();
                    $('#editTipoId').val('0');
                    $('#modalTipoQuarto .modal-title').html('<i class="bi bi-tag"></i> Tipo de Quarto');
                    carregarTiposQuarto();
                    carregarTiposQuartoSelect();
                } else {
                    Swal.fire('Erro', (response && response.message) || 'Erro ao salvar tipo', 'error');
                }
            },
            error: function(xhr) {
                btnSalvar.prop('disabled', false).text('Salvar Tipo');
                console.error('Erro:', xhr.responseText);
                let errorMsg = 'Erro ao salvar tipo';
                try {
                    let resp = JSON.parse(xhr.responseText);
                    if (resp.message) errorMsg = resp.message;
                } catch(e) {}
                Swal.fire('Erro', errorMsg, 'error');
            }
        });
    });

    $('#modalTipoQuarto').on('hidden.bs.modal', function() {
        $('#formTipoQuarto')[0].reset();
        $('#editTipoId').val('0');
        $('#modalTipoQuarto .modal-title').html('<i class="bi bi-tag"></i> Tipo de Quarto');
    });

    // Filtros
    $('#searchInput').on('input', function() {
        currentSearchQuartos = $(this).val().toLowerCase();
        currentPageQuartos = 1;
        aplicarFiltrosQuartos();
    });

    $('#estadoFilter').on('change', function() {
        currentEstado = $(this).val();
        currentPageQuartos = 1;
        aplicarFiltrosQuartos();
    });

    $('#searchTipoInput').on('input', function() {
        currentSearchTipos = $(this).val().toLowerCase();
        currentPageTipos = 1;
        aplicarFiltrosTipos();
    });

    // Relógio
    function updateClock() {
        let now = new Date();
        $('#horaAtual').text(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').text(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
        $('#anoAtual').text(now.getFullYear());
    }

    setInterval(updateClock, 1000);
    updateClock();

    // Inicialização
    $(document).ready(function() {
        carregarTiposQuartoSelect();
        carregarTiposQuarto();
        carregarQuartos();
    });
</script>
</body>
</html>