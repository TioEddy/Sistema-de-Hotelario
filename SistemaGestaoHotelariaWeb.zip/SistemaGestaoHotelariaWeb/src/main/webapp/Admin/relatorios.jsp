<%-- /webapp/Admin/relatorios.jsp --%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios · Sistema Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #F0F4F8; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 280px; height: 100vh; background: #0B2B40; color: #E8E8E8; overflow-y: auto; z-index: 1000; box-shadow: 4px 0 15px rgba(0,0,0,0.08); }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.05); border-bottom: 1px solid rgba(255,184,0,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #FFB800; margin-bottom: 12px; object-fit: cover; background: #0B2B40; }
        .sidebar .profile h3 { font-size: 1.15rem; font-weight: 600; margin: 5px 0 2px; color: #FFB800; }
        .sidebar .profile p { font-size: 0.75rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.9rem; }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFB800; }
        .sidebar li:hover { background: rgba(255,184,0,0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFB800; color: #0B2B40; }
        .sidebar li.active i { color: #0B2B40; }
        .sidebar li a { color: #E8E8E8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #0B2B40; font-weight: 500; }
        .sidebar .menu-section { color: #FFB800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 280px; height: 100vh; overflow-y: auto; padding: 20px 28px; display: flex; flex-direction: column; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2EAEF; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 2rem; color: #FFB800; }
        .logo-text { font-size: 1.3rem; font-weight: 700; color: #0B2B40; }
        .logo-text span { font-weight: 300; font-size: 0.7rem; color: #6C8D9C; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.75rem; color: #8AA6B5; }
        .time { font-size: 0.95rem; font-weight: 600; color: #0B2B40; }

        .btn-primary-custom { background: #FFB800; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #0B2B40; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #0B2B40; color: #FFB800; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2EAEF; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #6C8D9C; }
        .btn-outline-custom:hover { border-color: #FFB800; color: #FFB800; }

        .filters-bar { background: white; border-radius: 20px; padding: 20px 24px; margin-bottom: 24px; border: 1px solid #E2EAEF; }
        .filter-group { display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end; }
        .filter-item { flex: 1; min-width: 150px; }
        .filter-item label { font-size: 0.7rem; font-weight: 600; color: #0B2B40; margin-bottom: 5px; display: block; text-transform: uppercase; }
        .filter-item input, .filter-item select { width: 100%; padding: 10px 14px; border-radius: 12px; border: 1px solid #E2EAEF; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 24px; }
        .stat-card { background: white; border-radius: 20px; padding: 16px; border: 1px solid #E2EAEF; transition: all 0.2s; }
        .stat-card:hover { border-color: #FFB800; }
        .stat-card h4 { font-size: 0.7rem; color: #8AA6B5; text-transform: uppercase; margin-bottom: 8px; }
        .stat-card .value { font-size: 1.6rem; font-weight: 700; color: #0B2B40; }

        .table-container { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; border: 1px solid #E2EAEF; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFB800; color: #0B2B40; font-weight: 600; padding: 12px 8px; }
        .table td { padding: 12px 8px; vertical-align: middle; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 6px 12px; border-radius: 30px; transition: all 0.2s; font-size: 0.75rem; }
        .action-btn.pdf { background: #D9534F; color: white; }
        .action-btn.csv { background: #2E7D32; color: white; }
        .action-btn:hover { transform: scale(1.05); opacity: 0.9; }

        .footer { text-align: center; padding: 20px; background: white; border-radius: 20px; margin-top: auto; border: 1px solid #E2EAEF; }
        .footer p { margin: 0; font-size: 0.75rem; color: #6C8D9C; }

        .relatorio-tabs { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }
        .tab-btn { padding: 12px 24px; border: none; background: white; border-radius: 40px; font-weight: 600; color: #6C8D9C; cursor: pointer; transition: all 0.2s; }
        .tab-btn.active { background: #FFB800; color: #0B2B40; }
        .tab-btn:hover:not(.active) { background: #E2EAEF; }

        @media (max-width: 1000px) { .sidebar { width: 250px; } .main-wrapper { margin-left: 250px; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
        @media print { .sidebar, .topbar, .filters-bar, .action-buttons, .tab-btn, .footer { display: none !important; } .main-wrapper { margin-left: 0 !important; padding: 0 !important; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.7rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>
    <div class="menu-section">PRINCIPAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/reservas"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/quartos"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/clientes"><i class="bi bi-people"></i> Clientes</a></li>
    </ul>
    <div class="menu-section">OPERAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/check"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/consumos"><i class="bi bi-cup-straw"></i> Consumo de Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/qr"><i class="bi bi-qr-code"></i> QR Code</a></li>
    </ul>
    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>
    <div class="menu-section">ADMINISTRAÇÃO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Admin/funcionarios"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/usuarios"><i class="bi bi-people-fill"></i> Usuários</a></li>
        <li><a href="${pageContext.request.contextPath}/Admin/logs"><i class="bi bi-journal-text"></i> Logs do Sistema</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Admin/relatorios"><i class="bi bi-graph-up"></i> Relatórios</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-building"></i><div class="logo-text">Sistema Hotelaria<span>Relatórios</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="relatorio-tabs">
        <button class="tab-btn active" data-tipo="faturas"><i class="bi bi-receipt"></i> Faturas</button>
        <button class="tab-btn" data-tipo="reservas"><i class="bi bi-calendar-week"></i> Reservas</button>
        <button class="tab-btn" data-tipo="ocupacao"><i class="bi bi-building"></i> Ocupação</button>
        <button class="tab-btn" data-tipo="clientes"><i class="bi bi-people"></i> Clientes</button>
        <button class="tab-btn" data-tipo="financeiro"><i class="bi bi-cash-stack"></i> Financeiro</button>
    </div>

    <div class="filters-bar" id="filtersBar">
        <div class="filter-group">
            <div class="filter-item">
                <label><i class="bi bi-calendar"></i> Data Início</label>
                <input type="text" id="dataInicio" class="datepicker" placeholder="dd/mm/yyyy">
            </div>
            <div class="filter-item">
                <label><i class="bi bi-calendar"></i> Data Fim</label>
                <input type="text" id="dataFim" class="datepicker" placeholder="dd/mm/yyyy">
            </div>
            <div class="filter-item" id="statusFilterItem" style="display: none;">
                <label><i class="bi bi-tags"></i> Status</label>
                <select id="statusFiltro">
                    <option value="TODOS">Todos</option>
                    <option value="PENDENTE">Pendente</option>
                    <option value="CONFIRMADA">Confirmada</option>
                    <option value="CANCELADA">Cancelada</option>
                    <option value="FINALIZADA">Finalizada</option>
                </select>
            </div>
            <div class="filter-item">
                <button class="btn-primary-custom" id="btnFiltrar"><i class="bi bi-search"></i> Filtrar</button>
                <button class="btn-outline-custom" id="btnLimpar"><i class="bi bi-arrow-repeat"></i> Limpar</button>
            </div>
            <div class="filter-item">
                <button class="action-btn pdf" id="btnExportarPDF"><i class="bi bi-file-pdf"></i> Exportar PDF</button>
                <button class="action-btn csv" id="btnExportarCSV"><i class="bi bi-filetype-csv"></i> Exportar CSV</button>
            </div>
        </div>
    </div>

    <div class="stats-grid" id="statsGrid">
        <div class="stat-card"><h4>Total Registros</h4><div class="value" id="statTotal">-</div></div>
        <div class="stat-card"><h4>Valor Total</h4><div class="value" id="statValor">-</div></div>
        <div class="stat-card"><h4>Média</h4><div class="value" id="statMedia">-</div></div>
        <div class="stat-card"><h4>Última Atualização</h4><div class="value" id="statData">-</div></div>
    </div>

    <div class="table-container">
        <div class="table-responsive">
            <table class="table table-hover" id="relatorioTable">
                <thead id="tableHeader">
                    <tr><th>Carregando...</th></tr>
                </thead>
                <tbody id="tableBody">
                    <tr><td colspan="10" class="text-center py-4"><div class="spinner-border text-warning"></div></td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema Hotelaria. Todos os direitos reservados.</p></div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let tipoAtual = 'faturas';

    function formatMoney(v) {
        if (v === undefined || v === null || isNaN(v)) return "0 MZN";
        return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " MZN";
    }

    function escapeHtml(s) {
        if (!s) return "";
        return s.replace(/[&<>]/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m;
        });
    }

    function updateClock() {
        var now = new Date();
        $('#horaAtual').html(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' }));
        $('#anoAtual').html(now.getFullYear());
    }
    setInterval(updateClock, 1000);
    updateClock();

    flatpickr(".datepicker", { dateFormat: "Y-m-d", locale: "pt", allowInput: true });

    function carregarStats() {
        $.ajax({
            url: contextPath + '/Admin/relatorios/stats',
            method: 'GET',
            data: { tipo: tipoAtual, dataInicio: $('#dataInicio').val(), dataFim: $('#dataFim').val() },
            dataType: 'json',
            success: function(d) {
                $('#statTotal').text(d.total || '0');
                $('#statValor').html(d.valor_total ? formatMoney(d.valor_total) : (d.ocupados ? d.ocupados + ' / ' + d.total_quartos : '-'));
                $('#statMedia').html(d.ticket_medio ? formatMoney(d.ticket_medio) : '-');
                $('#statData').text(new Date().toLocaleDateString('pt-PT'));
            },
            error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function carregarDados() {
        $.ajax({
            url: contextPath + '/Admin/relatorios/dados',
            method: 'GET',
            data: { tipo: tipoAtual, dataInicio: $('#dataInicio').val(), dataFim: $('#dataFim').val(), status: $('#statusFiltro').val() },
            dataType: 'json',
            success: function(data) {
                renderizarTabela(data);
                carregarStats();
            },
            error: function() {
                $('#tableBody').html('<tr><td colspan="10" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
            }
        });
    }

    function renderizarTabela(data) {
        var thead = $('#tableHeader');
        var tbody = $('#tableBody');
        tbody.empty();

        if (tipoAtual === 'faturas') {
            thead.html('<tr><th>ID</th><th>Nº Fatura</th><th>Cliente</th><th>Reserva</th><th>Subtotal</th><th>IVA (16%)</th><th>Total</th><th>Data Emissão</th></tr>');
            $.each(data, function(i, item) {
                tbody.append('<tr>' +
                    '<td>' + item.id + '</td>' +
                    '<td><strong>' + escapeHtml(item.numero) + '</strong></td>' +
                    '<td>' + escapeHtml(item.cliente) + '</td>' +
                    '<td>#' + item.reserva + '</td>' +
                    '<td>' + formatMoney(item.subtotal) + '</td>' +
                    '<td>' + formatMoney(item.iva) + '</td>' +
                    '<td><strong>' + formatMoney(item.total) + '</strong></td>' +
                    '<td>' + item.data + '</td>' +
                '</tr>');
            });
        } else if (tipoAtual === 'reservas') {
            thead.html('<tr><th>ID</th><th>Cliente</th><th>Quarto</th><th>Entrada</th><th>Saída</th><th>Hóspedes</th><th>Status</th><th>Data Reserva</th></tr>');
            $.each(data, function(i, item) {
                var statusClass = '';
                if (item.status === 'CONFIRMADA') statusClass = 'badge bg-success';
                else if (item.status === 'PENDENTE') statusClass = 'badge bg-warning';
                else if (item.status === 'CANCELADA') statusClass = 'badge bg-danger';
                else if (item.status === 'FINALIZADA') statusClass = 'badge bg-secondary';
                tbody.append('<tr>' +
                    '<td>' + item.id + '</td>' +
                    '<td>' + escapeHtml(item.cliente) + '</td>' +
                    '<td>' + escapeHtml(item.quarto) + '</td>' +
                    '<td>' + item.entrada + '</td>' +
                    '<td>' + item.saida + '</td>' +
                    '<td>' + item.hospedes + '</td>' +
                    '<td><span class="' + statusClass + '">' + item.status + '</span></td>' +
                    '<td>' + item.data_reserva + '</td>' +
                '</tr>');
            });
        } else if (tipoAtual === 'ocupacao') {
            thead.html('<tr><th>ID</th><th>Número</th><th>Tipo</th><th>Preço Diária</th><th>Estado</th></tr>');
            $.each(data, function(i, item) {
                var estadoClass = '';
                if (item.estado === 'OCUPADO') estadoClass = 'badge bg-danger';
                else if (item.estado === 'LIVRE') estadoClass = 'badge bg-success';
                else if (item.estado === 'RESERVADO') estadoClass = 'badge bg-warning';
                else if (item.estado === 'MANUTENCAO') estadoClass = 'badge bg-secondary';
                else estadoClass = 'badge bg-info';
                tbody.append('<tr>' +
                    '<td>' + item.id + '</td>' +
                    '<td><strong>' + escapeHtml(item.numero) + '</strong></td>' +
                    '<td>' + escapeHtml(item.tipo) + '</td>' +
                    '<td>' + formatMoney(item.preco) + '</td>' +
                    '<td><span class="' + estadoClass + '">' + item.estado + '</span></td>' +
                '</tr>');
            });
        } else if (tipoAtual === 'clientes') {
            thead.html('<tr><th>ID</th><th>Nome</th><th>Sexo</th><th>Telefone</th><th>Email</th><th>Nacionalidade</th><th>Data Registro</th></tr>');
            $.each(data, function(i, item) {
                tbody.append('<tr>' +
                    '<td>' + item.id + '</td>' +
                    '<td>' + escapeHtml(item.nome) + '</td>' +
                    '<td>' + (item.sexo || '-') + '</td>' +
                    '<td>' + (item.telefone || '-') + '</td>' +
                    '<td>' + (item.email || '-') + '</td>' +
                    '<td>' + (item.nacionalidade || '-') + '</td>' +
                    '<td>' + item.data_registro + '</td>' +
                '</tr>');
            });
        } else if (tipoAtual === 'financeiro') {
            thead.html('<tr><th colspan="2">Resumo Financeiro</th></tr>');
            if (data.length > 0) {
                var item = data[0];
                tbody.append('<tr><td><strong>Faturamento Total</strong></td><td>' + formatMoney(item.faturamento_total) + '</td></tr>' +
                    '<tr><td><strong>Total Recebido</strong></td><td>' + formatMoney(item.recebido_total) + '</td></tr>' +
                    '<tr><td><strong>Valor Pendente</strong></td><td>' + formatMoney(item.pendente_total) + '</td></tr>' +
                    '<tr><td><strong>Total de Faturas</strong></td><td>' + item.total_faturas + '</td></tr>' +
                    '<tr><td><strong>Total de Pagamentos</strong></td><td>' + item.total_pagamentos + '</td></tr>');
            } else {
                tbody.append('<tr><td colspan="2" class="text-center py-4">Nenhum dado financeiro encontrado</td></tr>');
            }
        }

        if (data.length === 0 && tipoAtual !== 'financeiro') {
            tbody.html('<tr><td colspan="10" class="text-center py-4">Nenhum registro encontrado</td></tr>');
        }
    }

    function exportarPDF() {
        var params = new URLSearchParams({
            tipo: tipoAtual,
            dataInicio: $('#dataInicio').val(),
            dataFim: $('#dataFim').val(),
            status: $('#statusFiltro').val()
        });
        window.open(contextPath + '/Admin/relatorios/pdf?' + params.toString(), '_blank');
    }

    function exportarCSV() {
        var params = new URLSearchParams({
            tipo: tipoAtual,
            dataInicio: $('#dataInicio').val(),
            dataFim: $('#dataFim').val(),
            status: $('#statusFiltro').val()
        });
        window.location.href = contextPath + '/Admin/relatorios/csv?' + params.toString();
    }

    $('.tab-btn').on('click', function() {
        $('.tab-btn').removeClass('active');
        $(this).addClass('active');
        tipoAtual = $(this).data('tipo');

        if (tipoAtual === 'reservas') {
            $('#statusFilterItem').show();
        } else {
            $('#statusFilterItem').hide();
        }

        carregarDados();
    });

    $('#btnFiltrar').on('click', function() { carregarDados(); });
    $('#btnLimpar').on('click', function() {
        $('#dataInicio').val('');
        $('#dataFim').val('');
        $('#statusFiltro').val('TODOS');
        carregarDados();
    });
    $('#btnExportarPDF').on('click', function() { exportarPDF(); });
    $('#btnExportarCSV').on('click', function() { exportarCSV(); });

    carregarDados();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>