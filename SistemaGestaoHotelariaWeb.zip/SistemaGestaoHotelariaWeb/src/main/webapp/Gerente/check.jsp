<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check-in / Check-out · Hotelaria Manager</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F5F0E8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #1A3C2C;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(212, 175, 55, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #D4AF37;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #D4AF37; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #D4AF37; }
        .sidebar li:hover { background: rgba(212, 175, 55, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #D4AF37; color: #1A3C2C; }
        .sidebar li.active i { color: #1A3C2C; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1A3C2C; font-weight: 500; }
        .sidebar .menu-section {
            color: #D4AF37;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper {
            margin-left: 270px;
            height: 100vh;
            overflow-y: auto;
            padding: 20px 28px;
            position: relative;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #D4AF37; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1A3C2C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1A3C2C; }
        .refresh-btn {
            background: #D4AF37;
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .refresh-btn:hover {
            background: #1A3C2C;
            color: #D4AF37;
            transform: rotate(90deg);
        }
        .btn-primary-custom {
            background: #D4AF37;
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: #1A3C2C;
            transition: all 0.2s;
        }
        .btn-primary-custom:hover {
            background: #1A3C2C;
            color: #D4AF37;
            transform: translateY(-2px);
        }
        .btn-outline-custom {
            background: transparent;
            border: 2px solid #E8DFC8;
            padding: 8px 20px;
            border-radius: 40px;
            font-weight: 500;
            color: #8B9A87;
        }
        .btn-outline-custom:hover {
            border-color: #D4AF37;
            color: #D4AF37;
        }
        .btn-success-custom {
            background: #2E7D32;
            border: none;
            padding: 6px 16px;
            border-radius: 30px;
            font-weight: 500;
            color: white;
            font-size: 0.75rem;
        }
        .btn-success-custom:hover { background: #1B5E20; }
        .btn-danger-custom {
            background: #C76A3C;
            border: none;
            padding: 6px 16px;
            border-radius: 30px;
            font-weight: 500;
            color: white;
            font-size: 0.75rem;
        }
        .btn-danger-custom:hover { background: #A0522D; }
        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 16px 24px;
            margin-bottom: 24px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #F5F0E8;
            padding: 8px 16px;
            border-radius: 40px;
        }
        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            width: 250px;
        }
        .filter-select {
            padding: 8px 16px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            transition: all 0.3s ease;
            border: 1px solid #E8DFC8;
            cursor: pointer;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            border-color: #D4AF37;
        }
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .stat-header h3 {
            font-size: 0.7rem;
            font-weight: 600;
            color: #8B9A87;
            text-transform: uppercase;
        }
        .stat-header i { font-size: 1.5rem; color: #D4AF37; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #1A3C2C; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .chart-box {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid #E8DFC8;
        }
        .chart-box h3 {
            font-size: 0.85rem;
            font-weight: 600;
            color: #1A3C2C;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .chart-box h3 i { color: #D4AF37; }
        .chart-container { position: relative; height: 180px; width: 100%; }
        .table-section {
            background: white;
            border-radius: 20px;
            padding: 18px 20px;
            border: 1px solid #E8DFC8;
            margin-bottom: 28px;
        }
        .table-section h3 {
            font-size: 0.85rem;
            font-weight: 600;
            color: #1A3C2C;
            margin-bottom: 18px;
        }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th {
            border-bottom: 2px solid #D4AF37;
            color: #1A3C2C;
            font-weight: 600;
            padding: 10px 6px;
        }
        .badge-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-status.checkin { background: #E8F5E9; color: #2E7D32; }
        .badge-status.pendente { background: #FFF8E1; color: #F57C00; }
        .badge-status.hospedado { background: #1A3C2C; color: #D4AF37; }
        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom {
            background: #1A3C2C;
            color: white;
            border-radius: 24px 24px 0 0;
            padding: 20px 24px;
        }
        .detail-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #E8DFC8;
        }
        .detail-label { width: 130px; font-weight: 600; color: #1A3C2C; }
        .detail-value { flex: 1; color: #8B9A87; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E8DFC8;
            padding: 10px 14px;
        }
        .form-control-custom:focus, .form-select-custom:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.3);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #E8DFC8;
            border-top-color: #D4AF37;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">OPERACIONAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/quarto.jsp"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Gerente/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS & CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/cliente.jsp"><i class="bi bi-people"></i> Clientes</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumo Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/fatura.jsp"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">EQUIPA</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/funcionario.jsp"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/turno.jsp"><i class="bi bi-clock-history"></i> Turnos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Manager<span>Check-in / Check-out</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
            <button class="refresh-btn" id="refreshBtn" title="Atualizar dados">
                <i class="bi bi-arrow-repeat"></i>
            </button>
        </div>
    </div>

    <!-- CARDS ESTATÍSTICOS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>CHECK-INS HOJE</h3><i class="bi bi-person-arms-up"></i></div>
            <div class="stat-value" id="checkinsHoje">--</div>
            <div class="stat-footer">Pendentes: <span id="pendentesHoje">--</span></div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>CHECK-OUTS HOJE</h3><i class="bi bi-luggage"></i></div>
            <div class="stat-value" id="checkoutsHoje">--</div>
            <div class="stat-footer">A realizar hoje</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>HÓSPEDES NO HOTEL</h3><i class="bi bi-people-fill"></i></div>
            <div class="stat-value" id="hospedesHotel">--</div>
            <div class="stat-footer">Check-in realizados</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>RESERVAS PENDENTES</h3><i class="bi bi-calendar-week"></i></div>
            <div class="stat-value" id="reservasPendentes">--</div>
            <div class="stat-footer">Aguardam check-in</div>
        </div>
    </div>

    <!-- GRÁFICOS -->
    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Check-ins por Período</h3>
            <div class="chart-container"><canvas id="checkinsPeriodoChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Ocupação por Tipo</h3>
            <div class="chart-container"><canvas id="ocupacaoTipoChart"></canvas></div>
        </div>
    </div>

    <!-- BARRA DE FILTROS -->
    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por cliente ou quarto...">
        </div>
        <div>
            <select class="filter-select" id="statusFilter">
                <option value="pendentes">Check-ins Pendentes</option>
                <option value="hospedados">Hóspedes no Hotel</option>
                <option value="checkouts">Check-outs Hoje</option>
            </select>
        </div>
    </div>

    <!-- TABELA DE CHECK-INS PENDENTES -->
    <div class="table-section" id="tabelaPendentes">
        <h3><i class="bi bi-clock-history"></i> Check-ins Pendentes (Hoje)</h3>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Cliente</th><th>Quarto</th><th>Entrada</th><th>Saída</th><th>Hóspedes</th><th>Ações</th></tr></thead>
                <tbody id="pendentesTableBody"><tr><td colspan="6" class="text-center py-4"><div class="loading-spinner" style="width:30px;height:30px;"></div> Carregando...</td></tr></tbody>
            </table>
        </div>
    </div>

    <!-- TABELA DE HÓSPEDES NO HOTEL -->
    <div class="table-section" id="tabelaHospedados" style="display: none;">
        <h3><i class="bi bi-people-fill"></i> Hóspedes no Hotel</h3>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Cliente</th><th>Quarto</th><th>Check-in</th><th>Saída Prevista</th><th>Hóspedes</th><th>Ações</th></tr></thead>
                <tbody id="hospedadosTableBody"><tr><td colspan="6" class="text-center py-4"><div class="loading-spinner" style="width:30px;height:30px;"></div> Carregando...</td></tr></tbody>
            </table>
        </div>
    </div>

    <!-- TABELA DE CHECK-OUTS HOJE -->
    <div class="table-section" id="tabelaCheckouts" style="display: none;">
        <h3><i class="bi bi-luggage"></i> Check-outs Hoje</h3>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Cliente</th><th>Quarto</th><th>Saída Prevista</th><th>Diárias</th><th>Consumo</th><th>Total</th><th>Ações</th></tr></thead>
                <tbody id="checkoutsTableBody"><tr><td colspan="7" class="text-center py-4"><div class="loading-spinner" style="width:30px;height:30px;"></div> Carregando...</td></tr></tbody>
            </table>
        </div>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema de Check-in/Check-out
    </div>
</div>

<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-spinner"></div>
</div>

<!-- MODAL: Realizar Check-in -->
<div class="modal fade modal-custom" id="modalCheckin" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-person-arms-up"></i> Realizar Check-in</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" id="checkinReservaId">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="modalCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="modalQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Período:</div><div class="detail-value" id="modalPeriodo">-</div></div>
                <div class="mb-3 mt-3">
                    <label class="form-label">Observações</label>
                    <textarea class="form-control form-control-custom" id="checkinObservacoes" rows="2" placeholder="Observações adicionais..."></textarea>
                </div>
                <hr>
                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn-primary-custom" id="confirmCheckinBtn">Confirmar Check-in</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Realizar Check-out -->
<div class="modal fade modal-custom" id="modalCheckout" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-luggage"></i> Realizar Check-out</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" id="checkoutId">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="checkoutCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="checkoutQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Período:</div><div class="detail-value" id="checkoutPeriodo">-</div></div>
                <div class="detail-row"><div class="detail-label">Diárias:</div><div class="detail-value" id="checkoutDiarias">-</div></div>
                <div class="detail-row"><div class="detail-label">Consumo extra:</div><div class="detail-value" id="checkoutConsumo">0 MZN</div></div>
                <div class="detail-row" style="background: #FFF8E1; margin-top: 10px; border-radius: 12px;">
                    <div class="detail-label"><strong>Valor Total:</strong></div>
                    <div class="detail-value"><strong id="checkoutTotal">0 MZN</strong></div>
                </div>
                <div class="mb-3 mt-3">
                    <label class="form-label">Observações do Check-out</label>
                    <textarea class="form-control form-control-custom" id="checkoutObservacoes" rows="2" placeholder="Observações..."></textarea>
                </div>
                <hr>
                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn-primary-custom" id="confirmCheckoutBtn">Confirmar Check-out</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let periodoChart = null;
    let ocupacaoChart = null;
    let currentFilter = 'pendentes';

    function showLoading() { $('#loadingOverlay').show(); }
    function hideLoading() { $('#loadingOverlay').hide(); }

    function formatDate(dateStr) {
        if (!dateStr) return '';
        var parts = dateStr.split('-');
        if (parts.length === 3) return parts[2] + '/' + parts[1] + '/' + parts[0];
        return dateStr;
    }

    function formatDateTime(dateTimeStr) {
        if (!dateTimeStr) return '';
        return dateTimeStr.replace('T', ' ').substring(0, 16);
    }

    function formatMoney(v) {
        if (v === undefined || v === null || isNaN(v)) return "0 MZN";
        return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    // ==================== CARREGAR STATS ====================
    function loadStats() {
        $.ajax({
            url: contextPath + '/Gerente/api/check/stats',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                $('#checkinsHoje').text(data.checkins_hoje || 0);
                $('#pendentesHoje').text(data.pendentes_hoje || 0);
                $('#checkoutsHoje').text(data.checkouts_hoje || 0);
                $('#hospedesHotel').text(data.hospedes_hotel || 0);
                $('#reservasPendentes').text(data.reservas_pendentes || 0);
            },
            error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    // ==================== CARREGAR GRÁFICOS ====================
    function loadGraficos() {
        $.ajax({
            url: contextPath + '/Gerente/api/check/graficos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                // Gráfico de check-ins por hora
                if (periodoChart) periodoChart.destroy();
                var horas = data.checkins_por_hora || [];
                periodoChart = new Chart(document.getElementById('checkinsPeriodoChart'), {
                    type: 'bar',
                    data: {
                        labels: horas.map(function(h) { return h.hora + 'h'; }),
                        datasets: [{
                            label: 'Check-ins',
                            data: horas.map(function(h) { return h.total; }),
                            backgroundColor: '#D4AF37',
                            borderRadius: 8
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: { y: { beginAtZero: true } },
                        plugins: { legend: { display: false } }
                    }
                });

                // Gráfico de ocupação por tipo
                if (ocupacaoChart) ocupacaoChart.destroy();
                var tipos = data.ocupacao_por_tipo || [];
                ocupacaoChart = new Chart(document.getElementById('ocupacaoTipoChart'), {
                    type: 'bar',
                    data: {
                        labels: tipos.map(function(t) { return t.tipo; }),
                        datasets: [
                            { label: 'Ocupados', data: tipos.map(function(t) { return t.ocupados; }), backgroundColor: '#C76A3C', borderRadius: 6 },
                            { label: 'Livres', data: tipos.map(function(t) { return t.livres; }), backgroundColor: '#2E7D32', borderRadius: 6 }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: { y: { beginAtZero: true } }
                    }
                });
            },
            error: function() { console.error('Erro ao carregar gráficos'); }
        });
    }

    // ==================== CARREGAR CHECK-INS PENDENTES ====================
    function loadPendentes() {
        $.ajax({
            url: contextPath + '/Gerente/api/check/pendentes',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#pendentesTableBody');
                tbody.empty();
                var search = $('#searchInput').val().toLowerCase();

                var filtered = data.filter(function(r) {
                    return search === '' || r.cliente_nome.toLowerCase().indexOf(search) !== -1 || r.quarto_num.toLowerCase().indexOf(search) !== -1;
                });

                if (filtered.length === 0) {
                    tbody.html('<tr><td colspan="6" class="text-center py-4">Nenhum check-in pendente</td></tr>');
                    return;
                }

                for (var i = 0; i < filtered.length; i++) {
                    var r = filtered[i];
                    var row = '<tr>' +
                        '<td><strong>' + escapeHtml(r.cliente_nome) + '</strong></td>' +
                        '<td>' + escapeHtml(r.quarto_num) + '</td>' +
                        '<td>' + formatDate(r.data_entrada) + '</td>' +
                        '<td>' + formatDate(r.data_saida) + '</td>' +
                        '<td class="text-center">' + r.numero_hospedes + '</td>' +
                        '<td><button class="btn-success-custom" onclick="openCheckinModal(' + r.id_reserva + ')"><i class="bi bi-person-check"></i> Check-in</button></td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#pendentesTableBody').html('<tr><td colspan="6" class="text-center py-4 text-danger">Erro ao carregar dados</td></tr>');
            }
        });
    }

    // ==================== CARREGAR HÓSPEDES ====================
    function loadHospedados() {
        $.ajax({
            url: contextPath + '/Gerente/api/check/hospedados',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#hospedadosTableBody');
                tbody.empty();
                var search = $('#searchInput').val().toLowerCase();

                var filtered = data.filter(function(c) {
                    return search === '' || c.cliente_nome.toLowerCase().indexOf(search) !== -1 || c.quarto_num.toLowerCase().indexOf(search) !== -1;
                });

                if (filtered.length === 0) {
                    tbody.html('<tr><td colspan="6" class="text-center py-4">Nenhum hóspede no hotel</td></tr>');
                    return;
                }

                for (var i = 0; i < filtered.length; i++) {
                    var c = filtered[i];
                    var row = '<td>' +
                        '<td><strong>' + escapeHtml(c.cliente_nome) + '</strong></td>' +
                        '<td>' + escapeHtml(c.quarto_num) + '</td>' +
                        '<td>' + formatDateTime(c.data_checkin) + '</td>' +
                        '<td>' + formatDate(c.data_saida_prevista) + '</td>' +
                        '<td class="text-center">' + c.quantidade_hospedes + '</td>' +
                        '<td class="action-buttons">' +
                            '<button class="btn-danger-custom" onclick="openCheckoutModal(' + c.id_checkin + ')"><i class="bi bi-luggage"></i> Check-out</button>' +
                        '</td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#hospedadosTableBody').html('<tr><td colspan="6" class="text-center py-4 text-danger">Erro ao carregar dados</td></tr>');
            }
        });
    }

    // ==================== CARREGAR CHECK-OUTS ====================
    function loadCheckouts() {
        $.ajax({
            url: contextPath + '/Gerente/api/check/checkouts',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#checkoutsTableBody');
                tbody.empty();
                var search = $('#searchInput').val().toLowerCase();

                var filtered = data.filter(function(c) {
                    return search === '' || c.cliente_nome.toLowerCase().indexOf(search) !== -1 || c.quarto_num.toLowerCase().indexOf(search) !== -1;
                });

                if (filtered.length === 0) {
                    tbody.html('<tr><td colspan="7" class="text-center py-4">Nenhum check-out para hoje</td></tr>');
                    return;
                }

                for (var i = 0; i < filtered.length; i++) {
                    var c = filtered[i];
                    var row = '<td>' +
                        '<td><strong>' + escapeHtml(c.cliente_nome) + '</strong></td>' +
                        '<td>' + escapeHtml(c.quarto_num) + '</td>' +
                        '<td>' + formatDate(c.data_saida_prevista) + '</td>' +
                        '<td class="text-center">' + c.diarias + ' diárias</td>' +
                        '<td>' + formatMoney(c.consumo_total) + '</td>' +
                        '<td><strong>' + formatMoney(c.total) + '</strong></td>' +
                        '<td class="action-buttons">' +
                            '<button class="btn-danger-custom" onclick="openCheckoutModal(' + c.id_checkin + ')"><i class="bi bi-check2-circle"></i> Finalizar</button>' +
                        '</td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#checkoutsTableBody').html('<td><td colspan="7" class="text-center py-4 text-danger">Erro ao carregar dados</td></tr>');
            }
        });
    }

    // ==================== REALIZAR CHECK-IN ====================
    function openCheckinModal(reservaId) {
        $.ajax({
            url: contextPath + '/Gerente/api/check/reserva-detalhes',
            method: 'GET',
            data: { id: reservaId },
            dataType: 'json',
            success: function(data) {
                $('#checkinReservaId').val(data.id_reserva);
                $('#modalCliente').html('<strong>' + escapeHtml(data.cliente_nome) + '</strong>');
                $('#modalQuarto').html(data.quarto_num);
                $('#modalPeriodo').html(formatDate(data.data_entrada) + ' a ' + formatDate(data.data_saida));
                $('#checkinObservacoes').val(data.observacoes || '');
                new bootstrap.Modal(document.getElementById('modalCheckin')).show();
            },
            error: function() {
                Swal.fire('Erro', 'Não foi possível carregar os dados da reserva', 'error');
            }
        });
    }

    $('#confirmCheckinBtn').on('click', function() {
        showLoading();
        var reservaId = $('#checkinReservaId').val();
        var observacoes = $('#checkinObservacoes').val();

        $.ajax({
            url: contextPath + '/Gerente/api/check/realizar-checkin',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ id_reserva: reservaId, observacoes: observacoes }),
            dataType: 'json',
            success: function(response) {
                hideLoading();
                if (response.success) {
                    Swal.fire('Sucesso', 'Check-in realizado com sucesso!', 'success');
                    bootstrap.Modal.getInstance(document.getElementById('modalCheckin')).hide();
                    refreshAllData();
                } else {
                    Swal.fire('Erro', response.message, 'error');
                }
            },
            error: function() {
                hideLoading();
                Swal.fire('Erro', 'Erro ao realizar check-in', 'error');
            }
        });
    });

    // ==================== REALIZAR CHECK-OUT ====================
    function openCheckoutModal(checkinId) {
        $.ajax({
            url: contextPath + '/Gerente/api/check/checkout-detalhes',
            method: 'GET',
            data: { id: checkinId },
            dataType: 'json',
            success: function(data) {
                $('#checkoutId').val(data.id_checkin);
                $('#checkoutCliente').html('<strong>' + escapeHtml(data.cliente_nome) + '</strong>');
                $('#checkoutQuarto').html(data.quarto_num);
                $('#checkoutPeriodo').html(formatDate(data.data_checkin) + ' a ' + formatDate(data.data_saida_prevista));
                $('#checkoutDiarias').html(data.diarias + ' diárias x ' + formatMoney(data.preco_diaria) + ' = ' + formatMoney(data.total_quarto));
                $('#checkoutConsumo').html(formatMoney(data.consumo_total));
                $('#checkoutTotal').html(formatMoney(data.total));
                $('#checkoutObservacoes').val('');
                new bootstrap.Modal(document.getElementById('modalCheckout')).show();
            },
            error: function() {
                Swal.fire('Erro', 'Não foi possível carregar os dados', 'error');
            }
        });
    }

    $('#confirmCheckoutBtn').on('click', function() {
        showLoading();
        var checkinId = $('#checkoutId').val();
        var observacoes = $('#checkoutObservacoes').val();

        $.ajax({
            url: contextPath + '/Gerente/api/check/realizar-checkout',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ id_checkin: checkinId, observacoes: observacoes }),
            dataType: 'json',
            success: function(response) {
                hideLoading();
                if (response.success) {
                    Swal.fire('Sucesso', 'Check-out realizado com sucesso!', 'success');
                    bootstrap.Modal.getInstance(document.getElementById('modalCheckout')).hide();
                    refreshAllData();
                } else {
                    Swal.fire('Erro', response.message, 'error');
                }
            },
            error: function() {
                hideLoading();
                Swal.fire('Erro', 'Erro ao realizar check-out', 'error');
            }
        });
    });

    // ==================== REFRESH ====================
    function refreshAllData() {
        showLoading();
        Promise.all([
            new Promise(function(resolve) { loadStats(); setTimeout(resolve, 500); }),
            new Promise(function(resolve) { loadGraficos(); setTimeout(resolve, 500); }),
            new Promise(function(resolve) { loadPendentes(); setTimeout(resolve, 500); }),
            new Promise(function(resolve) { loadHospedados(); setTimeout(resolve, 500); }),
            new Promise(function(resolve) { loadCheckouts(); setTimeout(resolve, 500); })
        ]).finally(function() {
            setTimeout(hideLoading, 500);
            Swal.fire({
                icon: 'success',
                title: 'Atualizado!',
                text: 'Dados foram atualizados',
                timer: 1500,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        });
    }

    // ==================== FILTROS ====================
    function updateFilter() {
        var filter = $('#statusFilter').val();
        currentFilter = filter;

        if (filter === 'pendentes') {
            $('#tabelaPendentes').show();
            $('#tabelaHospedados').hide();
            $('#tabelaCheckouts').hide();
            loadPendentes();
        } else if (filter === 'hospedados') {
            $('#tabelaPendentes').hide();
            $('#tabelaHospedados').show();
            $('#tabelaCheckouts').hide();
            loadHospedados();
        } else if (filter === 'checkouts') {
            $('#tabelaPendentes').hide();
            $('#tabelaHospedados').hide();
            $('#tabelaCheckouts').show();
            loadCheckouts();
        }
    }

    $('#statusFilter').on('change', updateFilter);

    $('#searchInput').on('input', function() {
        if (currentFilter === 'pendentes') loadPendentes();
        else if (currentFilter === 'hospedados') loadHospedados();
        else if (currentFilter === 'checkouts') loadCheckouts();
    });

    // ==================== RELÓGIO ====================
    function updateClock() {
        var now = new Date();
        $('#horaAtual').text(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').text(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
    }
    setInterval(updateClock, 1000);
    updateClock();

    $('#refreshBtn').on('click', function() {
        refreshAllData();
    });

    // ==================== INICIALIZAÇÃO ====================
    $(document).ready(function() {
        loadStats();
        loadGraficos();
        loadPendentes();
        loadHospedados();
        loadCheckouts();

        setInterval(function() {
            loadStats();
            loadGraficos();
        }, 30000);
    });
</script>
</body>
</html>