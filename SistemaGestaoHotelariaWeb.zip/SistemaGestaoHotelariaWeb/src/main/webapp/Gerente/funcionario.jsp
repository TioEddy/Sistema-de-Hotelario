<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funcionários · Hotelaria Manager</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F5F0E8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #1A3C2C;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(212, 175, 55, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #D4AF37;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #D4AF37; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #D4AF37; }
        .sidebar li:hover { background: rgba(212, 175, 55, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #D4AF37; color: #1A3C2C; }
        .sidebar li.active i { color: #1A3C2C; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1A3C2C; font-weight: 500; }
        .sidebar .menu-section {
            color: #D4AF37;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper {
            margin-left: 270px;
            height: 100vh;
            overflow-y: auto;
            padding: 20px 28px;
            position: relative;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #D4AF37; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1A3C2C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1A3C2C; }
        .refresh-btn {
            background: #D4AF37;
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .refresh-btn:hover {
            background: #1A3C2C;
            color: #D4AF37;
            transform: rotate(90deg);
        }
        .btn-primary-custom {
            background: #D4AF37;
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: #1A3C2C;
            transition: all 0.2s;
        }
        .btn-primary-custom:hover {
            background: #1A3C2C;
            color: #D4AF37;
            transform: translateY(-2px);
        }
        .btn-outline-custom {
            background: transparent;
            border: 2px solid #E8DFC8;
            padding: 8px 20px;
            border-radius: 40px;
            font-weight: 500;
            color: #8B9A87;
        }
        .btn-outline-custom:hover {
            border-color: #D4AF37;
            color: #D4AF37;
        }
        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 16px 24px;
            margin-bottom: 24px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #F5F0E8;
            padding: 8px 16px;
            border-radius: 40px;
        }
        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            width: 250px;
        }
        .filter-select {
            padding: 8px 16px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            transition: all 0.3s ease;
            border: 1px solid #E8DFC8;
            cursor: pointer;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            border-color: #D4AF37;
        }
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .stat-header h3 {
            font-size: 0.7rem;
            font-weight: 600;
            color: #8B9A87;
            text-transform: uppercase;
        }
        .stat-header i { font-size: 1.5rem; color: #D4AF37; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #1A3C2C; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .chart-box {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid #E8DFC8;
        }
        .chart-box h3 {
            font-size: 0.85rem;
            font-weight: 600;
            color: #1A3C2C;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .chart-box h3 i { color: #D4AF37; }
        .chart-container { position: relative; height: 180px; width: 100%; }
        .table-section {
            background: white;
            border-radius: 20px;
            padding: 18px 20px;
            border: 1px solid #E8DFC8;
            margin-bottom: 28px;
        }
        .table-section h3 {
            font-size: 0.85rem;
            font-weight: 600;
            color: #1A3C2C;
            margin-bottom: 18px;
        }
        .table { margin: 0; font-size: 0.8rem; width: 100%; }
        .table thead th {
            border-bottom: 2px solid #D4AF37;
            color: #1A3C2C;
            font-weight: 600;
            padding: 10px 6px;
        }
        .badge-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-status.ATIVO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.INATIVO { background: #FFEBEE; color: #C76A3C; }
        .badge-sexo {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-sexo.M { background: #E3F2FD; color: #1976D2; }
        .badge-sexo.F { background: #FCE4EC; color: #C2185B; }
        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 5px;
            border-radius: 8px;
            transition: all 0.2s;
        }
        .action-btn.edit { color: #D4AF37; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F5F0E8; transform: scale(1.1); }
        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: flex-end;
            gap: 5px;
            list-style: none;
        }
        .page-link {
            color: #1A3C2C;
            border-radius: 8px;
            padding: 8px 12px;
            text-decoration: none;
            border: 1px solid #E8DFC8;
            background: white;
            cursor: pointer;
        }
        .page-item.active .page-link {
            background: #D4AF37;
            border-color: #D4AF37;
            color: #1A3C2C;
        }
        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom {
            background: #1A3C2C;
            color: white;
            border-radius: 24px 24px 0 0;
            padding: 20px 24px;
        }
        .detail-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #E8DFC8;
        }
        .detail-label { width: 130px; font-weight: 600; color: #1A3C2C; }
        .detail-value { flex: 1; color: #8B9A87; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E8DFC8;
            padding: 10px 14px;
        }
        .form-control-custom:focus, .form-select-custom:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.3);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #E8DFC8;
            border-top-color: #D4AF37;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">OPERACIONAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/quarto.jsp"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS & CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/cliente.jsp"><i class="bi bi-people"></i> Clientes</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumo Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/fatura.jsp"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">EQUIPA</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Gerente/funcionario.jsp"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/turno.jsp"><i class="bi bi-clock-history"></i> Turnos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Manager<span>Gestão de Funcionários</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
            <button class="refresh-btn" id="refreshBtn" title="Atualizar dados">
                <i class="bi bi-arrow-repeat"></i>
            </button>
        </div>
    </div>

    <!-- CARDS ESTATÍSTICOS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>TOTAL FUNCIONÁRIOS</h3><i class="bi bi-people"></i></div>
            <div class="stat-value" id="totalFuncionarios">--</div>
            <div class="stat-footer">Cadastrados no sistema</div>
        </div>
        <div class="stat-card" onclick="filterByStatus('ATIVO')">
            <div class="stat-header"><h3>ATIVOS</h3><i class="bi bi-check-circle"></i></div>
            <div class="stat-value" id="funcionariosAtivos">--</div>
            <div class="stat-footer">Em atividade</div>
        </div>
        <div class="stat-card" onclick="filterByStatus('INATIVO')">
            <div class="stat-header"><h3>INATIVOS</h3><i class="bi bi-x-circle"></i></div>
            <div class="stat-value" id="funcionariosInativos">--</div>
            <div class="stat-footer">Fora de atividade</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>ESTE MÊS</h3><i class="bi bi-calendar-plus"></i></div>
            <div class="stat-value" id="contratadosMes">--</div>
            <div class="stat-footer">Novas contratações</div>
        </div>
    </div>

    <!-- GRÁFICOS -->
    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Funcionários por Sexo</h3>
            <div class="chart-container"><canvas id="sexoChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Funcionários por Cargo</h3>
            <div class="chart-container"><canvas id="cargoChart"></canvas></div>
        </div>
    </div>

    <!-- BARRA DE FILTROS -->
    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por nome, cargo ou email...">
        </div>
        <div>
            <select class="filter-select" id="cargoFilter">
                <option value="">Todos os cargos</option>
                <option value="Recepcionista">Recepcionista</option>
                <option value="Gerente">Gerente</option>
                <option value="Financeiro">Financeiro</option>
                <option value="Housekeeping">Housekeeping</option>
                <option value="Manutenção">Manutenção</option>
                <option value="Segurança">Segurança</option>
                <option value="Administrador">Administrador</option>
            </select>
            <select class="filter-select" id="statusFilter">
                <option value="">Todos os status</option>
                <option value="ATIVO">ATIVO</option>
                <option value="INATIVO">INATIVO</option>
            </select>
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalFuncionario" onclick="resetModalForm()">
            <i class="bi bi-plus-lg"></i> Novo Funcionário
        </button>
    </div>

    <!-- TABELA DE FUNCIONÁRIOS -->
    <div class="table-section">
        <h3><i class="bi bi-list-ul"></i> Lista de Funcionários</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Nome</th><th>Cargo</th><th>Telefone</th><th>Email</th><th>Salário</th><th>Contratação</th><th>Turno</th><th>Status</th><th>Ações</th></tr>
                </thead>
                <tbody id="funcionariosTableBody"><tr><td colspan="9" class="text-center py-4"><div class="loading-spinner" style="width:30px;height:30px;"></div> Carregando...</td></tr></tbody>
            </table>
        </div>
        <div id="paginationContainer" class="pagination"></div>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema de Gestão de Funcionários
    </div>
</div>

<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-spinner"></div>
</div>

<!-- MODAL: Novo/Editar Funcionário -->
<div class="modal fade modal-custom" id="modalFuncionario" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-person-badge"></i> Funcionário</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formFuncionario">
                    <input type="hidden" id="editId" name="id_funcionario" value="">
                    <div class="mb-3">
                        <label class="form-label">Nome Completo <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-custom" id="nomeCompleto" name="nome" required placeholder="Ex: Ana Oliveira">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Sexo</label>
                            <select class="form-select form-select-custom" id="sexo" name="sexo">
                                <option value="">Selecione</option>
                                <option value="M">Masculino</option>
                                <option value="F">Feminino</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Telefone</label>
                            <input type="tel" class="form-control form-control-custom" id="telefone" name="telefone" placeholder="+258 84 123 4567">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control form-control-custom" id="email" name="email" placeholder="funcionario@hotelaria.co.mz">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cargo</label>
                            <select class="form-select form-select-custom" id="cargo" name="cargo" required>
                                <option value="">Selecione</option>
                                <option value="Administrador">Administrador</option>
                                <option value="Gerente">Gerente</option>
                                <option value="Recepcionista">Recepcionista</option>
                                <option value="Financeiro">Financeiro</option>
                                <option value="Housekeeping">Housekeeping</option>
                                <option value="Manutenção">Manutenção</option>
                                <option value="Segurança">Segurança</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Salário (MZN)</label>
                            <input type="number" class="form-control form-control-custom" id="salario" name="salario" step="0.01" placeholder="0.00">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Data Contratação</label>
                            <input type="date" class="form-control form-control-custom" id="dataContratacao" name="data_contratacao">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Turno</label>
                        <select class="form-select form-select-custom" id="turno" name="id_turno">
                            <option value="">Carregando turnos...</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select form-select-custom" id="status" name="status">
                            <option value="ATIVO">ATIVO</option>
                            <option value="INATIVO">INATIVO</option>
                        </select>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Salvar Funcionário</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Funcionário -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Funcionário</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Nome:</div><div class="detail-value" id="detNome">-</div></div>
                <div class="detail-row"><div class="detail-label">Sexo:</div><div class="detail-value" id="detSexo">-</div></div>
                <div class="detail-row"><div class="detail-label">Telefone:</div><div class="detail-value" id="detTelefone">-</div></div>
                <div class="detail-row"><div class="detail-label">Email:</div><div class="detail-value" id="detEmail">-</div></div>
                <div class="detail-row"><div class="detail-label">Cargo:</div><div class="detail-value" id="detCargo">-</div></div>
                <div class="detail-row"><div class="detail-label">Salário:</div><div class="detail-value" id="detSalario">-</div></div>
                <div class="detail-row"><div class="detail-label">Contratação:</div><div class="detail-value" id="detContratacao">-</div></div>
                <div class="detail-row"><div class="detail-label">Turno:</div><div class="detail-value" id="detTurno">-</div></div>
                <div class="detail-row"><div class="detail-label">Status:</div><div class="detail-value" id="detStatus">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                <button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let sexoChart = null;
    let cargoChart = null;
    let currentPage = 1;
    let currentSearch = '';
    let currentCargo = '';
    let currentStatus = '';

    function showLoading() { $('#loadingOverlay').show(); }
    function hideLoading() { $('#loadingOverlay').hide(); }

    function formatDate(dateStr) {
        if (!dateStr) return '';
        var parts = dateStr.split('-');
        if (parts.length === 3) return parts[2] + '/' + parts[1] + '/' + parts[0];
        return dateStr;
    }

    function formatMoney(v) {
        if (v === undefined || v === null || isNaN(v)) return "0 MZN";
        return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function getSexoBadge(sexo) {
        if (sexo === 'M') return '<span class="badge-sexo M"><i class="bi bi-gender-male"></i> M</span>';
        if (sexo === 'F') return '<span class="badge-sexo F"><i class="bi bi-gender-female"></i> F</span>';
        return '-';
    }

    function getStatusClass(status) { return status; }

    // ==================== CARREGAR TURNOS ====================
    function loadTurnos() {
        $.ajax({
            url: contextPath + '/Gerente/api/funcionario/turnos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var select = $('#turno');
                select.empty();
                select.append('<option value="">Selecione o turno</option>');
                for (var i = 0; i < data.length; i++) {
                    select.append('<option value="' + data[i].id_turno + '">' + escapeHtml(data[i].nome_turno) + ' (' + data[i].hora_inicio + ' - ' + data[i].hora_fim + ')</option>');
                }
            },
            error: function() { console.error('Erro ao carregar turnos'); }
        });
    }

    // ==================== CARREGAR STATS ====================
    function loadStats() {
        $.ajax({
            url: contextPath + '/Gerente/api/funcionario/stats',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                $('#totalFuncionarios').text(data.total || 0);
                $('#funcionariosAtivos').text(data.ativos || 0);
                $('#funcionariosInativos').text(data.inativos || 0);
                $('#contratadosMes').text(data.contratados_mes || 0);
            },
            error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    // ==================== CARREGAR GRÁFICOS ====================
    function loadGraficos() {
        $.ajax({
            url: contextPath + '/Gerente/api/funcionario/graficos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                // Gráfico por sexo
                if (sexoChart) sexoChart.destroy();
                sexoChart = new Chart(document.getElementById('sexoChart'), {
                    type: 'doughnut',
                    data: {
                        labels: ['Masculino', 'Feminino'],
                        datasets: [{
                            data: [data.homens || 0, data.mulheres || 0],
                            backgroundColor: ['#1976D2', '#C2185B'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } },
                        cutout: '60%'
                    }
                });

                // Gráfico por cargo
                if (cargoChart) cargoChart.destroy();
                var cargos = data.por_cargo || [];
                cargoChart = new Chart(document.getElementById('cargoChart'), {
                    type: 'bar',
                    data: {
                        labels: cargos.map(function(c) { return c.cargo; }),
                        datasets: [{
                            label: 'Quantidade',
                            data: cargos.map(function(c) { return c.total; }),
                            backgroundColor: '#D4AF37',
                            borderRadius: 8
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: { y: { beginAtZero: true } },
                        plugins: { legend: { display: false } }
                    }
                });
            },
            error: function() { console.error('Erro ao carregar gráficos'); }
        });
    }

    // ==================== CARREGAR FUNCIONÁRIOS ====================
    function loadFuncionarios() {
        showLoading();
        $.ajax({
            url: contextPath + '/Gerente/api/funcionario/listar',
            method: 'GET',
            data: { page: currentPage, search: currentSearch, cargo: currentCargo, status: currentStatus },
            dataType: 'json',
            success: function(data) {
                var tbody = $('#funcionariosTableBody');
                tbody.empty();

                if (!data.funcionarios || data.funcionarios.length === 0) {
                    tbody.html('<td><td colspan="9" class="text-center py-4">Nenhum funcionário encontrado</td></tr>');
                    $('#paginationContainer').empty();
                    hideLoading();
                    return;
                }

                for (var i = 0; i < data.funcionarios.length; i++) {
                    var f = data.funcionarios[i];
                    var row = '<tr>' +
                        '<td><strong>' + escapeHtml(f.nome) + '</strong> ' + getSexoBadge(f.sexo) + '</td>' +
                        '<td>' + escapeHtml(f.cargo) + '</td>' +
                        '<td>' + escapeHtml(f.telefone || '-') + '</td>' +
                        '<td>' + escapeHtml(f.email || '-') + '</td>' +
                        '<td>' + formatMoney(f.salario) + '</td>' +
                        '<td>' + formatDate(f.data_contratacao) + '</td>' +
                        '<td>' + escapeHtml(f.turno_nome || '-') + '</td>' +
                        '<td><span class="badge-status ' + getStatusClass(f.status) + '">' + escapeHtml(f.status) + '</span></td>' +
                        '<td class="action-buttons">' +
                            '<button class="action-btn edit" onclick="editFuncionario(' + f.id_funcionario + ')"><i class="bi bi-pencil"></i></button>' +
                            '<button class="action-btn view" onclick="viewFuncionario(' + f.id_funcionario + ')"><i class="bi bi-eye"></i></button>' +
                        '</td>' +
                        '</tr>';
                    tbody.append(row);
                }

                // Paginação
                var pagination = $('#paginationContainer');
                pagination.empty();
                if (data.total_pages > 1) {
                    var ul = $('<ul class="pagination"></ul>');
                    if (data.current_page > 1) {
                        ul.append('<li class="page-item"><a class="page-link" onclick="goToPage(' + (data.current_page - 1) + ')">«</a></li>');
                    }
                    for (var p = 1; p <= data.total_pages; p++) {
                        var activeClass = (p === data.current_page) ? 'active' : '';
                        ul.append('<li class="page-item ' + activeClass + '"><a class="page-link" onclick="goToPage(' + p + ')">' + p + '</a></li>');
                    }
                    if (data.current_page < data.total_pages) {
                        ul.append('<li class="page-item"><a class="page-link" onclick="goToPage(' + (data.current_page + 1) + ')">»</a></li>');
                    }
                    pagination.append(ul);
                }

                hideLoading();
            },
            error: function() {
                $('#funcionariosTableBody').html('<tr><td colspan="9" class="text-center py-4 text-danger">Erro ao carregar dados</td></tr>');
                hideLoading();
            }
        });
    }

    // ==================== FUNÇÕES DE AÇÃO ====================
    function goToPage(page) {
        currentPage = page;
        loadFuncionarios();
    }

    function filterByStatus(status) {
        currentStatus = status;
        currentPage = 1;
        $('#statusFilter').val(status);
        loadFuncionarios();
    }

    function resetModalForm() {
        $('#editId').val('');
        $('#formFuncionario')[0].reset();
        $('#nomeCompleto').val('');
        $('#sexo').val('');
        $('#telefone').val('');
        $('#email').val('');
        $('#cargo').val('');
        $('#salario').val('');
        $('#dataContratacao').val('');
        $('#turno').val('');
        $('#status').val('ATIVO');
        $('#modalFuncionario .modal-title').html('<i class="bi bi-person-badge"></i> Funcionário');
    }

    function editFuncionario(id) {
        $.ajax({
            url: contextPath + '/Gerente/api/funcionario/detalhes',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(data) {
                $('#editId').val(data.id_funcionario);
                $('#nomeCompleto').val(data.nome);
                $('#sexo').val(data.sexo || '');
                $('#telefone').val(data.telefone || '');
                $('#email').val(data.email || '');
                $('#cargo').val(data.cargo);
                $('#salario').val(data.salario);
                $('#dataContratacao').val(data.data_contratacao);
                $('#turno').val(data.id_turno || '');
                $('#status').val(data.status);
                $('#modalFuncionario .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Funcionário');
                new bootstrap.Modal(document.getElementById('modalFuncionario')).show();
            },
            error: function() {
                Swal.fire('Erro', 'Não foi possível carregar os dados do funcionário', 'error');
            }
        });
    }

    function viewFuncionario(id) {
        $.ajax({
            url: contextPath + '/Gerente/api/funcionario/detalhes',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(data) {
                $('#detNome').html('<strong>' + escapeHtml(data.nome) + '</strong>');
                $('#detSexo').text(data.sexo === 'M' ? 'Masculino' : data.sexo === 'F' ? 'Feminino' : '-');
                $('#detTelefone').text(data.telefone || '-');
                $('#detEmail').text(data.email || '-');
                $('#detCargo').text(data.cargo);
                $('#detSalario').text(formatMoney(data.salario));
                $('#detContratacao').text(formatDate(data.data_contratacao));
                $('#detTurno').text(data.turno_nome || '-');
                $('#detStatus').html('<span class="badge-status ' + data.status + '">' + escapeHtml(data.status) + '</span>');
                new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
            },
            error: function() {
                Swal.fire('Erro', 'Não foi possível carregar os detalhes', 'error');
            }
        });
    }

    // ==================== SALVAR FUNCIONÁRIO ====================
    $('#formFuncionario').on('submit', function(e) {
        e.preventDefault();
        showLoading();

        var formData = {
            id_funcionario: $('#editId').val(),
            nome: $('#nomeCompleto').val(),
            sexo: $('#sexo').val(),
            telefone: $('#telefone').val(),
            email: $('#email').val(),
            cargo: $('#cargo').val(),
            salario: $('#salario').val(),
            data_contratacao: $('#dataContratacao').val(),
            id_turno: $('#turno').val(),
            status: $('#status').val()
        };

        $.ajax({
            url: contextPath + '/Gerente/api/funcionario/salvar',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            dataType: 'json',
            success: function(response) {
                hideLoading();
                if (response.success) {
                    Swal.fire('Sucesso', response.message, 'success');
                    bootstrap.Modal.getInstance(document.getElementById('modalFuncionario')).hide();
                    loadFuncionarios();
                    loadStats();
                    loadGraficos();
                    loadTurnos();
                } else {
                    Swal.fire('Erro', response.message, 'error');
                }
            },
            error: function() {
                hideLoading();
                Swal.fire('Erro', 'Erro ao salvar funcionário', 'error');
            }
        });
    });

    // ==================== FILTROS ====================
    $('#searchInput').on('input', function() {
        currentSearch = this.value;
        currentPage = 1;
        loadFuncionarios();
    });

    $('#cargoFilter').on('change', function() {
        currentCargo = this.value;
        currentPage = 1;
        loadFuncionarios();
    });

    $('#statusFilter').on('change', function() {
        currentStatus = this.value;
        currentPage = 1;
        loadFuncionarios();
    });

    // ==================== RELÓGIO ====================
    function updateClock() {
        var now = new Date();
        $('#horaAtual').text(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').text(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
    }
    setInterval(updateClock, 1000);
    updateClock();

    $('#refreshBtn').on('click', function() {
        loadFuncionarios();
        loadStats();
        loadGraficos();
        Swal.fire({
            icon: 'success',
            title: 'Atualizado!',
            text: 'Dados dos funcionários foram atualizados',
            timer: 1500,
            showConfirmButton: false,
            toast: true,
            position: 'top-end'
        });
    });

    // ==================== INICIALIZAÇÃO ====================
    $(document).ready(function() {
        loadTurnos();
        loadStats();
        loadGraficos();
        loadFuncionarios();

        setInterval(function() {
            loadStats();
            loadGraficos();
        }, 30000);
    });
</script>
</body>
</html>