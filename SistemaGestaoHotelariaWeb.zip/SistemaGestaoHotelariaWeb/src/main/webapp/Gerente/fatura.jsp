<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faturas · Hotelaria Manager</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F5F0E8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #1A3C2C;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(212, 175, 55, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #D4AF37;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #D4AF37; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #D4AF37; }
        .sidebar li:hover { background: rgba(212, 175, 55, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #D4AF37; color: #1A3C2C; }
        .sidebar li.active i { color: #1A3C2C; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1A3C2C; font-weight: 500; }
        .sidebar .menu-section {
            color: #D4AF37;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper {
            margin-left: 270px;
            height: 100vh;
            overflow-y: auto;
            padding: 20px 28px;
            position: relative;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #D4AF37; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1A3C2C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1A3C2C; }
        .refresh-btn {
            background: #D4AF37;
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .refresh-btn:hover {
            background: #1A3C2C;
            color: #D4AF37;
            transform: rotate(90deg);
        }
        .btn-primary-custom {
            background: #D4AF37;
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: #1A3C2C;
            transition: all 0.2s;
        }
        .btn-primary-custom:hover {
            background: #1A3C2C;
            color: #D4AF37;
            transform: translateY(-2px);
        }
        .btn-outline-custom {
            background: transparent;
            border: 2px solid #E8DFC8;
            padding: 8px 20px;
            border-radius: 40px;
            font-weight: 500;
            color: #8B9A87;
        }
        .btn-outline-custom:hover {
            border-color: #D4AF37;
            color: #D4AF37;
        }
        .btn-success-custom {
            background: #2E7D32;
            border: none;
            padding: 8px 20px;
            border-radius: 30px;
            font-weight: 500;
            color: white;
        }
        .btn-success-custom:hover { background: #1B5E20; }
        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 16px 24px;
            margin-bottom: 24px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #F5F0E8;
            padding: 8px 16px;
            border-radius: 40px;
        }
        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            width: 250px;
        }
        .filter-select {
            padding: 8px 16px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            transition: all 0.3s ease;
            border: 1px solid #E8DFC8;
            cursor: pointer;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            border-color: #D4AF37;
        }
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .stat-header h3 {
            font-size: 0.7rem;
            font-weight: 600;
            color: #8B9A87;
            text-transform: uppercase;
        }
        .stat-header i { font-size: 1.5rem; color: #D4AF37; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #1A3C2C; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .chart-box {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid #E8DFC8;
        }
        .chart-box h3 {
            font-size: 0.85rem;
            font-weight: 600;
            color: #1A3C2C;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .chart-box h3 i { color: #D4AF37; }
        .chart-container { position: relative; height: 180px; width: 100%; }
        .table-section {
            background: white;
            border-radius: 20px;
            padding: 18px 20px;
            border: 1px solid #E8DFC8;
            margin-bottom: 28px;
        }
        .table-section h3 {
            font-size: 0.85rem;
            font-weight: 600;
            color: #1A3C2C;
            margin-bottom: 18px;
        }
        .table { margin: 0; font-size: 0.8rem; width: 100%; }
        .table thead th {
            border-bottom: 2px solid #D4AF37;
            color: #1A3C2C;
            font-weight: 600;
            padding: 10px 6px;
        }
        .badge-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-status.PAGA { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.VENCIDA { background: #FFEBEE; color: #C76A3C; }
        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 5px;
            border-radius: 8px;
            transition: all 0.2s;
        }
        .action-btn.view { color: #1976D2; }
        .action-btn.pdf { color: #C76A3C; }
        .action-btn:hover { background: #F5F0E8; transform: scale(1.1); }
        .pagination {
            margin-top: 20px;
            display: flex;
            justify-content: flex-end;
            gap: 5px;
            list-style: none;
        }
        .page-link {
            color: #1A3C2C;
            border-radius: 8px;
            padding: 8px 12px;
            text-decoration: none;
            border: 1px solid #E8DFC8;
            background: white;
            cursor: pointer;
        }
        .page-item.active .page-link {
            background: #D4AF37;
            border-color: #D4AF37;
            color: #1A3C2C;
        }
        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom {
            background: #1A3C2C;
            color: white;
            border-radius: 24px 24px 0 0;
            padding: 20px 24px;
        }
        .detail-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #E8DFC8;
        }
        .detail-label { width: 130px; font-weight: 600; color: #1A3C2C; }
        .detail-value { flex: 1; color: #8B9A87; }
        .qr-container {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E8DFC8;
            padding: 10px 14px;
        }
        .form-control-custom:focus, .form-select-custom:focus {
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
            outline: none;
        }
        .form-control-readonly {
            background-color: #F5F0E8;
            cursor: not-allowed;
        }
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.3);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #E8DFC8;
            border-top-color: #D4AF37;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">OPERACIONAL</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/quarto.jsp"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS & CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/cliente.jsp"><i class="bi bi-people"></i> Clientes</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumo Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Gerente/fatura.jsp"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">EQUIPA</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/funcionario.jsp"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/turno.jsp"><i class="bi bi-clock-history"></i> Turnos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Manager<span>Gestão de Faturas</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
            <button class="refresh-btn" id="refreshBtn" title="Atualizar dados">
                <i class="bi bi-arrow-repeat"></i>
            </button>
        </div>
    </div>

    <!-- CARDS ESTATÍSTICOS -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>TOTAL FATURADO</h3><i class="bi bi-cash-stack"></i></div>
            <div class="stat-value" id="totalFaturado">-- MZN</div>
            <div class="stat-footer">Valor total emitido</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>CONTAS A RECEBER</h3><i class="bi bi-credit-card"></i></div>
            <div class="stat-value" id="contasReceber">-- MZN</div>
            <div class="stat-footer">Faturas pendentes</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>FATURAS EMITIDAS</h3><i class="bi bi-receipt"></i></div>
            <div class="stat-value" id="totalFaturas">--</div>
            <div class="stat-footer">Total emitidas</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>ESTE MÊS</h3><i class="bi bi-calendar"></i></div>
            <div class="stat-value" id="faturasMes">--</div>
            <div class="stat-footer">Faturas emitidas</div>
        </div>
    </div>

    <!-- GRÁFICOS -->
    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Faturas por Estado</h3>
            <div class="chart-container"><canvas id="estadoFaturasChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Faturação Mensal</h3>
            <div class="chart-container"><canvas id="faturacaoMensalChart"></canvas></div>
        </div>
    </div>

    <!-- BARRA DE FILTROS -->
    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por cliente ou nº fatura...">
        </div>
        <div>
            <select class="filter-select" id="estadoFilter">
                <option value="">Todos os estados</option>
                <option value="PAGA">PAGA</option>
                <option value="PENDENTE">PENDENTE</option>
                <option value="VENCIDA">VENCIDA</option>
            </select>
            <input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por data" style="width: 130px;">
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalFatura" onclick="loadReservasDisponiveis()">
            <i class="bi bi-plus-lg"></i> Nova Fatura
        </button>
    </div>

    <!-- TABELA DE FATURAS -->
    <div class="table-section">
        <h3><i class="bi bi-list-ul"></i> Lista de Faturas</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Nº Fatura</th><th>Cliente</th><th>Reserva</th><th>Subtotal</th><th>IVA</th><th>Total</th><th>Data Emissão</th><th>Vencimento</th><th>Estado</th><th>Ações</th></tr>
                </thead>
                <tbody id="faturasTableBody"><tr><td colspan="10" class="text-center py-4"><div class="loading-spinner" style="width:30px;height:30px;"></div> Carregando...</td></tr></tbody>
            </table>
        </div>
        <div id="paginationContainer" class="pagination"></div>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema de Gestão de Faturas
    </div>
</div>

<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-spinner"></div>
</div>

<!-- MODAL: Nova Fatura -->
<div class="modal fade modal-custom" id="modalFatura" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-receipt"></i> Emitir Nova Fatura</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formFatura">
                    <div class="mb-3">
                        <label class="form-label">Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaFatura" name="id_reserva" required>
                            <option value="">Carregando reservas...</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subtotal (sem IVA)</label>
                        <input type="text" class="form-control form-control-custom form-control-readonly" id="subtotalFatura" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">IVA (16%)</label>
                        <input type="text" class="form-control form-control-custom form-control-readonly" id="ivaFatura" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Total a Pagar</label>
                        <input type="text" class="form-control form-control-custom form-control-readonly" id="totalFatura" readonly style="font-weight: bold; background: #FFF8E1;">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Data Vencimento</label>
                        <input type="date" class="form-control form-control-custom" id="dataVencimento" name="data_vencimento">
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Emitir Fatura</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Visualizar Fatura -->
<div class="modal fade modal-custom" id="modalVisualizarFatura" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-receipt"></i> Fatura #<span id="faturaNumeroModal">-</span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4" id="faturaPrintContent">
                <div class="qr-container">
                    <div style="text-align: center; margin-bottom: 30px;">
                        <i class="bi bi-building" style="font-size: 2rem; color: #D4AF37;"></i>
                        <h2 style="margin: 10px 0 5px; color: #1A3C2C;">Hotelaria Systems</h2>
                        <p style="color: #8B9A87; margin: 0;">Av. Marginal, 1234 - Maputo | Tel: +258 84 123 4567</p>
                        <p style="color: #8B9A87;">NUIT: 123456789 | Email: facturacao@hotelaria.co.mz</p>
                        <hr style="border-top: 2px solid #D4AF37; width: 100px;">
                    </div>

                    <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
                        <div>
                            <strong style="color: #1A3C2C;">FATURA Nº:</strong> <span id="printNumero">-</span><br>
                            <strong style="color: #1A3C2C;">Data Emissão:</strong> <span id="printDataEmissao">-</span><br>
                            <strong style="color: #1A3C2C;">Data Vencimento:</strong> <span id="printDataVencimento">-</span>
                        </div>
                        <div>
                            <strong style="color: #1A3C2C;">Cliente:</strong> <span id="printCliente">-</span><br>
                            <strong style="color: #1A3C2C;">Reserva:</strong> <span id="printReserva">-</span>
                        </div>
                    </div>

                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                        <thead>
                            <tr style="background: #F5F0E8; border-bottom: 2px solid #D4AF37;">
                                <th style="padding: 10px; text-align: left;">Descrição</th>
                                <th style="padding: 10px; text-align: right;">Valor (MZN)</th>
                             </tr>
                        </thead>
                        <tbody>
                            <tr><td style="padding: 10px;">Hospedagem - Serviços prestados</td><td style="padding: 10px; text-align: right;"><span id="printSubtotal">-</span></td></tr>
                            <tr style="border-top: 1px solid #E8DFC8;"><td style="padding: 10px;">IVA (16%)</td><td style="padding: 10px; text-align: right;"><span id="printIva">-</span></td></tr>
                            <tr style="border-top: 2px solid #D4AF37; background: #FFF8E1;">
                                <td style="padding: 10px;"><strong>TOTAL</strong></td>
                                <td style="padding: 10px; text-align: right;"><strong id="printTotal">-</strong></td>
                             </tr>
                        </tbody>
                    </table>

                    <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px dashed #E8DFC8;">
                        <p style="color: #8B9A87; font-size: 0.8rem;">Obrigado pela preferência!</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px; justify-content: center; gap: 12px;">
                <button class="btn-success-custom" id="printFaturaBtn"><i class="bi bi-printer"></i> Imprimir</button>
                <button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let estadoChart = null;
    let faturacaoChart = null;
    let currentPage = 1;
    let currentSearch = '';
    let currentEstado = '';
    let currentData = '';

    function showLoading() { $('#loadingOverlay').show(); }
    function hideLoading() { $('#loadingOverlay').hide(); }

    function formatDateTime(dateTimeStr) {
        if (!dateTimeStr) return '';
        return dateTimeStr.replace('T', ' ').substring(0, 16);
    }

    function formatDate(dateStr) {
        if (!dateStr) return '';
        var parts = dateStr.split('-');
        if (parts.length === 3) return parts[2] + '/' + parts[1] + '/' + parts[0];
        return dateStr;
    }

    function formatMoney(v) {
        if (v === undefined || v === null || isNaN(v)) return "0 MZN";
        return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function getEstadoClass(estado) {
        if (estado === 'PAGA') return 'PAGA';
        if (estado === 'PENDENTE') return 'PENDENTE';
        return 'VENCIDA';
    }

    // ==================== CARREGAR RESERVAS DISPONÍVEIS ====================
    function loadReservasDisponiveis() {
        $.ajax({
            url: contextPath + '/Gerente/api/fatura/reservas-disponiveis',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var select = $('#reservaFatura');
                select.empty();
                select.append('<option value="">Selecione a reserva</option>');
                for (var i = 0; i < data.length; i++) {
                    var r = data[i];
                    var valorTotal = r.valor_total || 0;
                    select.append('<option value="' + r.id_reserva + '" data-valor="' + valorTotal + '">#' + r.id_reserva + ' - ' + escapeHtml(r.cliente_nome) + ' - Quarto ' + escapeHtml(r.quarto_num) + ' - Valor: ' + formatMoney(valorTotal) + '</option>');
                }
                if (data.length === 0) {
                    select.append('<option value="" disabled>Nenhuma reserva disponível</option>');
                }

                // Data de vencimento padrão (30 dias)
                var vencimento = new Date();
                vencimento.setDate(vencimento.getDate() + 30);
                var vencimentoStr = vencimento.toISOString().split('T')[0];
                $('#dataVencimento').val(vencimentoStr);
            },
            error: function() { console.error('Erro ao carregar reservas'); }
        });
    }

    $('#reservaFatura').on('change', function() {
        var selected = $(this).find('option:selected');
        var valor = parseFloat(selected.data('valor')) || 0;
        var iva = valor * 0.16;
        var total = valor + iva;

        $('#subtotalFatura').val(formatMoney(valor));
        $('#ivaFatura').val(formatMoney(iva));
        $('#totalFatura').val(formatMoney(total));
    });

    // ==================== CARREGAR STATS ====================
    function loadStats() {
        $.ajax({
            url: contextPath + '/Gerente/api/fatura/stats',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                $('#totalFaturado').text(formatMoney(data.total_faturado || 0));
                $('#contasReceber').text(formatMoney(data.contas_receber || 0));
                $('#totalFaturas').text(data.total_faturas || 0);
                $('#faturasMes').text(data.faturas_mes || 0);
            },
            error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    // ==================== CARREGAR GRÁFICOS ====================
    function loadGraficos() {
        $.ajax({
            url: contextPath + '/Gerente/api/fatura/graficos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                // Gráfico por estado
                if (estadoChart) estadoChart.destroy();
                estadoChart = new Chart(document.getElementById('estadoFaturasChart'), {
                    type: 'doughnut',
                    data: {
                        labels: ['PAGA', 'PENDENTE', 'VENCIDA'],
                        datasets: [{
                            data: [data.pagas || 0, data.pendentes || 0, data.vencidas || 0],
                            backgroundColor: ['#2E7D32', '#F57C00', '#C76A3C'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } },
                        cutout: '60%'
                    }
                });

                // Gráfico de faturação mensal
                if (faturacaoChart) faturacaoChart.destroy();
                var faturacaoMensal = data.faturacao_mensal || [];
                faturacaoChart = new Chart(document.getElementById('faturacaoMensalChart'), {
                    type: 'line',
                    data: {
                        labels: faturacaoMensal.map(function(f) { return f.mes; }),
                        datasets: [{
                            label: 'Faturação (MZN)',
                            data: faturacaoMensal.map(function(f) { return f.total; }),
                            borderColor: '#D4AF37',
                            backgroundColor: 'rgba(212, 175, 55, 0.05)',
                            tension: 0.3,
                            fill: true,
                            pointBackgroundColor: '#D4AF37'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return formatMoney(v); } } } }
                    }
                });
            },
            error: function() { console.error('Erro ao carregar gráficos'); }
        });
    }

    // ==================== CARREGAR FATURAS ====================
    function loadFaturas() {
        showLoading();
        $.ajax({
            url: contextPath + '/Gerente/api/fatura/listar',
            method: 'GET',
            data: { page: currentPage, search: currentSearch, estado: currentEstado, data: currentData },
            dataType: 'json',
            success: function(data) {
                var tbody = $('#faturasTableBody');
                tbody.empty();

                if (!data.faturas || data.faturas.length === 0) {
                    tbody.html('<td><td colspan="10" class="text-center py-4">Nenhuma fatura encontrada</td></tr>');
                    $('#paginationContainer').empty();
                    hideLoading();
                    return;
                }

                for (var i = 0; i < data.faturas.length; i++) {
                    var f = data.faturas[i];
                    var estadoClass = getEstadoClass(f.estado_pagamento);
                    var row = '<tr>' +
                        '<td><strong>' + escapeHtml(f.numero_fatura) + '</strong></td>' +
                        '<td>' + escapeHtml(f.cliente_nome) + '</td>' +
                        '<td><span class="badge bg-secondary">#' + f.id_reserva + '</span></td>' +
                        '<td>' + formatMoney(f.subtotal) + '</td>' +
                        '<td>' + formatMoney(f.iva) + '</td>' +
                        '<td><strong>' + formatMoney(f.total) + '</strong></td>' +
                        '<td>' + formatDateTime(f.data_emissao) + '</td>' +
                        '<td>' + formatDate(f.data_vencimento) + '</td>' +
                        '<td><span class="badge-status ' + estadoClass + '">' + escapeHtml(f.estado_pagamento) + '</span></td>' +
                        '<td class="action-buttons">' +
                            '<button class="action-btn view" onclick="viewFatura(' + f.id_fatura + ')"><i class="bi bi-eye"></i></button>' +
                            '<button class="action-btn pdf" onclick="downloadFaturaPDF(' + f.id_fatura + ')"><i class="bi bi-file-pdf"></i></button>' +
                        '</td>' +
                        '</tr>';
                    tbody.append(row);
                }

                // Paginação
                var pagination = $('#paginationContainer');
                pagination.empty();
                if (data.total_pages > 1) {
                    var ul = $('<ul class="pagination"></ul>');
                    if (data.current_page > 1) {
                        ul.append('<li class="page-item"><a class="page-link" onclick="goToPage(' + (data.current_page - 1) + ')">«</a></li>');
                    }
                    for (var p = 1; p <= data.total_pages; p++) {
                        var activeClass = (p === data.current_page) ? 'active' : '';
                        ul.append('<li class="page-item ' + activeClass + '"><a class="page-link" onclick="goToPage(' + p + ')">' + p + '</a></li>');
                    }
                    if (data.current_page < data.total_pages) {
                        ul.append('<li class="page-item"><a class="page-link" onclick="goToPage(' + (data.current_page + 1) + ')">»</a></li>');
                    }
                    pagination.append(ul);
                }

                hideLoading();
            },
            error: function() {
                $('#faturasTableBody').html('<td><td colspan="10" class="text-center py-4 text-danger">Erro ao carregar dados</td></tr>');
                hideLoading();
            }
        });
    }

    // ==================== FUNÇÕES DE AÇÃO ====================
    function goToPage(page) {
        currentPage = page;
        loadFaturas();
    }

    function viewFatura(id) {
        $.ajax({
            url: contextPath + '/Gerente/api/fatura/detalhes',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(data) {
                $('#faturaNumeroModal').text(data.numero_fatura);
                $('#printNumero').text(data.numero_fatura);
                $('#printDataEmissao').text(formatDateTime(data.data_emissao));
                $('#printDataVencimento').text(formatDate(data.data_vencimento));
                $('#printCliente').text(data.cliente_nome);
                $('#printReserva').text('#' + data.id_reserva);
                $('#printSubtotal').text(formatMoney(data.subtotal));
                $('#printIva').text(formatMoney(data.iva));
                $('#printTotal').text(formatMoney(data.total));
                new bootstrap.Modal(document.getElementById('modalVisualizarFatura')).show();
            },
            error: function() {
                Swal.fire('Erro', 'Não foi possível carregar os detalhes da fatura', 'error');
            }
        });
    }

    function downloadFaturaPDF(id) {
        $.ajax({
            url: contextPath + '/Gerente/api/fatura/detalhes',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(data) {
                var printContent = $('#faturaPrintContent').clone();
                printContent.find('#printNumero').text(data.numero_fatura);
                printContent.find('#printDataEmissao').text(formatDateTime(data.data_emissao));
                printContent.find('#printDataVencimento').text(formatDate(data.data_vencimento));
                printContent.find('#printCliente').text(data.cliente_nome);
                printContent.find('#printReserva').text('#' + data.id_reserva);
                printContent.find('#printSubtotal').text(formatMoney(data.subtotal));
                printContent.find('#printIva').text(formatMoney(data.iva));
                printContent.find('#printTotal').text(formatMoney(data.total));

                var win = window.open('', '_blank');
                win.document.write('<!DOCTYPE html><html><head><title>Fatura_' + data.numero_fatura + '</title>');
                win.document.write('<style>');
                win.document.write('body { font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif; padding: 40px; }');
                win.document.write('table { width: 100%; border-collapse: collapse; }');
                win.document.write('th, td { padding: 10px; }');
                win.document.write('</style></head><body>');
                win.document.write(printContent.html());
                win.document.write('</body></html>');
                win.document.close();
                win.print();
                Swal.fire({
                    icon: 'success',
                    title: 'PDF gerado!',
                    text: 'Fatura ' + data.numero_fatura,
                    timer: 1500,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
            },
            error: function() {
                Swal.fire('Erro', 'Não foi possível gerar o PDF', 'error');
            }
        });
    }

    $('#printFaturaBtn').on('click', function() {
        var faturaNumero = $('#faturaNumeroModal').text();
        for (var i = 0; i < faturas.length; i++) {
            if (faturas[i].numero_fatura === faturaNumero) {
                downloadFaturaPDF(faturas[i].id_fatura);
                break;
            }
        }
    });

    // ==================== EMITIR FATURA ====================
    $('#formFatura').on('submit', function(e) {
        e.preventDefault();
        showLoading();

        var formData = {
            id_reserva: $('#reservaFatura').val(),
            data_vencimento: $('#dataVencimento').val()
        };

        $.ajax({
            url: contextPath + '/Gerente/api/fatura/emitir',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            dataType: 'json',
            success: function(response) {
                hideLoading();
                if (response.success) {
                    Swal.fire('Sucesso', response.message, 'success');
                    bootstrap.Modal.getInstance(document.getElementById('modalFatura')).hide();
                    loadFaturas();
                    loadStats();
                    loadGraficos();
                    $('#formFatura')[0].reset();
                    $('#subtotalFatura').val('');
                    $('#ivaFatura').val('');
                    $('#totalFatura').val('');
                } else {
                    Swal.fire('Erro', response.message, 'error');
                }
            },
            error: function() {
                hideLoading();
                Swal.fire('Erro', 'Erro ao emitir fatura', 'error');
            }
        });
    });

    // ==================== FILTROS ====================
    $('#searchInput').on('input', function() {
        currentSearch = this.value;
        currentPage = 1;
        loadFaturas();
    });

    $('#estadoFilter').on('change', function() {
        currentEstado = this.value;
        currentPage = 1;
        loadFaturas();
    });

    flatpickr("#dateFilter", {
        dateFormat: "Y-m-d",
        locale: "pt",
        onChange: function(selectedDates, dateStr) {
            currentData = dateStr;
            currentPage = 1;
            loadFaturas();
        }
    });

    // ==================== RELÓGIO ====================
    function updateClock() {
        var now = new Date();
        $('#horaAtual').text(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').text(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
    }
    setInterval(updateClock, 1000);
    updateClock();

    $('#refreshBtn').on('click', function() {
        loadFaturas();
        loadStats();
        loadGraficos();
        Swal.fire({
            icon: 'success',
            title: 'Atualizado!',
            text: 'Dados das faturas foram atualizados',
            timer: 1500,
            showConfirmButton: false,
            toast: true,
            position: 'top-end'
        });
    });

    // ==================== INICIALIZAÇÃO ====================
    $(document).ready(function() {
        loadStats();
        loadGraficos();
        loadFaturas();

        setInterval(function() {
            loadStats();
            loadGraficos();
        }, 30000);
    });
</script>
</body>
</html>