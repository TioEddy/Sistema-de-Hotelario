<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerente · Dashboard Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F5F0E8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #1A3C2C;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(212, 175, 55, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #D4AF37;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #D4AF37; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #D4AF37; }
        .sidebar li:hover { background: rgba(212, 175, 55, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #D4AF37; color: #1A3C2C; }
        .sidebar li.active i { color: #1A3C2C; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1A3C2C; font-weight: 500; }
        .sidebar .menu-section {
            color: #D4AF37;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #D4AF37; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1A3C2C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1A3C2C; }
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,0.08); border-color: #D4AF37; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-header i { font-size: 1.5rem; color: #D4AF37; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #1A3C2C; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; display: flex; align-items: center; gap: 6px; }
        .trend-up { color: #4CAF50; }
        .trend-down { color: #C76A3C; }
        .charts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #1A3C2C; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #D4AF37; }
        .chart-container { position: relative; height: 180px; width: 100%; }
        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1A3C2C; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #D4AF37; color: #1A3C2C; font-weight: 600; padding: 10px 6px; }
        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 500; }
        .badge-status.CONFIRMADA { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.CHECK-IN { background: #1A3C2C; color: #D4AF37; }
        .badge-status.OCUPADO { background: #E3F2FD; color: #1976D2; }
        .badge-status.LIVRE { background: #F1F8E9; color: #558B2F; }
        .badge-status.MANUTENCAO { background: #FFEBEE; color: #C76A3C; }
        .badge-status.PAGO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE_PAG { background: #FFF8E1; color: #F57C00; }
        .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .info-card { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; transition: all 0.2s; cursor: pointer; }
        .info-card:hover { border-color: #D4AF37; }
        .info-card h4 { font-size: 0.85rem; font-weight: 600; color: #1A3C2C; margin-bottom: 14px; }
        .info-item { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px dashed #E8DFC8; }
        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #D4AF37; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .info-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">OPERACIONAL</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Gerente/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/quarto.jsp"><i class="bi bi-door-open"></i> Quartos</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS & CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/cliente.jsp"><i class="bi bi-people"></i> Clientes</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumo Serviços</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/fatura.jsp"><i class="bi bi-receipt"></i> Faturas</a></li>
    </ul>

    <div class="menu-section">EQUIPA</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Gerente/funcionario.jsp"><i class="bi bi-person-badge"></i> Funcionários</a></li>
        <li><a href="${pageContext.request.contextPath}/Gerente/turno.jsp"><i class="bi bi-clock-history"></i> Turnos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Manager<span>Dashboard Gerencial</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <!-- CARDS ESTATÍSTICOS (Dinâmicos via AJAX) -->
    <div class="stats-grid">
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Gerente/quarto.jsp'">
            <div class="stat-header"><h3>OCUPAÇÃO HOJE</h3><i class="bi bi-building"></i></div>
            <div class="stat-value" id="taxaOcupacao">--%</div>
            <div class="stat-footer"><i class="bi bi-graph-up trend-up"></i><span id="ocupacaoVariacao">-</span></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Gerente/check.jsp'">
            <div class="stat-header"><h3>CHECK-INS</h3><i class="bi bi-person-arms-up"></i></div>
            <div class="stat-value" id="checkinsHoje">--</div>
            <div class="stat-footer"><i class="bi bi-check-circle"></i><span id="checkinsRealizados">0 realizados</span></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Gerente/check.jsp'">
            <div class="stat-header"><h3>CHECK-OUTS</h3><i class="bi bi-luggage"></i></div>
            <div class="stat-value" id="checkoutsHoje">--</div>
            <div class="stat-footer"><i class="bi bi-clock"></i><span id="checkoutsAguardando">0 aguardando</span></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Gerente/consumo.jsp'">
            <div class="stat-header"><h3>CONSUMO TOTAL</h3><i class="bi bi-cup-straw"></i></div>
            <div class="stat-value" id="consumoTotal">-- MZN</div>
            <div class="stat-footer"><i class="bi bi-trending-up trend-up"></i><span id="consumoVariacao">-</span></div>
        </div>
    </div>

    <!-- GRÁFICOS -->
    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Estado das Reservas</h3>
            <div class="chart-container"><canvas id="reservasEstadoChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Top Serviços Consumidos</h3>
            <div class="chart-container"><canvas id="servicosChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-graph-up"></i> Faturação Mensal</h3>
            <div class="chart-container"><canvas id="faturamentoChart"></canvas></div>
        </div>
    </div>

    <!-- TABELA: Check-ins do dia -->
    <div class="table-section">
        <h3><i class="bi bi-person-check"></i> Check-ins Hoje</h3>
        <table class="table">
            <thead>
                <tr><th>Hóspede</th><th>Quarto</th><th>Check-in</th><th>Hóspedes</th><th>Observações</th><th>Status</th></tr>
            </thead>
            <tbody id="checkinsTableBody">
                <tr><td colspan="6" class="text-center py-4"><div class="loading-spinner"></div> Carregando...</td></tr>
            </tbody>
        </table>
    </div>

    <!-- TABELA: Estado dos Quartos -->
    <div class="table-section">
        <h3><i class="bi bi-door-open"></i> Estado dos Quartos</h3>
        <table class="table">
            <thead>
                <tr><th>Nº Quarto</th><th>Tipo</th><th>Piso</th><th>Estado</th><th>Hóspede</th></tr>
            </thead>
            <tbody id="quartosTableBody">
                <tr><td colspan="5" class="text-center py-4"><div class="loading-spinner"></div> Carregando...</td></tr>
            </tbody>
        </table>
    </div>

    <!-- CARDS ADICIONAIS -->
    <div class="info-grid">
        <div class="info-card" onclick="location.href='${pageContext.request.contextPath}/Gerente/consumo.jsp'">
            <h4><i class="bi bi-cup-straw"></i> Top Serviços Consumidos</h4>
            <div class="info-item" id="topServico1"><span>Carregando...</span><strong>--</strong></div>
            <div class="info-item" id="topServico2"><span>Carregando...</span><strong>--</strong></div>
            <div class="info-item" id="topServico3"><span>Carregando...</span><strong>--</strong></div>
            <div class="info-item" id="topServico4"><span>Carregando...</span><strong>--</strong></div>
        </div>
        <div class="info-card" onclick="location.href='${pageContext.request.contextPath}/Gerente/pagamento.jsp'">
            <h4><i class="bi bi-cash-stack"></i> Pagamentos do Dia</h4>
            <div class="info-item" id="pagamentoDinheiro"><span>Dinheiro</span><span>-- MZN</span></div>
            <div class="info-item" id="pagamentoPOS"><span>POS</span><span>-- MZN</span></div>
            <div class="info-item" id="pagamentoMPesa"><span>M-Pesa</span><span>-- MZN</span></div>
            <div class="info-item" id="pagamentoTransferencia"><span>Transferência</span><span>-- MZN</span></div>
            <div class="info-item mt-2"><strong>Total</strong><strong id="totalPagamentos">-- MZN</strong></div>
        </div>
        <div class="info-card" onclick="location.href='${pageContext.request.contextPath}/Gerente/funcionario.jsp'">
            <h4><i class="bi bi-person-badge"></i> Funcionários em Serviço</h4>
            <div class="info-item"><span>Total Funcionários</span><strong id="totalFuncionarios">--</strong></div>
            <div class="info-item"><span>Recepcionistas</span><strong id="recepcionistasCount">--</strong></div>
            <div class="info-item"><span>Housekeeping</span><strong id="housekeepingCount">--</strong></div>
            <div class="info-item"><span>Manutenção</span><strong id="manutencaoCount">--</strong></div>
        </div>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';

    // Variáveis para os charts
    let reservasEstadoChart = null;
    let servicosChart = null;
    let faturamentoChart = null;

    // ==================== FUNÇÕES AUXILIARES ====================
    function formatMoney(value) {
        if (value === undefined || value === null || isNaN(value)) return "0 MZN";
        return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function getEstadoClass(estado) {
        var estadoUpper = (estado || '').toUpperCase();
        if (estadoUpper === 'CONFIRMADA') return 'CONFIRMADA';
        if (estadoUpper === 'PENDENTE') return 'PENDENTE';
        if (estadoUpper === 'CHECK-IN') return 'CHECK-IN';
        if (estadoUpper === 'OCUPADO') return 'OCUPADO';
        if (estadoUpper === 'LIVRE') return 'LIVRE';
        if (estadoUpper === 'MANUTENCAO') return 'MANUTENCAO';
        return 'PENDENTE';
    }

    function getBadgeStatus(estado) {
        var classe = getEstadoClass(estado);
        return '<span class="badge-status ' + classe + '">' + estado + '</span>';
    }

    // ==================== CARREGAR DADOS DO DASHBOARD ====================
    function loadDashboardData() {
        $.ajax({
            url: contextPath + '/Gerente/api/dashboard',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                // Atualizar cards
                $('#taxaOcupacao').text((data.taxa_ocupacao || 0) + '%');
                $('#ocupacaoVariacao').text(data.ocupacao_variacao || '+0%');
                $('#checkinsHoje').text(data.checkins_hoje || 0);
                $('#checkinsRealizados').text((data.checkins_realizados || 0) + ' realizados');
                $('#checkoutsHoje').text(data.checkouts_hoje || 0);
                $('#checkoutsAguardando').text((data.checkouts_aguardando || 0) + ' aguardando');
                $('#consumoTotal').html(formatMoney(data.consumo_total || 0));
                $('#consumoVariacao').text(data.consumo_variacao || '+0%');

                // Atualizar cards de serviços top
                if (data.top_servicos && data.top_servicos.length > 0) {
                    for (var i = 0; i < Math.min(4, data.top_servicos.length); i++) {
                        $('#topServico' + (i+1)).html('<span>' + escapeHtml(data.top_servicos[i].nome) + '</span><strong>' + data.top_servicos[i].quantidade + ' consumos</strong>');
                    }
                }

                // Atualizar pagamentos do dia
                if (data.pagamentos_dia) {
                    $('#pagamentoDinheiro').html('<span>Dinheiro</span><span>' + formatMoney(data.pagamentos_dia.dinheiro || 0) + '</span>');
                    $('#pagamentoPOS').html('<span>POS</span><span>' + formatMoney(data.pagamentos_dia.pos || 0) + '</span>');
                    $('#pagamentoMPesa').html('<span>M-Pesa</span><span>' + formatMoney(data.pagamentos_dia.mpesa || 0) + '</span>');
                    $('#pagamentoTransferencia').html('<span>Transferência</span><span>' + formatMoney(data.pagamentos_dia.transferencia || 0) + '</span>');
                    $('#totalPagamentos').html(formatMoney(data.pagamentos_dia.total || 0));
                }

                // Atualizar funcionários
                if (data.funcionarios) {
                    $('#totalFuncionarios').text(data.funcionarios.total || 0);
                    $('#recepcionistasCount').text(data.funcionarios.recepcionistas || 0);
                    $('#housekeepingCount').text(data.funcionarios.housekeeping || 0);
                    $('#manutencaoCount').text(data.funcionarios.manutencao || 0);
                }

                // Atualizar gráficos
                updateCharts(data);
            },
            error: function(xhr, status, error) {
                console.error('Erro ao carregar dashboard:', error);
            }
        });
    }

    // ==================== CARREGAR CHECK-INS DO DIA ====================
    function loadCheckinsHoje() {
        $.ajax({
            url: contextPath + '/Gerente/api/checkins/hoje',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#checkinsTableBody');
                tbody.empty();

                if (!data || data.length === 0) {
                    tbody.html('<tr><td colspan="6" class="text-center py-4">Nenhum check-in para hoje</td></tr>');
                    return;
                }

                for (var i = 0; i < data.length; i++) {
                    var c = data[i];
                    var row = '<tr>' +
                        '<td><strong>' + escapeHtml(c.cliente_nome) + '</strong></td>' +
                        '<td>' + escapeHtml(c.quarto_num) + '</td>' +
                        '<td>' + c.hora_checkin + '</td>' +
                        '<td class="text-center">' + (c.numero_hospedes || 1) + '</td>' +
                        '<td>' + (c.observacoes || '-') + '</td>' +
                        '<td>' + getBadgeStatus(c.status || 'PENDENTE') + '</td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#checkinsTableBody').html('<tr><td colspan="6" class="text-center py-4 text-danger">Erro ao carregar check-ins</td></tr>');
            }
        });
    }

    // ==================== CARREGAR QUARTOS ====================
    function loadQuartos() {
        $.ajax({
            url: contextPath + '/Gerente/api/quartos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#quartosTableBody');
                tbody.empty();

                if (!data || data.length === 0) {
                    tbody.html('<tr><td colspan="5" class="text-center py-4">Nenhum quarto cadastrado</td></tr>');
                    return;
                }

                for (var i = 0; i < data.length; i++) {
                    var q = data[i];
                    var row = '<tr>' +
                        '<td><strong>' + escapeHtml(q.numero_quarto) + '</strong></td>' +
                        '<td>' + escapeHtml(q.tipo || '-') + '</td>' +
                        '<td>' + (q.piso ? q.piso + 'º' : '-') + '</td>' +
                        '<td>' + getBadgeStatus(q.estado) + '</td>' +
                        '<td>' + escapeHtml(q.hospede_atual || '-') + '</td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#quartosTableBody').html('<tr><td colspan="5" class="text-center py-4 text-danger">Erro ao carregar quartos</td></tr>');
            }
        });
    }

    // ==================== ATUALIZAR GRÁFICOS ====================
    function updateCharts(data) {
        // Gráfico de estado das reservas
        var ctxReservas = document.getElementById('reservasEstadoChart').getContext('2d');
        if (reservasEstadoChart) reservasEstadoChart.destroy();

        var reservasData = data.reservas_estado || { CONFIRMADA: 0, PENDENTE: 0, 'CHECK-IN': 0, FINALIZADA: 0, CANCELADA: 0 };

        reservasEstadoChart = new Chart(ctxReservas, {
            type: 'doughnut',
            data: {
                labels: ['CONFIRMADAS', 'PENDENTES', 'CHECK-IN', 'FINALIZADAS', 'CANCELADAS'],
                datasets: [{
                    data: [
                        reservasData.CONFIRMADA || 0,
                        reservasData.PENDENTE || 0,
                        reservasData['CHECK-IN'] || 0,
                        reservasData.FINALIZADA || 0,
                        reservasData.CANCELADA || 0
                    ],
                    backgroundColor: ['#2E7D32', '#F57C00', '#1A3C2C', '#1976D2', '#C76A3C'],
                    borderWidth: 0,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } },
                cutout: '60%'
            }
        });

        // Gráfico de serviços consumidos
        var ctxServicos = document.getElementById('servicosChart').getContext('2d');
        if (servicosChart) servicosChart.destroy();

        var servicosLabels = [];
        var servicosValues = [];
        if (data.top_servicos) {
            for (var i = 0; i < data.top_servicos.length; i++) {
                servicosLabels.push(data.top_servicos[i].nome);
                servicosValues.push(data.top_servicos[i].quantidade);
            }
        }

        servicosChart = new Chart(ctxServicos, {
            type: 'bar',
            data: {
                labels: servicosLabels.length > 0 ? servicosLabels : ['Nenhum dado'],
                datasets: [{
                    label: 'Quantidade',
                    data: servicosValues.length > 0 ? servicosValues : [0],
                    backgroundColor: '#D4AF37',
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, grid: { color: '#E8DFC8' } }, x: { grid: { display: false } } },
                plugins: { legend: { display: false } }
            }
        });

        // Gráfico de faturação mensal
        var ctxFaturamento = document.getElementById('faturamentoChart').getContext('2d');
        if (faturamentoChart) faturamentoChart.destroy();

        var mesesLabels = data.faturamento_mensal ? data.faturamento_mensal.map(function(m) { return m.mes; }) : ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
        var valoresFaturamento = data.faturamento_mensal ? data.faturamento_mensal.map(function(m) { return m.total; }) : [0, 0, 0, 0, 0, 0];

        faturamentoChart = new Chart(ctxFaturamento, {
            type: 'line',
            data: {
                labels: mesesLabels,
                datasets: [{
                    label: 'Faturação (MZN)',
                    data: valoresFaturamento,
                    borderColor: '#1A3C2C',
                    backgroundColor: 'rgba(26, 60, 44, 0.05)',
                    tension: 0.3,
                    fill: true,
                    pointBackgroundColor: '#D4AF37',
                    pointBorderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#E8DFC8' },
                        ticks: { callback: function(v) { return v.toLocaleString() + ' MZN'; } }
                    }
                }
            }
        });
    }

    // ==================== RELÓGIO ====================
    function updateClock() {
        var now = new Date();
        var timeStr = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        var dateStr = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
        $('#horaAtual').text(timeStr);
        $('#dataAtual').text(dateStr);
    }
    setInterval(updateClock, 1000);
    updateClock();

    // ==================== INICIALIZAÇÃO ====================
    $(document).ready(function() {
        loadDashboardData();
        loadCheckinsHoje();
        loadQuartos();

        // Refresh automático a cada 30 segundos
        setInterval(function() {
            loadDashboardData();
            loadCheckinsHoje();
            loadQuartos();
        }, 30000);
    });
</script>

</body>
</html>