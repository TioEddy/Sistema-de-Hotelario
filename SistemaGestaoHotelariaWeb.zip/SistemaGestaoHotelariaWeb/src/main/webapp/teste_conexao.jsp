<%@ page import="java.sql.*" %>
<%@ page import="com.hotel.dao.ConexaoDB" %>
<!DOCTYPE html>
<html>
<head>
    <title>Teste Conexão Banco</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .success { color: green; background: #e8f5e9; padding: 10px; border-radius: 5px; }
        .error { color: red; background: #ffebee; padding: 10px; border-radius: 5px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #0B2B40; color: white; }
    </style>
</head>
<body>
    <h1>🔧 Teste de Conexão com Banco de Dados</h1>

    <%
        try {
            Connection conn = ConexaoDB.getConexao();
            if (conn != null && !conn.isClosed()) {
                out.println("<div class='success'>✅ Conexão estabelecida com sucesso!</div>");

                // Testar consulta na tabela usuario
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM usuario");

                out.println("<h2>📋 Usuários no banco:</h2>");
                out.println("<table>");
                out.println("<tr><th>ID</th><th>Nome</th><th>Username</th><th>Email</th><th>Perfil</th><th>Estado</th><th>Senha</th></tr>");

                while (rs.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs.getInt("id_usuario") + "</td>");
                    out.println("<td>" + rs.getString("nome") + "</td>");
                    out.println("<td>" + rs.getString("username") + "</td>");
                    out.println("<td>" + (rs.getString("email") != null ? rs.getString("email") : "-") + "</td>");
                    out.println("<td>" + rs.getInt("id_perfil") + "</td>");
                    out.println("<td>" + rs.getString("estado") + "</td>");
                    out.println("<td>" + rs.getString("senha") + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");

                rs.close();
                stmt.close();
            } else {
                out.println("<div class='error'>❌ Falha na conexão!</div>");
            }
            ConexaoDB.fecharConexao();
        } catch (Exception e) {
            out.println("<div class='error'>❌ Erro: " + e.getMessage() + "</div>");
            e.printStackTrace(response.getWriter());
        }
    %>
</body>
</html>