<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Teste API Usuários</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .success { color: green; background: #e8f5e9; padding: 10px; border-radius: 5px; }
        .error { color: red; background: #ffebee; padding: 10px; border-radius: 5px; }
        pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
        h2 { color: #0B2B40; margin-top: 20px; }
    </style>
</head>
<body>
    <h1>🔧 Teste da API de Usuários</h1>

    <h2>📋 1. Teste /Admin/usuarios/listar</h2>
    <div id="resultadoListar" style="background:#f0f0f0; padding:10px; margin-bottom:20px; border-radius:5px;">
        Carregando...
    </div>

    <h2>📋 2. Teste /Admin/usuarios/perfis</h2>
    <div id="resultadoPerfis" style="background:#f0f0f0; padding:10px; margin-bottom:20px; border-radius:5px;">
        Carregando...
    </div>

    <h2>📋 3. Teste Buscar usuário por ID (id=1)</h2>
    <div id="resultadoEditar" style="background:#f0f0f0; padding:10px; margin-bottom:20px; border-radius:5px;">
        Carregando...
    </div>

    <script>
        // Testar listar usuários
        fetch('/SistemaGestaoHotelariaWeb/Admin/usuarios/listar')
            .then(response => response.json())
            .then(data => {
                document.getElementById('resultadoListar').innerHTML =
                    '<div class="success">✅ Sucesso!</div>' +
                    '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
            })
            .catch(error => {
                document.getElementById('resultadoListar').innerHTML =
                    '<div class="error">❌ Erro: ' + error + '</div>' +
                    '<p>Verifique se o servidor está rodando e o UsuarioController está registrado.</p>';
            });

        // Testar listar perfis
        fetch('/SistemaGestaoHotelariaWeb/Admin/usuarios/perfis')
            .then(response => response.json())
            .then(data => {
                document.getElementById('resultadoPerfis').innerHTML =
                    '<div class="success">✅ Sucesso!</div>' +
                    '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
            })
            .catch(error => {
                document.getElementById('resultadoPerfis').innerHTML =
                    '<div class="error">❌ Erro: ' + error + '</div>';
            });

        // Testar buscar usuário por ID
        fetch('/SistemaGestaoHotelariaWeb/Admin/usuarios/editar?id=1')
            .then(response => response.json())
            .then(data => {
                document.getElementById('resultadoEditar').innerHTML =
                    '<div class="success">✅ Sucesso!</div>' +
                    '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
            })
            .catch(error => {
                document.getElementById('resultadoEditar').innerHTML =
                    '<div class="error">❌ Erro: ' + error + '</div>';
            });
    </script>
</body>
</html>