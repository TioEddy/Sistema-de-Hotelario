<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Saindo do Sistema · Hotelaria</title>

  <!-- Bootstrap Icons & Font Awesome -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow-x: hidden;
    }

    body {
      background: linear-gradient(135deg, #0B2B40 0%, #1A4B6E 100%);
      transition: background 0.5s ease;
    }

    .logout-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(8px);
      z-index: 999;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      visibility: hidden;
      transition: all 0.5s ease;
    }

    .logout-overlay.show {
      opacity: 1;
      visibility: visible;
    }

    .logout-card {
      background: white;
      border-radius: 32px;
      padding: 48px 40px;
      text-align: center;
      max-width: 500px;
      width: 90%;
      animation: fadeInUp 0.6s ease-out;
      box-shadow: 0 30px 60px rgba(0, 0, 0, 0.3);
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(40px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.1); }
      100% { transform: scale(1); }
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    @keyframes float {
      0% { transform: translateY(0px); }
      50% { transform: translateY(-10px); }
      100% { transform: translateY(0px); }
    }

    .logout-icon {
      font-size: 5rem;
      color: #FFB800;
      margin-bottom: 24px;
      animation: pulse 0.8s ease-in-out;
    }

    .logout-card h2 {
      font-size: 1.8rem;
      font-weight: 700;
      color: #0B2B40;
      margin-bottom: 12px;
    }

    .logout-card p {
      color: #6C8D9C;
      margin-bottom: 8px;
    }

    .user-info {
      background: #F0F5F8;
      border-radius: 20px;
      padding: 16px;
      margin: 24px 0;
      display: inline-block;
      width: 100%;
    }

    .user-info .user-name {
      font-weight: 700;
      color: #0B2B40;
      font-size: 1.1rem;
    }

    .user-info .user-role {
      color: #FFB800;
      font-size: 0.8rem;
      font-weight: 600;
    }

    .user-avatar {
      width: 60px;
      height: 60px;
      background: #0B2B40;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 12px;
    }

    .user-avatar i {
      font-size: 2rem;
      color: #FFB800;
    }

    .spinner-container {
      margin: 20px 0;
    }

    .spinner-border-custom {
      width: 40px;
      height: 40px;
      border: 3px solid #E2EAEF;
      border-top-color: #FFB800;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto;
    }

    .progress-bar-container {
      width: 100%;
      height: 4px;
      background: #E2EAEF;
      border-radius: 4px;
      margin: 24px 0;
      overflow: hidden;
    }

    .progress-bar-fill {
      width: 0%;
      height: 100%;
      background: #FFB800;
      border-radius: 4px;
      transition: width 0.1s linear;
    }

    .btn-group {
      display: flex;
      gap: 16px;
      justify-content: center;
      margin-top: 24px;
    }

    .btn-login-again {
      background: #FFB800;
      border: none;
      padding: 12px 28px;
      border-radius: 40px;
      font-weight: 600;
      color: #0B2B40;
      transition: all 0.3s;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }

    .btn-login-again:hover {
      background: #0B2B40;
      color: #FFB800;
      transform: translateY(-2px);
    }

    .btn-stay {
      background: transparent;
      border: 2px solid #E2EAEF;
      padding: 12px 28px;
      border-radius: 40px;
      font-weight: 600;
      color: #6C8D9C;
      transition: all 0.3s;
    }

    .btn-stay:hover {
      border-color: #FFB800;
      color: #FFB800;
    }

    .countdown {
      font-size: 0.85rem;
      color: #8AA6B5;
      margin-top: 16px;
    }

    .countdown span {
      font-weight: 700;
      color: #FFB800;
      font-size: 1.1rem;
    }

    .particle {
      position: fixed;
      bottom: 0;
      animation: float 3s ease-in-out infinite;
      opacity: 0.15;
      pointer-events: none;
      z-index: 0;
    }

    @keyframes float {
      0% { transform: translateY(0) rotate(0deg); opacity: 0; }
      50% { opacity: 0.3; }
      100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
    }
  </style>
</head>
<body>

<div class="logout-overlay" id="logoutOverlay">
  <div class="logout-card">
    <div class="logout-icon">
      <i class="bi bi-box-arrow-right"></i>
    </div>
    <h2>Até breve!</h2>
    <p>A sua sessão está sendo encerrada com segurança.</p>

    <div class="user-info" id="userInfo">
      <div class="user-avatar">
        <i class="bi bi-person-circle"></i>
      </div>
      <div class="user-name" id="userName">Carregando...</div>
      <div class="user-role" id="userRole"></div>
    </div>

    <div class="spinner-container">
      <div class="spinner-border-custom"></div>
    </div>

    <div class="progress-bar-container">
      <div class="progress-bar-fill" id="progressBar"></div>
    </div>

    <p class="text-muted" style="font-size: 0.85rem;">
      <i class="bi bi-shield-check"></i> Sessão encerrada com segurança
    </p>

    <div class="countdown" id="countdownText">
      Redirecionando em <span id="seconds">5</span> segundos...
    </div>

    <div class="btn-group">
      <a href="#" class="btn-login-again" id="loginNowBtn">
        <i class="bi bi-box-arrow-in-right"></i> Entrar novamente
      </a>
      <button class="btn-stay" id="stayBtn">
        <i class="bi bi-x-circle"></i> Fechar
      </button>
    </div>
  </div>
</div>

<script>
  // Cores por perfil para o fundo
  const roleColors = {
    1: { bg: "linear-gradient(135deg, #0B2B40 0%, #1A4B6E 100%)", accent: "#FFB800" },      // Admin
    2: { bg: "linear-gradient(135deg, #2B5F4C 0%, #3D7A62 100%)", accent: "#FFC107" },      // Recepcionista
    3: { bg: "linear-gradient(135deg, #1B2B3C 0%, #2C3E50 100%)", accent: "#2ECC71" },      // Financeiro
    4: { bg: "linear-gradient(135deg, #1A3C2C 0%, #2D6A4F 100%)", accent: "#D4AF37" }       // Gerente
  };

  function getRoleIdFromName(roleName) {
    var roleMap = {
      'Administrador': 1,
      'Recepcionista': 2,
      'Financeiro': 3,
      'Gerente': 4,
      'admin': 1,
      'recepcao': 2,
      'financeiro': 3,
      'gerente': 4
    };
    return roleMap[roleName] || 1;
  }

  // Carregar dados do usuário do localStorage
  function loadUserData() {
    var userName = "Usuário";
    var userRole = "Colaborador";
    var userRoleId = 1;
    var userEmail = "";

    var storedUser = localStorage.getItem('usuarioLogado');

    if (storedUser) {
      try {
        var user = JSON.parse(storedUser);
        userName = user.name || user.username || user.role || "Usuário";
        userRole = user.role || "Colaborador";
        userRoleId = user.perfil_id || getRoleIdFromName(userRole);
        userEmail = user.email || "";
      } catch(e) {
        console.log("Erro ao parsear usuário:", e);
      }
    } else {
      // Tentar recuperar de outras chaves possíveis
      var hotelUser = localStorage.getItem('hotelUser');
      if (hotelUser) {
        try {
          var user = JSON.parse(hotelUser);
          userName = user.name || user.username || "Usuário";
          userRole = user.role || "Colaborador";
          userRoleId = user.perfil_id || getRoleIdFromName(userRole);
          userEmail = user.email || "";
        } catch(e) {}
      }
    }

    // Atualizar UI
    document.getElementById('userName').textContent = userName;
    document.getElementById('userRole').innerHTML = '<i class="bi bi-shield-check"></i> ' + userRole + ' · ' + userEmail;

    // Aplicar cor de fundo conforme perfil
    var color = roleColors[userRoleId] || roleColors[1];
    document.body.style.background = color.bg;
  }

  // Limpar dados da sessão
  function clearSession() {
    localStorage.removeItem('usuarioLogado');
    localStorage.removeItem('hotelUser');
    localStorage.removeItem('userHotelRole');
    localStorage.removeItem('rememberedHotelEmail');
    localStorage.removeItem('hotelEmail');
    localStorage.removeItem('userRole');
    sessionStorage.clear();
    console.log('[LOG_SISTEMA] Sessão encerrada com sucesso');
  }

  // Animar progress bar e redirecionar
  var seconds = 5;
  var interval;
  var progressInterval;

  function startCountdown() {
    var secondsSpan = document.getElementById('seconds');
    var progressBar = document.getElementById('progressBar');

    interval = setInterval(function() {
      seconds--;
      if (secondsSpan) secondsSpan.textContent = seconds;

      if (seconds <= 0) {
        clearInterval(interval);
        clearInterval(progressInterval);
        redirectToLogin();
      }
    }, 1000);

    var progress = 0;
    progressInterval = setInterval(function() {
      progress += 2;
      if (progressBar) progressBar.style.width = progress + '%';
      if (progress >= 100) clearInterval(progressInterval);
    }, 100);
  }

  function redirectToLogin() {
    window.location.href = "login.jsp";
  }

  function setupButtons() {
    var loginNowBtn = document.getElementById('loginNowBtn');
    var stayBtn = document.getElementById('stayBtn');

    if (loginNowBtn) {
      loginNowBtn.addEventListener('click', function(e) {
        e.preventDefault();
        clearInterval(interval);
        clearInterval(progressInterval);
        redirectToLogin();
      });
    }

    if (stayBtn) {
      stayBtn.addEventListener('click', function() {
        clearInterval(interval);
        clearInterval(progressInterval);
        var overlay = document.getElementById('logoutOverlay');
        if (overlay) {
          overlay.style.opacity = '0';
          setTimeout(function() {
            overlay.style.visibility = 'hidden';
          }, 300);
        }
      });
    }
  }

  function createParticles() {
    var particles = ['🏨', '🔑', '💰', '📊', '👋', '✨', '⭐', '🌙', '🛎️', '🧳'];
    for (var i = 0; i < 20; i++) {
      var particle = document.createElement('div');
      particle.className = 'particle';
      particle.innerHTML = particles[Math.floor(Math.random() * particles.length)];
      particle.style.left = Math.random() * 100 + '%';
      particle.style.fontSize = (Math.random() * 24 + 16) + 'px';
      particle.style.animationDuration = (Math.random() * 4 + 3) + 's';
      particle.style.animationDelay = Math.random() * 5 + 's';
      document.body.appendChild(particle);
    }
  }

  function init() {
    loadUserData();
    clearSession();
    createParticles();

    var overlay = document.getElementById('logoutOverlay');
    setTimeout(function() {
      overlay.classList.add('show');
    }, 100);

    setupButtons();
    startCountdown();

    console.log('[LOG_SISTEMA] Logout realizado em ' + new Date().toLocaleString());
  }

  window.addEventListener('DOMContentLoaded', init);
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>