<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balancete · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .btn-primary-custom { background: #2ECC71; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: white; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #1B2B3C; color: #2ECC71; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #2ECC71; color: #2ECC71; }
        .btn-export { background: transparent; border: 1px solid #E2E8F0; padding: 6px 12px; border-radius: 30px; font-size: 0.75rem; transition: all 0.2s; cursor: pointer; }
        .btn-export:hover { border-color: #2ECC71; color: #2ECC71; background: #E8F5E9; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2E8F0; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .month-selector select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2E8F0; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; transition: all 0.3s ease; border: 1px solid #E2E8F0; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #2ECC71; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.6rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #2ECC71; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #2ECC71; color: #1B2B3C; font-weight: 600; padding: 10px 6px; }

        .badge-tipo { padding: 4px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 500; }
        .badge-tipo.receita { background: #E8F5E9; color: #2E7D32; }
        .badge-tipo.despesa { background: #FFEBEE; color: #E74C3C; }
        .total-row { background: #FFF8E1; font-weight: bold; }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        @media print { .sidebar, .topbar, .filters-bar, .pagination, .footer, .btn, .charts-grid { display: none !important; } .main-wrapper { margin-left: 0 !important; padding: 0 !important; } .stats-grid, .table-section { box-shadow: none; border: 1px solid #ddd; } }
        @media (max-width: 1200px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .charts-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-calculator-fill"></i><div class="logo-text">Hotelaria · Financeiro<span>Balancete</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="filters-bar">
        <div class="month-selector">
            <i class="bi bi-calendar-month" style="color: #2ECC71; font-size: 1.2rem;"></i>
            <select id="periodoSelect" class="filter-select">
                <option value="1">Janeiro 2026</option>
                <option value="2">Fevereiro 2026</option>
                <option value="3">Março 2026</option>
                <option value="4">Abril 2026</option>
                <option value="5">Maio 2026</option>
                <option value="6">Junho 2026</option>
                <option value="7">Julho 2026</option>
                <option value="8">Agosto 2026</option>
                <option value="9">Setembro 2026</option>
                <option value="10">Outubro 2026</option>
                <option value="11">Novembro 2026</option>
                <option value="12">Dezembro 2026</option>
                <option value="0">Acumulado 2026</option>
            </select>
            <button class="btn-primary-custom" id="atualizarBalancete"><i class="bi bi-arrow-repeat"></i> Atualizar</button>
        </div>
        <div>
            <button class="btn-export" onclick="exportBalancetePDF()"><i class="bi bi-filetype-pdf"></i> PDF</button>
            <button class="btn-export" onclick="exportBalanceteCSV()"><i class="bi bi-filetype-csv"></i> CSV</button>
            <button class="btn-export" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir</button>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>TOTAL RECEITAS</h3><i class="bi bi-arrow-up-circle"></i></div><div class="stat-value" id="totalReceitas">0 MZN</div></div>
        <div class="stat-card"><div class="stat-header"><h3>TOTAL DESPESAS</h3><i class="bi bi-arrow-down-circle"></i></div><div class="stat-value" id="totalDespesas">0 MZN</div></div>
        <div class="stat-card"><div class="stat-header"><h3>RESULTADO</h3><i class="bi bi-calculator"></i></div><div class="stat-value" id="resultado">0 MZN</div></div>
        <div class="stat-card"><div class="stat-header"><h3>MARGEM</h3><i class="bi bi-graph-up"></i></div><div class="stat-value" id="margem">0%</div></div>
    </div>

    <div class="charts-grid">
        <div class="chart-box"><h3><i class="bi bi-pie-chart"></i> Distribuição de Receitas</h3><div class="chart-container"><canvas id="receitasChart"></canvas></div></div>
        <div class="chart-box"><h3><i class="bi bi-pie-chart"></i> Distribuição de Despesas</h3><div class="chart-container"><canvas id="despesasChart"></canvas></div></div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-table"></i> Balancete de Verificação</h3>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Conta</th><th>Categoria</th><th>Tipo</th><th>Saldo Anterior</th><th>Débito (Mês)</th><th>Crédito (Mês)</th><th>Saldo Atual</th></tr></thead>
                <tbody id="balanceteTableBody"><tr><td colspan="7" class="text-center py-4"><div class="spinner-border text-success"></div></td></tr></tbody>
            </table>
        </div>
    </div>

    <div class="footer"><i class="bi bi-database"></i> Sistema Hotelaria · Módulo Financeiro · Balancete de Verificação</div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let periodoAtual = new Date().getMonth() + 1;
    let anoAtual = new Date().getFullYear();
    let graficos = {};

    function formatMoney(v) { if (v === undefined || v === null || isNaN(v)) return "0 MZN"; return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN"; }

    function carregarBalancete() {
        var mes = periodoAtual === 0 ? null : periodoAtual;
        $.ajax({ url: contextPath + '/Financeiro/balancete/dados', method: 'GET', data: { mes: mes, ano: anoAtual }, dataType: 'json',
            success: function(d) {
                atualizarCards(d);
                carregarGraficos(d);
                renderizarTabela(d);
            }, error: function() { $('#balanceteTableBody').html('<tr><td colspan="7" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function atualizarCards(d) {
        var receitas = d.receitas || 0;
        var despesas = d.despesas || 0;
        var resultado = receitas - despesas;
        var margem = receitas > 0 ? (resultado / receitas * 100).toFixed(1) : 0;
        $('#totalReceitas').html(formatMoney(receitas));
        $('#totalDespesas').html(formatMoney(despesas));
        $('#resultado').html(formatMoney(resultado));
        $('#resultado').css('color', resultado >= 0 ? '#2E7D32' : '#E74C3C');
        $('#margem').text(margem + '%');
        $('#margem').css('color', parseFloat(margem) >= 0 ? '#2E7D32' : '#E74C3C');
    }

    function carregarGraficos(d) {
        var receitasPorCategoria = d.receitas_por_categoria || {};
        var despesasPorCategoria = d.despesas_por_categoria || {};
        var labelsReceitas = Object.keys(receitasPorCategoria);
        var dataReceitas = labelsReceitas.map(function(k) { return receitasPorCategoria[k]; });
        var labelsDespesas = Object.keys(despesasPorCategoria);
        var dataDespesas = labelsDespesas.map(function(k) { return despesasPorCategoria[k]; });
        if (graficos.receitas) graficos.receitas.destroy();
        graficos.receitas = new Chart(document.getElementById('receitasChart'), {
            type: 'doughnut', data: { labels: labelsReceitas, datasets: [{ data: dataReceitas, backgroundColor: ['#2ECC71', '#3498DB', '#F39C12', '#1ABC9C', '#9B59B6'], borderWidth: 0 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
        });
        if (graficos.despesas) graficos.despesas.destroy();
        graficos.despesas = new Chart(document.getElementById('despesasChart'), {
            type: 'doughnut', data: { labels: labelsDespesas, datasets: [{ data: dataDespesas, backgroundColor: ['#E74C3C', '#F39C12', '#3498DB', '#1ABC9C', '#9B59B6'], borderWidth: 0 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
        });
    }

    function renderizarTabela(d) {
        var tbody = $('#balanceteTableBody');
        tbody.empty();
        var contas = d.contas || [];
        if (contas.length === 0) { tbody.html('<tr><td colspan="7" class="text-center py-4">Nenhum dado encontrado</td></tr>'); return; }
        var totalSaldoAnterior = 0, totalDebito = 0, totalCredito = 0, totalSaldoAtual = 0;
        $.each(contas, function(i, c) {
            totalSaldoAnterior += c.saldo_anterior || 0;
            totalDebito += c.debito || 0;
            totalCredito += c.credito || 0;
            totalSaldoAtual += c.saldo_atual || 0;
            tbody.append('<tr>' +
                '<td><strong>' + (c.conta || '-') + '</strong></td>' +
                '<td>' + (c.categoria || '-') + '</td>' +
                '<td><span class="badge-tipo ' + (c.tipo === 'receita' ? 'receita' : 'despesa') + '">' + (c.tipo === 'receita' ? 'RECEITA' : 'DESPESA') + '</span></td>' +
                '<td>' + formatMoney(c.saldo_anterior) + '</td>' +
                '<td>' + formatMoney(c.debito) + '</td>' +
                '<td>' + formatMoney(c.credito) + '</td>' +
                '<td><strong>' + formatMoney(c.saldo_atual) + '</strong></td>' +
            '</tr>');
        });
        tbody.append('<tr class="total-row"><td><strong>TOTAIS</strong></td><td>-</td><td>-</td><td><strong>' + formatMoney(totalSaldoAnterior) + '</strong></td><td><strong>' + formatMoney(totalDebito) + '</strong></td><td><strong>' + formatMoney(totalCredito) + '</strong></td><td><strong>' + formatMoney(totalSaldoAtual) + '</strong></td></tr>');
    }

    function exportBalanceteCSV() {
        $.ajax({ url: contextPath + '/Financeiro/balancete/dados', method: 'GET', data: { mes: periodoAtual === 0 ? null : periodoAtual, ano: anoAtual }, dataType: 'json',
            success: function(d) {
                var headers = ['Conta', 'Categoria', 'Tipo', 'Saldo Anterior', 'Débito', 'Crédito', 'Saldo Atual'];
                var csvRows = [headers.join(',')];
                var contas = d.contas || [];
                for (var i = 0; i < contas.length; i++) {
                    var c = contas[i];
                    csvRows.push(['"' + c.conta + '"', '"' + c.categoria + '"', c.tipo, c.saldo_anterior || 0, c.debito || 0, c.credito || 0, c.saldo_atual || 0].join(','));
                }
                var blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
                var url = URL.createObjectURL(blob); var a = document.createElement('a'); a.href = url; a.download = 'balancete_' + (periodoAtual === 0 ? 'acumulado' : periodoAtual) + '_' + anoAtual + '.csv'; a.click(); URL.revokeObjectURL(url);
                showAlert('success', 'Balancete exportado com sucesso!');
            }, error: function() { showAlert('error', 'Erro ao exportar CSV'); }
        });
    }

    function exportBalancetePDF() {
        var { jsPDF } = window.jspdf;
        var doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
        var now = new Date();
        var dataAtual = now.toLocaleDateString('pt-PT') + ' ' + now.toLocaleTimeString('pt-PT');
        doc.setFontSize(16); doc.setTextColor(27, 43, 60); doc.text('Hotelaria Systems - Balancete Financeiro', 20, 20);
        doc.setFontSize(12); doc.setTextColor(46, 204, 113); doc.text((periodoAtual === 0 ? 'Ano ' + anoAtual : periodoAtual + '/' + anoAtual), 20, 32);
        doc.setFontSize(10); doc.setTextColor(127, 140, 141); doc.text('Emitido em: ' + dataAtual, 20, 42);
        $.ajax({ url: contextPath + '/Financeiro/balancete/dados', method: 'GET', data: { mes: periodoAtual === 0 ? null : periodoAtual, ano: anoAtual }, dataType: 'json', async: false,
            success: function(d) {
                var tableData = []; var contas = d.contas || [];
                for (var i = 0; i < contas.length; i++) {
                    var c = contas[i];
                    tableData.push([c.conta, c.categoria, c.tipo, formatMoney(c.saldo_anterior), formatMoney(c.debito), formatMoney(c.credito), formatMoney(c.saldo_atual)]);
                }
                doc.autoTable({ head: [['Conta', 'Categoria', 'Tipo', 'Saldo Anterior', 'Débito', 'Crédito', 'Saldo Atual']], body: tableData, startY: 50, theme: 'striped', headStyles: { fillColor: [27, 43, 60], textColor: [46, 204, 113] }, styles: { fontSize: 8 } });
            }
        });
        doc.save('balancete_' + (periodoAtual === 0 ? 'acumulado' : periodoAtual) + '_' + anoAtual + '.pdf');
        showAlert('success', 'PDF gerado com sucesso!');
    }

    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    $('#periodoSelect').on('change', function() { periodoAtual = parseInt($(this).val()); carregarBalancete(); });
    $('#atualizarBalancete').on('click', function() { carregarBalancete(); showAlert('success', 'Balancete atualizado!'); });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); }
    setInterval(updateClock, 1000); updateClock();

    carregarBalancete();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>