<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contas a Receber · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .btn-primary-custom { background: #2ECC71; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: white; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #1B2B3C; color: #2ECC71; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #2ECC71; color: #2ECC71; }
        .btn-export { background: transparent; border: 1px solid #E2E8F0; padding: 6px 12px; border-radius: 30px; font-size: 0.75rem; transition: all 0.2s; cursor: pointer; }
        .btn-export:hover { border-color: #2ECC71; color: #2ECC71; background: #E8F5E9; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2E8F0; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #ECF0F1; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2E8F0; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; transition: all 0.3s ease; border: 1px solid #E2E8F0; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #2ECC71; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.6rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }
        .stat-footer { font-size: 0.7rem; color: #7F8C8D; }

        .charts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #2ECC71; }
        .chart-container { position: relative; height: 170px; width: 100%; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #2ECC71; color: #1B2B3C; font-weight: 600; padding: 10px 6px; }

        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 500; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.VENCIDA { background: #FFEBEE; color: #E74C3C; }
        .badge-status.PARCIAL { background: #E3F2FD; color: #1976D2; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.pay { color: #2E7D32; }
        .action-btn.view { color: #3498DB; }
        .action-btn:hover { background: #ECF0F1; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #1B2B3C; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2E8F0; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #2ECC71; border-color: #2ECC71; color: white; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

        .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .info-card { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; transition: all 0.2s; cursor: pointer; }
        .info-card:hover { border-color: #2ECC71; }
        .info-card h4 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 14px; }
        .info-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #E2E8F0; }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #1B2B3C; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2E8F0; }
        .detail-label { width: 130px; font-weight: 600; color: #1B2B3C; }
        .detail-value { flex: 1; color: #7F8C8D; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2E8F0; padding: 10px 14px; }
        .form-control-custom:focus, .form-select-custom:focus { border-color: #2ECC71; box-shadow: 0 0 0 3px rgba(46,204,113,0.1); }

        @media (max-width: 1200px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .charts-grid { grid-template-columns: 1fr; } .info-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
    </ul>

    <div class="menu-section">RELATÓRIOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-calculator-fill"></i><div class="logo-text">Hotelaria · Financeiro<span>Contas a Receber</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>TOTAL A RECEBER</h3><i class="bi bi-credit-card"></i></div><div class="stat-value" id="totalReceber">0 MZN</div><div class="stat-footer">Faturas pendentes e vencidas</div></div>
        <div class="stat-card"><div class="stat-header"><h3>VENCIDAS</h3><i class="bi bi-exclamation-triangle"></i></div><div class="stat-value" id="totalVencido">0 MZN</div><div class="stat-footer">Faturas vencidas</div></div>
        <div class="stat-card"><div class="stat-header"><h3>A VENCER (30d)</h3><i class="bi bi-calendar"></i></div><div class="stat-value" id="totalAVencer">0 MZN</div><div class="stat-footer">Próximos 30 dias</div></div>
        <div class="stat-card"><div class="stat-header"><h3>TAXA INADIMP.</h3><i class="bi bi-graph-down"></i></div><div class="stat-value" id="taxaInadimplencia">0%</div><div class="stat-footer">do total faturado</div></div>
    </div>

    <div class="charts-grid">
        <div class="chart-box"><h3><i class="bi bi-pie-chart"></i> Situação das Contas</h3><div class="chart-container"><canvas id="situacaoContasChart"></canvas></div></div>
        <div class="chart-box"><h3><i class="bi bi-bar-chart"></i> Vencimento por Período</h3><div class="chart-container"><canvas id="vencimentoPeriodoChart"></canvas></div></div>
        <div class="chart-box"><h3><i class="bi bi-graph-up"></i> Projeção de Recebimento</h3><div class="chart-container"><canvas id="projecaoRecebimentoChart"></canvas></div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por cliente ou fatura..."></div>
        <div>
            <select class="filter-select" id="statusFilter"><option value="">Todos os status</option><option value="PENDENTE">PENDENTE</option><option value="VENCIDA">VENCIDA</option><option value="PARCIAL">PARCIAL</option></select>
            <input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por vencimento" style="width: 130px;">
        </div>
        <div>
            <button class="btn-export" onclick="exportContasCSV()"><i class="bi bi-filetype-csv"></i> CSV</button>
            <button class="btn-export" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir</button>
        </div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-list-ul"></i> Contas a Receber</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Fatura</th>
                        <th>Cliente</th>
                        <th>Reserva</th>
                        <th>Total</th>
                        <th>Pago</th>
                        <th>Saldo</th>
                        <th>Vencimento</th>
                        <th>Dias</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="contasTableBody">
                    <tr><td colspan="10" class="text-center py-4"><div class="spinner-border text-success"></div></td></tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="info-grid">
        <div class="info-card"><h4><i class="bi bi-pie-chart"></i> Resumo por Status</h4>
            <div class="info-item"><span><i class="bi bi-hourglass" style="color:#F57C00;"></i> Pendentes</span><strong id="qtdPendentes">0</strong></div>
            <div class="info-item"><span><i class="bi bi-exclamation-triangle" style="color:#E74C3C;"></i> Vencidas</span><strong id="qtdVencidas">0</strong></div>
            <div class="info-item"><span><i class="bi bi-clock" style="color:#1976D2;"></i> Parciais</span><strong id="qtdParciais">0</strong></div>
            <div class="info-item mt-2"><strong>Total Contas</strong><strong id="totalContas">0</strong></div>
        </div>
        <div class="info-card"><h4><i class="bi bi-calendar"></i> Vencimento por Faixa</h4>
            <div class="info-item"><span>Vencidas</span><strong id="faixaVencidas">0 MZN</strong></div>
            <div class="info-item"><span>Até 30 dias</span><strong id="faixa30">0 MZN</strong></div>
            <div class="info-item"><span>31 a 60 dias</span><strong id="faixa60">0 MZN</strong></div>
            <div class="info-item"><span>Acima de 60 dias</span><strong id="faixa90">0 MZN</strong></div>
        </div>
        <div class="info-card"><h4><i class="bi bi-people"></i> Top Devedores</h4>
            <div class="info-item"><span>1º</span><strong id="devedor1">-</strong></div>
            <div class="info-item"><span>2º</span><strong id="devedor2">-</strong></div>
            <div class="info-item"><span>3º</span><strong id="devedor3">-</strong></div>
        </div>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Registrar Pagamento -->
<div class="modal fade modal-custom" id="modalPagamento" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-cash"></i> Registrar Pagamento</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formPagamento">
                    <input type="hidden" id="pagamentoFaturaId">
                    <input type="hidden" id="pagamentoReservaId">
                    <div class="detail-row"><div class="detail-label">Fatura:</div><div class="detail-value" id="modalFaturaNum">-</div></div>
                    <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="modalCliente">-</div></div>
                    <div class="detail-row"><div class="detail-label">Saldo Devedor:</div><div class="detail-value" id="modalSaldo">-</div></div>
                    <div class="mb-3 mt-3"><label class="form-label">Valor do Pagamento <span class="text-danger">*</span></label><input type="number" class="form-control form-control-custom" id="valorPagamento" step="0.01" required placeholder="0.00"></div>
                    <div class="mb-3"><label class="form-label">Método de Pagamento</label><select class="form-select form-select-custom" id="metodoPagamento">
                        <option value="1">Dinheiro</option>
                        <option value="2">POS</option>
                        <option value="3">Transferência Bancária</option>
                        <option value="4">M-Pesa</option>
                        <option value="5">E-Mola</option>
                    </select></div>
                    <div class="mb-3"><label class="form-label">Referência</label><input type="text" class="form-control form-control-custom" id="referenciaPagamento" placeholder="Nº transação"></div>
                    <div class="mb-3"><label class="form-label">Data do Pagamento</label><input type="text" class="form-control form-control-custom" id="dataPagamento" placeholder="Selecione a data"></div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Registrar Pagamento</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 5, currentFilter = "", currentStatusFilter = "", currentDateFilter = "";
    let todasContas = [];
    let situacaoChart = null, vencimentoChart = null, projecaoChart = null;

    function formatMoney(v) { if (v === undefined || v === null || isNaN(v)) return "0 MZN"; return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN"; }
    function formatDate(dateStr) { if (!dateStr) return "-"; var parts = dateStr.split("-"); return parts[2] + "/" + parts[1] + "/" + parts[0]; }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    function calcularDiasAtraso(dataVencimento) {
        if (!dataVencimento) return 0;
        var hoje = new Date();
        var vencimento = new Date(dataVencimento);
        if (hoje <= vencimento) return 0;
        var diffTime = Math.abs(hoje - vencimento);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    function loadContasReceber() {
        $.ajax({ url: contextPath + '/Financeiro/contas-receber/listar', method: 'GET', dataType: 'json',
            success: function(d) { todasContas = d; aplicarFiltros(); carregarGraficos(); },
            error: function() { $('#contasTableBody').html('<tr><td colspan="10" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function loadStats() {
        $.ajax({ url: contextPath + '/Financeiro/contas-receber/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalReceber').html(formatMoney(d.total_receber || 0));
                $('#totalVencido').html(formatMoney(d.total_vencido || 0));
                $('#totalAVencer').html(formatMoney(d.total_a_vencer || 0));
                $('#taxaInadimplencia').text((d.taxa_inadimplencia || 0).toFixed(1) + '%');
                $('#qtdPendentes').text(d.pendentes || 0);
                $('#qtdVencidas').text(d.vencidas || 0);
                $('#qtdParciais').text(d.parciais || 0);
                $('#totalContas').text((d.pendentes || 0) + (d.vencidas || 0) + (d.parciais || 0));
                $('#faixaVencidas').html(formatMoney(d.faixa_vencidas || 0));
                $('#faixa30').html(formatMoney(d.faixa_30 || 0));
                $('#faixa60').html(formatMoney(d.faixa_60 || 0));
                $('#faixa90').html(formatMoney(d.faixa_90 || 0));
                if (d.top_devedores && d.top_devedores.length > 0) {
                    $('#devedor1').html(formatMoney(d.top_devedores[0].total));
                    $('#devedor2').html(d.top_devedores[1] ? formatMoney(d.top_devedores[1].total) : '-');
                    $('#devedor3').html(d.top_devedores[2] ? formatMoney(d.top_devedores[2].total) : '-');
                }
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function carregarGraficos() {
        var situacao = { PENDENTE: 0, VENCIDA: 0, PARCIAL: 0 };
        var faixas = { vencidas: 0, ate30: 0, ate60: 0, acima60: 0 };
        var hoje = new Date();

        $.each(todasContas, function(i, c) {
            situacao[c.status] = (situacao[c.status] || 0) + c.saldo;
            var vencimento = new Date(c.data_vencimento);
            var diffDias = Math.ceil((vencimento - hoje) / (1000 * 60 * 60 * 24));
            if (diffDias < 0) faixas.vencidas += c.saldo;
            else if (diffDias <= 30) faixas.ate30 += c.saldo;
            else if (diffDias <= 60) faixas.ate60 += c.saldo;
            else faixas.acima60 += c.saldo;
        });

        if (situacaoChart) situacaoChart.destroy();
        situacaoChart = new Chart(document.getElementById('situacaoContasChart'), {
            type: 'doughnut',
            data: { labels: ['PENDENTE', 'VENCIDA', 'PARCIAL'], datasets: [{ data: [situacao.PENDENTE, situacao.VENCIDA, situacao.PARCIAL], backgroundColor: ['#F57C00', '#E74C3C', '#3498DB'], borderWidth: 0 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
        });

        if (vencimentoChart) vencimentoChart.destroy();
        vencimentoChart = new Chart(document.getElementById('vencimentoPeriodoChart'), {
            type: 'bar',
            data: { labels: ['Vencidas', 'Até 30 dias', '31-60 dias', '+60 dias'], datasets: [{ label: 'Valor (MZN)', data: [faixas.vencidas, faixas.ate30, faixas.ate60, faixas.acima60], backgroundColor: ['#E74C3C', '#F57C00', '#3498DB', '#1B2B3C'], borderRadius: 8 }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return formatMoney(v); } } } }, plugins: { legend: { display: false } } }
        });

        if (projecaoChart) projecaoChart.destroy();
        projecaoChart = new Chart(document.getElementById('projecaoRecebimentoChart'), {
            type: 'line',
            data: { labels: ['Jun', 'Jul', 'Ago', 'Set', 'Out'], datasets: [{ label: 'Previsão (MZN)', data: [45000, 52000, 48000, 55000, 60000], borderColor: '#2ECC71', backgroundColor: 'rgba(46,204,113,0.05)', tension: 0.3, fill: true, pointBackgroundColor: '#2ECC71' }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return formatMoney(v); } } } } }
        });
    }

    function aplicarFiltros() {
        var filtrados = todasContas.filter(function(c) {
            var matchSearch = !currentFilter || (c.cliente_nome && c.cliente_nome.toLowerCase().includes(currentFilter)) || (c.numero_fatura && c.numero_fatura.toLowerCase().includes(currentFilter));
            var matchStatus = !currentStatusFilter || c.status === currentStatusFilter;
            var matchDate = !currentDateFilter || c.data_vencimento === currentDateFilter;
            return matchSearch && matchStatus && matchDate;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
    }

    function renderizarTabela(contas) {
        var tbody = $('#contasTableBody');
        tbody.empty();
        if (contas.length === 0) { tbody.html('<tr><td colspan="10" class="text-center py-4">Nenhuma conta a receber encontrada</td></td>'); return; }
        $.each(contas, function(i, c) {
            var diasAtraso = calcularDiasAtraso(c.data_vencimento);
            tbody.append('<tr>' +
                '<td><strong>' + escapeHtml(c.numero_fatura) + '</strong></td>' +
                '<td>' + escapeHtml(c.cliente_nome) + '</td>' +
                '<td><span class="badge bg-secondary">#' + c.id_reserva + '</span></td>' +
                '<td>' + formatMoney(c.total) + '</td>' +
                '<td>' + formatMoney(c.valor_pago) + '</td>' +
                '<td><strong>' + formatMoney(c.saldo) + '</strong></td>' +
                '<td>' + formatDate(c.data_vencimento) + '</td>' +
                '<td class="' + (diasAtraso > 0 ? 'text-danger' : '') + '">' + (diasAtraso > 0 ? diasAtraso + ' dias' : '-') + '</td>' +
                '<td><span class="badge-status ' + c.status + '">' + c.status + '</span></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn pay" data-id="' + c.id_fatura + '" data-saldo="' + c.saldo + '" data-numero="' + escapeHtml(c.numero_fatura) + '" data-cliente="' + escapeHtml(c.cliente_nome) + '" title="Registrar Pagamento"><i class="bi bi-cash"></i></button>' +
                    '<button class="action-btn view" data-id="' + c.id_fatura + '" title="Detalhes"><i class="bi bi-eye"></i></button>' +
                '</td>' +
            '</tr>');
        });
        $('.action-btn.pay').off('click').on('click', function() { registrarPagamento($(this).data('id'), $(this).data('saldo'), $(this).data('numero'), $(this).data('cliente')); });
        $('.action-btn.view').off('click').on('click', function() { viewFatura($(this).data('id')); });
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); return false; }

    function registrarPagamento(id, saldo, numeroFatura, clienteNome) {
        $.ajax({
            url: contextPath + '/Financeiro/faturas/detalhes',
            method: 'GET',
            data: { id: id },
            dataType: 'json',
            success: function(fatura) {
                if (fatura && fatura.id_fatura) {
                    $('#pagamentoFaturaId').val(id);
                    $('#pagamentoReservaId').val(fatura.id_reserva);
                    $('#modalFaturaNum').text(numeroFatura);
                    $('#modalCliente').text(clienteNome);
                    $('#modalSaldo').text(formatMoney(saldo));
                    $('#valorPagamento').val(saldo);
                    if (flatpickrPagamento) flatpickrPagamento.setDate(new Date());
                    new bootstrap.Modal(document.getElementById('modalPagamento')).show();
                } else {
                    showAlert('error', 'Erro ao carregar dados da fatura!');
                }
            },
            error: function() {
                showAlert('error', 'Erro ao carregar dados da fatura!');
            }
        });
    }

    function viewFatura(id) {
        $.ajax({ url: contextPath + '/Financeiro/faturas/detalhes', method: 'GET', data: { id: id }, dataType: 'json',
            success: function(f) {
                if (f && f.id_fatura) {
                    Swal.fire({ title: 'Detalhes da Fatura', html: '<strong>Fatura:</strong> ' + f.numero_fatura + '<br><strong>Cliente:</strong> ' + f.cliente_nome + '<br><strong>Reserva:</strong> #' + f.id_reserva + '<br><strong>Total:</strong> ' + formatMoney(f.total) + '<br><strong>Pago:</strong> ' + formatMoney(f.valor_pago) + '<br><strong>Saldo:</strong> ' + formatMoney(f.saldo) + '<br><strong>Vencimento:</strong> ' + formatDate(f.data_vencimento), icon: 'info', confirmButtonColor: '#2ECC71' });
                } else { showAlert('error', 'Fatura não encontrada!'); }
            }, error: function() { showAlert('error', 'Erro ao carregar detalhes'); }
        });
    }

    $('#formPagamento').on('submit', function(e) {
        e.preventDefault();
        var faturaId = $('#pagamentoFaturaId').val();
        var reservaId = $('#pagamentoReservaId').val();
        var valorPago = parseFloat($('#valorPagamento').val());
        var metodoId = $('#metodoPagamento').val();
        var referencia = $('#referenciaPagamento').val();
        var dataPagamento = $('#dataPagamento').val();

        if (!faturaId || !reservaId || isNaN(valorPago) || valorPago <= 0) {
            showAlert('warning', 'Valor inválido ou dados da fatura não carregados!');
            return;
        }
        if (!dataPagamento) {
            var now = new Date();
            dataPagamento = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0') + 'T' + String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
        }

        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Processando...');

        $.ajax({
            url: contextPath + '/Financeiro/pagamentos/salvar',
            method: 'POST',
            data: {
                id_reserva: reservaId,
                id_fatura: faturaId,
                valor: valorPago,
                id_metodo_pagamento: metodoId,
                referencia_pagamento: referencia,
                data_pagamento: dataPagamento.replace('T', ' ') + ':00',
                estado_pagamento: 'PAGO'
            },
            dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Registrar Pagamento');
                if (r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalPagamento')).hide();
                    $('#formPagamento')[0].reset();
                    loadContasReceber();
                    showAlert('success', 'Pagamento registrado com sucesso!');
                } else {
                    showAlert('error', r.message || 'Erro ao registrar pagamento');
                }
            },
            error: function(xhr, status, error) {
                btn.prop('disabled', false).text('Registrar Pagamento');
                console.error('Erro:', error);
                showAlert('error', 'Erro ao registrar pagamento: ' + error);
            }
        });
    });

    $('#modalPagamento').on('hidden.bs.modal', function() { $('#formPagamento')[0].reset(); });

    $('#searchInput').on('input', function() { currentFilter = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });
    $('#statusFilter').on('change', function() { currentStatusFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });
    flatpickr("#dateFilter", { dateFormat: "Y-m-d", locale: "pt", onChange: function(selectedDates, dateStr) { currentDateFilter = dateStr; currentPage = 1; aplicarFiltros(); } });
    var flatpickrPagamento = flatpickr("#dataPagamento", { enableTime: true, dateFormat: "Y-m-d H:i", locale: "pt", time_24hr: true, defaultDate: new Date() });

    function exportContasCSV() {
        var filtrados = todasContas.filter(function(c) {
            var matchStatus = !currentStatusFilter || c.status === currentStatusFilter;
            var matchDate = !currentDateFilter || c.data_vencimento === currentDateFilter;
            return matchStatus && matchDate;
        });
        var headers = ['Fatura', 'Cliente', 'Reserva', 'Total', 'Pago', 'Saldo', 'Vencimento', 'Dias Atraso', 'Status'];
        var csvRows = [headers.join(',')];
        for (var i = 0; i < filtrados.length; i++) {
            var c = filtrados[i];
            csvRows.push(['"' + c.numero_fatura + '"', '"' + (c.cliente_nome || '') + '"', '#' + c.id_reserva, c.total, c.valor_pago, c.saldo, c.data_vencimento, calcularDiasAtraso(c.data_vencimento), c.status].join(','));
        }
        var blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'contas_receber_' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        showAlert('success', 'Relatório exportado com sucesso!');
    }

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    loadContasReceber();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>