<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Taxas e IVA · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .btn-primary-custom { background: #2ECC71; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: white; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #1B2B3C; color: #2ECC71; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #2ECC71; color: #2ECC71; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; transition: all 0.3s ease; border: 1px solid #E2E8F0; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #2ECC71; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.8rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }
        .stat-footer { font-size: 0.7rem; color: #7F8C8D; }

        .cards-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .config-card { background: white; border-radius: 20px; padding: 20px; border: 1px solid #E2E8F0; transition: all 0.2s; }
        .config-card:hover { border-color: #2ECC71; }
        .config-card h4 { font-size: 1rem; font-weight: 600; color: #1B2B3C; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
        .config-card h4 i { color: #2ECC71; font-size: 1.3rem; }
        .config-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #E2E8F0; }
        .config-item:last-child { border-bottom: none; }
        .config-label { font-weight: 500; color: #1B2B3C; }
        .config-value { display: flex; align-items: center; gap: 10px; }
        .config-value input { width: 80px; padding: 6px 10px; border-radius: 12px; border: 1px solid #E2E8F0; text-align: right; }
        .config-value input:focus { border-color: #2ECC71; outline: none; }
        .config-value button { padding: 5px 15px; font-size: 0.75rem; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #2ECC71; color: #1B2B3C; font-weight: 600; padding: 10px 6px; }

        .badge-taxa { padding: 4px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 500; }
        .badge-taxa.IVA { background: #E8F5E9; color: #2E7D32; }
        .badge-taxa.Municipal { background: #E3F2FD; color: #1976D2; }
        .badge-taxa.Turística { background: #FFF8E1; color: #F57C00; }
        .badge-taxa.Outra { background: #F3E5F5; color: #7B1FA2; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.edit { color: #F39C12; }
        .action-btn:hover { background: #ECF0F1; transform: scale(1.1); }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #1B2B3C; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2E8F0; padding: 10px 14px; }
        .form-control-custom:focus, .form-select-custom:focus { border-color: #2ECC71; box-shadow: 0 0 0 3px rgba(46,204,113,0.1); }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        @media (max-width: 1200px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .cards-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-calculator-fill"></i><div class="logo-text">Hotelaria · Financeiro<span>Taxas e IVA</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>IVA PADRÃO</h3><i class="bi bi-percent"></i></div><div class="stat-value" id="ivaPadrao">16%</div><div class="stat-footer">Aplicado em serviços</div></div>
        <div class="stat-card"><div class="stat-header"><h3>IVA REDUZIDO</h3><i class="bi bi-percent"></i></div><div class="stat-value" id="ivaReduzido">10%</div><div class="stat-footer">Alimentação</div></div>
        <div class="stat-card"><div class="stat-header"><h3>TAXA MUNICIPAL</h3><i class="bi bi-building"></i></div><div class="stat-value" id="taxaMunicipal">5%</div><div class="stat-footer">Sobre diárias</div></div>
        <div class="stat-card"><div class="stat-header"><h3>TAXA TURÍSTICA</h3><i class="bi bi-tree"></i></div><div class="stat-value" id="taxaTuristica">2%</div><div class="stat-footer">Por noite/hóspede</div></div>
    </div>

    <div class="cards-grid">
        <div class="config-card">
            <h4><i class="bi bi-sliders2"></i> Configuração de IVA</h4>
            <div class="config-item"><span class="config-label">IVA Normal (Serviços)</span><div class="config-value"><input type="number" id="ivaNormalInput" step="0.1"><span>%</span><button class="btn-primary-custom" onclick="atualizarTaxa('iva_normal')">Salvar</button></div></div>
            <div class="config-item"><span class="config-label">IVA Reduzido (Alimentação)</span><div class="config-value"><input type="number" id="ivaReduzidoInput" step="0.1"><span>%</span><button class="btn-primary-custom" onclick="atualizarTaxa('iva_reduzido')">Salvar</button></div></div>
            <div class="config-item"><span class="config-label">IVA Intermédio</span><div class="config-value"><input type="number" id="ivaIntermedioInput" step="0.1"><span>%</span><button class="btn-primary-custom" onclick="atualizarTaxa('iva_intermedio')">Salvar</button></div></div>
        </div>
        <div class="config-card">
            <h4><i class="bi bi-sliders2"></i> Outras Taxas</h4>
            <div class="config-item"><span class="config-label">Taxa Municipal</span><div class="config-value"><input type="number" id="taxaMunicipalInput" step="0.1"><span>%</span><button class="btn-primary-custom" onclick="atualizarTaxa('taxa_municipal')">Salvar</button></div></div>
            <div class="config-item"><span class="config-label">Taxa Turística</span><div class="config-value"><input type="number" id="taxaTuristicaInput" step="0.1"><span>%</span><button class="btn-primary-custom" onclick="atualizarTaxa('taxa_turistica')">Salvar</button></div></div>
            <div class="config-item"><span class="config-label">Multa por Atraso</span><div class="config-value"><input type="number" id="multaAtrasoInput" step="0.1"><span>%/dia</span><button class="btn-primary-custom" onclick="atualizarTaxa('multa_atraso')">Salvar</button></div></div>
        </div>
    </div>

    <div class="table-section">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
            <h3><i class="bi bi-clock-history"></i> Histórico de Alterações de Taxas</h3>
            <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalNovaTaxa"><i class="bi bi-plus-lg"></i> Nova Taxa</button>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Data</th><th>Taxa</th><th>Tipo</th><th>Valor</th><th>Ações</th></tr>
                </thead>
                <tbody id="historicoTableBody"></tbody>
            </table>
        </div>
    </div>

    <div class="footer"><i class="bi bi-database"></i> Configurações de Taxas e IVA · Aplicado em todas as faturas do sistema</div>
</div>

<!-- MODAIS -->
<div class="modal fade modal-custom" id="modalNovaTaxa" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-plus-circle"></i> Adicionar Taxa</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formTaxa">
                    <div class="mb-3"><label class="form-label">Nome da Taxa <span class="text-danger">*</span></label><input type="text" class="form-control form-control-custom" id="nomeTaxa" required></div>
                    <div class="mb-3"><label class="form-label">Tipo</label><select class="form-select form-select-custom" id="tipoTaxa"><option value="IVA">IVA</option><option value="Municipal">Taxa Municipal</option><option value="Turística">Taxa Turística</option><option value="Outra">Outra</option></select></div>
                    <div class="mb-3"><label class="form-label">Valor (%) <span class="text-danger">*</span></label><input type="number" class="form-control form-control-custom" id="valorTaxa" step="0.1" required></div>
                    <div class="mb-3"><label class="form-label">Descrição</label><textarea class="form-control form-control-custom" id="descricaoTaxa" rows="2"></textarea></div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Salvar Taxa</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade modal-custom" id="modalEditarTaxa" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-pencil-square"></i> Editar Taxa</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formEditarTaxa">
                    <input type="hidden" id="editarTaxaId">
                    <div class="mb-3"><label class="form-label">Valor (%) <span class="text-danger">*</span></label><input type="number" class="form-control form-control-custom" id="editarValorTaxa" step="0.1" required></div>
                    <div class="mb-3"><label class="form-label">Observação</label><textarea class="form-control form-control-custom" id="editarObsTaxa" rows="2"></textarea></div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Atualizar</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let historicoTaxas = [];

    function formatMoney(v) { if (v === undefined || v === null || isNaN(v)) return "0 MZN"; return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN"; }
    function formatDate(dateStr) { if (!dateStr) return "-"; var parts = dateStr.split("-"); return parts[2] + "/" + parts[1] + "/" + parts[0]; }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }

    function carregarConfiguracoes() {
        $.ajax({ url: contextPath + '/Financeiro/taxas/configuracoes', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#ivaNormalInput').val(d.iva_normal || 16);
                $('#ivaReduzidoInput').val(d.iva_reduzido || 10);
                $('#ivaIntermedioInput').val(d.iva_intermedio || 13);
                $('#taxaMunicipalInput').val(d.taxa_municipal || 5);
                $('#taxaTuristicaInput').val(d.taxa_turistica || 2);
                $('#multaAtrasoInput').val(d.multa_atraso || 2);
                $('#ivaPadrao').text((d.iva_normal || 16) + '%');
                $('#ivaReduzido').text((d.iva_reduzido || 10) + '%');
                $('#taxaMunicipal').text((d.taxa_municipal || 5) + '%');
                $('#taxaTuristica').text((d.taxa_turistica || 2) + '%');
            }, error: function() { console.error('Erro ao carregar configurações'); }
        });
    }

    function carregarHistorico() {
        $.ajax({ url: contextPath + '/Financeiro/taxas/historico', method: 'GET', dataType: 'json',
            success: function(d) { historicoTaxas = d; renderizarHistorico(); },
            error: function() { $('#historicoTableBody').html('<tr><td colspan="5" class="text-center text-danger py-4">❌ Erro ao carregar histórico</td></tr>'); }
        });
    }

    function renderizarHistorico() {
        var tbody = $('#historicoTableBody');
        tbody.empty();
        if (historicoTaxas.length === 0) { tbody.html('<tr><td colspan="5" class="text-center py-4">Nenhum registro encontrado</td></tr>'); return; }
        $.each(historicoTaxas, function(i, t) {
            tbody.append('<tr>' +
                '<td>' + formatDate(t.data) + '</td>' +
                '<td><strong>' + escapeHtml(t.nome) + '</strong></td>' +
                '<td><span class="badge-taxa ' + t.tipo + '">' + t.tipo + '</span></td>' +
                '<td>' + t.valor + '%</span></td>' +
                '<td class="action-buttons"><button class="action-btn edit" onclick="editarTaxaHistorico(' + t.id + ')"><i class="bi bi-pencil"></i></button></td>' +
            '</tr>');
        });
    }

    function atualizarTaxa(tipo) {
        var valor = parseFloat($('#' + tipo + 'Input').val());
        if (isNaN(valor)) { showAlert('warning', 'Valor inválido!'); return; }
        $.ajax({ url: contextPath + '/Financeiro/taxas/atualizar', method: 'POST', data: { tipo: tipo, valor: valor }, dataType: 'json',
            success: function(r) { if (r.success) { carregarConfiguracoes(); carregarHistorico(); showAlert('success', r.message); } else { showAlert('error', r.message); } },
            error: function() { showAlert('error', 'Erro ao atualizar taxa'); }
        });
    }

    function editarTaxaHistorico(id) {
        var taxa = historicoTaxas.find(function(t) { return t.id === id; });
        if (taxa) { $('#editarTaxaId').val(id); $('#editarValorTaxa').val(taxa.valor); $('#editarObsTaxa').val(""); new bootstrap.Modal(document.getElementById('modalEditarTaxa')).show(); }
    }

    $('#formTaxa').on('submit', function(e) {
        e.preventDefault();
        var dados = { nome: $('#nomeTaxa').val(), tipo: $('#tipoTaxa').val(), valor: parseFloat($('#valorTaxa').val()), descricao: $('#descricaoTaxa').val() };
        $.ajax({ url: contextPath + '/Financeiro/taxas/salvar', method: 'POST', data: dados, dataType: 'json',
            success: function(r) {
                if (r.success) { bootstrap.Modal.getInstance(document.getElementById('modalNovaTaxa')).hide(); $('#formTaxa')[0].reset(); carregarHistorico(); showAlert('success', 'Taxa adicionada!'); }
                else { showAlert('error', r.message); }
            }, error: function() { showAlert('error', 'Erro ao salvar taxa'); }
        });
    });

    $('#formEditarTaxa').on('submit', function(e) {
        e.preventDefault();
        var dados = { id: $('#editarTaxaId').val(), valor: parseFloat($('#editarValorTaxa').val()), obs: $('#editarObsTaxa').val() };
        $.ajax({ url: contextPath + '/Financeiro/taxas/atualizar-valor', method: 'POST', data: dados, dataType: 'json',
            success: function(r) { if (r.success) { bootstrap.Modal.getInstance(document.getElementById('modalEditarTaxa')).hide(); carregarHistorico(); carregarConfiguracoes(); showAlert('success', 'Taxa atualizada!'); } else { showAlert('error', r.message); } },
            error: function() { showAlert('error', 'Erro ao atualizar'); }
        });
    });

    $('#modalNovaTaxa, #modalEditarTaxa').on('hidden.bs.modal', function() { $(this).find('form')[0].reset(); });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); }
    setInterval(updateClock, 1000); updateClock();

    carregarConfiguracoes();
    carregarHistorico();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>