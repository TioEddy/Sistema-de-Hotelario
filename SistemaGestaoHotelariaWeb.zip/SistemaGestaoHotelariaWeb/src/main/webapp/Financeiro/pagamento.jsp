<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamentos · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .btn-primary-custom { background: #2ECC71; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: white; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #1B2B3C; color: #2ECC71; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #2ECC71; color: #2ECC71; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2E8F0; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #ECF0F1; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2E8F0; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; transition: all 0.3s ease; border: 1px solid #E2E8F0; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #2ECC71; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.6rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }
        .stat-footer { font-size: 0.7rem; color: #7F8C8D; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }
        .table-responsive { overflow-x: auto; border-radius: 16px; }
        .table { margin: 0; font-size: 0.8rem; width: 100%; border-collapse: collapse; }
        .table thead th { border-bottom: 2px solid #2ECC71; color: #1B2B3C; font-weight: 600; padding: 14px 12px; background: #F8F9FA; white-space: nowrap; }
        .table tbody td { padding: 12px; vertical-align: middle; border-bottom: 1px solid #E2E8F0; }
        .table tbody tr:hover { background: #F8F9FA; }

        .badge-status { padding: 5px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 600; text-align: center; display: inline-block; min-width: 80px; }
        .badge-status.PAGO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.PARCIAL { background: #E3F2FD; color: #1976D2; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.view { color: #3498DB; }
        .action-btn.edit { color: #F39C12; }
        .action-btn:hover { background: #ECF0F1; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #1B2B3C; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2E8F0; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #2ECC71; border-color: #2ECC71; color: white; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

        .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .info-card { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; transition: all 0.2s; cursor: pointer; }
        .info-card:hover { border-color: #2ECC71; }
        .info-card h4 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 14px; }
        .info-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #E2E8F0; }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #1B2B3C; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2E8F0; }
        .detail-label { width: 130px; font-weight: 600; color: #1B2B3C; }
        .detail-value { flex: 1; color: #7F8C8D; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2E8F0; padding: 10px 14px; }
        .form-control-custom:focus, .form-select-custom:focus { border-color: #2ECC71; box-shadow: 0 0 0 3px rgba(46,204,113,0.1); }
        .form-control-readonly { background-color: #ECF0F1; cursor: not-allowed; }

        @media (max-width: 1200px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .info-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
    </ul>

    <div class="menu-section">RELATÓRIOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-calculator-fill"></i><div class="logo-text">Hotelaria · Financeiro<span>Gestão de Pagamentos</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>TOTAL ARRECADADO</h3><i class="bi bi-cash-stack"></i></div><div class="stat-value" id="totalArrecadado">0 MZN</div><div class="stat-footer">Total de pagamentos</div></div>
        <div class="stat-card"><div class="stat-header"><h3>CONTAS A RECEBER</h3><i class="bi bi-credit-card"></i></div><div class="stat-value" id="totalPendente">0 MZN</div><div class="stat-footer">Faturas pendentes</div></div>
        <div class="stat-card"><div class="stat-header"><h3>PAGAMENTOS HOJE</h3><i class="bi bi-check-circle"></i></div><div class="stat-value" id="pagamentosHoje">0</div><div class="stat-footer">Hoje</div></div>
        <div class="stat-card"><div class="stat-header"><h3>TICKET MÉDIO</h3><i class="bi bi-credit-card"></i></div><div class="stat-value" id="ticketMedio">0 MZN</div><div class="stat-footer">por pagamento</div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por cliente ou reserva..."></div>
        <div>
            <select class="filter-select" id="estadoFilter"><option value="">Todos os estados</option><option value="PAGO">PAGO</option><option value="PENDENTE">PENDENTE</option><option value="PARCIAL">PARCIAL</option></select>
            <select class="filter-select" id="metodoFilter"><option value="">Todos os métodos</option></select>
            <input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por data" style="width: 130px;">
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalPagamento"><i class="bi bi-plus-lg"></i> Novo Pagamento</button>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-cash-stack"></i> Histórico de Pagamentos</h3>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th><i class="bi bi-hash"></i> Reserva</th>
                        <th><i class="bi bi-person"></i> Cliente</th>
                        <th><i class="bi bi-cash-stack"></i> Valor</th>
                        <th><i class="bi bi-credit-card"></i> Método</th>
                        <th><i class="bi bi-file-text"></i> Referência</th>
                        <th><i class="bi bi-calendar3"></i> Data</th>
                        <th><i class="bi bi-info-circle"></i> Estado</th>
                        <th><i class="bi bi-gear"></i> Ações</th>
                    </tr>
                </thead>
                <tbody id="pagamentosTableBody">
                    <tr><td colspan="8" class="text-center py-5"><div class="spinner-border text-success"></div><p class="mt-2">Carregando pagamentos...</p><\/td><\/tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="info-grid">
        <div class="info-card"><h4><i class="bi bi-pie-chart"></i> Distribuição por Método</h4>
            <div class="info-item"><span>Dinheiro</span><strong id="percDinheiro">0%</strong></div>
            <div class="info-item"><span>POS</span><strong id="percPOS">0%</strong></div>
            <div class="info-item"><span>M-Pesa</span><strong id="percMPesa">0%</strong></div>
            <div class="info-item"><span>Transferência</span><strong id="percTransferencia">0%</strong></div>
            <div class="info-item"><span>E-Mola</span><strong id="percEMola">0%</strong></div>
        </div>
        <div class="info-card"><h4><i class="bi bi-receipt"></i> Resumo por Estado</h4>
            <div class="info-item"><span><i class="bi bi-check-circle" style="color:#2E7D32;"></i> PAGOS</span><strong id="totalPagosCount">0</strong></div>
            <div class="info-item"><span><i class="bi bi-hourglass" style="color:#F57C00;"></i> PENDENTES</span><strong id="totalPendentesCount">0</strong></div>
            <div class="info-item"><span><i class="bi bi-clock" style="color:#1976D2;"></i> PARCIAIS</span><strong id="totalParciaisCount">0</strong></div>
        </div>
        <div class="info-card"><h4><i class="bi bi-graph-up"></i> Últimos 30 dias</h4>
            <div class="info-item"><span>Valor arrecadado</span><strong id="ultimos30dias">0 MZN</strong></div>
            <div class="info-item"><span>Quantidade</span><strong id="qtdUltimos30dias">0</strong></div>
            <div class="info-item"><span>Média diária</span><strong id="mediaDiaria">0 MZN</strong></div>
        </div>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Novo/Editar Pagamento -->
<div class="modal fade modal-custom" id="modalPagamento" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-cash"></i> Registrar Pagamento</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formPagamento">
                    <input type="hidden" id="editId" value="">
                    <div class="mb-3">
                        <label class="form-label">Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaPagamento" required>
                            <option value="">Carregando reservas...</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Valor do Pagamento <span class="text-danger">*</span></label>
                        <input type="number" class="form-control form-control-readonly" id="valorPagamento" step="0.01" required placeholder="0.00" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Método de Pagamento <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="metodoPagamento" required>
                            <option value="">Selecione</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Referência (opcional)</label>
                        <input type="text" class="form-control form-control-custom" id="referenciaPagamento" placeholder="Nº transação, comprovativo...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Data do Pagamento</label>
                        <input type="text" class="form-control form-control-custom" id="dataPagamento" placeholder="Selecione a data">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Estado</label>
                        <select class="form-select form-select-custom" id="estadoPagamento">
                            <option value="PAGO">PAGO</option>
                            <option value="PENDENTE">PENDENTE</option>
                            <option value="PARCIAL">PARCIAL</option>
                        </select>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Salvar Pagamento</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Pagamento -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Pagamento</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Reserva:</div><div class="detail-value" id="detReserva">-</div></div>
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="detCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Valor:</div><div class="detail-value" id="detValor">-</div></div>
                <div class="detail-row"><div class="detail-label">Método:</div><div class="detail-value" id="detMetodo">-</div></div>
                <div class="detail-row"><div class="detail-label">Referência:</div><div class="detail-value" id="detReferencia">-</div></div>
                <div class="detail-row"><div class="detail-label">Data:</div><div class="detail-value" id="detData">-</div></div>
                <div class="detail-row"><div class="detail-label">Estado:</div><div class="detail-value" id="detEstado">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 5, currentFilter = "", currentEstadoFilter = "", currentMetodoFilter = "", currentDateFilter = "";
    let todosPagamentos = [], reservasLista = [], metodosLista = [];
    let flatpickrInstance = null;

    function formatMoney(v) {
        if (v === undefined || v === null || isNaN(v)) return "0 MZN";
        return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function formatMoneyDec(v) {
        if (v === undefined || v === null || isNaN(v)) return "0.00";
        return Number(v).toFixed(2);
    }

    function formatDateTime(dateStr) {
        if (!dateStr) return "-";
        return dateStr.replace('T', ' ').substring(0, 16);
    }

    function escapeHtml(s) {
        if (!s) return "";
        return s.replace(/[&<>]/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m;
        });
    }

    function showAlert(type, msg) {
        Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false });
    }

    // ==================== CARDS DE ESTATÍSTICAS ====================
    function loadStats() {
        $.ajax({ url: contextPath + '/Financeiro/pagamentos/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalArrecadado').html(formatMoney(d.total_arrecadado || 0));
                $('#totalPendente').html(formatMoney(d.total_pendente || 0));
                $('#pagamentosHoje').text(d.pagamentos_hoje || 0);
                $('#ticketMedio').html(formatMoney(d.ticket_medio || 0));
            }, error: function() {
                console.error('Erro ao carregar stats');
            }
        });
    }

    // ==================== CARREGAR RESERVAS COM VALOR TOTAL ====================
    function loadReservas() {
        $.ajax({
            url: contextPath + '/Financeiro/pagamentos/reservas',
            method: 'GET',
            dataType: 'json',
            success: function(d) {
                reservasLista = d;
                var select = $('#reservaPagamento');
                select.html('<option value="">Selecione a reserva</option>');

                if (d.length === 0) {
                    select.html('<option value="">Nenhuma reserva disponível</option>');
                } else {
                    $.each(d, function(i, r) {
                        var saldoPendente = parseFloat(r.saldo_pendente) || parseFloat(r.valor_total) || 0;
                        var valorTotal = parseFloat(r.valor_total) || 0;
                        var statusIcon = r.estado_reserva === 'CONFIRMADA' ? '✅' : '📋';

                        select.append('<option value="' + r.id_reserva +
                            '" data-valor="' + saldoPendente +
                            '" data-valor-total="' + valorTotal +
                            '" data-cliente="' + escapeHtml(r.cliente_nome) +
                            '" data-quarto="' + escapeHtml(r.quarto) + '">' +
                            statusIcon + ' #' + r.id_reserva +
                            ' - ' + escapeHtml(r.cliente_nome) +
                            ' - ' + escapeHtml(r.quarto) +
                            ' - Total: ' + formatMoney(valorTotal) +
                            ' (Saldo: ' + formatMoney(saldoPendente) + ')' +
                        '</option>');
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error('Erro ao carregar reservas:', error);
                $('#reservaPagamento').html('<option value="">Erro ao carregar reservas</option>');
            }
        });
    }

    // ==================== CARREGAR MÉTODOS DE PAGAMENTO ====================
    function loadMetodos() {
        $.ajax({ url: contextPath + '/Financeiro/metodos-pagamento/listar', method: 'GET', dataType: 'json',
            success: function(d) {
                metodosLista = d;
                var selectFiltro = $('#metodoFilter');
                var selectModal = $('#metodoPagamento');
                selectFiltro.html('<option value="">Todos os métodos</option>');
                selectModal.html('<option value="">Selecione</option>');
                $.each(d, function(i, m) {
                    selectFiltro.append('<option value="' + escapeHtml(m.nome_metodo) + '">' + escapeHtml(m.nome_metodo) + '</option>');
                    selectModal.append('<option value="' + m.id_metodo_pagamento + '" data-nome="' + escapeHtml(m.nome_metodo) + '">' + escapeHtml(m.nome_metodo) + '</option>');
                });
            }, error: function() { console.error('Erro ao carregar métodos'); }
        });
    }

    // ==================== CARREGAR LISTA DE PAGAMENTOS ====================
    function loadPagamentos() {
        $.ajax({ url: contextPath + '/Financeiro/pagamentos/listar', method: 'GET', dataType: 'json',
            success: function(d) {
                todosPagamentos = d;
                aplicarFiltros();
            },
            error: function() {
                $('#pagamentosTableBody').html('<tr><td colspan="8" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
            }
        });
    }

    // ==================== APLICAR FILTROS ====================
    function aplicarFiltros() {
        var filtrados = todosPagamentos.filter(function(p) {
            var matchSearch = !currentFilter || (p.cliente_nome && p.cliente_nome.toLowerCase().includes(currentFilter)) || (p.id_reserva && p.id_reserva.toString().includes(currentFilter));
            var matchEstado = !currentEstadoFilter || p.estado_pagamento === currentEstadoFilter;
            var matchMetodo = !currentMetodoFilter || p.metodo_nome === currentMetodoFilter;
            var matchDate = !currentDateFilter || (p.data_pagamento && p.data_pagamento.split(' ')[0] === currentDateFilter);
            return matchSearch && matchEstado && matchMetodo && matchDate;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
        carregarInfoCards();
    }

    // ==================== RENDERIZAR TABELA ====================
    function renderizarTabela(pagamentos) {
        var tbody = $('#pagamentosTableBody');
        tbody.empty();
        if (pagamentos.length === 0) {
            tbody.html('<tr><td colspan="8" class="text-center py-4">Nenhum pagamento encontrado</td></tr>');
            return;
        }
        $.each(pagamentos, function(i, p) {
            tbody.append(
                '<tr>' +
                    '<td><span class="badge bg-secondary">#' + p.id_reserva + '</span></td>' +
                    '<td><strong>' + escapeHtml(p.cliente_nome) + '</strong></td>' +
                    '<td><strong>' + formatMoney(p.valor) + '</strong></td>' +
                    '<td>' + (p.metodo_nome || '-') + '</td>' +
                    '<td>' + (p.referencia_pagamento || '-') + '</td>' +
                    '<td>' + formatDateTime(p.data_pagamento) + '</td>' +
                    '<td><span class="badge-status ' + p.estado_pagamento + '">' + p.estado_pagamento + '</span></td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" data-id="' + p.id_pagamento + '" title="Editar"><i class="bi bi-pencil"></i></button>' +
                        '<button class="action-btn view" data-id="' + p.id_pagamento + '" title="Detalhes"><i class="bi bi-eye"></i></button>' +
                    '</td>' +
                '</tr>'
            );
        });
        $('.action-btn.edit').off('click').on('click', function() { editPagamento($(this).data('id')); });
        $('.action-btn.view').off('click').on('click', function() { viewPagamento($(this).data('id')); });
    }

    // ==================== PAGINAÇÃO ====================
    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); return false; }

    // ==================== EDITAR PAGAMENTO ====================
    function editPagamento(id) {
        var p = todosPagamentos.find(function(pag) { return pag.id_pagamento === id; });
        if (p) {
            $('#editId').val(p.id_pagamento);
            $('#reservaPagamento').val(p.id_reserva);
            $('#valorPagamento').val(formatMoneyDec(p.valor));
            var metodoOption = $('#metodoPagamento option[data-nome="' + p.metodo_nome + '"]');
            if (metodoOption.length) $('#metodoPagamento').val(metodoOption.val());
            $('#referenciaPagamento').val(p.referencia_pagamento || "");
            $('#estadoPagamento').val(p.estado_pagamento);
            if (p.data_pagamento && flatpickrInstance) {
                flatpickrInstance.setDate(p.data_pagamento.replace(' ', 'T'));
            }
            $('#modalPagamento .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Pagamento');
            new bootstrap.Modal(document.getElementById('modalPagamento')).show();
        }
    }

    // ==================== VISUALIZAR DETALHES ====================
    function viewPagamento(id) {
        var p = todosPagamentos.find(function(pag) { return pag.id_pagamento === id; });
        if (p) {
            $('#detReserva').html('<strong>#' + p.id_reserva + '</strong>');
            $('#detCliente').text(p.cliente_nome);
            $('#detValor').text(formatMoney(p.valor));
            $('#detMetodo').text(p.metodo_nome || '-');
            $('#detReferencia').text(p.referencia_pagamento || '-');
            $('#detData').text(p.data_pagamento);
            $('#detEstado').html('<span class="badge-status ' + p.estado_pagamento + '">' + p.estado_pagamento + '</span>');
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        }
    }

    // ==================== CARREGAR CARDS DE INFORMAÇÃO ====================
    function carregarInfoCards() {
        // Distribuição por método
        var porMetodo = {};
        var totalValor = 0;
        $.each(todosPagamentos, function(i, p) {
            if (p.estado_pagamento === 'PAGO') {
                if (!porMetodo[p.metodo_nome]) porMetodo[p.metodo_nome] = 0;
                porMetodo[p.metodo_nome] += p.valor;
                totalValor += p.valor;
            }
        });

        $('#percDinheiro').text(totalValor > 0 ? Math.round((porMetodo['Dinheiro'] || 0) / totalValor * 100) + '%' : '0%');
        $('#percPOS').text(totalValor > 0 ? Math.round((porMetodo['POS'] || 0) / totalValor * 100) + '%' : '0%');
        $('#percMPesa').text(totalValor > 0 ? Math.round((porMetodo['M-Pesa'] || 0) / totalValor * 100) + '%' : '0%');
        $('#percTransferencia').text(totalValor > 0 ? Math.round((porMetodo['Transferência Bancária'] || 0) / totalValor * 100) + '%' : '0%');
        $('#percEMola').text(totalValor > 0 ? Math.round((porMetodo['E-Mola'] || 0) / totalValor * 100) + '%' : '0%');

        // Resumo por estado
        var pagos = 0, pendentes = 0, parciais = 0;
        $.each(todosPagamentos, function(i, p) {
            if (p.estado_pagamento === 'PAGO') pagos++;
            else if (p.estado_pagamento === 'PENDENTE') pendentes++;
            else if (p.estado_pagamento === 'PARCIAL') parciais++;
        });
        $('#totalPagosCount').text(pagos);
        $('#totalPendentesCount').text(pendentes);
        $('#totalParciaisCount').text(parciais);

        // Últimos 30 dias
        var trintaDias = new Date();
        trintaDias.setDate(trintaDias.getDate() - 30);
        var total30 = 0, qtd30 = 0;
        $.each(todosPagamentos, function(i, p) {
            if (p.data_pagamento && new Date(p.data_pagamento) >= trintaDias && p.estado_pagamento === 'PAGO') {
                total30 += p.valor;
                qtd30++;
            }
        });
        $('#ultimos30dias').html(formatMoney(total30));
        $('#qtdUltimos30dias').text(qtd30);
        $('#mediaDiaria').html(formatMoney(qtd30 > 0 ? total30 / 30 : 0));
    }

    // ==================== EVENTO: SELECIONAR RESERVA (AUTO PREENCHER VALOR) ====================
    $('#reservaPagamento').on('change', function() {
        var selectedValue = $(this).val();
        var $valorInput = $('#valorPagamento');

        if (!selectedValue || selectedValue === "") {
            $valorInput.val('');
            $valorInput.prop('readonly', false);
            $valorInput.css('backgroundColor', '');
            $valorInput.attr('placeholder', 'Valor do pagamento');
            return;
        }

        // Buscar na lista de reservas carregadas
        var reservaEncontrada = reservasLista.find(function(r) {
            return r.id_reserva == selectedValue;
        });

        if (reservaEncontrada) {
            var saldoPendente = parseFloat(reservaEncontrada.saldo_pendente) || parseFloat(reservaEncontrada.valor_total) || 0;

            if (saldoPendente > 0) {
                $valorInput.val(saldoPendente.toFixed(2));
                $valorInput.prop('readonly', false);
                $valorInput.css('backgroundColor', '#e8f5e9');
                $valorInput.attr('placeholder', 'Valor do pagamento');
                console.log("✅ Valor preenchido automaticamente: " + saldoPendente.toFixed(2) + " MZN");
            } else {
                $valorInput.val('');
                $valorInput.prop('readonly', false);
                $valorInput.css('backgroundColor', '#fff3e0');
                $valorInput.attr('placeholder', 'Saldo zerado! Digite valor manualmente');
                console.warn("⚠️ Saldo pendente é zero para reserva #" + selectedValue);
            }
        } else {
            $valorInput.val('');
            $valorInput.prop('readonly', false);
            $valorInput.css('backgroundColor', '');
            console.warn("⚠️ Reserva não encontrada na lista:", selectedValue);
        }
    });

    // ==================== SUBMIT DO FORMULÁRIO ====================
    $('#formPagamento').on('submit', function(e) {
        e.preventDefault();
        var editId = $('#editId').val();
        var reservaId = $('#reservaPagamento').val();
        var valor = parseFloat($('#valorPagamento').val());
        var metodoId = $('#metodoPagamento').val();
        var referencia = $('#referenciaPagamento').val();
        var estado = $('#estadoPagamento').val();
        var dataPagamento = $('#dataPagamento').val();

        if (!reservaId || !metodoId || isNaN(valor) || valor <= 0) {
            showAlert('warning', 'Preencha todos os campos obrigatórios!');
            return;
        }

        if (!dataPagamento) {
            var now = new Date();
            dataPagamento = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0') + 'T' + String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
        }

        var pagamentoData = {
            id: editId || '',
            id_reserva: reservaId,
            valor: valor,
            id_metodo_pagamento: metodoId,
            referencia_pagamento: referencia,
            data_pagamento: dataPagamento.replace('T', ' ') + ':00',
            estado_pagamento: estado
        };

        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Salvando...');

        $.ajax({
            url: contextPath + '/Financeiro/pagamentos/salvar',
            method: 'POST',
            data: pagamentoData,
            dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Salvar Pagamento');
                if (r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalPagamento')).hide();
                    $('#formPagamento')[0].reset();
                    $('#editId').val("");
                    $('#valorPagamento').css('backgroundColor', '');
                    $('#modalPagamento .modal-title').html('<i class="bi bi-cash"></i> Registrar Pagamento');
                    loadPagamentos();
                    loadReservas();
                    showAlert('success', 'Pagamento ' + (editId ? 'atualizado' : 'registrado') + ' com sucesso!');
                } else {
                    showAlert('error', r.message || 'Erro ao salvar');
                }
            },
            error: function(xhr, status, error) {
                btn.prop('disabled', false).text('Salvar Pagamento');
                console.error('Erro:', error);
                showAlert('error', 'Erro ao salvar pagamento');
            }
        });
    });

    // ==================== RESET MODAL ====================
    $('#modalPagamento').on('hidden.bs.modal', function() {
        $('#formPagamento')[0].reset();
        $('#editId').val("");
        $('#valorPagamento').css('backgroundColor', '');
        $('#modalPagamento .modal-title').html('<i class="bi bi-cash"></i> Registrar Pagamento');
    });

    // ==================== FILTROS ====================
    $('#searchInput').on('input', function() {
        currentFilter = $(this).val().toLowerCase();
        currentPage = 1;
        aplicarFiltros();
    });

    $('#estadoFilter').on('change', function() {
        currentEstadoFilter = $(this).val();
        currentPage = 1;
        aplicarFiltros();
    });

    $('#metodoFilter').on('change', function() {
        currentMetodoFilter = $(this).val();
        currentPage = 1;
        aplicarFiltros();
    });

    // ==================== FLATPICKR ====================
    flatpickr("#dataPagamento", {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        locale: "pt",
        time_24hr: true,
        defaultDate: new Date()
    });

    flatpickrInstance = flatpickr("#dateFilter", {
        dateFormat: "Y-m-d",
        locale: "pt",
        onChange: function(selectedDates, dateStr) {
            currentDateFilter = dateStr;
            currentPage = 1;
            aplicarFiltros();
        }
    });

    // ==================== RELÓGIO ====================
    function updateClock() {
        var now = new Date();
        $('#horaAtual').html(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' }));
        $('#anoAtual').html(now.getFullYear());
    }
    setInterval(updateClock, 1000);
    updateClock();

    // ==================== INICIALIZAÇÃO ====================
    $(document).ready(function() {
        loadReservas();
        loadMetodos();
        loadPagamentos();
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>