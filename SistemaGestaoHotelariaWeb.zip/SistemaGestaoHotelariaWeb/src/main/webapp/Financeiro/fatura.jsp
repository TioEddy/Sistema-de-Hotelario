<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faturas · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .btn-primary-custom { background: #2ECC71; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: white; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #1B2B3C; color: #2ECC71; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #2ECC71; color: #2ECC71; }
        .btn-export { background: transparent; border: 1px solid #E2E8F0; padding: 6px 12px; border-radius: 30px; font-size: 0.75rem; transition: all 0.2s; }
        .btn-export:hover { border-color: #2ECC71; color: #2ECC71; background: #E8F5E9; }
        .btn-export-pdf { border-color: #E74C3C; color: #E74C3C; }
        .btn-export-csv { border-color: #2E7D32; color: #2E7D32; }
        .btn-export-print { border-color: #3498DB; color: #3498DB; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2E8F0; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .search-box { display: flex; align-items: center; gap: 10px; background: #ECF0F1; padding: 8px 16px; border-radius: 40px; }
        .search-box input { border: none; background: transparent; outline: none; width: 250px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2E8F0; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; transition: all 0.3s ease; border: 1px solid #E2E8F0; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #2ECC71; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.6rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }
        .stat-footer { font-size: 0.7rem; color: #7F8C8D; }

        .charts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #2ECC71; }
        .chart-container { position: relative; height: 170px; width: 100%; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #2ECC71; color: #1B2B3C; font-weight: 600; padding: 10px 6px; }

        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 500; }
        .badge-status.PAGO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.PARCIAL { background: #E3F2FD; color: #1976D2; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.view { color: #3498DB; }
        .action-btn.pdf { color: #E74C3C; }
        .action-btn:hover { background: #ECF0F1; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #1B2B3C; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2E8F0; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #2ECC71; border-color: #2ECC71; color: white; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

        .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .info-card { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; transition: all 0.2s; cursor: pointer; }
        .info-card:hover { border-color: #2ECC71; }
        .info-card h4 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 14px; }
        .info-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #E2E8F0; }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #1B2B3C; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E2E8F0; }
        .detail-label { width: 130px; font-weight: 600; color: #1B2B3C; }
        .detail-value { flex: 1; color: #7F8C8D; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2E8F0; padding: 10px 14px; }
        .form-control-custom:focus, .form-select-custom:focus { border-color: #2ECC71; box-shadow: 0 0 0 3px rgba(46,204,113,0.1); }
        .form-control-readonly { background-color: #ECF0F1; cursor: not-allowed; }

        @media print { .sidebar, .topbar, .filters-bar, .pagination, .footer, .action-buttons, .btn, .notification-icon, .stats-grid, .charts-grid, .info-grid { display: none !important; } .main-wrapper { margin-left: 0 !important; padding: 0 !important; } .table-section { box-shadow: none; border: none; padding: 0; } }
        @media (max-width: 1200px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .charts-grid { grid-template-columns: 1fr; } .info-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
    </ul>

    <div class="menu-section">RELATÓRIOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-calculator-fill"></i><div class="logo-text">Hotelaria · Financeiro<span>Gestão de Faturas</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>TOTAL FATURADO</h3><i class="bi bi-cash-stack"></i></div><div class="stat-value" id="totalFaturado">0 MZN</div><div class="stat-footer">Total de faturas emitidas</div></div>
        <div class="stat-card"><div class="stat-header"><h3>CONTAS A RECEBER</h3><i class="bi bi-credit-card"></i></div><div class="stat-value" id="contasReceber">0 MZN</div><div class="stat-footer">Faturas pendentes</div></div>
        <div class="stat-card"><div class="stat-header"><h3>FATURAS EMITIDAS</h3><i class="bi bi-receipt"></i></div><div class="stat-value" id="totalFaturas">0</div><div class="stat-footer">este mês: <span id="faturasMes">0</span></div></div>
        <div class="stat-card"><div class="stat-header"><h3>TICKET MÉDIO</h3><i class="bi bi-credit-card"></i></div><div class="stat-value" id="ticketMedio">0 MZN</div><div class="stat-footer">por fatura</div></div>
    </div>

    <div class="charts-grid">
        <div class="chart-box"><h3><i class="bi bi-pie-chart"></i> Faturas por Estado</h3><div class="chart-container"><canvas id="estadoFaturasChart"></canvas></div></div>
        <div class="chart-box"><h3><i class="bi bi-bar-chart"></i> Faturação Mensal</h3><div class="chart-container"><canvas id="faturacaoMensalChart"></canvas></div></div>
        <div class="chart-box"><h3><i class="bi bi-graph-up"></i> Faturação por Tipo</h3><div class="chart-container"><canvas id="faturacaoTipoChart"></canvas></div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInput" placeholder="Buscar por cliente ou nº fatura..."></div>
        <div>
            <select class="filter-select" id="estadoFilter"><option value="">Todos os estados</option><option value="PAGO">PAGO</option><option value="PENDENTE">PENDENTE</option><option value="PARCIAL">PARCIAL</option></select>
            <input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por data" style="width: 130px;">
        </div>
        <div>
            <button class="btn-export btn-export-pdf" onclick="exportFaturasPDF()"><i class="bi bi-filetype-pdf"></i> PDF</button>
            <button class="btn-export btn-export-csv" onclick="exportFaturasCSV()"><i class="bi bi-filetype-csv"></i> CSV</button>
            <button class="btn-export btn-export-print" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir</button>
            <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalFatura"><i class="bi bi-plus-lg"></i> Nova Fatura</button>
        </div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-receipt"></i> Lista de Faturas</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Nº Fatura</th><th>Cliente</th><th>Reserva</th><th>Subtotal</th><th>IVA</th><th>Total</th><th>Data Emissão</th><th>Estado</th><th>Ações</th></tr>
                </thead>
                <tbody id="faturasTableBody"><tr><td colspan="9" class="text-center py-4"><div class="spinner-border text-success"></div></td></tr></tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="info-grid">
        <div class="info-card"><h4><i class="bi bi-pie-chart"></i> Resumo por Estado</h4>
            <div class="info-item"><span><i class="bi bi-check-circle" style="color:#2E7D32;"></i> PAGAS</span><strong id="qtdPagas">0</strong></div>
            <div class="info-item"><span><i class="bi bi-hourglass" style="color:#F57C00;"></i> PENDENTES</span><strong id="qtdPendentes">0</strong></div>
            <div class="info-item"><span><i class="bi bi-clock" style="color:#1976D2;"></i> PARCIAIS</span><strong id="qtdParciais">0</strong></div>
        </div>
        <div class="info-card"><h4><i class="bi bi-receipt"></i> Faturação por Tipo</h4>
            <div class="info-item"><span>Hospedagem</span><strong id="totalHospedagem">0 MZN</strong></div>
            <div class="info-item"><span>Serviços</span><strong id="totalServicos">0 MZN</strong></div>
            <div class="info-item mt-2"><strong>TOTAL</strong><strong id="totalGeralTipo">0 MZN</strong></div>
        </div>
        <div class="info-card"><h4><i class="bi bi-graph-up"></i> Indicadores</h4>
            <div class="info-item"><span>IVA Total</span><strong id="totalIVA">0 MZN</strong></div>
            <div class="info-item"><span>Faturas este mês</span><strong id="faturasMesCard">0</strong></div>
            <div class="info-item"><span>Ticket Médio</span><strong id="ticketMedioCard">0 MZN</strong></div>
        </div>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<!-- MODAL: Nova Fatura -->
<div class="modal fade modal-custom" id="modalFatura" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-receipt"></i> Emitir Nova Fatura</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formFatura">
                    <div class="mb-3"><label class="form-label">Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaFatura" required><option value="">Carregando reservas...</option></select>
                    </div>
                    <div class="mb-3"><label class="form-label">Subtotal (sem IVA)</label>
                        <input type="text" class="form-control form-control-readonly" id="subtotalFatura" readonly>
                    </div>
                    <div class="mb-3"><label class="form-label">IVA (16%)</label>
                        <input type="text" class="form-control form-control-readonly" id="ivaFatura" readonly>
                    </div>
                    <div class="mb-3"><label class="form-label">Total a Pagar</label>
                        <input type="text" class="form-control form-control-readonly" id="totalFatura" readonly style="font-weight: bold; background: #FFF8E1;">
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Emitir Fatura</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Visualizar Fatura -->
<div class="modal fade modal-custom" id="modalVisualizarFatura" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-receipt"></i> Fatura #<span id="faturaNumeroModal">-</span></h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4" id="faturaPrintContent">
                <div style="text-align: center; margin-bottom: 30px;">
                    <i class="bi bi-building" style="font-size: 2rem; color: #2ECC71;"></i>
                    <h2 style="margin: 10px 0 5px; color: #1B2B3C;">Hotelaria Systems</h2>
                    <p style="color: #7F8C8D; margin: 0;">Av. Marginal, 1234 - Maputo | Tel: +258 84 123 4567</p>
                    <p style="color: #7F8C8D;">NUIT: 123456789 | Email: facturacao@hotelaria.co.mz</p>
                    <hr style="border-top: 2px solid #2ECC71; width: 100px;">
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
                    <div><strong>FATURA Nº:</strong> <span id="printNumero">-</span><br><strong>Data Emissão:</strong> <span id="printData">-</span></div>
                    <div><strong>Cliente:</strong> <span id="printCliente">-</span><br><strong>Reserva:</strong> <span id="printReserva">-</span></div>
                </div>
                <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                    <thead><tr style="background: #ECF0F1; border-bottom: 2px solid #2ECC71;"><th style="padding: 10px; text-align: left;">Descrição</th><th style="padding: 10px; text-align: right;">Valor (MZN)</th></tr></thead>
                    <tbody>
                        <tr><td style="padding: 10px;">Hospedagem - Diárias</td><td style="padding: 10px; text-align: right;"><span id="printSubtotal">-</span></td></tr>
                        <tr><td style="padding: 10px;">IVA (16%)</td><td style="padding: 10px; text-align: right;"><span id="printIva">-</span></td></tr>
                        <tr style="border-top: 2px solid #2ECC71; background: #FFF8E1;"><td style="padding: 10px;"><strong>TOTAL</strong></td><td style="padding: 10px; text-align: right;"><strong id="printTotal">-</strong></td></tr>
                    </tbody>
                </table>
                <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px dashed #E2E8F0;"><p style="color: #7F8C8D; font-size: 0.8rem;">Obrigado pela preferência!</p></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px; justify-content: center; gap: 12px;">
                <button class="btn-primary-custom" id="printFaturaBtn"><i class="bi bi-printer"></i> Imprimir</button>
                <button class="btn-outline-custom" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 5, currentFilter = "", currentEstadoFilter = "", currentDateFilter = "";
    let todasFaturas = [], reservasLista = [];
    let estadoChart = null, faturacaoChart = null, faturacaoTipoChart = null;

    function formatMoney(v) { if (v === undefined || v === null || isNaN(v)) return "0 MZN"; return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN"; }
    function formatDateTime(dateStr) { if (!dateStr) return "-"; return dateStr.replace('T', ' ').substring(0, 16); }
    function escapeHtml(s) { if (!s) return ""; return s.replace(/[&<>]/g, function(m) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m; }); }
    function showAlert(type, msg) { Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false }); }

    function loadStats() {
        $.ajax({ url: contextPath + '/Financeiro/faturas/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#totalFaturado').html(formatMoney(d.total_faturado || 0));
                $('#contasReceber').html(formatMoney(d.contas_receber || 0));
                $('#totalFaturas').text(d.total || 0);
                $('#faturasMes').text(d.faturas_mes || 0);
                $('#ticketMedio').html(formatMoney(d.ticket_medio || 0));

                $('#faturasMesCard').text(d.faturas_mes || 0);
                $('#ticketMedioCard').html(formatMoney(d.ticket_medio || 0));
                $('#totalIVA').html(formatMoney(d.total_iva || 0));
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function loadReservas() {
        $.ajax({ url: contextPath + '/Financeiro/faturas/reservas', method: 'GET', dataType: 'json',
            success: function(d) {
                reservasLista = d;
                var select = $('#reservaFatura');
                select.html('<option value="">Selecione a reserva</option>');
                if (d.length === 0) {
                    select.html('<option value="">Nenhuma reserva disponível</option>');
                } else {
                    $.each(d, function(i, r) {
                        select.append('<option value="' + r.id_reserva + '" data-valor="' + r.valor_total + '" data-cliente="' + escapeHtml(r.cliente_nome) + '">' +
                            ' #' + r.id_reserva + ' - ' + escapeHtml(r.cliente_nome) + ' - ' + escapeHtml(r.quarto) + ' - ' + formatMoney(r.valor_total) +
                        '</option>');
                    });
                }
            }, error: function() { console.error('Erro ao carregar reservas'); }
        });
    }

    function loadFaturas() {
        $.ajax({ url: contextPath + '/Financeiro/faturas/listar', method: 'GET', dataType: 'json',
            success: function(d) { todasFaturas = d; aplicarFiltros(); carregarGraficos(); },
            error: function() { $('#faturasTableBody').html('<tr><td colspan="9" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>'); }
        });
    }

    function aplicarFiltros() {
        var filtrados = todasFaturas.filter(function(f) {
            var matchSearch = !currentFilter || (f.cliente_nome && f.cliente_nome.toLowerCase().includes(currentFilter)) || (f.numero_fatura && f.numero_fatura.toLowerCase().includes(currentFilter));
            var matchEstado = !currentEstadoFilter || f.estado_pagamento === currentEstadoFilter;
            var matchDate = !currentDateFilter || (f.data_emissao && f.data_emissao.split(' ')[0] === currentDateFilter);
            return matchSearch && matchEstado && matchDate;
        });
        var totalPages = Math.ceil(filtrados.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginados = filtrados.slice(start, start + rowsPerPage);
        renderizarTabela(paginados);
        renderizarPaginacao(totalPages);
        loadStats();
        carregarInfoCards();
    }

    function renderizarTabela(faturas) {
        var tbody = $('#faturasTableBody');
        tbody.empty();
        if (faturas.length === 0) { tbody.html('<tr><td colspan="9" class="text-center py-4">Nenhuma fatura encontrada</td></tr>'); return; }
        $.each(faturas, function(i, f) {
            tbody.append('<tr>' +
                '<td><strong>' + escapeHtml(f.numero_fatura) + '</strong></td>' +
                '<td>' + escapeHtml(f.cliente_nome) + '</td>' +
                '<td><span class="badge bg-secondary">#' + f.id_reserva + '</span></td>' +
                '<td>' + formatMoney(f.subtotal) + '</td>' +
                '<td>' + formatMoney(f.iva) + '</td>' +
                '<td><strong>' + formatMoney(f.total) + '</strong></td>' +
                '<td>' + f.data_emissao + '</td>' +
                '<td><span class="badge-status ' + (f.estado_pagamento || 'PENDENTE') + '">' + (f.estado_pagamento || 'PENDENTE') + '</span></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn view" data-id="' + f.id_fatura + '" title="Visualizar"><i class="bi bi-eye"></i></button>' +
                    '<button class="action-btn pdf" data-id="' + f.id_fatura + '" title="PDF"><i class="bi bi-file-pdf"></i></button>' +
                '</td>' +
            '</tr>');
        });
        $('.action-btn.view').off('click').on('click', function() { viewFatura($(this).data('id')); });
        $('.action-btn.pdf').off('click').on('click', function() { downloadFaturaPDF($(this).data('id')); });
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + '); return false;">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + '); return false;">' + i + '</a></li>';
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + '); return false;">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) { currentPage = page; aplicarFiltros(); return false; }

    function viewFatura(id) {
        $.ajax({ url: contextPath + '/Financeiro/faturas/detalhes', method: 'GET', data: { id: id }, dataType: 'json',
            success: function(f) {
                if (f && f.id_fatura) {
                    $('#faturaNumeroModal').text(f.numero_fatura);
                    $('#printNumero').text(f.numero_fatura);
                    $('#printData').text(f.data_emissao);
                    $('#printCliente').text(f.cliente_nome);
                    $('#printReserva').text('#' + f.id_reserva);
                    $('#printSubtotal').text(formatMoney(f.subtotal));
                    $('#printIva').text(formatMoney(f.iva));
                    $('#printTotal').text(formatMoney(f.total));
                    new bootstrap.Modal(document.getElementById('modalVisualizarFatura')).show();
                } else { showAlert('error', 'Fatura não encontrada!'); }
            }, error: function() { showAlert('error', 'Erro ao carregar detalhes da fatura'); }
        });
    }

    function downloadFaturaPDF(id) {
        var fatura = todasFaturas.find(function(f) { return f.id_fatura === id; });
        if (fatura) {
            var printContent = document.getElementById('faturaPrintContent').cloneNode(true);
            $(printContent).find('#printNumero').text(fatura.numero_fatura);
            $(printContent).find('#printData').text(fatura.data_emissao);
            $(printContent).find('#printCliente').text(fatura.cliente_nome);
            $(printContent).find('#printReserva').text('#' + fatura.id_reserva);
            $(printContent).find('#printSubtotal').text(formatMoney(fatura.subtotal));
            $(printContent).find('#printIva').text(formatMoney(fatura.iva));
            $(printContent).find('#printTotal').text(formatMoney(fatura.total));
            var win = window.open('', '_blank');
            win.document.write('<!DOCTYPE html><html><head><title>Fatura_' + fatura.numero_fatura + '</title><style>body{font-family:"Segoe UI",sans-serif;padding:40px;}table{width:100%;border-collapse:collapse;}th,td{padding:10px;}</style></head><body>');
            win.document.write(printContent.outerHTML);
            win.document.write('</body></html>');
            win.document.close();
            win.print();
        } else { showAlert('error', 'Fatura não encontrada!'); }
    }

    $('#printFaturaBtn').on('click', function() {
        var faturaNumero = $('#faturaNumeroModal').text();
        var fatura = todasFaturas.find(function(f) { return f.numero_fatura === faturaNumero; });
        if (fatura) downloadFaturaPDF(fatura.id_fatura);
    });

    function carregarInfoCards() {
        var pagas = 0, pendentes = 0, parciais = 0, totalHospedagem = 0, totalServicos = 0;
        $.each(todasFaturas, function(i, f) {
            if (f.estado_pagamento === 'PAGO') pagas++;
            else if (f.estado_pagamento === 'PENDENTE') pendentes++;
            else if (f.estado_pagamento === 'PARCIAL') parciais++;
            totalHospedagem += f.subtotal || 0;
            totalServicos += f.iva || 0;
        });
        $('#qtdPagas').text(pagas);
        $('#qtdPendentes').text(pendentes);
        $('#qtdParciais').text(parciais);
        $('#totalHospedagem').html(formatMoney(totalHospedagem));
        $('#totalServicos').html(formatMoney(totalServicos));
        $('#totalGeralTipo').html(formatMoney(totalHospedagem + totalServicos));
    }

    function carregarGraficos() {
        var estados = { PAGO: 0, PENDENTE: 0, PARCIAL: 0 };
        var faturamentoMensal = {};
        $.each(todasFaturas, function(i, f) {
            estados[f.estado_pagamento || 'PENDENTE']++;
            var mes = f.data_emissao ? f.data_emissao.substring(0, 7) : null;
            if (mes) { faturamentoMensal[mes] = (faturamentoMensal[mes] || 0) + f.total; }
        });
        if (estadoChart) estadoChart.destroy();
        estadoChart = new Chart(document.getElementById('estadoFaturasChart'), {
            type: 'doughnut',
            data: { labels: ['PAGO', 'PENDENTE', 'PARCIAL'], datasets: [{ data: [estados.PAGO, estados.PENDENTE, estados.PARCIAL], backgroundColor: ['#2E7D32', '#F57C00', '#1976D2'], borderWidth: 0 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
        });
        var meses = Object.keys(faturamentoMensal).sort().slice(-6);
        var valores = meses.map(function(m) { return faturamentoMensal[m]; });
        if (faturacaoChart) faturacaoChart.destroy();
        faturacaoChart = new Chart(document.getElementById('faturacaoMensalChart'), {
            type: 'line',
            data: { labels: meses, datasets: [{ label: 'Faturação (MZN)', data: valores, borderColor: '#2ECC71', backgroundColor: 'rgba(46,204,113,0.05)', tension: 0.3, fill: true, pointBackgroundColor: '#2ECC71' }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return formatMoney(v); } } } } }
        });
        if (faturacaoTipoChart) faturacaoTipoChart.destroy();
        faturacaoTipoChart = new Chart(document.getElementById('faturacaoTipoChart'), {
            type: 'bar',
            data: { labels: ['Hospedagem', 'Serviços'], datasets: [{ data: [100000, 25000], backgroundColor: ['#2ECC71', '#3498DB'], borderRadius: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return formatMoney(v); } } } } }
        });
    }

    $('#formFatura').on('submit', function(e) {
        e.preventDefault();
        var idReserva = $('#reservaFatura').val();
        if (!idReserva) { showAlert('warning', 'Selecione uma reserva!'); return; }
        var subtotal = parseFloat($('#subtotalFatura').val().replace(/[^\d,.-]/g, '').replace(',', '.')) || 0;
        var iva = parseFloat($('#ivaFatura').val().replace(/[^\d,.-]/g, '').replace(',', '.')) || 0;
        var total = parseFloat($('#totalFatura').val().replace(/[^\d,.-]/g, '').replace(',', '.')) || 0;
        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Emitindo...');
        $.ajax({ url: contextPath + '/Financeiro/faturas/emitir', method: 'POST', data: { id_reserva: idReserva, subtotal: subtotal, iva: iva, total: total }, dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Emitir Fatura');
                if (r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalFatura')).hide();
                    $('#formFatura')[0].reset();
                    $('#subtotalFatura').val('');
                    $('#ivaFatura').val('');
                    $('#totalFatura').val('');
                    loadFaturas();
                    loadReservas();
                    showAlert('success', 'Fatura ' + (r.numero_fatura || '') + ' emitida com sucesso!');
                } else { showAlert('error', r.message || 'Erro ao emitir fatura'); }
            }, error: function() { btn.prop('disabled', false).text('Emitir Fatura'); showAlert('error', 'Erro ao emitir fatura'); }
        });
    });

    $('#modalFatura').on('hidden.bs.modal', function() {
        $('#formFatura')[0].reset();
        $('#subtotalFatura').val('');
        $('#ivaFatura').val('');
        $('#totalFatura').val('');
    });

    $('#reservaFatura').on('change', function() {
        var selected = $(this).find('option:selected');
        var valor = parseFloat(selected.data('valor')) || 0;
        var iva = valor * 0.16;
        var total = valor + iva;
        $('#subtotalFatura').val(formatMoney(valor));
        $('#ivaFatura').val(formatMoney(iva));
        $('#totalFatura').val(formatMoney(total));
    });

    $('#searchInput').on('input', function() { currentFilter = $(this).val().toLowerCase(); currentPage = 1; aplicarFiltros(); });
    $('#estadoFilter').on('change', function() { currentEstadoFilter = $(this).val(); currentPage = 1; aplicarFiltros(); });
    flatpickr("#dateFilter", { dateFormat: "Y-m-d", locale: "pt", onChange: function(selectedDates, dateStr) { currentDateFilter = dateStr; currentPage = 1; aplicarFiltros(); } });

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    function exportFaturasCSV() {
        var filtrados = todasFaturas.filter(function(f) {
            var matchEstado = !currentEstadoFilter || f.estado_pagamento === currentEstadoFilter;
            var matchDate = !currentDateFilter || (f.data_emissao && f.data_emissao.split(' ')[0] === currentDateFilter);
            return matchEstado && matchDate;
        });
        var headers = ['Nº Fatura', 'Cliente', 'Reserva', 'Subtotal', 'IVA', 'Total', 'Data Emissão', 'Estado'];
        var csvRows = [headers.join(',')];
        for (var i = 0; i < filtrados.length; i++) {
            var f = filtrados[i];
            csvRows.push([
                '"' + f.numero_fatura + '"',
                '"' + (f.cliente_nome || '') + '"',
                '#' + f.id_reserva,
                f.subtotal,
                f.iva,
                f.total,
                f.data_emissao,
                f.estado_pagamento || 'PENDENTE'
            ].join(','));
        }
        var blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'faturas_' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        showAlert('success', 'Faturas exportadas para CSV!');
    }

    function exportFaturasPDF() {
        var filtrados = todasFaturas.filter(function(f) {
            var matchEstado = !currentEstadoFilter || f.estado_pagamento === currentEstadoFilter;
            var matchDate = !currentDateFilter || (f.data_emissao && f.data_emissao.split(' ')[0] === currentDateFilter);
            return matchEstado && matchDate;
        });
        var now = new Date();
        var dataAtual = now.toLocaleDateString('pt-PT') + ' ' + now.toLocaleTimeString('pt-PT');
        var { jsPDF } = window.jspdf;
        var doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
        doc.setFontSize(16);
        doc.setTextColor(27, 43, 60);
        doc.text('Hotelaria Systems - Relatório de Faturas', 20, 20);
        doc.setFontSize(10);
        doc.setTextColor(127, 140, 141);
        doc.text('Emitido em: ' + dataAtual, 20, 30);
        doc.text('Total de faturas: ' + filtrados.length, 20, 37);
        var tableData = [];
        for (var i = 0; i < filtrados.length; i++) {
            var f = filtrados[i];
            tableData.push([f.numero_fatura, f.cliente_nome || '-', '#' + f.id_reserva, formatMoney(f.subtotal), formatMoney(f.iva), formatMoney(f.total), f.data_emissao, f.estado_pagamento || 'PENDENTE']);
        }
        doc.autoTable({
            head: [['Nº Fatura', 'Cliente', 'Reserva', 'Subtotal', 'IVA', 'Total', 'Data Emissão', 'Estado']],
            body: tableData,
            startY: 45,
            margin: { top: 45, left: 15, right: 15, bottom: 15 },
            theme: 'striped',
            headStyles: { fillColor: [27, 43, 60], textColor: [46, 204, 113], fontStyle: 'bold' },
            alternateRowStyles: { fillColor: [236, 240, 241] },
            styles: { fontSize: 8, cellPadding: 2 }
        });
        doc.save('faturas_' + new Date().toISOString().split('T')[0] + '.pdf');
        showAlert('success', 'Faturas exportadas para PDF!');
    }

    loadReservas();
    loadFaturas();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>