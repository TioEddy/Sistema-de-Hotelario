<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Métodos de Pagamento · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .btn-primary-custom { background: #2ECC71; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: white; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #1B2B3C; color: #2ECC71; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #2ECC71; color: #2ECC71; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; border: 1px solid #E2E8F0; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.6rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }
        .stat-footer { font-size: 0.7rem; color: #7F8C8D; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #2ECC71; color: #1B2B3C; font-weight: 600; padding: 10px 6px; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn { background: transparent; border: none; cursor: pointer; padding: 5px; border-radius: 8px; transition: all 0.2s; }
        .action-btn.edit { color: #F39C12; }
        .action-btn:hover { background: #ECF0F1; transform: scale(1.1); }

        .pagination { margin-top: 20px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link { color: #1B2B3C; border-radius: 8px; padding: 8px 12px; text-decoration: none; border: 1px solid #E2E8F0; background: white; cursor: pointer; }
        .page-item.active .page-link { background: #2ECC71; border-color: #2ECC71; color: white; }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #1B2B3C; color: white; border-radius: 24px 24px 0 0; padding: 20px 24px; }
        .form-control-custom { border-radius: 12px; border: 1px solid #E2E8F0; padding: 10px 14px; }
        .form-control-custom:focus { border-color: #2ECC71; box-shadow: 0 0 0 3px rgba(46,204,113,0.1); }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        @media (max-width: 1200px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-calculator-fill"></i><div class="logo-text">Hotelaria · Financeiro<span>Métodos de Pagamento</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>TOTAL MÉTODOS</h3><i class="bi bi-credit-card"></i></div><div class="stat-value" id="totalMetodos">0</div><div class="stat-footer">Métodos cadastrados</div></div>
        <div class="stat-card"><div class="stat-header"><h3>TOTAL PAGAMENTOS</h3><i class="bi bi-cash-stack"></i></div><div class="stat-value" id="totalPagamentos">0</div><div class="stat-footer">Transações realizadas</div></div>
        <div class="stat-card"><div class="stat-header"><h3>VALOR TOTAL</h3><i class="bi bi-graph-up"></i></div><div class="stat-value" id="valorTotal" style="font-size: 1.2rem;">0 MZN</div><div class="stat-footer">Montante processado</div></div>
        <div class="stat-card"><div class="stat-header"><h3>MAIS USADO</h3><i class="bi bi-trophy"></i></div><div class="stat-value" id="maisUsado" style="font-size: 1.2rem;">-</div><div class="stat-footer">Últimos 30 dias</div></div>
    </div>

    <div class="table-section">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
            <h3><i class="bi bi-list-ul"></i> Métodos de Pagamento</h3>
            <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalMetodo"><i class="bi bi-plus-lg"></i> Novo Método</button>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Método</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="metodosTableBody">
                    <tr><td colspan="2" class="text-center py-4"><div class="spinner-border text-success"></div></td></tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer"><i class="bi bi-database"></i> Tabela: metodo_pagamento · Gestão de métodos de pagamento do sistema</div>
</div>

<!-- MODAL: Novo/Editar Método -->
<div class="modal fade modal-custom" id="modalMetodo" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-credit-card"></i> Método de Pagamento</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formMetodo">
                    <input type="hidden" id="editId" value="0">
                    <div class="mb-3"><label class="form-label">Nome do Método <span class="text-danger">*</span></label><input type="text" class="form-control form-control-custom" id="nomeMetodo" required placeholder="Ex: Dinheiro, POS, M-Pesa, Transferência Bancária"></div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Salvar Método</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let currentPage = 1, rowsPerPage = 5, totalMetodos = [];

    function showAlert(type, msg) {
        Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false });
    }

    function escapeHtml(s) {
        if (!s) return "";
        return String(s).replace(/[&<>]/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m;
        });
    }

    function carregarMetodos() {
        $.ajax({
            url: contextPath + '/Financeiro/metodos-pagamento/listar',
            method: 'GET',
            dataType: 'json',
            success: function(d) {
                totalMetodos = d;
                renderizarTabela();
                atualizarStats();
            },
            error: function() {
                $('#metodosTableBody').html('<tr><td colspan="2" class="text-center text-danger py-4">❌ Erro ao carregar dados</td></tr>');
            }
        });
    }

    function atualizarStats() {
        var total = totalMetodos.length;
        $('#totalMetodos').text(total);

        // Buscar total de pagamentos
        $.ajax({
            url: contextPath + '/Financeiro/pagamentos/stats',
            method: 'GET',
            dataType: 'json',
            success: function(d) {
                $('#totalPagamentos').text(d.total_pagamentos || 0);
                var valorTotal = (d.total_arrecadado || 0).toLocaleString('pt-MZ');
                $('#valorTotal').text(valorTotal + ' MZN');
            },
            error: function() {
                $('#totalPagamentos').text(0);
                $('#valorTotal').text('0 MZN');
            }
        });

        // Buscar método mais usado
        $.ajax({
            url: contextPath + '/Financeiro/metodos-pagamento/mais-usado',
            method: 'GET',
            dataType: 'json',
            success: function(d) {
                $('#maisUsado').html('<i class="bi bi-star-fill" style="color: #F39C12;"></i> ' + (d.nome || '-'));
            },
            error: function() {
                $('#maisUsado').text('-');
            }
        });
    }

    function renderizarTabela() {
        var totalPages = Math.ceil(totalMetodos.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        var start = (currentPage - 1) * rowsPerPage;
        var paginated = totalMetodos.slice(start, start + rowsPerPage);
        var tbody = $('#metodosTableBody');
        tbody.empty();

        if (paginated.length === 0) {
            tbody.html('<tr><td colspan="2" class="text-center py-4">Nenhum método encontrado</td></tr>');
            return;
        }

        for (var i = 0; i < paginated.length; i++) {
            var m = paginated[i];
            tbody.append(
                '<tr>' +
                    '<td><strong>' + escapeHtml(m.nome_metodo || '-') + '</strong></td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" data-id="' + (m.id_metodo_pagamento || 0) + '" data-nome="' + escapeHtml(m.nome_metodo || '') + '" title="Editar"><i class="bi bi-pencil"></i></button>' +
                    '</td>' +
                '</tr>'
            );
        }

        $('.action-btn.edit').off('click').on('click', function() {
            editarMetodo($(this).data('id'), $(this).data('nome'));
        });

        renderizarPaginacao(totalPages);
    }

    function renderizarPaginacao(totalPages) {
        var html = '';
        if (currentPage > 1) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage - 1) + ')">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            html += '<li class="page-item ' + (i === currentPage ? 'active' : '') + '"><a class="page-link" href="#" onclick="mudarPagina(' + i + ')">' + i + '</a></li>';
        }
        if (currentPage < totalPages) html += '<li class="page-item"><a class="page-link" href="#" onclick="mudarPagina(' + (currentPage + 1) + ')">»</a></li>';
        $('#pagination').html(html);
    }

    function mudarPagina(page) {
        currentPage = page;
        renderizarTabela();
        return false;
    }

    function editarMetodo(id, nome) {
        $('#editId').val(id);
        $('#nomeMetodo').val(nome);
        $('#modalMetodo .modal-title').html('<i class="bi bi-pencil-square"></i> Editar Método');
        new bootstrap.Modal(document.getElementById('modalMetodo')).show();
    }

    $('#formMetodo').on('submit', function(e) {
        e.preventDefault();
        var id = $('#editId').val() || 0;
        var dados = {
            id_metodo_pagamento: parseInt(id),
            nome_metodo: $('#nomeMetodo').val().trim()
        };

        if (!dados.nome_metodo) {
            showAlert('error', 'Informe o nome do método de pagamento');
            return;
        }

        var btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true).text('Salvando...');

        $.ajax({
            url: contextPath + '/Financeiro/metodos-pagamento/salvar',
            method: 'POST',
            data: dados,
            dataType: 'json',
            success: function(r) {
                btn.prop('disabled', false).text('Salvar Método');
                if (r && r.success) {
                    bootstrap.Modal.getInstance(document.getElementById('modalMetodo')).hide();
                    $('#formMetodo')[0].reset();
                    $('#editId').val("0");
                    $('#modalMetodo .modal-title').html('<i class="bi bi-credit-card"></i> Método de Pagamento');
                    carregarMetodos();
                    showAlert('success', id == 0 ? 'Método criado com sucesso!' : 'Método atualizado com sucesso!');
                } else {
                    showAlert('error', r.message || 'Erro ao salvar método');
                }
            },
            error: function() {
                btn.prop('disabled', false).text('Salvar Método');
                showAlert('error', 'Erro ao salvar método');
            }
        });
    });

    $('#modalMetodo').on('hidden.bs.modal', function() {
        $('#formMetodo')[0].reset();
        $('#editId').val("0");
        $('#modalMetodo .modal-title').html('<i class="bi bi-credit-card"></i> Método de Pagamento');
    });

    function updateClock() {
        var now = new Date();
        $('#horaAtual').html(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' }));
    }
    setInterval(updateClock, 1000);
    updateClock();

    carregarMetodos();
</script>
</body>
</html>