<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Extrato Financeiro · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .btn-primary-custom { background: #2ECC71; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: white; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #1B2B3C; color: #2ECC71; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #2ECC71; color: #2ECC71; }
        .btn-export { background: transparent; border: 1px solid #E2E8F0; padding: 6px 12px; border-radius: 30px; font-size: 0.75rem; transition: all 0.2s; cursor: pointer; }
        .btn-export:hover { border-color: #2ECC71; color: #2ECC71; background: #E8F5E9; }

        .filters-bar { background: white; border-radius: 20px; padding: 16px 24px; margin-bottom: 24px; border: 1px solid #E2E8F0; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; justify-content: space-between; }
        .date-range { display: flex; align-items: center; gap: 10px; }
        .date-range input { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2E8F0; background: white; width: 140px; }
        .filter-select { padding: 8px 16px; border-radius: 40px; border: 1px solid #E2E8F0; background: white; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; transition: all 0.3s ease; border: 1px solid #E2E8F0; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #2ECC71; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.6rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }
        .stat-footer { font-size: 0.7rem; color: #7F8C8D; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #2ECC71; }
        .chart-container { position: relative; height: 170px; width: 100%; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }

        /* Tabela responsiva e organizada */
        .table-responsive { border-radius: 16px; overflow-x: auto; }
        .table { margin: 0; font-size: 0.8rem; width: 100%; border-collapse: collapse; }
        .table thead th {
            border-bottom: 2px solid #2ECC71;
            color: #1B2B3C;
            font-weight: 600;
            padding: 14px 12px;
            background: #F8F9FA;
            white-space: nowrap;
        }
        .table tbody td {
            padding: 12px;
            vertical-align: middle;
            border-bottom: 1px solid #E2E8F0;
        }
        .table tbody tr:hover { background: #F8F9FA; }

        /* Colunas com largura fixa para melhor visualização */
        .table th:nth-child(1), .table td:nth-child(1) { width: 110px; white-space: nowrap; }
        .table th:nth-child(2), .table td:nth-child(2) { width: 35%; }
        .table th:nth-child(3), .table td:nth-child(3) { width: 15%; }
        .table th:nth-child(4), .table td:nth-child(4) { width: 100px; text-align: center; }
        .table th:nth-child(5), .table td:nth-child(5) { width: 120px; text-align: right; }
        .table th:nth-child(6), .table td:nth-child(6) { width: 120px; text-align: right; }

        .badge-tipo {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 600;
            text-align: center;
            min-width: 75px;
        }
        .badge-tipo.receita { background: #E8F5E9; color: #2E7D32; }
        .badge-tipo.despesa { background: #FFEBEE; color: #E74C3C; }

        .valor-positivo { color: #2E7D32; font-weight: 600; }
        .valor-negativo { color: #E74C3C; font-weight: 600; }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        @media print {
            .sidebar, .topbar, .filters-bar, .pagination, .footer, .action-buttons, .btn, .charts-grid { display: none !important; }
            .main-wrapper { margin-left: 0 !important; padding: 0 !important; }
            .stats-grid, .table-section { box-shadow: none; border: 1px solid #ddd; }
            .table thead th { background: #f0f0f0 !important; }
            .badge-tipo { border: 1px solid #ddd; }
        }
        @media (max-width: 1200px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .charts-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
    </ul>

    <div class="menu-section">RELATÓRIOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area"><i class="bi bi-calculator-fill"></i><div class="logo-text">Hotelaria · Financeiro<span>Extrato Financeiro</span></div></div>
        <div class="right-area"><div class="date-time"><div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div><div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div></div></div>
    </div>

    <div class="filters-bar">
        <div class="date-range">
            <i class="bi bi-calendar-range" style="color: #2ECC71;"></i>
            <input type="text" id="dataInicio" placeholder="Data inicial">
            <span>até</span>
            <input type="text" id="dataFim" placeholder="Data final">
        </div>
        <div>
            <select class="filter-select" id="tipoFilter">
                <option value="">Todos os tipos</option>
                <option value="receita">📈 Receitas</option>
                <option value="despesa">📉 Despesas</option>
            </select>
            <select class="filter-select" id="categoriaFilter">
                <option value="">Todas categorias</option>
                <option value="Hospedagem">🏨 Hospedagem</option>
                <option value="Alimentação">🍽️ Alimentação</option>
                <option value="Serviços">⚙️ Serviços</option>
                <option value="Salários">👥 Salários</option>
                <option value="Manutenção">🔧 Manutenção</option>
                <option value="Utilidades">💡 Utilidades</option>
            </select>
        </div>
        <div>
            <button class="btn-primary-custom" id="aplicarFiltros"><i class="bi bi-funnel"></i> Aplicar</button>
            <button class="btn-export" onclick="exportExtratoCSV()"><i class="bi bi-filetype-csv"></i> CSV</button>
            <button class="btn-export" onclick="window.print()"><i class="bi bi-printer"></i> Imprimir</button>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>SALDO INICIAL</h3><i class="bi bi-wallet2"></i></div><div class="stat-value" id="saldoInicial">0 MZN</div><div class="stat-footer">Início do período</div></div>
        <div class="stat-card"><div class="stat-header"><h3>RECEITAS</h3><i class="bi bi-arrow-up-circle"></i></div><div class="stat-value" id="totalReceitas">0 MZN</div><div class="stat-footer"><i class="bi bi-graph-up trend-up"></i> Total de entradas</div></div>
        <div class="stat-card"><div class="stat-header"><h3>DESPESAS</h3><i class="bi bi-arrow-down-circle"></i></div><div class="stat-value" id="totalDespesas">0 MZN</div><div class="stat-footer"><i class="bi bi-graph-down trend-down"></i> Total de saídas</div></div>
        <div class="stat-card"><div class="stat-header"><h3>SALDO FINAL</h3><i class="bi bi-calculator"></i></div><div class="stat-value" id="saldoFinal">0 MZN</div><div class="stat-footer">Resultado do período</div></div>
    </div>

    <div class="charts-grid">
        <div class="chart-box"><h3><i class="bi bi-pie-chart"></i> Receitas vs Despesas</h3><div class="chart-container"><canvas id="receitaDespesaChart"></canvas></div></div>
        <div class="chart-box"><h3><i class="bi bi-bar-chart"></i> Evolução Diária</h3><div class="chart-container"><canvas id="evolucaoDiariaChart"></canvas></div></div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-list-ul"></i> Movimentações Financeiras</h3>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th><i class="bi bi-calendar3"></i> Data</th>
                        <th><i class="bi bi-file-text"></i> Descrição</th>
                        <th><i class="bi bi-tag"></i> Categoria</th>
                        <th><i class="bi bi-info-circle"></i> Tipo</th>
                        <th><i class="bi bi-cash-stack"></i> Valor</th>
                        <th><i class="bi bi-wallet2"></i> Saldo</th>
                    </tr>
                </thead>
                <tbody id="extratoTableBody">
                    <tr><td colspan="6" class="text-center py-5">
                        <div class="spinner-border text-success" role="status">
                            <span class="visually-hidden">Carregando...</span>
                        </div>
                        <p class="mt-2 text-muted">Carregando movimentações...</p>
                    </td></tr>
                </tbody>
                <tfoot id="extratoTableFooter" style="display: none;">
                    <tr style="background: #FFF8E1; font-weight: 600; border-top: 2px solid #2ECC71;">
                        <td colspan="4" style="text-align: right;"><strong>TOTAIS:</strong></td>
                        <td id="footerTotalReceitas" style="text-align: right; color: #2E7D32;">0 MZN</td>
                        <td id="footerSaldoFinal" style="text-align: right;">0 MZN</td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="text-center text-muted mt-3" id="emptyMessage" style="display: none;">
            <i class="bi bi-inbox" style="font-size: 2rem;"></i>
            <p>Nenhuma movimentação encontrada no período selecionado.</p>
        </div>
    </div>

    <div class="footer"><i class="bi bi-database"></i> Sistema Hotelaria · Módulo Financeiro · Extrato de Movimentações</div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';
    let saldoAnterior = 0;
    let todasMovimentacoes = [];
    let graficos = {};

    function formatMoney(v) {
        if (v === undefined || v === null || isNaN(v)) return "0 MZN";
        return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function formatDateTime(dateStr) {
        if (!dateStr) return "-";
        return dateStr.replace('T', ' ').substring(0, 16);
    }

    function formatDateBR(dateStr) {
        if (!dateStr) return "-";
        var parts = dateStr.split("-");
        if (parts.length === 3) return parts[2] + "/" + parts[1] + "/" + parts[0];
        return dateStr;
    }

    function showAlert(type, msg) {
        Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: msg, timer: 3000, showConfirmButton: false });
    }

    function escapeHtml(s) {
        if (!s) return "";
        return s.replace(/[&<>]/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m;
        });
    }

    function carregarExtrato() {
        var dataInicio = $('#dataInicio').val();
        var dataFim = $('#dataFim').val();

        $('#extratoTableBody').html('<tr><td colspan="6" class="text-center py-5"><div class="spinner-border text-success"></div><p class="mt-2">Carregando...</p></td></tr>');

        $.ajax({
            url: contextPath + '/Financeiro/extrato/listar',
            method: 'GET',
            data: { data_inicio: dataInicio, data_fim: dataFim },
            dataType: 'json',
            success: function(result) {
                todasMovimentacoes = result.movimentos || [];
                saldoAnterior = result.saldo_anterior || 0;
                aplicarFiltros();
                atualizarStats();
                carregarGraficos();
            },
            error: function() {
                $('#extratoTableBody').html('<td><td colspan="6" class="text-center text-danger py-4"><i class="bi bi-exclamation-triangle"></i> Erro ao carregar dados</td></tr>');
            }
        });
    }

    function aplicarFiltros() {
        var tipo = $('#tipoFilter').val();
        var categoria = $('#categoriaFilter').val();

        var filtrados = todasMovimentacoes.filter(function(m) {
            var matchTipo = !tipo || m.tipo === tipo;
            var matchCategoria = !categoria || m.categoria === categoria;
            return matchTipo && matchCategoria;
        });

        var saldo = saldoAnterior;
        var movComSaldo = [];

        // Ordenar por data (mais recente primeiro)
        filtrados.sort(function(a, b) {
            return (a.data || '').localeCompare(b.data || '') * -1;
        });

        for (var i = filtrados.length - 1; i >= 0; i--) {
            var m = filtrados[i];
            if (m.tipo === 'receita') saldo += m.valor;
            else saldo -= m.valor;
            movComSaldo.unshift({
                data: m.data,
                descricao: m.descricao,
                categoria: m.categoria,
                tipo: m.tipo,
                valor: m.valor,
                saldo: saldo
            });
        }

        renderizarTabela(movComSaldo);
    }

    function renderizarTabela(movimentos) {
        var tbody = $('#extratoTableBody');
        tbody.empty();

        if (movimentos.length === 0) {
            $('#emptyMessage').show();
            $('#extratoTableFooter').hide();
            tbody.html('<tr><td colspan="6" class="text-center py-5"><i class="bi bi-inbox" style="font-size: 2rem; color: #BDC3C7;"></i><p class="mt-2 text-muted">Nenhuma movimentação encontrada</p></td></tr>');
            return;
        }

        $('#emptyMessage').hide();
        $('#extratoTableFooter').show();

        var totalReceitas = 0;
        var ultimoSaldo = 0;

        $.each(movimentos, function(i, m) {
            var tipoClasse = m.tipo === 'receita' ? 'valor-positivo' : 'valor-negativo';
            var valorFormatado = (m.tipo === 'receita' ? '+' : '-') + ' ' + formatMoney(m.valor);
            var badgeClasse = m.tipo === 'receita' ? 'receita' : 'despesa';
            var badgeTexto = m.tipo === 'receita' ? 'RECEITA' : 'DESPESA';

            if (m.tipo === 'receita') totalReceitas += m.valor;
            ultimoSaldo = m.saldo;

            var row = $('<tr>' +
                '<td><span class="text-nowrap"><i class="bi bi-calendar3 me-1 text-muted"></i> ' + formatDateTime(m.data) + '</span></td>' +
                '<td><strong>' + escapeHtml(m.descricao || '-') + '</strong></td>' +
                '<td><span class="text-muted">' + escapeHtml(m.categoria || '-') + '</span></td>' +
                '<td><span class="badge-tipo ' + badgeClasse + '">' + badgeTexto + '</span></td>' +
                '<td class="' + tipoClasse + ' text-end"><strong>' + valorFormatado + '</strong></td>' +
                '<td class="text-end"><strong>' + formatMoney(m.saldo) + '</strong></td>' +
            '<table>');
            tbody.append(row);
        });

        $('#footerTotalReceitas').html(formatMoney(totalReceitas));
        $('#footerSaldoFinal').html(formatMoney(ultimoSaldo));
    }

    function atualizarStats() {
        var totalReceitas = 0, totalDespesas = 0;
        $.each(todasMovimentacoes, function(i, m) {
            if (m.tipo === 'receita') totalReceitas += m.valor;
            else totalDespesas += m.valor;
        });
        var saldoFinal = saldoAnterior + totalReceitas - totalDespesas;

        $('#saldoInicial').html(formatMoney(saldoAnterior));
        $('#totalReceitas').html(formatMoney(totalReceitas));
        $('#totalDespesas').html(formatMoney(totalDespesas));
        $('#saldoFinal').html(formatMoney(saldoFinal));

        // Cor do saldo final
        var saldoFinalColor = saldoFinal >= 0 ? '#2E7D32' : '#E74C3C';
        $('#saldoFinal').css('color', saldoFinalColor);
    }

    function carregarGraficos() {
        var totalReceitas = 0, totalDespesas = 0;
        $.each(todasMovimentacoes, function(i, m) {
            if (m.tipo === 'receita') totalReceitas += m.valor;
            else totalDespesas += m.valor;
        });

        if (graficos.receitaDespesa) graficos.receitaDespesa.destroy();
        graficos.receitaDespesa = new Chart(document.getElementById('receitaDespesaChart'), {
            type: 'doughnut',
            data: {
                labels: ['Receitas', 'Despesas'],
                datasets: [{
                    data: [totalReceitas, totalDespesas],
                    backgroundColor: ['#2ECC71', '#E74C3C'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { font: { size: 10 } } },
                    tooltip: { callbacks: { label: function(ctx) { return ctx.label + ': ' + formatMoney(ctx.raw); } } }
                },
                cutout: '60%'
            }
        });

        var diasMap = {};
        $.each(todasMovimentacoes, function(i, m) {
            var dia = m.data ? m.data.split(' ')[0] : null;
            if (dia) {
                if (!diasMap[dia]) diasMap[dia] = { receita: 0, despesa: 0 };
                if (m.tipo === 'receita') diasMap[dia].receita += m.valor;
                else diasMap[dia].despesa += m.valor;
            }
        });

        var datas = Object.keys(diasMap).sort();
        var receitasDiarias = datas.map(function(d) { return diasMap[d].receita; });
        var despesasDiarias = datas.map(function(d) { return diasMap[d].despesa; });

        if (graficos.evolucaoDiaria) graficos.evolucaoDiaria.destroy();
        graficos.evolucaoDiaria = new Chart(document.getElementById('evolucaoDiariaChart'), {
            type: 'bar',
            data: {
                labels: datas.map(function(d) { return formatDateBR(d); }),
                datasets: [
                    { label: 'Receitas', data: receitasDiarias, backgroundColor: '#2ECC71', borderRadius: 6, barPercentage: 0.7 },
                    { label: 'Despesas', data: despesasDiarias, backgroundColor: '#E74C3C', borderRadius: 6, barPercentage: 0.7 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(v) { return formatMoney(v); }
                        }
                    },
                    x: { ticks: { maxRotation: 45, minRotation: 45, font: { size: 9 } } }
                },
                plugins: { tooltip: { callbacks: { label: function(ctx) { return ctx.dataset.label + ': ' + formatMoney(ctx.raw); } } } }
            }
        });
    }

    function exportExtratoCSV() {
        var headers = ['Data', 'Descrição', 'Categoria', 'Tipo', 'Valor'];
        var csvRows = [headers.join(',')];

        for (var i = 0; i < todasMovimentacoes.length; i++) {
            var m = todasMovimentacoes[i];
            csvRows.push([
                '"' + m.data + '"',
                '"' + (m.descricao || '').replace(/"/g, '""') + '"',
                '"' + (m.categoria || '') + '"',
                m.tipo,
                m.valor
            ].join(','));
        }

        var blob = new Blob(["\uFEFF" + csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'extrato_financeiro_' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        showAlert('success', 'Extrato exportado com sucesso!');
    }

    $('#aplicarFiltros').on('click', function() {
        carregarExtrato();
        showAlert('success', 'Filtros aplicados!');
    });

    $('#tipoFilter, #categoriaFilter').on('change', function() {
        aplicarFiltros();
    });

    flatpickr("#dataInicio", { dateFormat: "Y-m-d", locale: "pt", defaultDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1) });
    flatpickr("#dataFim", { dateFormat: "Y-m-d", locale: "pt", defaultDate: new Date() });

    function updateClock() {
        var now = new Date();
        $('#horaAtual').html(now.toLocaleTimeString('pt-PT'));
        $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' }));
    }
    setInterval(updateClock, 1000);
    updateClock();

    carregarExtrato();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>