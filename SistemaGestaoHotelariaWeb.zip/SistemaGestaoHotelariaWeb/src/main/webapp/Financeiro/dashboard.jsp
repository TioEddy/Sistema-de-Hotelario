<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Financeiro · Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #ECF0F1; height: 100vh; overflow: hidden; }

        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100vh; background: #1B2B3C; color: #D5DEE5; overflow-y: auto; z-index: 1000; }
        .sidebar .profile { text-align: center; padding: 28px 20px 25px; background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(46,204,113,0.2); }
        .sidebar .profile img { width: 85px; height: 85px; border-radius: 50%; border: 3px solid #2ECC71; margin-bottom: 12px; object-fit: cover; }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; color: #2ECC71; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.7; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li { padding: 10px 16px; margin: 4px 0; border-radius: 12px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.25s ease; font-size: 0.85rem; }
        .sidebar li i { font-size: 1.1rem; width: 24px; color: #2ECC71; }
        .sidebar li:hover { background: rgba(46,204,113,0.12); transform: translateX(4px); }
        .sidebar li.active { background: #2ECC71; color: #1B2B3C; }
        .sidebar li.active i { color: #1B2B3C; }
        .sidebar li a { color: #D5DEE5; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #1B2B3C; font-weight: 500; }
        .sidebar .menu-section { color: #2ECC71; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 2px; padding: 20px 20px 8px; font-weight: 600; }

        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }

        .topbar { display: flex; justify-content: space-between; align-items: center; background: white; border-radius: 20px; padding: 12px 24px; margin-bottom: 28px; border: 1px solid #E2E8F0; }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #2ECC71; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #1B2B3C; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #7F8C8D; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #7F8C8D; }
        .time { font-size: 0.9rem; font-weight: 600; color: #1B2B3C; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card { background: white; border-radius: 20px; padding: 18px 16px; transition: all 0.3s ease; border: 1px solid #E2E8F0; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); border-color: #2ECC71; }
        .stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #7F8C8D; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #2ECC71; }
        .stat-value { font-size: 1.6rem; font-weight: 700; color: #1B2B3C; margin-bottom: 4px; }
        .stat-footer { font-size: 0.7rem; color: #7F8C8D; }

        .charts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #2ECC71; }
        .chart-container { position: relative; height: 170px; width: 100%; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E2E8F0; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #2ECC71; color: #1B2B3C; font-weight: 600; padding: 10px 6px; }

        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 500; }
        .badge-status.pago { background: #E8F5E9; color: #2E7D32; }
        .badge-status.pendente { background: #FFF8E1; color: #F57C00; }
        .badge-status.parcial { background: #E3F2FD; color: #1976D2; }

        .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 20px; }
        .info-card { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E2E8F0; cursor: pointer; }
        .info-card:hover { border-color: #2ECC71; }
        .info-card h4 { font-size: 0.85rem; font-weight: 600; color: #1B2B3C; margin-bottom: 14px; }
        .info-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #E2E8F0; }

        .footer { text-align: center; padding: 16px; color: #7F8C8D; font-size: 0.7rem; }

        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .info-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.6rem;"><i class="bi bi-shield-check"></i> Perfil: ${sessionScope.usuarioLogado.nomePerfil}</p>
    </div>

    <div class="menu-section">FINANCEIRO</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Financeiro/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/pagamentos"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/faturas"><i class="bi bi-receipt"></i> Faturas</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/contas-receber"><i class="bi bi-credit-card"></i> Contas a Receber</a></li>
    </ul>

    <div class="menu-section">RELATÓRIOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/relatorio-mensal"><i class="bi bi-bar-chart"></i> Relatório Mensal</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/extrato"><i class="bi bi-graph-up"></i> Extrato Financeiro</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/balancete"><i class="bi bi-file-spreadsheet"></i> Balancete</a></li>
    </ul>

    <div class="menu-section">CONFIGURAÇÕES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Financeiro/metodos-pagamento"><i class="bi bi-gear"></i> Métodos Pagamento</a></li>
        <li><a href="${pageContext.request.contextPath}/Financeiro/taxas"><i class="bi bi-percent"></i> Taxas/IVA</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-calculator-fill"></i>
            <div class="logo-text">Hotelaria · Financeiro<span>Gestão Financeira</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Financeiro/relatorio-mensal'">
            <div class="stat-header"><h3>FATURAMENTO MÊS</h3><i class="bi bi-cash-stack"></i></div>
            <div class="stat-value" id="faturamentoMes">0 MZN</div>
            <div class="stat-footer" id="faturamentoMesFooter"></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Financeiro/contas-receber'">
            <div class="stat-header"><h3>CONTAS A RECEBER</h3><i class="bi bi-credit-card"></i></div>
            <div class="stat-value" id="contasReceber">0 MZN</div>
            <div class="stat-footer" id="contasReceberFooter"></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Financeiro/pagamentos'">
            <div class="stat-header"><h3>TOTAL PAGO (MÊS)</h3><i class="bi bi-check-circle"></i></div>
            <div class="stat-value" id="totalPagoMes">0 MZN</div>
            <div class="stat-footer" id="totalPagoMesFooter"></div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Financeiro/relatorio-mensal'">
            <div class="stat-header"><h3>DESPESAS MÊS</h3><i class="bi bi-box-seam"></i></div>
            <div class="stat-value" id="despesasMes">0 MZN</div>
            <div class="stat-footer" id="despesasMesFooter"></div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Pagamentos por Método</h3>
            <div class="chart-container"><canvas id="metodosPagamentoChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Faturação Mensal</h3>
            <div class="chart-container"><canvas id="faturacaoMensalChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-graph-up"></i> Receita vs Despesa</h3>
            <div class="chart-container"><canvas id="receitaDespesaChart"></canvas></div>
        </div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-clock-history"></i> Últimos Pagamentos</h3>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Data</th><th>Cliente</th><th>Método</th><th>Valor</th><th>Status</th></tr></thead>
                <tbody id="ultimosPagamentos"></tbody>
            </table>
        </div>
    </div>

    <div class="footer"><p><i class="bi bi-c-circle"></i> <span id="anoAtual"></span> Sistema de Gestão Hoteleira. Todos os direitos reservados.</p></div>
</div>

<script>
    const contextPath = '${pageContext.request.contextPath}';

    function formatMoney(v) { if (v === undefined || v === null || isNaN(v)) return "0 MZN"; return Number(v).toLocaleString('pt-MZ', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN"; }

    function loadStats() {
        $.ajax({ url: contextPath + '/Financeiro/stats', method: 'GET', dataType: 'json',
            success: function(d) {
                $('#faturamentoMes').html(formatMoney(d.faturamento_mes || 0));
                $('#contasReceber').html(formatMoney(d.contas_receber || 0));
                $('#totalPagoMes').html(formatMoney(d.total_pago_mes || 0));
                $('#despesasMes').html(formatMoney(d.despesas_mes || 0));

                $('#faturamentoMesFooter').html(d.faturas_pendentes ? d.faturas_pendentes + ' faturas pendentes' : '');
                $('#contasReceberFooter').html(d.faturas_pendentes ? d.faturas_pendentes + ' faturas em aberto' : '');
            }, error: function() { console.error('Erro ao carregar stats'); }
        });
    }

    function loadUltimosPagamentos() {
        $.ajax({ url: contextPath + '/Financeiro/pagamentos/listar', method: 'GET', dataType: 'json',
            success: function(d) {
                var tbody = $('#ultimosPagamentos');
                tbody.empty();
                var recentes = d.slice(0, 5);
                $.each(recentes, function(i, p) {
                    var statusClass = p.estado_pagamento === 'PAGO' ? 'pago' : (p.estado_pagamento === 'PARCIAL' ? 'parcial' : 'pendente');
                    tbody.append('<tr><td>' + p.data_pagamento + '</td><td>' + (p.cliente_nome || '-') + '</td><td>' + (p.metodo_nome || '-') + '</td><td>' + formatMoney(p.valor) + '</td><td><span class="badge-status ' + statusClass + '">' + p.estado_pagamento + '</span></td></tr>');
                });
                if (recentes.length === 0) tbody.html('<tr><td colspan="5" class="text-center">Nenhum pagamento registado</td></tr>');
            }, error: function() { console.error('Erro ao carregar pagamentos'); }
        });
    }

    function loadGraficos() {
        $.ajax({ url: contextPath + '/Financeiro/graficos', method: 'GET', dataType: 'json',
            success: function(d) {
                // Gráfico de métodos de pagamento
                if (d.metodos_pagamento && d.metodos_pagamento.length > 0) {
                    var labels = [], data = [];
                    $.each(d.metodos_pagamento, function(i, m) {
                        labels.push(m.nome);
                        data.push(m.valor_total);
                    });
                    new Chart(document.getElementById('metodosPagamentoChart'), {
                        type: 'doughnut',
                        data: { labels: labels, datasets: [{ data: data, backgroundColor: ['#1B2B3C', '#2ECC71', '#3498DB', '#F39C12', '#9B59B6'], borderWidth: 0 }] },
                        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
                    });
                }

                // Gráfico de faturação mensal
                if (d.faturacao_mensal && d.faturacao_mensal.length > 0) {
                    var labels2 = [], data2 = [];
                    $.each(d.faturacao_mensal, function(i, f) {
                        labels2.push(f.mes);
                        data2.push(f.total);
                    });
                    new Chart(document.getElementById('faturacaoMensalChart'), {
                        type: 'line',
                        data: { labels: labels2, datasets: [{ label: 'Faturação (MZN)', data: data2, borderColor: '#2ECC71', backgroundColor: 'rgba(46, 204, 113, 0.05)', tension: 0.3, fill: true, pointBackgroundColor: '#2ECC71' }] },
                        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return v.toLocaleString(); } } } } }
                    });
                }

                // Gráfico de receita vs despesa (dados dos últimos 6 meses)
                if (d.faturacao_mensal && d.faturacao_mensal.length > 0) {
                    var labels3 = [], receitas = [], despesas = [];
                    $.each(d.faturacao_mensal, function(i, f) {
                        labels3.push(f.mes);
                        receitas.push(f.total);
                        despesas.push(f.total * 0.3); // Simulação - ajustar conforme dados reais
                    });
                    new Chart(document.getElementById('receitaDespesaChart'), {
                        type: 'bar',
                        data: { labels: labels3, datasets: [{ label: 'Receita', data: receitas, backgroundColor: '#2ECC71', borderRadius: 6 }, { label: 'Despesa', data: despesas, backgroundColor: '#E74C3C', borderRadius: 6 }] },
                        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return v.toLocaleString(); } } } } }
                    });
                }
            }, error: function() { console.error('Erro ao carregar gráficos'); }
        });
    }

    function updateClock() { var now = new Date(); $('#horaAtual').html(now.toLocaleTimeString('pt-PT')); $('#dataAtual').html(now.toLocaleDateString('pt-PT', { day:'2-digit', month:'long', year:'numeric' })); $('#anoAtual').html(now.getFullYear()); }
    setInterval(updateClock, 1000); updateClock();

    loadStats();
    loadUltimosPagamentos();
    loadGraficos();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>