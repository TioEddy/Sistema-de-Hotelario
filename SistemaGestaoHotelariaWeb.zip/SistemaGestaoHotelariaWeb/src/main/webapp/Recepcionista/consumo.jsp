<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consumo de Serviços · Recepção</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #2C5F8A;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 193, 7, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFC107;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
        .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFC107; color: #2C5F8A; }
        .sidebar li.active i { color: #2C5F8A; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
        .sidebar .menu-section {
            color: #FFC107;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #FFC107; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #FFC107; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 12px 20px;
            margin-bottom: 20px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #F9F6EF;
            padding: 6px 14px;
            border-radius: 40px;
        }
        .search-box input { border: none; background: transparent; outline: none; width: 220px; font-size: 0.8rem; }
        .filter-select {
            padding: 6px 14px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.8rem;
            cursor: pointer;
        }
        .filter-select:hover { border-color: #FFC107; }

        .btn-primary-custom {
            background: #FFC107;
            border: none;
            padding: 8px 20px;
            border-radius: 40px;
            font-weight: 600;
            color: #2C5F8A;
            transition: all 0.2s;
            font-size: 0.85rem;
        }
        .btn-primary-custom:hover { background: #2C5F8A; color: #FFC107; transform: translateY(-2px); }
        .btn-outline-custom {
            background: transparent;
            border: 1px solid #E8DFC8;
            padding: 6px 16px;
            border-radius: 40px;
            font-weight: 500;
            color: #8B9A87;
            font-size: 0.8rem;
        }
        .btn-outline-custom:hover { border-color: #FFC107; color: #FFC107; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }
        .table-section h3 i { color: #FFC107; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFC107; color: #2C5F8A; font-weight: 600; padding: 10px 6px; }

        .badge-servico {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-servico.Restaurante { background: #E8F5E9; color: #2E7D32; }
        .badge-servico.Mini-bar { background: #E3F2FD; color: #1976D2; }
        .badge-servico.SPA { background: #F3E5F5; color: #7B1FA2; }
        .badge-servico.Lavandaria { background: #FFF8E1; color: #F57C00; }
        .badge-servico.RoomService { background: #FCE4EC; color: #C2185B; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .action-btn.edit { color: #FFC107; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F9F6EF; transform: scale(1.1); }

        .pagination { margin-top: 16px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link {
            color: #2C5F8A;
            border-radius: 8px;
            padding: 6px 10px;
            text-decoration: none;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.75rem;
        }
        .page-item.active .page-link { background: #FFC107; border-color: #FFC107; color: #2C5F8A; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #2C5F8A; color: white; border-radius: 24px 24px 0 0; padding: 16px 20px; }
        .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E8DFC8; }
        .detail-label { width: 100px; font-weight: 600; color: #2C5F8A; }
        .detail-value { flex: 1; color: #8B9A87; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E8DFC8;
            padding: 8px 12px;
            font-size: 0.85rem;
        }
        .form-control-readonly { background-color: #F9F6EF; cursor: not-allowed; }

        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .filters-bar { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
    </div>

    <div class="menu-section">ATENDIMENTO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
    </ul>

    <div class="menu-section">CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Recepção<span>Consumo de Serviços</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>TOTAL CONSUMOS</h3><i class="bi bi-cup-straw"></i></div>
            <div class="stat-value" id="totalConsumos">0</div>
            <div class="stat-footer">Registros no sistema</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>FATURAÇÃO</h3><i class="bi bi-cash-stack"></i></div>
            <div class="stat-value" id="totalFaturado">0 MZN</div>
            <div class="stat-footer">Valor total consumido</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>HÓSPEDES ATIVOS</h3><i class="bi bi-people-fill"></i></div>
            <div class="stat-value" id="hospedesAtivos">0</div>
            <div class="stat-footer">Com consumo registrado</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>MAIS CONSUMIDO</h3><i class="bi bi-trophy"></i></div>
            <div class="stat-value" id="topServico" style="font-size: 1rem;">-</div>
            <div class="stat-footer">Serviço mais requisitado</div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Consumo por Serviço</h3>
            <div class="chart-container"><canvas id="servicosChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Consumo por Hóspede</h3>
            <div class="chart-container"><canvas id="hospedesChart"></canvas></div>
        </div>
    </div>

    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por hóspede ou serviço...">
        </div>
        <div>
            <select class="filter-select" id="servicoFilter">
                <option value="">Todos os serviços</option>
            </select>
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalConsumo">
            <i class="bi bi-plus-lg"></i> Novo Consumo
        </button>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-list-ul"></i> Registro de Consumos</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Data/Hora</th><th>Hóspede</th><th>Quarto</th><th>Serviço</th><th>Quantidade</th><th>Subtotal</th><th>Ações</th></tr>
                </thead>
                <tbody id="consumosTableBody">
                    <tr><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos
    </div>
</div>

<!-- MODAL: Novo/Editar Consumo -->
<div class="modal fade modal-custom" id="modalConsumo" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Novo Consumo</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formConsumo">
                    <input type="hidden" id="editId" value="">
                    <div class="mb-3">
                        <label class="form-label">Hóspede / Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaId" required>
                            <option value="">Selecione o hóspede</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Serviço <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="servicoId" required>
                            <option value="">Selecione o serviço</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Quantidade</label>
                        <input type="number" class="form-control form-control-custom" id="quantidade" value="1" min="1" max="99">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subtotal</label>
                        <input type="text" class="form-control form-control-custom form-control-readonly" id="subtotal" readonly>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Registrar Consumo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Consumo -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Consumo</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Data/Hora:</div><div class="detail-value" id="detData">-</div></div>
                <div class="detail-row"><div class="detail-label">Hóspede:</div><div class="detail-value" id="detHospede">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="detQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Serviço:</div><div class="detail-value" id="detServico">-</div></div>
                <div class="detail-row"><div class="detail-label">Quantidade:</div><div class="detail-value" id="detQuantidade">-</div></div>
                <div class="detail-row"><div class="detail-label">Preço Unit.:</div><div class="detail-value" id="detPreco">-</div></div>
                <div class="detail-row"><div class="detail-label">Subtotal:</div><div class="detail-value" id="detSubtotal">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                <button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let servicosChart = null;
    let hospedesChart = null;
    let currentPage = 1;
    let rowsPerPage = 6;
    let currentFilter = "";
    let currentServicoFilter = "";
    let consumos = [];

    function formatMoney(value) {
        if (value === undefined || value === null || isNaN(value)) return "0 MZN";
        return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function formatDateTime(dateTimeStr) {
        if (!dateTimeStr) return "";
        var parts = dateTimeStr.split(" ");
        if (parts.length === 2) {
            var dataParts = parts[0].split("-");
            var data = dataParts[2] + "/" + dataParts[1] + "/" + dataParts[0];
            var hora = parts[1].substring(0, 5);
            return data + " " + hora;
        }
        return dateTimeStr;
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function showAlert(type, message) {
        var alertDiv = document.createElement('div');
        alertDiv.className = 'position-fixed bottom-0 end-0 m-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.style.background = type === 'success' ? '#2E7D32' : '#D9534F';
        alertDiv.style.color = 'white';
        alertDiv.style.borderRadius = '12px';
        alertDiv.style.padding = '10px 18px';
        alertDiv.style.fontSize = '0.8rem';
        alertDiv.innerHTML = '<i class="bi bi-' + (type === 'success' ? 'check-circle' : 'exclamation-triangle') + '"></i> ' + message;
        document.body.appendChild(alertDiv);
        setTimeout(function() { alertDiv.remove(); }, 3000);
    }

    async function fetchAPI(endpoint, options) {
        options = options || {};
        try {
            var response = await fetch(contextPath + endpoint, options);
            if (!response.ok) throw new Error('Erro: ' + response.status);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            return null;
        }
    }

    async function carregarEstatisticas() {
        var data = await fetchAPI('/Recepcionista/api/consumo/estatisticas');
        if (data && data.success) {
            document.getElementById('totalConsumos').innerHTML = data.total_consumos || 0;
            document.getElementById('totalFaturado').innerHTML = formatMoney(data.total_faturado || 0);
            document.getElementById('hospedesAtivos').innerHTML = data.hospedes_ativos || 0;
            var topServicoNome = data.top_servico_nome || "-";
            var topServicoTotal = data.top_servico_total || 0;
            document.getElementById('topServico').innerHTML = topServicoNome !== "-" ? topServicoNome + " (" + topServicoTotal + ")" : "-";
        }
    }

    async function carregarConsumos() {
        var data = await fetchAPI('/Recepcionista/api/consumo/listar');
        if (data && data.length > 0) {
            consumos = data;
        } else {
            consumos = [];
        }
        renderTable();
        updateCharts();
    }

    async function carregarServicos() {
        var data = await fetchAPI('/Recepcionista/api/servico/listar');
        if (data && data.length > 0) {
            var select = document.getElementById('servicoId');
            select.innerHTML = '<option value="">Selecione o serviço</option>';
            for (var i = 0; i < data.length; i++) {
                select.innerHTML += '<option value="' + data[i].id_servico + '" data-preco="' + data[i].preco + '">' + escapeHtml(data[i].nome_servico) + ' - ' + formatMoney(data[i].preco) + '</option>';
            }
            var filterSelect = document.getElementById('servicoFilter');
            filterSelect.innerHTML = '<option value="">Todos os serviços</option>';
            for (var i = 0; i < data.length; i++) {
                filterSelect.innerHTML += '<option value="' + escapeHtml(data[i].nome_servico) + '">' + escapeHtml(data[i].nome_servico) + '</option>';
            }
        }
    }

    async function carregarHospedesSelect() {
        try {
            var data = await fetchAPI('/Recepcionista/api/hospede/lista');
            var select = document.getElementById('reservaId');

            if (data && data.length > 0) {
                select.innerHTML = '<option value="">Selecione o hóspede</option>';
                for (var i = 0; i < data.length; i++) {
                    select.innerHTML += '<option value="' + data[i].id_reserva + '">' +
                        escapeHtml(data[i].nome) + ' - Quarto ' + escapeHtml(data[i].quarto_num) + '</option>';
                }
            } else {
                // Fallback: buscar reservas da tabela consumo_servico
                select.innerHTML = '<option value="">Selecione o hóspede</option>';

                if (consumos && consumos.length > 0) {
                    var reservasUnicas = {};
                    for (var i = 0; i < consumos.length; i++) {
                        var item = consumos[i];
                        if (!reservasUnicas[item.id_reserva]) {
                            reservasUnicas[item.id_reserva] = {
                                id_reserva: item.id_reserva,
                                nome: item.hospede_nome,
                                quarto: item.quarto_num
                            };
                        }
                    }

                    for (var id in reservasUnicas) {
                        var h = reservasUnicas[id];
                        select.innerHTML += '<option value="' + h.id_reserva + '">' +
                            escapeHtml(h.nome) + ' - Quarto ' + escapeHtml(h.quarto) + '</option>';
                    }
                }
            }
        } catch (error) {
            console.error('Erro ao carregar hóspedes:', error);
        }
    }

    function updateCharts() {
        if (!consumos || consumos.length === 0) {
            if (servicosChart) servicosChart.destroy();
            if (hospedesChart) hospedesChart.destroy();
            return;
        }

        // Gráfico de consumo por serviço
        var servicoData = {};
        for (var i = 0; i < consumos.length; i++) {
            var servicoNome = consumos[i].servico_nome;
            if (!servicoData[servicoNome]) servicoData[servicoNome] = 0;
            servicoData[servicoNome] += consumos[i].subtotal;
        }

        var labels = Object.keys(servicoData);
        var data = Object.values(servicoData);
        var colors = ['#FFC107', '#2E7D32', '#1976D2', '#C2185B', '#F57C00', '#7B1FA2', '#009688'];

        var ctxServicos = document.getElementById('servicosChart').getContext('2d');
        if (servicosChart) servicosChart.destroy();
        if (labels.length > 0) {
            servicosChart = new Chart(ctxServicos, {
                type: 'doughnut',
                data: { labels: labels, datasets: [{ data: data, backgroundColor: colors.slice(0, labels.length), borderWidth: 0, borderRadius: 6 }] },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
            });
        }

        // Gráfico de consumo por hóspede
        var hospedeData = {};
        for (var i = 0; i < consumos.length; i++) {
            var hospedeNome = consumos[i].hospede_nome;
            if (!hospedeData[hospedeNome]) hospedeData[hospedeNome] = 0;
            hospedeData[hospedeNome] += consumos[i].subtotal;
        }

        var hospedeLabels = Object.keys(hospedeData);
        var hospedeValues = Object.values(hospedeData);

        var ctxHospedes = document.getElementById('hospedesChart').getContext('2d');
        if (hospedesChart) hospedesChart.destroy();
        if (hospedeLabels.length > 0) {
            hospedesChart = new Chart(ctxHospedes, {
                type: 'bar',
                data: { labels: hospedeLabels, datasets: [{ label: 'Valor Consumido (MZN)', data: hospedeValues, backgroundColor: '#FFC107', borderRadius: 6 }] },
                options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, grid: { color: '#E8DFC8' } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } }
            });
        }
    }

    function filterConsumos() {
        if (!consumos || consumos.length === 0) return [];
        var result = [];
        for (var i = 0; i < consumos.length; i++) {
            var c = consumos[i];
            var matchSearch = true;
            if (currentFilter) {
                matchSearch = (c.hospede_nome && c.hospede_nome.toLowerCase().indexOf(currentFilter) !== -1) ||
                              (c.servico_nome && c.servico_nome.toLowerCase().indexOf(currentFilter) !== -1);
            }
            var matchServico = true;
            if (currentServicoFilter) {
                matchServico = c.servico_nome === currentServicoFilter;
            }
            if (matchSearch && matchServico) {
                result.push(c);
            }
        }
        return result;
    }

    function renderTable() {
        var filtered = filterConsumos();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (totalPages === 0) totalPages = 1;
        if (currentPage > totalPages) currentPage = totalPages;

        var start = (currentPage - 1) * rowsPerPage;
        var paginated = filtered.slice(start, start + rowsPerPage);

        var tbody = document.getElementById('consumosTableBody');
        tbody.innerHTML = "";

        if (paginated.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum consumo registrado</td></tr>';
            document.getElementById('pagination').innerHTML = "";
            return;
        }

        for (var i = 0; i < paginated.length; i++) {
            var c = paginated[i];
            var servicoClass = (c.servico_nome || "").replace(/ /g, '');
            var row = '<tr>' +
                '<td>' + formatDateTime(c.data_consumo) + '</td>' +
                '<td><strong>' + escapeHtml(c.hospede_nome) + '</strong></td>' +
                '<td>' + escapeHtml(c.quarto_num) + '</td>' +
                '<td><span class="badge-servico ' + servicoClass + '">' + escapeHtml(c.servico_nome) + '</span></td>' +
                '<td class="text-center">' + c.quantidade + '</td>' +
                '<td><strong>' + formatMoney(c.subtotal) + '</strong></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn edit" onclick="editarConsumo(' + c.id_consumo + ')"><i class="bi bi-pencil"></i></button>' +
                    '<button class="action-btn view" onclick="verConsumo(' + c.id_consumo + ')"><i class="bi bi-eye"></i></button>' +
                '</td>' +
                '</tr>';
            tbody.innerHTML += row;
        }

        renderPagination(totalPages);
    }

    function renderPagination(totalPages) {
        var pagination = document.getElementById('pagination');
        pagination.innerHTML = "";
        if (totalPages <= 1) return;

        pagination.innerHTML += '<li class="page-item ' + (currentPage === 1 ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(1)">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            pagination.innerHTML += '<li class="page-item ' + (currentPage === i ? 'active' : '') + '"><a class="page-link" href="#" onclick="changePage(' + i + ')">' + i + '</a></li>';
        }
        pagination.innerHTML += '<li class="page-item ' + (currentPage === totalPages ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(' + totalPages + ')">»</a></li>';
    }

    function changePage(page) {
        var filtered = filterConsumos();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (page < 1 || page > totalPages) return;
        currentPage = page;
        renderTable();
    }

    async function editarConsumo(id) {
        var data = await fetchAPI('/Recepcionista/api/consumo/detalhes?id=' + id);
        if (data && data.success) {
            document.getElementById('editId').value = data.id_consumo;
            document.getElementById('reservaId').value = data.id_reserva;
            document.getElementById('servicoId').value = data.id_servico;
            document.getElementById('quantidade').value = data.quantidade;
            document.getElementById('subtotal').value = formatMoney(data.subtotal);
            document.querySelector('#modalConsumo .modal-title').innerHTML = '<i class="bi bi-pencil-square"></i> Editar Consumo';
            new bootstrap.Modal(document.getElementById('modalConsumo')).show();
        } else {
            showAlert('error', 'Erro ao carregar dados do consumo');
        }
    }

    async function verConsumo(id) {
        var data = await fetchAPI('/Recepcionista/api/consumo/detalhes?id=' + id);
        if (data && data.success) {
            document.getElementById('detData').innerHTML = formatDateTime(data.data_consumo);
            document.getElementById('detHospede').innerHTML = escapeHtml(data.hospede_nome);
            document.getElementById('detQuarto').innerHTML = escapeHtml(data.quarto_num);
            document.getElementById('detServico').innerHTML = data.servico_nome;
            document.getElementById('detQuantidade').innerHTML = data.quantidade;
            document.getElementById('detPreco').innerHTML = formatMoney(data.preco_unitario);
            document.getElementById('detSubtotal').innerHTML = formatMoney(data.subtotal);
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        } else {
            showAlert('error', 'Erro ao carregar detalhes do consumo');
        }
    }

    document.getElementById('servicoId').addEventListener('change', function() {
        var selected = this.options[this.selectedIndex];
        var preco = parseFloat(selected.getAttribute('data-preco') || 0);
        var quantidade = parseInt(document.getElementById('quantidade').value) || 1;
        document.getElementById('subtotal').value = formatMoney(preco * quantidade);
    });

    document.getElementById('quantidade').addEventListener('input', function() {
        var selected = document.getElementById('servicoId').options[document.getElementById('servicoId').selectedIndex];
        var preco = parseFloat(selected.getAttribute('data-preco') || 0);
        var quantidade = parseInt(this.value) || 1;
        document.getElementById('subtotal').value = formatMoney(preco * quantidade);
    });

    document.getElementById('formConsumo').addEventListener('submit', async function(e) {
        e.preventDefault();
        var editId = document.getElementById('editId').value;
        var reservaId = document.getElementById('reservaId').value;
        var servicoId = document.getElementById('servicoId').value;
        var quantidade = document.getElementById('quantidade').value;

        if (!reservaId || !servicoId) {
            showAlert('error', 'Preencha todos os campos obrigatórios');
            return;
        }

        var url = editId ? '/Recepcionista/api/consumo/atualizar' : '/Recepcionista/api/consumo/criar';
        var body = editId ? 'id_consumo=' + editId + '&id_reserva=' + reservaId + '&id_servico=' + servicoId + '&quantidade=' + quantidade : 'id_reserva=' + reservaId + '&id_servico=' + servicoId + '&quantidade=' + quantidade;

        var result = await fetchAPI(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body
        });

        if (result && result.success) {
            showAlert('success', result.message);
            bootstrap.Modal.getInstance(document.getElementById('modalConsumo')).hide();
            document.getElementById('formConsumo').reset();
            document.getElementById('editId').value = "";
            document.getElementById('subtotal').value = "";
            document.querySelector('#modalConsumo .modal-title').innerHTML = '<i class="bi bi-plus-circle"></i> Novo Consumo';
            await carregarEstatisticas();
            await carregarConsumos();
            await carregarHospedesSelect();
        } else {
            showAlert('error', (result && result.error) || 'Erro ao salvar consumo');
        }
    });

    document.getElementById('modalConsumo').addEventListener('hidden.bs.modal', function() {
        document.getElementById('formConsumo').reset();
        document.getElementById('editId').value = "";
        document.getElementById('subtotal').value = "";
        document.querySelector('#modalConsumo .modal-title').innerHTML = '<i class="bi bi-plus-circle"></i> Novo Consumo';
    });

    document.getElementById('searchInput').addEventListener('input', function(e) {
        currentFilter = e.target.value.toLowerCase();
        currentPage = 1;
        renderTable();
    });

    document.getElementById('servicoFilter').addEventListener('change', function(e) {
        currentServicoFilter = e.target.value;
        currentPage = 1;
        renderTable();
    });

    function updateClock() {
        var now = new Date();
        document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Inicialização
    carregarEstatisticas();
    carregarConsumos();
    carregarServicos();

    // Aguardar consumos carregar para preencher hóspedes
    setTimeout(function() {
        carregarHospedesSelect();
    }, 1000);

    setInterval(function() {
        carregarEstatisticas();
        carregarConsumos();
    }, 30000);
</script>
</body>
</html>