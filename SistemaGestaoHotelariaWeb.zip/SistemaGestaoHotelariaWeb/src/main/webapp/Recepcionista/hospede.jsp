<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hóspedes · Recepção</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #2C5F8A;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 193, 7, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFC107;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
        .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFC107; color: #2C5F8A; }
        .sidebar li.active i { color: #2C5F8A; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
        .sidebar .menu-section {
            color: #FFC107;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #FFC107; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

        .btn-primary-custom { background: #FFC107; border: none; padding: 10px 24px; border-radius: 40px; font-weight: 600; color: #2C5F8A; transition: all 0.2s; }
        .btn-primary-custom:hover { background: #2C5F8A; color: #FFC107; transform: translateY(-2px); }
        .btn-outline-custom { background: transparent; border: 2px solid #E2E8F0; padding: 8px 20px; border-radius: 40px; font-weight: 500; color: #7F8C8D; }
        .btn-outline-custom:hover { border-color: #FFC107; color: #FFC107; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #FFC107; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 12px 20px;
            margin-bottom: 20px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #F9F6EF;
            padding: 6px 14px;
            border-radius: 40px;
        }
        .search-box input { border: none; background: transparent; outline: none; width: 220px; font-size: 0.8rem; }
        .btn-add { background: #FFC107; border: none; padding: 6px 18px; border-radius: 40px; font-weight: 500; color: #2C5F8A; transition: all 0.2s; }
        .btn-add:hover { background: #2C5F8A; color: #FFC107; transform: translateY(-2px); }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }
        .table-section h3 i { color: #FFC107; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFC107; color: #2C5F8A; font-weight: 600; padding: 10px 6px; }

        .badge-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-status.HOSPEDADO { background: #2C5F8A; color: #FFC107; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.CHECKOUT { background: #E3F2FD; color: #1976D2; }

        .action-buttons { display: flex; gap: 8px; flex-wrap: wrap; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 6px;
            transition: all 0.2s;
            font-size: 0.7rem;
        }
        .action-btn.view { background: #1976D2; color: white; }
        .action-btn.checkin { background: #2E7D32; color: white; }
        .action-btn.checkout { background: #D9534F; color: white; }
        .action-btn.edit { background: #F39C12; color: white; }
        .action-btn:hover { transform: scale(1.05); opacity: 0.9; }

        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #2C5F8A; color: white; border-radius: 24px 24px 0 0; padding: 16px 20px; }
        .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E8DFC8; }
        .detail-label { width: 130px; font-weight: 600; color: #2C5F8A; }
        .detail-value { flex: 1; color: #8B9A87; }
        .form-control-custom, .form-select-custom { border-radius: 12px; border: 1px solid #E2E8F0; padding: 10px 14px; width: 100%; }

        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .filters-bar { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
    </div>

    <div class="menu-section">ATENDIMENTO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
    </ul>

    <div class="menu-section">CLIENTES</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Recepção<span>Gestão de Hóspedes</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="stat-header"><h3>TOTAL CLIENTES</h3><i class="bi bi-people-fill"></i></div><div class="stat-value" id="totalClientes">--</div><div class="stat-footer">Clientes cadastrados</div></div>
        <div class="stat-card"><div class="stat-header"><h3>HÓSPEDES NO HOTEL</h3><i class="bi bi-building"></i></div><div class="stat-value" id="hospedesHotel">--</div><div class="stat-footer">Check-in realizados</div></div>
        <div class="stat-card"><div class="stat-header"><h3>CHECK-OUTS HOJE</h3><i class="bi bi-luggage"></i></div><div class="stat-value" id="checkoutsHoje">--</div><div class="stat-footer">Saídas previstas</div></div>
        <div class="stat-card"><div class="stat-header"><h3>RESERVAS HOJE</h3><i class="bi bi-calendar-check"></i></div><div class="stat-value" id="reservasHoje">--</div><div class="stat-footer">Check-ins pendentes</div></div>
    </div>

    <div class="charts-grid">
        <div class="chart-box"><h3><i class="bi bi-pie-chart"></i> Hóspedes por Tipo</h3><div class="chart-container"><canvas id="hospedesTipoChart"></canvas></div></div>
        <div class="chart-box"><h3><i class="bi bi-bar-chart"></i> Movimento Mensal</h3><div class="chart-container"><canvas id="movimentoMensalChart"></canvas></div></div>
    </div>

    <div class="filters-bar">
        <div class="search-box"><i class="bi bi-search"></i><input type="text" id="searchInputClientes" placeholder="Buscar cliente por nome..."></div>
        <div>
            <button class="btn-add" data-bs-toggle="modal" data-bs-target="#modalCliente"><i class="bi bi-plus-lg"></i> Novo Cliente</button>
        </div>
    </div>

    <!-- TABELA 1: Hóspedes no Hotel (PRIMEIRA) -->
    <div class="table-section" id="tabelaHospedados">
        <h3><i class="bi bi-people-fill"></i> Hóspedes no Hotel</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Hóspede</th><th>Quarto</th><th>Check-in</th><th>Saída Prevista</th><th>Consumo</th><th>Status</th><th>Ações</th></tr>
                </thead>
                <tbody id="hospedadosTableBody">
                    <td><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando......</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- TABELA 2: TODOS OS CLIENTES CADASTRADOS (SEGUNDA) -->
    <div class="table-section" id="tabelaTodosClientes">
        <h3><i class="bi bi-database"></i> Todos os Clientes Cadastrados</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>Email</th>
                        <th>Documento</th>
                        <th>Nacionalidade</th>
                        <th>Data Registro</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="todosClientesTableBody">
                    <tr><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando clientes...</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="footer"><i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos</div>
</div>

<!-- MODAL: Novo/Editar Cliente -->
<div class="modal fade modal-custom" id="modalCliente" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-person-plus"></i> <span id="modalClienteTitle">Novo Cliente</span></h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <form id="formCliente">
                    <input type="hidden" id="clienteId" value="0">
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Nome Completo <span class="text-danger">*</span></label><input type="text" class="form-control form-control-custom" id="nomeCompleto" required></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Sexo</label><select class="form-select form-select-custom" id="sexo"><option value="M">Masculino</option><option value="F">Feminino</option></select></div>
                        <div class="col-md-3 mb-3"><label class="form-label">Data Nascimento</label><input type="date" class="form-control form-control-custom" id="dataNascimento"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Telefone</label><input type="tel" class="form-control form-control-custom" id="telefone"></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Email</label><input type="email" class="form-control form-control-custom" id="email"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Tipo Documento</label><select class="form-select form-select-custom" id="tipoDocumento"><option value="1">BI</option><option value="2">Passaporte</option><option value="3">DIRE</option></select></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Nº Documento</label><input type="text" class="form-control form-control-custom" id="numeroDocumento"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Nacionalidade</label><select class="form-select form-select-custom" id="nacionalidade"><option value="1">Moçambicana</option><option value="2">Sul-africana</option><option value="3">Portuguesa</option><option value="4">Brasileira</option><option value="5">Angolana</option></select></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Endereço</label><input type="text" class="form-control form-control-custom" id="endereco"></div>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2"><button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button><button type="submit" class="btn-primary-custom">Salvar Cliente</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Hóspede -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom"><h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Hóspede</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Nome:</div><div class="detail-value" id="detNome">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="detQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Check-in:</div><div class="detail-value" id="detCheckin">-</div></div>
                <div class="detail-row"><div class="detail-label">Check-out:</div><div class="detail-value" id="detCheckout">-</div></div>
                <div class="detail-row"><div class="detail-label">Hóspedes:</div><div class="detail-value" id="detHospedes">-</div></div>
                <div class="detail-row"><div class="detail-label">Consumo:</div><div class="detail-value" id="detConsumo">-</div></div>
                <div class="detail-row"><div class="detail-label">Observações:</div><div class="detail-value" id="detObs">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;"><button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button></div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let hospedesTipoChart = null;
    let movimentoMensalChart = null;

    function formatMoney(value) {
        if (value === undefined || value === null || isNaN(value)) return "0 MZN";
        return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m] || m;
        });
    }

    function showAlert(type, message) {
        Swal.fire({ icon: type, title: type === 'success' ? 'Sucesso' : 'Erro', text: message, timer: 3000, showConfirmButton: false });
    }

    async function fetchAPI(endpoint, options) {
        try {
            var response = await fetch(contextPath + endpoint, options || { method: 'GET' });
            if (!response.ok) throw new Error('Erro: ' + response.status);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            return null;
        }
    }

    // GRÁFICOS - Dados mockados para teste
    function carregarCharts() {
        // Gráfico de Hóspedes por Tipo (mockado)
        var ctxTipo = document.getElementById('hospedesTipoChart').getContext('2d');
        if (hospedesTipoChart) hospedesTipoChart.destroy();
        hospedesTipoChart = new Chart(ctxTipo, {
            type: 'doughnut',
            data: {
                labels: ['Hóspedes no Hotel', 'Check-ins Pendentes'],
                datasets: [{
                    data: [12, 8],
                    backgroundColor: ['#2C5F8A', '#FFC107'],
                    borderWidth: 0,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } },
                cutout: '60%'
            }
        });

        // Gráfico de Movimento Mensal (mockado)
        var meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        var entradas = [12, 15, 18, 22, 28, 25, 20, 18, 22, 26, 30, 28];
        var saidas = [10, 12, 15, 18, 22, 20, 18, 15, 20, 24, 28, 25];

        var ctxMovimento = document.getElementById('movimentoMensalChart').getContext('2d');
        if (movimentoMensalChart) movimentoMensalChart.destroy();
        movimentoMensalChart = new Chart(ctxMovimento, {
            type: 'bar',
            data: {
                labels: meses,
                datasets: [
                    { label: 'Entradas', data: entradas, backgroundColor: '#2C5F8A', borderRadius: 6 },
                    { label: 'Saídas', data: saidas, backgroundColor: '#FFC107', borderRadius: 6 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, grid: { color: '#E8DFC8' } }, x: { grid: { display: false } } }
            }
        });
    }

    async function carregarEstatisticas() {
        var data = await fetchAPI('/Recepcionista/api/hospede/estatisticas');
        if (data) {
            document.getElementById('hospedesHotel').textContent = data.hospedados || 0;
            document.getElementById('checkoutsHoje').textContent = data.checkouts_hoje || 0;
            document.getElementById('reservasHoje').textContent = data.reservas_hoje || 0;
        }
    }

    async function carregarHospedados() {
        var data = await fetchAPI('/Recepcionista/api/hospede/lista');
        var tbody = document.getElementById('hospedadosTableBody');

        if (!data || data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum hóspede no momento</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        for (var i = 0; i < data.length; i++) {
            var h = data[i];
            var isVip = h.consumo_total > 5000;
            tbody.innerHTML += '<tr>' +
                '<td><strong>' + escapeHtml(h.nome) + '</strong>' + (isVip ? ' <i class="bi bi-star-fill" style="color: #FFC107;"></i>' : '') + '</td>' +
                '<td>' + escapeHtml(h.quarto_num) + '</td>' +
                '<td>' + h.data_checkin + '</td>' +
                '<td>' + h.data_saida + '</td>' +
                '<td>' + formatMoney(h.consumo_total) + '</td>' +
                '<td><span class="badge-status HOSPEDADO">HOSPEDADO</span></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn view" onclick="verDetalhesHospede(' + h.id_checkin + ')"><i class="bi bi-eye"></i> Detalhes</button>' +
                    '<button class="action-btn checkout" onclick="realizarCheckout(' + h.id_checkin + ')"><i class="bi bi-luggage"></i> Check-out</button>' +
                '</td>' +
                '</tr>';
        }
    }

    async function listarTodosClientes() {
        var tbody = document.getElementById('todosClientesTableBody');
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando clientes...</td></tr>';

        try {
            var data = await fetchAPI('/Recepcionista/api/cliente/listar');

            if (!data || data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum cliente cadastrado</td></tr>';
                document.getElementById('totalClientes').textContent = '0';
                return;
            }

            document.getElementById('totalClientes').textContent = data.length;
            tbody.innerHTML = '';

            var searchTerm = document.getElementById('searchInputClientes').value.toLowerCase();

            var filtered = data.filter(function(c) {
                return (c.nomeCompleto && c.nomeCompleto.toLowerCase().indexOf(searchTerm) !== -1) ||
                       (c.telefone && c.telefone.indexOf(searchTerm) !== -1);
            });

            for (var i = 0; i < filtered.length; i++) {
                var c = filtered[i];
                var dataRegistro = c.dataRegistro ? new Date(c.dataRegistro).toLocaleDateString('pt-PT') : '-';

                tbody.innerHTML += '<tr>' +
                    '<td><strong>' + escapeHtml(c.nomeCompleto || '') + '</strong></td>' +
                    '<td>' + (c.telefone || '-') + '</td>' +
                    '<td>' + (c.email || '-') + '</td>' +
                    '<td>' + (c.tipoDocumento || 'BI') + ': ' + (c.numeroDocumento || '-') + '</td>' +
                    '<td>' + (c.pais || '-') + '</td>' +
                    '<td>' + dataRegistro + '</td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" onclick="editarCliente(' + c.idCliente + ')"><i class="bi bi-pencil"></i> Editar</button>' +
                    '</td>' +
                    '</tr>';
            }

            if (filtered.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum cliente encontrado</td></tr>';
            }
        } catch (error) {
            console.error('Erro ao listar clientes:', error);
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Erro ao carregar clientes</td></tr>';
        }
    }

    async function verDetalhesHospede(idCheckin) {
        var data = await fetchAPI('/Recepcionista/api/hospede/detalhes?id=' + idCheckin);
        if (data && data.success) {
            document.getElementById('detNome').innerHTML = '<strong>' + escapeHtml(data.nome) + '</strong>';
            document.getElementById('detQuarto').innerHTML = data.quarto_num;
            document.getElementById('detCheckin').innerHTML = data.data_checkin;
            document.getElementById('detCheckout').innerHTML = data.data_saida;
            document.getElementById('detHospedes').innerHTML = data.quantidade_hospedes;
            document.getElementById('detConsumo').innerHTML = formatMoney(data.consumo_total);
            document.getElementById('detObs').innerHTML = data.observacoes || "Nenhuma";
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        } else {
            showAlert('error', 'Erro ao carregar detalhes do hóspede');
        }
    }

    async function realizarCheckout(checkinId) {
        var result = await fetchAPI('/Recepcionista/api/check/checkout/realizar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id_checkin=' + checkinId + '&valor_total=0&observacoes='
        });
        if (result && result.success) {
            showAlert('success', result.message);
            carregarTodosDados();
        } else {
            showAlert('error', (result && result.error) || 'Erro ao realizar check-out');
        }
    }

    async function editarCliente(id) {
        var data = await fetchAPI('/Recepcionista/api/cliente/buscar?id=' + id);
        if (data && data.success && data.cliente) {
            var c = data.cliente;
            document.getElementById('clienteId').value = c.idCliente || 0;
            document.getElementById('nomeCompleto').value = c.nomeCompleto || '';
            document.getElementById('sexo').value = c.sexo || 'M';
            document.getElementById('dataNascimento').value = c.dataNascimento || '';
            document.getElementById('telefone').value = c.telefone || '';
            document.getElementById('email').value = c.email || '';
            document.getElementById('tipoDocumento').value = c.idTipoDocumento ? c.idTipoDocumento.toString() : '1';
            document.getElementById('numeroDocumento').value = c.numeroDocumento || '';
            document.getElementById('nacionalidade').value = c.idNacionalidade ? c.idNacionalidade.toString() : '1';
            document.getElementById('endereco').value = c.endereco || '';
            document.getElementById('modalClienteTitle').innerText = 'Editar Cliente';
            new bootstrap.Modal(document.getElementById('modalCliente')).show();
        } else {
            showAlert('error', 'Erro ao carregar dados do cliente');
        }
    }

    document.getElementById('formCliente').addEventListener('submit', async function(e) {
        e.preventDefault();

        var nomeCompleto = document.getElementById('nomeCompleto').value.trim();
        if (!nomeCompleto) {
            showAlert('error', 'O campo Nome Completo é obrigatório');
            return;
        }

        var id = document.getElementById('clienteId').value;
        var dados = {
            id_cliente: id ? parseInt(id) : 0,
            nome_completo: nomeCompleto,
            sexo: document.getElementById('sexo').value,
            data_nascimento: document.getElementById('dataNascimento').value || null,
            telefone: document.getElementById('telefone').value || null,
            email: document.getElementById('email').value || null,
            id_tipo_documento: parseInt(document.getElementById('tipoDocumento').value),
            numero_documento: document.getElementById('numeroDocumento').value || null,
            id_nacionalidade: parseInt(document.getElementById('nacionalidade').value),
            endereco: document.getElementById('endereco').value || null
        };

        var result = await fetchAPI('/Recepcionista/api/cliente/salvar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        if (result && result.success) {
            var modal = bootstrap.Modal.getInstance(document.getElementById('modalCliente'));
            if (modal) modal.hide();
            document.getElementById('formCliente').reset();
            document.getElementById('clienteId').value = '0';
            document.getElementById('modalClienteTitle').innerText = 'Novo Cliente';
            showAlert('success', id == 0 ? 'Cliente cadastrado com sucesso!' : 'Cliente atualizado com sucesso!');
            carregarTodosDados();
        } else {
            showAlert('error', result?.message || 'Erro ao salvar cliente');
        }
    });

    document.getElementById('modalCliente').addEventListener('hidden.bs.modal', function() {
        document.getElementById('formCliente').reset();
        document.getElementById('clienteId').value = '0';
        document.getElementById('modalClienteTitle').innerText = 'Novo Cliente';
    });

    document.getElementById('searchInputClientes').addEventListener('input', function() {
        listarTodosClientes();
    });

    function carregarTodosDados() {
        carregarEstatisticas();
        carregarHospedados();
        listarTodosClientes();
        carregarCharts();
    }

    function updateClock() {
        var now = new Date();
        document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
    }

    setInterval(updateClock, 1000);
    updateClock();

    // Inicialização
    carregarTodosDados();
    setInterval(function() { carregarTodosDados(); }, 30000);
</script>
</body>
</html>