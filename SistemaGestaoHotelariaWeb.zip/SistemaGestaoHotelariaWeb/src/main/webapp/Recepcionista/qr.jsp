<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Acesso · Recepção</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #2C5F8A;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 193, 7, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFC107;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
        .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFC107; color: #2C5F8A; }
        .sidebar li.active i { color: #2C5F8A; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
        .sidebar .menu-section {
            color: #FFC107;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #FFC107; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #FFC107; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 12px 20px;
            margin-bottom: 20px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #F9F6EF;
            padding: 6px 14px;
            border-radius: 40px;
        }
        .search-box input { border: none; background: transparent; outline: none; width: 220px; font-size: 0.8rem; }
        .filter-select {
            padding: 6px 14px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.8rem;
            cursor: pointer;
        }
        .filter-select:hover { border-color: #FFC107; }

        .btn-primary-custom {
            background: #FFC107;
            border: none;
            padding: 8px 20px;
            border-radius: 40px;
            font-weight: 600;
            color: #2C5F8A;
            transition: all 0.2s;
            font-size: 0.85rem;
        }
        .btn-primary-custom:hover { background: #2C5F8A; color: #FFC107; transform: translateY(-2px); }

        .btn-outline-custom {
            background: transparent;
            border: 1px solid #E8DFC8;
            padding: 6px 16px;
            border-radius: 40px;
            font-weight: 500;
            color: #8B9A87;
            font-size: 0.8rem;
        }
        .btn-outline-custom:hover { border-color: #FFC107; color: #FFC107; }

        .btn-success-custom {
            background: #2E7D32;
            border: none;
            padding: 6px 16px;
            border-radius: 30px;
            font-weight: 500;
            color: white;
            font-size: 0.75rem;
        }
        .btn-success-custom:hover { background: #1B5E20; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }
        .table-section h3 i { color: #FFC107; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFC107; color: #2C5F8A; font-weight: 600; padding: 10px 6px; }

        .badge-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-status.ATIVO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.USADO { background: #E3F2FD; color: #1976D2; }
        .badge-status.EXPIRADO { background: #FFEBEE; color: #D9534F; }

        .qr-code-small {
            width: 40px;
            height: 40px;
            background: #F9F6EF;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        .qr-code-small img { border-radius: 6px; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .action-btn.download { color: #2E7D32; }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F9F6EF; transform: scale(1.1); }

        .pagination { margin-top: 16px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link {
            color: #2C5F8A;
            border-radius: 8px;
            padding: 6px 10px;
            text-decoration: none;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.75rem;
        }
        .page-item.active .page-link { background: #FFC107; border-color: #FFC107; color: #2C5F8A; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #2C5F8A; color: white; border-radius: 24px 24px 0 0; padding: 16px 20px; }
        .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E8DFC8; }
        .detail-label { width: 100px; font-weight: 600; color: #2C5F8A; }
        .detail-value { flex: 1; color: #8B9A87; }
        .qr-container { background: white; padding: 20px; border-radius: 20px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .qr-code-large { display: flex; justify-content: center; margin: 15px 0; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E8DFC8;
            padding: 8px 12px;
            font-size: 0.85rem;
        }

        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .filters-bar { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
    </div>

    <div class="menu-section">ATENDIMENTO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
    </ul>

    <div class="menu-section">CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Recepção<span>QR Code Acesso</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>TOTAL QR CODES</h3><i class="bi bi-qr-code"></i></div>
            <div class="stat-value" id="totalQr">--</div>
            <div class="stat-footer">Gerados no sistema</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>ATIVOS</h3><i class="bi bi-check-circle"></i></div>
            <div class="stat-value" id="qrAtivos">--</div>
            <div class="stat-footer">Disponíveis para uso</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>UTILIZADOS</h3><i class="bi bi-check2-all"></i></div>
            <div class="stat-value" id="qrUsados">--</div>
            <div class="stat-footer">Já utilizados</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>EXPIRADOS</h3><i class="bi bi-hourglass-split"></i></div>
            <div class="stat-value" id="qrExpirados">--</div>
            <div class="stat-footer">Fora da validade</div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> QR Codes por Estado</h3>
            <div class="chart-container"><canvas id="estadoQRChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> QR Codes por Mês</h3>
            <div class="chart-container"><canvas id="qrMesChart"></canvas></div>
        </div>
    </div>

    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por hóspede ou reserva...">
        </div>
        <div>
            <select class="filter-select" id="estadoFilter">
                <option value="">Todos os estados</option>
                <option value="ATIVO">ATIVO</option>
                <option value="USADO">USADO</option>
                <option value="EXPIRADO">EXPIRADO</option>
            </select>
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalGerarQR">
            <i class="bi bi-plus-lg"></i> Gerar QR Code
        </button>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-list-ul"></i> QR Codes Gerados</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Hóspede</th><th>Reserva</th><th>Quarto</th><th>Data Geração</th><th>Estado</th><th>QR Code</th><th>Ações</th></tr>
                </thead>
                <tbody id="qrTableBody">
                    <tr><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                </tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos
    </div>
</div>

<!-- MODAL: Gerar QR Code -->
<div class="modal fade modal-custom" id="modalGerarQR" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-qr-code"></i> Gerar QR Code</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formGerarQR">
                    <div class="mb-3">
                        <label class="form-label">Selecione a Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaSelect" required>
                            <option value="">Selecione uma reserva</option>
                        </select>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Gerar QR Code</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Visualizar QR Code -->
<div class="modal fade modal-custom" id="modalVisualizarQR" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-qr-code"></i> QR Code de Acesso</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 text-center">
                <div class="qr-container">
                    <div class="detail-row">
                        <div class="detail-label">Hóspede:</div>
                        <div class="detail-value" id="qrHospede">-</div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Quarto:</div>
                        <div class="detail-value" id="qrQuarto">-</div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Reserva:</div>
                        <div class="detail-value" id="qrReservaId">-</div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Estado:</div>
                        <div class="detail-value" id="qrEstado">-</div>
                    </div>
                    <div class="qr-code-large" id="qrCodeContainer"></div>
                    <div class="mt-3">
                        <button class="btn-success-custom" id="downloadQRBtn">
                            <i class="bi bi-download"></i> Baixar QR Code
                        </button>
                        <button class="btn-outline-custom ms-2" id="printQRBtn">
                            <i class="bi bi-printer"></i> Imprimir
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let estadoChart = null;
    let mesChart = null;
    let currentQrCodeImage = null;
    let qrCodes = [];
    let reservas = [];
    let currentPage = 1;
    let rowsPerPage = 5;
    let currentFilter = "";
    let currentEstadoFilter = "";

    function formatDateTime(dateTimeStr) {
        if (!dateTimeStr) return "";
        return dateTimeStr;
    }

    function formatDate(dateStr) {
        if (!dateStr) return "";
        var parts = dateStr.split("-");
        return parts[2] + "/" + parts[1] + "/" + parts[0];
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function showAlert(type, message) {
        var alertDiv = document.createElement('div');
        alertDiv.className = 'position-fixed bottom-0 end-0 m-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.style.background = type === 'success' ? '#2E7D32' : '#D9534F';
        alertDiv.style.color = 'white';
        alertDiv.style.borderRadius = '12px';
        alertDiv.style.padding = '10px 18px';
        alertDiv.style.fontSize = '0.8rem';
        alertDiv.innerHTML = '<i class="bi bi-' + (type === 'success' ? 'check-circle' : 'exclamation-triangle') + '"></i> ' + message;
        document.body.appendChild(alertDiv);
        setTimeout(function() { alertDiv.remove(); }, 3000);
    }

    async function fetchAPI(endpoint, options) {
        options = options || {};
        try {
            var response = await fetch(contextPath + endpoint, options);
            if (!response.ok) throw new Error('Erro: ' + response.status);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            return null;
        }
    }

    function generateQRCodeImage(data) {
        return "https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=" + encodeURIComponent(data);
    }

    async function carregarQRCodes() {
        var data = await fetchAPI('/Recepcionista/api/qr/listar');
        if (data && data.length > 0) {
            qrCodes = data;
        } else {
            qrCodes = [];
        }
        renderTable();
        updateStats();
        updateCharts();
    }

    async function carregarReservasSelect() {
        var data = await fetchAPI('/Recepcionista/api/reserva/listar');
        if (data && data.length > 0) {
            reservas = data;
            var select = document.getElementById('reservaSelect');
            select.innerHTML = '<option value="">Selecione uma reserva</option>';
            var qrReservas = {};
            for (var i = 0; i < qrCodes.length; i++) {
                qrReservas[qrCodes[i].id_reserva] = true;
            }
            for (var i = 0; i < reservas.length; i++) {
                var r = reservas[i];
                if (!qrReservas[r.id_reserva] && (r.estado_reserva === 'CONFIRMADA' || r.estado_reserva === 'PENDENTE')) {
                    var option = document.createElement('option');
                    option.value = r.id_reserva;
                    option.textContent = "#" + r.id_reserva + " - " + r.cliente_nome + " - Quarto " + r.quarto_num;
                    select.appendChild(option);
                }
            }
        }
    }

    function updateStats() {
        var total = qrCodes.length;
        var ativos = 0, usados = 0, expirados = 0;
        for (var i = 0; i < qrCodes.length; i++) {
            if (qrCodes[i].estado === "ATIVO") ativos++;
            else if (qrCodes[i].estado === "USADO") usados++;
            else if (qrCodes[i].estado === "EXPIRADO") expirados++;
        }
        document.getElementById('totalQr').textContent = total;
        document.getElementById('qrAtivos').textContent = ativos;
        document.getElementById('qrUsados').textContent = usados;
        document.getElementById('qrExpirados').textContent = expirados;
    }

    function updateCharts() {
        var ativos = 0, usados = 0, expirados = 0;
        for (var i = 0; i < qrCodes.length; i++) {
            if (qrCodes[i].estado === "ATIVO") ativos++;
            else if (qrCodes[i].estado === "USADO") usados++;
            else if (qrCodes[i].estado === "EXPIRADO") expirados++;
        }

        var ctxEstado = document.getElementById('estadoQRChart').getContext('2d');
        if (estadoChart) estadoChart.destroy();
        estadoChart = new Chart(ctxEstado, {
            type: 'doughnut',
            data: { labels: ['ATIVO', 'USADO', 'EXPIRADO'], datasets: [{ data: [ativos, usados, expirados], backgroundColor: ['#2E7D32', '#1976D2', '#D9534F'], borderWidth: 0, borderRadius: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
        });

        var meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        var qrPorMes = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        for (var i = 0; i < qrCodes.length; i++) {
            var data = new Date(qrCodes[i].data_geracao);
            var mes = data.getMonth();
            qrPorMes[mes]++;
        }

        var ctxMes = document.getElementById('qrMesChart').getContext('2d');
        if (mesChart) mesChart.destroy();
        mesChart = new Chart(ctxMes, {
            type: 'bar',
            data: { labels: meses, datasets: [{ label: 'QR Codes Gerados', data: qrPorMes, backgroundColor: '#FFC107', borderRadius: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, grid: { color: '#E8DFC8' } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } }
        });
    }

    function filterQrCodes() {
        var result = [];
        for (var i = 0; i < qrCodes.length; i++) {
            var q = qrCodes[i];
            var matchSearch = true;
            if (currentFilter) {
                matchSearch = (q.hospede_nome && q.hospede_nome.toLowerCase().indexOf(currentFilter) !== -1) ||
                              (q.id_reserva && q.id_reserva.toString().indexOf(currentFilter) !== -1);
            }
            var matchEstado = true;
            if (currentEstadoFilter) {
                matchEstado = q.estado === currentEstadoFilter;
            }
            if (matchSearch && matchEstado) {
                result.push(q);
            }
        }
        return result;
    }

    function renderTable() {
        var filtered = filterQrCodes();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (totalPages === 0) totalPages = 1;
        if (currentPage > totalPages) currentPage = totalPages;

        var start = (currentPage - 1) * rowsPerPage;
        var paginated = filtered.slice(start, start + rowsPerPage);

        var tbody = document.getElementById('qrTableBody');
        tbody.innerHTML = "";

        if (paginated.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum QR Code encontrado</td></tr>';
            document.getElementById('pagination').innerHTML = "";
            return;
        }

        for (var i = 0; i < paginated.length; i++) {
            var q = paginated[i];
            var qrPreview = generateQRCodeImage(q.codigo);
            var row = '<tr>' +
                '<td><strong>' + escapeHtml(q.hospede_nome) + '</strong></td>' +
                '<td><span class="badge bg-secondary">#' + q.id_reserva + '</span></td>' +
                '<td>' + escapeHtml(q.quarto_num) + '</td>' +
                '<td>' + formatDateTime(q.data_geracao) + '</td>' +
                '<td><span class="badge-status ' + q.estado + '">' + q.estado + '</span></td>' +
                '<td><div class="qr-code-small" onclick="viewQRCode(' + q.id_qrcode + ')"><img src="' + qrPreview + '" width="36" height="36" style="border-radius: 6px;"></div></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn download" onclick="downloadQRCode(' + q.id_qrcode + ')"><i class="bi bi-download"></i></button>' +
                    '<button class="action-btn view" onclick="viewQRCode(' + q.id_qrcode + ')"><i class="bi bi-eye"></i></button>' +
                '</td>' +
                '</tr>';
            tbody.innerHTML += row;
        }

        renderPagination(totalPages);
    }

    function renderPagination(totalPages) {
        var pagination = document.getElementById('pagination');
        pagination.innerHTML = "";
        if (totalPages <= 1) return;

        pagination.innerHTML += '<li class="page-item ' + (currentPage === 1 ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(1)">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            pagination.innerHTML += '<li class="page-item ' + (currentPage === i ? 'active' : '') + '"><a class="page-link" href="#" onclick="changePage(' + i + ')">' + i + '</a></li>';
        }
        pagination.innerHTML += '<li class="page-item ' + (currentPage === totalPages ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(' + totalPages + ')">»</a></li>';
    }

    function changePage(page) {
        var filtered = filterQrCodes();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (page < 1 || page > totalPages) return;
        currentPage = page;
        renderTable();
    }

    async function viewQRCode(id) {
        var data = await fetchAPI('/Recepcionista/api/qr/detalhes?id=' + id);
        if (data && data.success) {
            currentQrCodeImage = data;
            document.getElementById('qrHospede').innerHTML = '<strong>' + escapeHtml(data.hospede_nome) + '</strong>';
            document.getElementById('qrQuarto').innerHTML = data.quarto_num;
            document.getElementById('qrReservaId').innerHTML = "#" + data.id_reserva;
            document.getElementById('qrEstado').innerHTML = '<span class="badge-status ' + data.estado + '">' + data.estado + '</span>';

            var qrContainer = document.getElementById('qrCodeContainer');
            qrContainer.innerHTML = "";
            var qrImage = document.createElement('img');
            qrImage.src = generateQRCodeImage(data.codigo);
            qrImage.style.width = "160px";
            qrImage.style.height = "160px";
            qrContainer.appendChild(qrImage);

            new bootstrap.Modal(document.getElementById('modalVisualizarQR')).show();
        } else {
            showAlert('error', 'Erro ao carregar detalhes do QR Code');
        }
    }

    async function downloadQRCode(id) {
        var data = await fetchAPI('/Recepcionista/api/qr/detalhes?id=' + id);
        if (data && data.success) {
            var link = document.createElement('a');
            link.download = 'qrcode_reserva_' + data.id_reserva + '.png';
            link.href = generateQRCodeImage(data.codigo);
            link.click();
            showAlert('success', 'QR Code baixado com sucesso!');
        } else {
            showAlert('error', 'Erro ao baixar QR Code');
        }
    }

    document.getElementById('downloadQRBtn').addEventListener('click', function() {
        if (currentQrCodeImage) {
            var link = document.createElement('a');
            link.download = 'qrcode_reserva_' + currentQrCodeImage.id_reserva + '.png';
            link.href = generateQRCodeImage(currentQrCodeImage.codigo);
            link.click();
        }
    });

    document.getElementById('printQRBtn').addEventListener('click', function() {
        if (currentQrCodeImage) {
            var printWindow = window.open('', '_blank');
            printWindow.document.write('<!DOCTYPE html><html><head><title>QR Code - Reserva ' + currentQrCodeImage.id_reserva + '</title>');
            printWindow.document.write('<style>');
            printWindow.document.write('body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: white; }');
            printWindow.document.write('.print-container { text-align: center; padding: 30px; }');
            printWindow.document.write('img { width: 250px; height: 250px; margin: 20px; }');
            printWindow.document.write('.info { margin-top: 20px; font-size: 14px; color: #333; }');
            printWindow.document.write('</style></head><body>');
            printWindow.document.write('<div class="print-container">');
            printWindow.document.write('<h2>Hotelaria Systems</h2>');
            printWindow.document.write('<h3>QR Code de Acesso</h3>');
            printWindow.document.write('<img src="' + generateQRCodeImage(currentQrCodeImage.codigo) + '" alt="QR Code">');
            printWindow.document.write('<div class="info">');
            printWindow.document.write('<p><strong>Hóspede:</strong> ' + currentQrCodeImage.hospede_nome + '</p>');
            printWindow.document.write('<p><strong>Quarto:</strong> ' + currentQrCodeImage.quarto_num + '</p>');
            printWindow.document.write('<p><strong>Reserva:</strong> #' + currentQrCodeImage.id_reserva + '</p>');
            printWindow.document.write('</div></div>');
            printWindow.document.write('<script>window.onload = function() { window.print(); setTimeout(function() { window.close(); }, 500); };<\/script>');
            printWindow.document.write('</body></html>');
            printWindow.document.close();
        }
    });

    document.getElementById('formGerarQR').addEventListener('submit', async function(e) {
        e.preventDefault();
        var reservaId = document.getElementById('reservaSelect').value;

        var result = await fetchAPI('/Recepcionista/api/qr/gerar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id_reserva=' + reservaId
        });

        if (result && result.success) {
            bootstrap.Modal.getInstance(document.getElementById('modalGerarQR')).hide();
            document.getElementById('formGerarQR').reset();
            await carregarQRCodes();
            await carregarReservasSelect();
            showAlert('success', result.message);
        } else {
            showAlert('error', (result && result.error) || 'Erro ao gerar QR Code');
        }
    });

    document.getElementById('modalGerarQR').addEventListener('hidden.bs.modal', function() {
        document.getElementById('formGerarQR').reset();
    });

    document.getElementById('searchInput').addEventListener('input', function(e) {
        currentFilter = e.target.value.toLowerCase();
        currentPage = 1;
        renderTable();
    });

    document.getElementById('estadoFilter').addEventListener('change', function(e) {
        currentEstadoFilter = e.target.value;
        currentPage = 1;
        renderTable();
    });

    function updateClock() {
        var now = new Date();
        document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
    }
    setInterval(updateClock, 1000);
    updateClock();

    carregarQRCodes();
    carregarReservasSelect();
    setInterval(function() { carregarQRCodes(); }, 30000);
</script>
</body>
</html>