<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagamentos · Recepção</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #2C5F8A;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 193, 7, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFC107;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
        .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFC107; color: #2C5F8A; }
        .sidebar li.active i { color: #2C5F8A; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
        .sidebar .menu-section {
            color: #FFC107;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #FFC107; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #FFC107; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 12px 20px;
            margin-bottom: 20px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #F9F6EF;
            padding: 6px 14px;
            border-radius: 40px;
        }
        .search-box input { border: none; background: transparent; outline: none; width: 220px; font-size: 0.8rem; }
        .filter-select {
            padding: 6px 14px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.8rem;
            cursor: pointer;
        }
        .filter-select:hover { border-color: #FFC107; }

        .btn-primary-custom {
            background: #FFC107;
            border: none;
            padding: 8px 20px;
            border-radius: 40px;
            font-weight: 600;
            color: #2C5F8A;
            transition: all 0.2s;
            font-size: 0.85rem;
        }
        .btn-primary-custom:hover { background: #2C5F8A; color: #FFC107; transform: translateY(-2px); }
        .btn-outline-custom {
            background: transparent;
            border: 1px solid #E8DFC8;
            padding: 6px 16px;
            border-radius: 40px;
            font-weight: 500;
            color: #8B9A87;
            font-size: 0.8rem;
        }
        .btn-outline-custom:hover { border-color: #FFC107; color: #FFC107; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }
        .table-section h3 i { color: #FFC107; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFC107; color: #2C5F8A; font-weight: 600; padding: 10px 6px; }

        .badge-status {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
        }
        .badge-status.PAGO { background: #E8F5E9; color: #2E7D32; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.PARCIAL { background: #E3F2FD; color: #1976D2; }

        .action-buttons { display: flex; gap: 8px; }
        .action-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 4px;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .action-btn.view { color: #1976D2; }
        .action-btn:hover { background: #F9F6EF; transform: scale(1.1); }

        .pagination { margin-top: 16px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link {
            color: #2C5F8A;
            border-radius: 8px;
            padding: 6px 10px;
            text-decoration: none;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.75rem;
        }
        .page-item.active .page-link { background: #FFC107; border-color: #FFC107; color: #2C5F8A; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #2C5F8A; color: white; border-radius: 24px 24px 0 0; padding: 16px 20px; }
        .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E8DFC8; }
        .detail-label { width: 100px; font-weight: 600; color: #2C5F8A; }
        .detail-value { flex: 1; color: #8B9A87; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E8DFC8;
            padding: 8px 12px;
            font-size: 0.85rem;
        }

        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .filters-bar { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
    </div>

    <div class="menu-section">ATENDIMENTO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
    </ul>

    <div class="menu-section">CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Recepção<span>Gestão de Pagamentos</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>TOTAL ARRECADADO</h3><i class="bi bi-cash-stack"></i></div>
            <div class="stat-value" id="totalArrecadado">0 MZN</div>
            <div class="stat-footer">Total de pagamentos confirmados</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>PENDENTES</h3><i class="bi bi-hourglass-split"></i></div>
            <div class="stat-value" id="totalPendente">0 MZN</div>
            <div class="stat-footer">A receber</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>PAGAMENTOS HOJE</h3><i class="bi bi-check-circle"></i></div>
            <div class="stat-value" id="pagamentosHoje">0</div>
            <div class="stat-footer">Registrados hoje</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>TICKET MÉDIO</h3><i class="bi bi-credit-card"></i></div>
            <div class="stat-value" id="ticketMedio">0 MZN</div>
            <div class="stat-footer">Por pagamento confirmado</div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Pagamentos por Método</h3>
            <div class="chart-container"><canvas id="metodosChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Evolução Mensal</h3>
            <div class="chart-container"><canvas id="evolucaoMensalChart"></canvas></div>
        </div>
    </div>

    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por cliente ou reserva...">
        </div>
        <div>
            <select class="filter-select" id="estadoFilter">
                <option value="">Todos os estados</option>
                <option value="PAGO">PAGO</option>
                <option value="PENDENTE">PENDENTE</option>
                <option value="PARCIAL">PARCIAL</option>
            </select>
            <select class="filter-select" id="metodoFilter">
                <option value="">Todos os métodos</option>
                <option value="Dinheiro">Dinheiro</option>
                <option value="POS">POS</option>
                <option value="Transferência Bancária">Transferência Bancária</option>
                <option value="M-Pesa">M-Pesa</option>
                <option value="E-Mola">E-Mola</option>
            </select>
        </div>
        <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalPagamento">
            <i class="bi bi-plus-lg"></i> Novo Pagamento
        </button>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-list-ul"></i> Histórico de Pagamentos</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Reserva</th><th>Cliente</th><th>Valor</th><th>Método</th><th>Referência</th><th>Data Pagamento</th><th>Estado</th><th>Ações</th></tr>
                </thead>
                <tbody id="pagamentosTableBody"></tbody>
            </table>
        </div>
        <ul class="pagination" id="pagination"></ul>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos
    </div>
</div>

<!-- MODAL: Novo Pagamento -->
<div class="modal fade modal-custom" id="modalPagamento" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-cash"></i> Registrar Pagamento</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formPagamento">
                    <div class="mb-3">
                        <label class="form-label">Reserva <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="reservaPagamento" required>
                            <option value="">Selecione a reserva</option>
                            <option value="1024" data-valor="12500">#1024 - Carlos Mendes - Quarto 204 - 12.500 MZN</option>
                            <option value="1022" data-valor="24000">#1022 - Joaquim Langa - Quarto 312 - 24.000 MZN</option>
                            <option value="1021" data-valor="25500">#1021 - Elena Russo - Quarto 405 - 25.500 MZN</option>
                            <option value="1020" data-valor="9000">#1020 - Maria Santos - Quarto 201 - 9.000 MZN</option>
                            <option value="1023" data-valor="8200">#1023 - Ana Silva - Quarto 108 - 8.200 MZN</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Valor do Pagamento <span class="text-danger">*</span></label>
                        <input type="number" class="form-control form-control-custom" id="valorPagamento" step="0.01" required placeholder="0.00">
                        <small class="text-muted" id="valorTotalReserva"></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Método de Pagamento <span class="text-danger">*</span></label>
                        <select class="form-select form-select-custom" id="metodoPagamento" required>
                            <option value="">Selecione</option>
                            <option value="Dinheiro">Dinheiro</option>
                            <option value="POS">POS</option>
                            <option value="Transferência Bancária">Transferência Bancária</option>
                            <option value="M-Pesa">M-Pesa</option>
                            <option value="E-Mola">E-Mola</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Referência (opcional)</label>
                        <input type="text" class="form-control form-control-custom" id="referenciaPagamento" placeholder="Nº transação, comprovativo...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Estado</label>
                        <select class="form-select form-select-custom" id="estadoPagamento">
                            <option value="PAGO">PAGO</option>
                            <option value="PENDENTE">PENDENTE</option>
                            <option value="PARCIAL">PARCIAL</option>
                        </select>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-primary-custom">Registrar Pagamento</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Detalhes do Pagamento -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Pagamento</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Reserva:</div><div class="detail-value" id="detReserva">-</div></div>
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="detCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Valor:</div><div class="detail-value" id="detValor">-</div></div>
                <div class="detail-row"><div class="detail-label">Método:</div><div class="detail-value" id="detMetodo">-</div></div>
                <div class="detail-row"><div class="detail-label">Referência:</div><div class="detail-value" id="detReferencia">-</div></div>
                <div class="detail-row"><div class="detail-label">Data:</div><div class="detail-value" id="detData">-</div></div>
                <div class="detail-row"><div class="detail-label">Estado:</div><div class="detail-value" id="detEstado">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                <button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let metodosChart = null;
    let evolucaoChart = null;

    // DADOS MOCKADOS PARA TESTE
    var pagamentos = [
        { id_pagamento: 1, id_reserva: 1024, valor: 12500, metodo: "POS", referencia_pagamento: "POS-123456", data_pagamento: "2026-05-22 10:30:00", estado_pagamento: "PAGO", cliente_nome: "Carlos Mendes" },
        { id_pagamento: 2, id_reserva: 1021, valor: 25500, metodo: "M-Pesa", referencia_pagamento: "847123456", data_pagamento: "2026-05-21 14:20:00", estado_pagamento: "PAGO", cliente_nome: "Elena Russo" },
        { id_pagamento: 3, id_reserva: 1022, valor: 10000, metodo: "Dinheiro", referencia_pagamento: "", data_pagamento: "2026-05-23 09:15:00", estado_pagamento: "PARCIAL", cliente_nome: "Joaquim Langa" },
        { id_pagamento: 4, id_reserva: 1020, valor: 0, metodo: "", referencia_pagamento: "", data_pagamento: "", estado_pagamento: "PENDENTE", cliente_nome: "Maria Santos" },
        { id_pagamento: 5, id_reserva: 1023, valor: 3000, metodo: "E-Mola", referencia_pagamento: "EM-445566", data_pagamento: "2026-05-23 11:45:00", estado_pagamento: "PARCIAL", cliente_nome: "Ana Silva" }
    ];

    var reservasInfo = {
        1024: { cliente: "Carlos Mendes", quarto: "204 - Luxo", valor_total: 12500 },
        1023: { cliente: "Ana Paula Silva", quarto: "108 - Standard", valor_total: 8200 },
        1022: { cliente: "Joaquim Pedro Langa", quarto: "312 - Família", valor_total: 24000 },
        1021: { cliente: "Elena Russo", quarto: "405 - Master", valor_total: 25500 },
        1020: { cliente: "Maria Joana Santos", quarto: "201 - Deluxe", valor_total: 9000 }
    };

    var currentPage = 1;
    var rowsPerPage = 5;
    var currentFilter = "";
    var currentEstadoFilter = "";
    var currentMetodoFilter = "";

    function formatMoney(value) {
        if (value === undefined || value === null || isNaN(value)) return "0 MZN";
        return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function formatDateTime(dateTimeStr) {
        if (!dateTimeStr) return "-";
        var parts = dateTimeStr.split(" ");
        if (parts.length === 2) {
            var dataParts = parts[0].split("-");
            var data = dataParts[2] + "/" + dataParts[1] + "/" + dataParts[0];
            var hora = parts[1].substring(0, 5);
            return data + " " + hora;
        }
        return dateTimeStr;
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function showAlert(type, message) {
        var alertDiv = document.createElement('div');
        alertDiv.className = 'position-fixed bottom-0 end-0 m-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.style.background = type === 'success' ? '#2E7D32' : '#D9534F';
        alertDiv.style.color = 'white';
        alertDiv.style.borderRadius = '12px';
        alertDiv.style.padding = '10px 18px';
        alertDiv.style.fontSize = '0.8rem';
        alertDiv.innerHTML = '<i class="bi bi-' + (type === 'success' ? 'check-circle' : 'exclamation-triangle') + '"></i> ' + message;
        document.body.appendChild(alertDiv);
        setTimeout(function() { alertDiv.remove(); }, 3000);
    }

    function updateStats() {
        var totalPago = 0;
        var totalPendenteCalc = 0;
        var pagamentosHoje = 0;
        var hoje = new Date().toISOString().split('T')[0];
        var pagos = [];

        for (var i = 0; i < pagamentos.length; i++) {
            if (pagamentos[i].estado_pagamento === "PAGO") {
                totalPago += pagamentos[i].valor;
                pagos.push(pagamentos[i]);
                if (pagamentos[i].data_pagamento && pagamentos[i].data_pagamento.split(' ')[0] === hoje) {
                    pagamentosHoje++;
                }
            }
            if (pagamentos[i].estado_pagamento === "PENDENTE") {
                var reserva = reservasInfo[pagamentos[i].id_reserva];
                totalPendenteCalc += reserva ? reserva.valor_total : 0;
            }
            if (pagamentos[i].estado_pagamento === "PARCIAL") {
                var reserva = reservasInfo[pagamentos[i].id_reserva];
                if (reserva) {
                    totalPendenteCalc += (reserva.valor_total - pagamentos[i].valor);
                }
            }
        }
        var ticketMedio = pagos.length > 0 ? totalPago / pagos.length : 0;

        document.getElementById('totalArrecadado').innerHTML = formatMoney(totalPago);
        document.getElementById('totalPendente').innerHTML = formatMoney(totalPendenteCalc);
        document.getElementById('pagamentosHoje').textContent = pagamentosHoje;
        document.getElementById('ticketMedio').innerHTML = formatMoney(ticketMedio);
    }

    function updateCharts() {
        var metodosCount = {};
        for (var i = 0; i < pagamentos.length; i++) {
            var p = pagamentos[i];
            if (p.estado_pagamento === "PAGO" && p.metodo) {
                if (!metodosCount[p.metodo]) metodosCount[p.metodo] = 0;
                metodosCount[p.metodo] += p.valor;
            }
        }

        var metodosLabels = Object.keys(metodosCount);
        var metodosData = Object.values(metodosCount);
        var cores = ['#2E7D32', '#FFC107', '#1976D2', '#F57C00', '#9B59B6'];

        var ctxMetodos = document.getElementById('metodosChart').getContext('2d');
        if (metodosChart) metodosChart.destroy();
        if (metodosLabels.length > 0) {
            metodosChart = new Chart(ctxMetodos, {
                type: 'doughnut',
                data: { labels: metodosLabels, datasets: [{ data: metodosData, backgroundColor: cores.slice(0, metodosLabels.length), borderWidth: 0, borderRadius: 6 }] },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
            });
        } else {
            // Mostrar gráfico vazio
            metodosChart = new Chart(ctxMetodos, {
                type: 'doughnut',
                data: { labels: ['Nenhum pagamento'], datasets: [{ data: [1], backgroundColor: ['#E8DFC8'], borderWidth: 0 }] },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
            });
        }

        var meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
        var valores = [285000, 312000, 358000, 395000, 428750, 452300, 480000, 510000, 535000, 560000, 590000, 620000];

        var ctxEvolucao = document.getElementById('evolucaoMensalChart').getContext('2d');
        if (evolucaoChart) evolucaoChart.destroy();
        evolucaoChart = new Chart(ctxEvolucao, {
            type: 'line',
            data: { labels: meses, datasets: [{ label: 'Arrecadação (MZN)', data: valores, borderColor: '#FFC107', backgroundColor: 'rgba(255, 193, 7, 0.05)', tension: 0.3, fill: true, pointBackgroundColor: '#FFC107', pointBorderColor: '#fff' }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { callback: function(v) { return formatMoney(v); } } } } }
        });
    }

    function filterPagamentos() {
        var result = [];
        for (var i = 0; i < pagamentos.length; i++) {
            var p = pagamentos[i];
            var matchSearch = true;
            if (currentFilter) {
                matchSearch = (p.cliente_nome && p.cliente_nome.toLowerCase().indexOf(currentFilter) !== -1) ||
                              (p.id_reserva && p.id_reserva.toString().indexOf(currentFilter) !== -1);
            }
            var matchEstado = true;
            if (currentEstadoFilter) {
                matchEstado = p.estado_pagamento === currentEstadoFilter;
            }
            var matchMetodo = true;
            if (currentMetodoFilter) {
                matchMetodo = p.metodo === currentMetodoFilter;
            }
            if (matchSearch && matchEstado && matchMetodo) {
                result.push(p);
            }
        }
        return result;
    }

    function renderTable() {
        var filtered = filterPagamentos();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (totalPages === 0) totalPages = 1;
        if (currentPage > totalPages) currentPage = totalPages;

        var start = (currentPage - 1) * rowsPerPage;
        var paginated = filtered.slice(start, start + rowsPerPage);

        var tbody = document.getElementById('pagamentosTableBody');
        tbody.innerHTML = "";

        if (paginated.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4">Nenhum pagamento encontrado</td></tr>';
            document.getElementById('pagination').innerHTML = "";
            return;
        }

        for (var i = 0; i < paginated.length; i++) {
            var p = paginated[i];
            var row = '<tr>' +
                '<td>#<strong>' + p.id_reserva + '</strong></td>' +
                '<td><strong>' + escapeHtml(p.cliente_nome) + '</strong></td>' +
                '<td><strong>' + formatMoney(p.valor) + '</strong></td>' +
                '<td>' + (p.metodo || '-') + '</td>' +
                '<td>' + (p.referencia_pagamento || '-') + '</td>' +
                '<td>' + formatDateTime(p.data_pagamento) + '</td>' +
                '<td><span class="badge-status ' + p.estado_pagamento + '">' + p.estado_pagamento + '</span></td>' +
                '<td class="action-buttons">' +
                    '<button class="action-btn view" onclick="verPagamento(' + p.id_pagamento + ')"><i class="bi bi-eye"></i></button>' +
                '</td>' +
                '</tr>';
            tbody.innerHTML += row;
        }

        renderPagination(totalPages);
    }

    function renderPagination(totalPages) {
        var pagination = document.getElementById('pagination');
        pagination.innerHTML = "";
        if (totalPages <= 1) return;

        pagination.innerHTML += '<li class="page-item ' + (currentPage === 1 ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(1)">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            pagination.innerHTML += '<li class="page-item ' + (currentPage === i ? 'active' : '') + '"><a class="page-link" href="#" onclick="changePage(' + i + ')">' + i + '</a></li>';
        }
        pagination.innerHTML += '<li class="page-item ' + (currentPage === totalPages ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(' + totalPages + ')">»</a></li>';
    }

    function changePage(page) {
        var filtered = filterPagamentos();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (page < 1 || page > totalPages) return;
        currentPage = page;
        renderTable();
    }

    function verPagamento(id) {
        var pagamento = null;
        for (var i = 0; i < pagamentos.length; i++) {
            if (pagamentos[i].id_pagamento === id) {
                pagamento = pagamentos[i];
                break;
            }
        }
        if (pagamento) {
            var reserva = reservasInfo[pagamento.id_reserva];
            document.getElementById('detReserva').innerHTML = "#" + pagamento.id_reserva;
            document.getElementById('detCliente').innerHTML = escapeHtml(pagamento.cliente_nome);
            document.getElementById('detValor').innerHTML = formatMoney(pagamento.valor);
            document.getElementById('detMetodo').innerHTML = pagamento.metodo || '-';
            document.getElementById('detReferencia').innerHTML = pagamento.referencia_pagamento || '-';
            document.getElementById('detData').innerHTML = formatDateTime(pagamento.data_pagamento);
            document.getElementById('detEstado').innerHTML = '<span class="badge-status ' + pagamento.estado_pagamento + '">' + pagamento.estado_pagamento + '</span>';
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        }
    }

    document.getElementById('reservaPagamento').addEventListener('change', function() {
        var selected = this.options[this.selectedIndex];
        var valorTotal = selected.getAttribute('data-valor');
        if (valorTotal && parseFloat(valorTotal) > 0) {
            document.getElementById('valorTotalReserva').innerHTML = 'Total da reserva: ' + formatMoney(parseFloat(valorTotal));
            document.getElementById('valorPagamento').value = valorTotal;
        } else {
            document.getElementById('valorTotalReserva').innerHTML = '';
        }
    });

    document.getElementById('formPagamento').addEventListener('submit', function(e) {
        e.preventDefault();
        var reservaId = parseInt(document.getElementById('reservaPagamento').value);
        var valor = parseFloat(document.getElementById('valorPagamento').value);
        var metodo = document.getElementById('metodoPagamento').value;
        var referencia = document.getElementById('referenciaPagamento').value;
        var estado = document.getElementById('estadoPagamento').value;

        if (!reservaId || !valor || !metodo) {
            showAlert('error', 'Preencha todos os campos obrigatórios!');
            return;
        }

        var now = new Date();
        var dataPagamento = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0') + ' ' + String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0') + ':00';

        var maxId = 0;
        for (var i = 0; i < pagamentos.length; i++) {
            if (pagamentos[i].id_pagamento > maxId) maxId = pagamentos[i].id_pagamento;
        }
        var novoId = maxId + 1;

        var reserva = reservasInfo[reservaId];

        pagamentos.push({
            id_pagamento: novoId,
            id_reserva: reservaId,
            valor: valor,
            metodo: metodo,
            referencia_pagamento: referencia,
            data_pagamento: dataPagamento,
            estado_pagamento: estado,
            cliente_nome: reserva ? reserva.cliente : "Cliente"
        });

        bootstrap.Modal.getInstance(document.getElementById('modalPagamento')).hide();
        document.getElementById('formPagamento').reset();
        renderTable();
        updateStats();
        updateCharts();
        showAlert('success', 'Pagamento registrado com sucesso!');
    });

    document.getElementById('modalPagamento').addEventListener('hidden.bs.modal', function() {
        document.getElementById('formPagamento').reset();
        document.getElementById('valorTotalReserva').innerHTML = '';
    });

    document.getElementById('searchInput').addEventListener('input', function(e) {
        currentFilter = e.target.value.toLowerCase();
        currentPage = 1;
        renderTable();
    });

    document.getElementById('estadoFilter').addEventListener('change', function(e) {
        currentEstadoFilter = e.target.value;
        currentPage = 1;
        renderTable();
    });

    document.getElementById('metodoFilter').addEventListener('change', function(e) {
        currentMetodoFilter = e.target.value;
        currentPage = 1;
        renderTable();
    });

    function updateClock() {
        var now = new Date();
        document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
    }
    setInterval(updateClock, 1000);
    updateClock();

    renderTable();
    updateStats();
    updateCharts();
</script>
</body>
</html>