<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estado de Quartos · Recepção</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #2C5F8A;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 193, 7, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFC107;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
        .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFC107; color: #2C5F8A; }
        .sidebar li.active i { color: #2C5F8A; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
        .sidebar .menu-section {
            color: #FFC107;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #FFC107; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #FFC107; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 12px 20px;
            margin-bottom: 20px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #F9F6EF;
            padding: 6px 14px;
            border-radius: 40px;
        }
        .search-box input { border: none; background: transparent; outline: none; width: 220px; font-size: 0.8rem; }
        .filter-select {
            padding: 6px 14px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.8rem;
            cursor: pointer;
        }
        .filter-select:hover { border-color: #FFC107; }

        .rooms-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 28px;
        }
        .room-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            border: 1px solid #E8DFC8;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .room-card:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,0.08); border-color: #FFC107; }
        .room-number { font-size: 1.4rem; font-weight: 700; color: #2C5F8A; margin-bottom: 8px; }
        .room-type { font-size: 0.7rem; color: #8B9A87; margin-bottom: 12px; }
        .room-status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.65rem;
            font-weight: 500;
            margin-bottom: 12px;
        }
        .room-status.LIVRE { background: #E8F5E9; color: #2E7D32; }
        .room-status.OCUPADO { background: #FFEBEE; color: #D9534F; }
        .room-status.RESERVADO { background: #FFF8E1; color: #F57C00; }
        .room-status.MANUTENCAO { background: #E3F2FD; color: #1976D2; }
        .room-status.LIMPEZA { background: #F3E5F5; color: #7B1FA2; }
        .room-info { font-size: 0.7rem; color: #8B9A87; margin-top: 8px; padding-top: 8px; border-top: 1px dashed #E8DFC8; }
        .room-info i { color: #FFC107; margin-right: 4px; }

        .pagination { margin-top: 16px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
        .page-link {
            color: #2C5F8A;
            border-radius: 8px;
            padding: 6px 10px;
            text-decoration: none;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.75rem;
        }
        .page-item.active .page-link { background: #FFC107; border-color: #FFC107; color: #2C5F8A; }
        .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom { background: #2C5F8A; color: white; border-radius: 24px 24px 0 0; padding: 16px 20px; }
        .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E8DFC8; }
        .detail-label { width: 120px; font-weight: 600; color: #2C5F8A; }
        .detail-value { flex: 1; color: #8B9A87; }

        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .rooms-grid { grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); }
            .filters-bar { flex-direction: column; align-items: stretch; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
    </div>

    <div class="menu-section">ATENDIMENTO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
    </ul>

    <div class="menu-section">CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Recepção<span>Estado dos Quartos</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>TOTAL QUARTOS</h3><i class="bi bi-building"></i></div>
            <div class="stat-value" id="totalQuartos">0</div>
            <div class="stat-footer">Capacidade total</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>LIVRES</h3><i class="bi bi-door-open"></i></div>
            <div class="stat-value" id="totalLivres">0</div>
            <div class="stat-footer">Disponíveis hoje</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>OCUPADOS</h3><i class="bi bi-person-fill"></i></div>
            <div class="stat-value" id="totalOcupados">0</div>
            <div class="stat-footer">Com hóspedes</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>TAXA OCUPAÇÃO</h3><i class="bi bi-percent"></i></div>
            <div class="stat-value" id="taxaOcupacao">0%</div>
            <div class="stat-footer">Hoje</div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Distribuição por Estado</h3>
            <div class="chart-container"><canvas id="estadoQuartosChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Ocupação por Tipo</h3>
            <div class="chart-container"><canvas id="ocupacaoTipoChart"></canvas></div>
        </div>
    </div>

    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por número ou tipo...">
        </div>
        <div>
            <select class="filter-select" id="estadoFilter">
                <option value="">Todos os estados</option>
                <option value="LIVRE">LIVRE</option>
                <option value="OCUPADO">OCUPADO</option>
                <option value="RESERVADO">RESERVADO</option>
                <option value="MANUTENCAO">MANUTENÇÃO</option>
                <option value="LIMPEZA">LIMPEZA</option>
            </select>
        </div>
    </div>

    <div class="rooms-grid" id="roomsGrid">
        <div class="text-center py-5 w-100"><div class="loading-spinner"></div> Carregando quartos...</div>
    </div>

    <ul class="pagination" id="pagination"></ul>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos
    </div>
</div>

<!-- MODAL: Detalhes do Quarto -->
<div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes do Quarto</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="detail-row"><div class="detail-label">Número:</div><div class="detail-value" id="detNumero">-</div></div>
                <div class="detail-row"><div class="detail-label">Tipo:</div><div class="detail-value" id="detTipo">-</div></div>
                <div class="detail-row"><div class="detail-label">Piso:</div><div class="detail-value" id="detPiso">-</div></div>
                <div class="detail-row"><div class="detail-label">Diária:</div><div class="detail-value" id="detDiaria">-</div></div>
                <div class="detail-row"><div class="detail-label">Estado:</div><div class="detail-value" id="detEstado">-</div></div>
                <div class="detail-row"><div class="detail-label">Hóspede Atual:</div><div class="detail-value" id="detHospede">-</div></div>
            </div>
            <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                <button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let estadoChart = null;
    let ocupacaoChart = null;
    let quartos = [];
    let currentPage = 1;
    let rowsPerPage = 12;
    let currentFilter = "";
    let currentEstadoFilter = "";

    function formatMoney(value) {
        if (value === undefined || value === null || isNaN(value)) return "0 MZN";
        return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function showAlert(type, message) {
        var alertDiv = document.createElement('div');
        alertDiv.className = 'position-fixed bottom-0 end-0 m-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.style.background = type === 'success' ? '#2E7D32' : '#D9534F';
        alertDiv.style.color = 'white';
        alertDiv.style.borderRadius = '12px';
        alertDiv.style.padding = '10px 18px';
        alertDiv.style.fontSize = '0.8rem';
        alertDiv.innerHTML = '<i class="bi bi-' + (type === 'success' ? 'check-circle' : 'exclamation-triangle') + '"></i> ' + message;
        document.body.appendChild(alertDiv);
        setTimeout(function() { alertDiv.remove(); }, 3000);
    }

    async function fetchAPI(endpoint) {
        try {
            var response = await fetch(contextPath + endpoint);
            if (!response.ok) throw new Error('Erro: ' + response.status);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            return null;
        }
    }

    async function carregarQuartos() {
        var data = await fetchAPI('/Recepcionista/api/quartos/listar');
        if (data && data.length > 0) {
            quartos = data;
            renderGrid();
            updateStats();
            updateCharts();
        } else {
            console.log('Nenhum quarto encontrado ou erro na API');
            document.getElementById('roomsGrid').innerHTML = '<div class="text-center py-5 w-100">Erro ao carregar quartos. Verifique a conexão com o banco.</div>';
        }
    }

    function updateStats() {
        var total = quartos.length;
        var livres = 0, ocupados = 0;
        for (var i = 0; i < quartos.length; i++) {
            if (quartos[i].estado === "LIVRE") livres++;
            if (quartos[i].estado === "OCUPADO") ocupados++;
        }
        var taxa = total > 0 ? Math.round((ocupados / total) * 100) : 0;

        document.getElementById('totalQuartos').textContent = total;
        document.getElementById('totalLivres').textContent = livres;
        document.getElementById('totalOcupados').textContent = ocupados;
        document.getElementById('taxaOcupacao').textContent = taxa + "%";
    }

    function updateCharts() {
        var livres = 0, ocupados = 0, reservados = 0, manutencao = 0, limpeza = 0;
        for (var i = 0; i < quartos.length; i++) {
            if (quartos[i].estado === "LIVRE") livres++;
            else if (quartos[i].estado === "OCUPADO") ocupados++;
            else if (quartos[i].estado === "RESERVADO") reservados++;
            else if (quartos[i].estado === "MANUTENCAO") manutencao++;
            else if (quartos[i].estado === "LIMPEZA") limpeza++;
        }

        var ctxEstado = document.getElementById('estadoQuartosChart').getContext('2d');
        if (estadoChart) estadoChart.destroy();
        estadoChart = new Chart(ctxEstado, {
            type: 'doughnut',
            data: {
                labels: ['LIVRE', 'OCUPADO', 'RESERVADO', 'MANUTENÇÃO', 'LIMPEZA'],
                datasets: [{ data: [livres, ocupados, reservados, manutencao, limpeza], backgroundColor: ['#2E7D32', '#D9534F', '#F57C00', '#1976D2', '#7B1FA2'], borderWidth: 0, borderRadius: 6 }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
        });

        var tipos = [...new Set(quartos.map(q => q.tipo))];
        var ocupacaoPorTipo = [];
        for (var t = 0; t < tipos.length; t++) {
            var totalTipo = 0, ocupadosTipo = 0;
            for (var i = 0; i < quartos.length; i++) {
                if (quartos[i].tipo === tipos[t]) {
                    totalTipo++;
                    if (quartos[i].estado === "OCUPADO") ocupadosTipo++;
                }
            }
            ocupacaoPorTipo.push(totalTipo > 0 ? Math.round((ocupadosTipo / totalTipo) * 100) : 0);
        }

        var ctxOcupacao = document.getElementById('ocupacaoTipoChart').getContext('2d');
        if (ocupacaoChart) ocupacaoChart.destroy();
        ocupacaoChart = new Chart(ctxOcupacao, {
            type: 'bar',
            data: { labels: tipos, datasets: [{ label: 'Taxa de Ocupação (%)', data: ocupacaoPorTipo, backgroundColor: '#FFC107', borderRadius: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, max: 100, grid: { color: '#E8DFC8' } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } }
        });
    }

    function filterQuartos() {
        var result = [];
        for (var i = 0; i < quartos.length; i++) {
            var q = quartos[i];
            var matchSearch = true;
            if (currentFilter) {
                matchSearch = (q.numero_quarto && q.numero_quarto.toLowerCase().indexOf(currentFilter) !== -1) ||
                              (q.tipo && q.tipo.toLowerCase().indexOf(currentFilter) !== -1);
            }
            var matchEstado = true;
            if (currentEstadoFilter) {
                matchEstado = q.estado === currentEstadoFilter;
            }
            if (matchSearch && matchEstado) {
                result.push(q);
            }
        }
        return result;
    }

    function renderGrid() {
        var filtered = filterQuartos();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (totalPages === 0) totalPages = 1;
        if (currentPage > totalPages) currentPage = totalPages;

        var start = (currentPage - 1) * rowsPerPage;
        var paginated = filtered.slice(start, start + rowsPerPage);

        var grid = document.getElementById('roomsGrid');
        grid.innerHTML = "";

        if (paginated.length === 0) {
            grid.innerHTML = '<div class="text-center py-5 w-100">Nenhum quarto encontrado</div>';
            document.getElementById('pagination').innerHTML = "";
            return;
        }

        for (var i = 0; i < paginated.length; i++) {
            var q = paginated[i];
            var card = document.createElement('div');
            card.className = 'room-card';
            card.onclick = (function(quarto) {
                return function() { viewQuarto(quarto.id_quarto); };
            })(q);
            card.innerHTML = '<div class="room-number">' + escapeHtml(q.numero_quarto) + '</div>' +
                           '<div class="room-type">' + escapeHtml(q.tipo || 'Standard') + ' • Piso ' + (q.piso || 1) + '</div>' +
                           '<span class="room-status ' + q.estado + '">' + q.estado + '</span>' +
                           '<div class="room-info">' +
                               '<i class="bi bi-cash"></i> ' + formatMoney(q.preco_diaria || 2500) + '/noite<br>' +
                               '<i class="bi bi-door-open"></i> Disponível' +
                           '</div>';
            grid.appendChild(card);
        }

        renderPagination(totalPages);
    }

    function renderPagination(totalPages) {
        var pagination = document.getElementById('pagination');
        pagination.innerHTML = "";
        if (totalPages <= 1) return;

        pagination.innerHTML += '<li class="page-item ' + (currentPage === 1 ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(1)">«</a></li>';
        for (var i = 1; i <= totalPages; i++) {
            pagination.innerHTML += '<li class="page-item ' + (currentPage === i ? 'active' : '') + '"><a class="page-link" href="#" onclick="changePage(' + i + ')">' + i + '</a></li>';
        }
        pagination.innerHTML += '<li class="page-item ' + (currentPage === totalPages ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(' + totalPages + ')">»</a></li>';
    }

    function changePage(page) {
        var filtered = filterQuartos();
        var totalPages = Math.ceil(filtered.length / rowsPerPage);
        if (page < 1 || page > totalPages) return;
        currentPage = page;
        renderGrid();
    }

    async function viewQuarto(id) {
        var data = await fetchAPI('/Recepcionista/api/quartos/detalhes?id=' + id);
        if (data && data.success) {
            document.getElementById('detNumero').innerHTML = '<strong>' + escapeHtml(data.numero_quarto) + '</strong>';
            document.getElementById('detTipo').innerHTML = escapeHtml(data.tipo || 'Standard');
            document.getElementById('detPiso').innerHTML = (data.piso || 1) + 'º';
            document.getElementById('detDiaria').innerHTML = formatMoney(data.preco_diaria || 2500);
            document.getElementById('detEstado').innerHTML = '<span class="room-status ' + data.estado + '">' + data.estado + '</span>';
            document.getElementById('detHospede').innerHTML = data.hospede_atual || "Nenhum hóspede";
            new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
        } else {
            showAlert('error', 'Erro ao carregar detalhes do quarto');
        }
    }

    document.getElementById('searchInput').addEventListener('input', function(e) {
        currentFilter = e.target.value.toLowerCase();
        currentPage = 1;
        renderGrid();
    });

    document.getElementById('estadoFilter').addEventListener('change', function(e) {
        currentEstadoFilter = e.target.value;
        currentPage = 1;
        renderGrid();
    });

    function updateClock() {
        var now = new Date();
        document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
    }
    setInterval(updateClock, 1000);
    updateClock();

    // Inicialização
    carregarQuartos();
    setInterval(function() { carregarQuartos(); }, 30000);
</script>
</body>
</html>