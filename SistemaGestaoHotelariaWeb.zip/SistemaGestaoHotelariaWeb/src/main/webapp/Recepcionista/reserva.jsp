    <%@ page contentType="text/html;charset=UTF-8" language="java" %>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
    <%@ page import="com.hotel.model.Usuario" %>
    <%
        Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
        if (usuarioLogado == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
    %>
    <!DOCTYPE html>
    <html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reservas · Recepção</title>

        <!-- Bootstrap Icons & Font Awesome -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

        <!-- Bootstrap 5 CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <!-- Chart.js -->
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

        <!-- Flatpickr -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>

        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: #F0F4F8;
                height: 100vh;
                overflow: hidden;
            }
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                width: 270px;
                height: 100vh;
                background: #2C5F8A;
                color: #E8DFC8;
                overflow-y: auto;
                z-index: 1000;
            }
            .sidebar .profile {
                text-align: center;
                padding: 28px 20px 25px;
                background: rgba(255, 255, 255, 0.05);
                border-bottom: 1px solid rgba(255, 193, 7, 0.25);
            }
            .sidebar .profile img {
                width: 85px;
                height: 85px;
                border-radius: 50%;
                border: 3px solid #FFC107;
                margin-bottom: 12px;
                object-fit: cover;
            }
            .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
            .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
            .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
            .sidebar li {
                padding: 10px 16px;
                margin: 4px 0;
                border-radius: 12px;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 12px;
                transition: all 0.25s ease;
            }
            .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
            .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
            .sidebar li.active { background: #FFC107; color: #2C5F8A; }
            .sidebar li.active i { color: #2C5F8A; }
            .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
            .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
            .sidebar .menu-section {
                color: #FFC107;
                font-size: 0.65rem;
                text-transform: uppercase;
                letter-spacing: 2px;
                padding: 20px 20px 8px;
                font-weight: 600;
            }
            .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
            .topbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: white;
                border-radius: 20px;
                padding: 12px 24px;
                margin-bottom: 28px;
                border: 1px solid #E8DFC8;
            }
            .logo-area { display: flex; align-items: center; gap: 12px; }
            .logo-area i { font-size: 1.8rem; color: #FFC107; }
            .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
            .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
            .right-area { display: flex; align-items: center; gap: 25px; }
            .date-time { text-align: right; }
            .date { font-size: 0.7rem; color: #8B9A87; }
            .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

            .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
            .stat-card {
                background: white;
                border-radius: 20px;
                padding: 18px 16px;
                border: 1px solid #E8DFC8;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
            .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
            .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
            .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
            .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
            .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

            .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
            .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
            .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
            .chart-box h3 i { color: #FFC107; }
            .chart-container { position: relative; height: 200px; width: 100%; }

            .filters-bar {
                background: white;
                border-radius: 20px;
                padding: 12px 20px;
                margin-bottom: 20px;
                border: 1px solid #E8DFC8;
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                align-items: center;
                justify-content: space-between;
            }
            .search-box {
                display: flex;
                align-items: center;
                gap: 8px;
                background: #F9F6EF;
                padding: 6px 14px;
                border-radius: 40px;
            }
            .search-box input {
                border: none;
                background: transparent;
                outline: none;
                width: 220px;
                font-size: 0.8rem;
            }
            .filter-select {
                padding: 6px 14px;
                border-radius: 40px;
                border: 1px solid #E8DFC8;
                background: white;
                font-size: 0.8rem;
                cursor: pointer;
            }
            .filter-select:hover { border-color: #FFC107; }

            .btn-primary-custom {
                background: #FFC107;
                border: none;
                padding: 8px 20px;
                border-radius: 40px;
                font-weight: 600;
                color: #2C5F8A;
                transition: all 0.2s;
                font-size: 0.85rem;
            }
            .btn-primary-custom:hover { background: #2C5F8A; color: #FFC107; transform: translateY(-2px); }

            .btn-outline-custom {
                background: transparent;
                border: 1px solid #E8DFC8;
                padding: 6px 16px;
                border-radius: 40px;
                font-weight: 500;
                color: #8B9A87;
                font-size: 0.8rem;
            }
            .btn-outline-custom:hover { border-color: #FFC107; color: #FFC107; }

            .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
            .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }
            .table-section h3 i { color: #FFC107; }
            .table { margin: 0; font-size: 0.8rem; }
            .table thead th { border-bottom: 2px solid #FFC107; color: #2C5F8A; font-weight: 600; padding: 10px 6px; }

            .badge-status {
                padding: 4px 12px;
                border-radius: 30px;
                font-size: 0.65rem;
                font-weight: 500;
            }
            .badge-status.CONFIRMADA { background: #E8F5E9; color: #2E7D32; }
            .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
            .badge-status.CANCELADA { background: #FFEBEE; color: #D9534F; }
            .badge-status.FINALIZADA { background: #E3F2FD; color: #1976D2; }

            .action-buttons { display: flex; gap: 8px; }
            .action-btn {
                background: transparent;
                border: none;
                cursor: pointer;
                padding: 4px;
                border-radius: 6px;
                transition: all 0.2s;
            }
            .action-btn.edit { color: #FFC107; }
            .action-btn.view { color: #1976D2; }
            .action-btn:hover { background: #F9F6EF; transform: scale(1.1); }

            .pagination { margin-top: 16px; display: flex; justify-content: flex-end; gap: 5px; list-style: none; }
            .page-link {
                color: #2C5F8A;
                border-radius: 8px;
                padding: 6px 10px;
                text-decoration: none;
                border: 1px solid #E8DFC8;
                background: white;
                font-size: 0.75rem;
            }
            .page-item.active .page-link { background: #FFC107; border-color: #FFC107; color: #2C5F8A; }
            .page-item.disabled .page-link { color: #A0AD9B; cursor: not-allowed; }

            .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
            .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
            @keyframes spin { to { transform: rotate(360deg); } }

            .modal-custom .modal-content { border-radius: 24px; border: none; }
            .modal-header-custom {
                background: #2C5F8A;
                color: white;
                border-radius: 24px 24px 0 0;
                padding: 16px 20px;
            }
            .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E8DFC8; }
            .detail-label { width: 120px; font-weight: 600; color: #2C5F8A; }
            .detail-value { flex: 1; color: #8B9A87; }
            .form-control-custom, .form-select-custom {
                border-radius: 12px;
                border: 1px solid #E8DFC8;
                padding: 8px 12px;
                font-size: 0.85rem;
            }

            @media (max-width: 1200px) {
                .stats-grid { grid-template-columns: repeat(2, 1fr); }
                .charts-grid { grid-template-columns: 1fr; }
                .filters-bar { flex-direction: column; align-items: stretch; }
            }
        </style>
    </head>
    <body>

    <div class="sidebar">
        <div class="profile">
            <c:choose>
                <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                    <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
                </c:when>
                <c:otherwise>
                    <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
                </c:otherwise>
            </c:choose>
            <h3>${sessionScope.usuarioLogado.nome}</h3>
            <p>${sessionScope.usuarioLogado.email}</p>
            <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
        </div>

        <div class="menu-section">ATENDIMENTO</div>
        <ul>
            <li><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
            <li><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
            <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
            <li><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
        </ul>

        <div class="menu-section">CLIENTES</div>
        <ul>
            <li><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
            <li><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
        </ul>

        <div class="menu-section">SERVIÇOS</div>
        <ul>
            <li><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
            <li><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
            <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </div>

    <div class="main-wrapper">
        <div class="topbar">
            <div class="logo-area">
                <i class="bi bi-building"></i>
                <div class="logo-text">Hotelaria Recepção<span>Gestão de Reservas</span></div>
            </div>
            <div class="right-area">
                <div class="date-time">
                    <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                    <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
                </div>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header"><h3>TOTAL RESERVAS</h3><i class="bi bi-calendar-week"></i></div>
                <div class="stat-value" id="totalReservas">--</div>
                <div class="stat-footer">Este mês: <span id="reservasMes">--</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><h3>CONFIRMADAS</h3><i class="bi bi-check-circle"></i></div>
                <div class="stat-value" id="totalConfirmadas">--</div>
                <div class="stat-footer">Prontas para check-in</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><h3>PENDENTES</h3><i class="bi bi-clock"></i></div>
                <div class="stat-value" id="totalPendentes">--</div>
                <div class="stat-footer">Aguardando confirmação</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><h3>CHECK-IN</h3><i class="bi bi-person-check"></i></div>
                <div class="stat-value" id="totalCheckin">--</div>
                <div class="stat-footer">Hóspedes no hotel</div>
            </div>
        </div>

        <div class="charts-grid">
            <div class="chart-box">
                <h3><i class="bi bi-pie-chart"></i> Reservas por Estado</h3>
                <div class="chart-container"><canvas id="reservasEstadoChart"></canvas></div>
            </div>
            <div class="chart-box">
                <h3><i class="bi bi-bar-chart"></i> Reservas por Mês</h3>
                <div class="chart-container"><canvas id="reservasMesChart"></canvas></div>
            </div>
        </div>

        <div class="filters-bar">
            <div class="search-box">
                <i class="bi bi-search"></i>
                <input type="text" id="searchInput" placeholder="Buscar por cliente ou quarto...">
            </div>
            <div>
                <select class="filter-select" id="statusFilter">
                    <option value="">Todos os estados</option>
                    <option value="PENDENTE">Pendente</option>
                    <option value="CONFIRMADA">Confirmada</option>
                    <option value="FINALIZADA">Finalizada</option>
                    <option value="CANCELADA">Cancelada</option>
                </select>
                <input type="text" id="dateFilter" class="filter-select" placeholder="Filtrar por data" style="width: 130px;">
            </div>
            <button class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#modalReserva">
                <i class="bi bi-plus-lg"></i> Nova Reserva
            </button>
        </div>

        <div class="table-section">
            <h3><i class="bi bi-list-ul"></i> Lista de Reservas</h3>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr><th>Cliente</th><th>Quarto</th><th>Entrada</th><th>Saída</th><th>Hóspedes</th><th>Estado</th><th>Ações</th></tr>
                    </thead>
                    <tbody id="reservasTableBody">
                        <tr><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                    </tbody>
                </table>
            </div>
            <ul class="pagination" id="pagination"></ul>
        </div>

        <div class="footer">
            <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos
        </div>
    </div>

    <!-- MODAL: Nova/Editar Reserva -->
    <div class="modal fade modal-custom" id="modalReserva" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header-custom">
                    <h5 class="modal-title"><i class="bi bi-calendar-plus"></i> Nova Reserva</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <form id="formReserva">
                        <input type="hidden" id="editId" value="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Cliente <span class="text-danger">*</span></label>
                                <select class="form-select form-select-custom" id="clienteId" required>
                                    <option value="">Selecione o cliente</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Quarto <span class="text-danger">*</span></label>
                                <select class="form-select form-select-custom" id="quartoId" required>
                                    <option value="">Selecione o quarto</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Data Entrada <span class="text-danger">*</span></label>
                                <input type="date" class="form-control form-control-custom" id="dataEntrada" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Data Saída <span class="text-danger">*</span></label>
                                <input type="date" class="form-control form-control-custom" id="dataSaida" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Número de Hóspedes</label>
                                <input type="number" class="form-control form-control-custom" id="numHospedes" value="1" min="1" max="10">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Estado da Reserva</label>
                                <select class="form-select form-select-custom" id="estadoReserva">
                                    <option value="PENDENTE">Pendente</option>
                                    <option value="CONFIRMADA">Confirmada</option>
                                    <option value="FINALIZADA">Finalizada</option>
                                    <option value="CANCELADA">Cancelada</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Observações</label>
                            <textarea class="form-control form-control-custom" id="observacoes" rows="2"></textarea>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn-primary-custom">Salvar Reserva</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL: Detalhes da Reserva -->
    <div class="modal fade modal-custom" id="modalDetalhes" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header-custom">
                    <h5 class="modal-title"><i class="bi bi-eye"></i> Detalhes da Reserva</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="detCliente">-</div></div>
                    <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="detQuarto">-</div></div>
                    <div class="detail-row"><div class="detail-label">Entrada:</div><div class="detail-value" id="detEntrada">-</div></div>
                    <div class="detail-row"><div class="detail-label">Saída:</div><div class="detail-value" id="detSaida">-</div></div>
                    <div class="detail-row"><div class="detail-label">Hóspedes:</div><div class="detail-value" id="detHospedes">-</div></div>
                    <div class="detail-row"><div class="detail-label">Estado:</div><div class="detail-value" id="detEstado">-</div></div>
                    <div class="detail-row"><div class="detail-label">Observações:</div><div class="detail-value" id="detObs">-</div></div>
                    <div class="detail-row"><div class="detail-label">Data Registro:</div><div class="detail-value" id="detDataRegistro">-</div></div>
                </div>
                <div class="modal-footer" style="border: none; padding: 16px 24px 24px;">
                    <button class="btn-primary-custom" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const contextPath = '${pageContext.request.contextPath}';
        let estadoChart = null;
        let mesChart = null;
        let reservas = [];
        let currentPage = 1;
        let rowsPerPage = 5;
        let currentFilter = "";
        let currentStatusFilter = "";
        let currentDateFilter = "";

        // Cache para dados
        let clientesCache = [];
        let quartosCache = [];

        function formatMoney(value) {
            if (value === undefined || value === null || isNaN(value)) return "0 MZN";
            return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
        }

        function formatDate(dateStr) {
            if (!dateStr) return "";
            var parts = dateStr.split("-");
            return parts[2] + "/" + parts[1] + "/" + parts[0];
        }

        function formatDateTime(dateTimeStr) {
            if (!dateTimeStr) return "";
            return dateTimeStr.replace(/-/g, '/').substring(0, 16);
        }

        function escapeHtml(str) {
            if (!str) return "";
            return str.replace(/[&<>]/g, function(m) {
                if (m === '&') return '&amp;';
                if (m === '<') return '&lt;';
                if (m === '>') return '&gt;';
                return m;
            });
        }

        function showAlert(type, message) {
            var alertDiv = document.createElement('div');
            alertDiv.className = 'position-fixed bottom-0 end-0 m-3';
            alertDiv.style.zIndex = '9999';
            alertDiv.style.background = type === 'success' ? '#2E7D32' : '#D9534F';
            alertDiv.style.color = 'white';
            alertDiv.style.borderRadius = '12px';
            alertDiv.style.padding = '10px 18px';
            alertDiv.style.fontSize = '0.8rem';
            alertDiv.innerHTML = '<i class="bi bi-' + (type === 'success' ? 'check-circle' : 'exclamation-triangle') + '"></i> ' + message;
            document.body.appendChild(alertDiv);
            setTimeout(function() { alertDiv.remove(); }, 3000);
        }

        async function fetchAPI(endpoint, options) {
            options = options || {};
            try {
                var response = await fetch(contextPath + endpoint, options);
                if (!response.ok) throw new Error('Erro: ' + response.status);
                return await response.json();
            } catch (error) {
                console.error('API Error:', error);
                return null;
            }
        }

        async function carregarReservas() {
            var data = await fetchAPI('/Recepcionista/api/reserva/listar', {});
            if (data && Array.isArray(data) && data.length > 0) {
                reservas = data;
            } else if (data && !Array.isArray(data) && data.reservas) {
                reservas = data.reservas;
            } else {
                reservas = [];
            }
            renderTable();
            updateStats();
            updateCharts();
        }

        async function carregarClientesCache() {
            try {
                var data = await fetchAPI('/Recepcionista/api/reserva/clientes', {});
                if (data && Array.isArray(data)) {
                    clientesCache = data;
                    console.log('Clientes carregados em cache:', clientesCache.length);
                }
            } catch (error) {
                console.error('Erro ao carregar cache de clientes:', error);
            }
        }

        async function carregarQuartosCache() {
            try {
                var data = await fetchAPI('/Recepcionista/api/reserva/quartos', {});
                if (data && Array.isArray(data)) {
                    quartosCache = data;
                    console.log('Quartos carregados em cache:', quartosCache.length);
                }
            } catch (error) {
                console.error('Erro ao carregar cache de quartos:', error);
            }
        }

        function preencherSelectClientes(valorSelecionado) {
            var select = document.getElementById('clienteId');
            select.innerHTML = '<option value="">Selecione o cliente</option>';

            for (var i = 0; i < clientesCache.length; i++) {
                var cliente = clientesCache[i];
                var selected = (cliente.id_cliente == valorSelecionado) ? 'selected' : '';
                select.innerHTML += '<option value="' + cliente.id_cliente + '" ' + selected + '>' +
                                    escapeHtml(cliente.nome_completo) + '</option>';
            }

            if (valorSelecionado && select.value != valorSelecionado) {
                console.warn('Cliente ID ' + valorSelecionado + ' não encontrado na lista!');
            }
        }

        function preencherSelectQuartos(valorSelecionado) {
            var select = document.getElementById('quartoId');
            select.innerHTML = '<option value="">Selecione o quarto</option>';

            if (!quartosCache || quartosCache.length === 0) {
                console.warn('Nenhum quarto carregado no cache');
                select.innerHTML = '<option value="">Nenhum quarto disponível</option>';
                return;
            }

            for (var i = 0; i < quartosCache.length; i++) {
                var quarto = quartosCache[i];
                var selected = (quarto.id_quarto == valorSelecionado) ? 'selected' : '';

                // Verificação segura para estado (evita erro se estado for null/undefined)
                var estado = quarto.estado || 'LIVRE';
                var estadoTexto = '';
                if (estado !== 'LIVRE') {
                    estadoTexto = ' [' + estado + ']';
                }

                select.innerHTML += '<option value="' + quarto.id_quarto + '" ' + selected + '>' +
                                    escapeHtml(quarto.numero) + ' - ' +
                                    escapeHtml(quarto.tipo) + estadoTexto + ' - ' +
                                    formatMoney(quarto.preco_diaria) + '</option>';
            }

            if (valorSelecionado && select.value != valorSelecionado) {
                console.warn('Quarto ID ' + valorSelecionado + ' não encontrado na lista!');
            }
        }

        async function editarReserva(id) {
            console.log('Editando reserva ID:', id);

            var reserva = null;
            for (var i = 0; i < reservas.length; i++) {
                if (reservas[i].id_reserva === id) {
                    reserva = reservas[i];
                    break;
                }
            }

            if (reserva) {
                console.log('Reserva encontrada:', reserva);

                // Carregar caches se estiverem vazios
                if (clientesCache.length === 0) {
                    await carregarClientesCache();
                }
                if (quartosCache.length === 0) {
                    await carregarQuartosCache();
                }

                // Preencher os selects com o valor selecionado
                preencherSelectClientes(reserva.id_cliente);
                preencherSelectQuartos(reserva.id_quarto);

                // Preencher os outros campos
                document.getElementById('editId').value = reserva.id_reserva;
                document.getElementById('dataEntrada').value = reserva.data_entrada;
                document.getElementById('dataSaida').value = reserva.data_saida;
                document.getElementById('numHospedes').value = reserva.numero_hospedes || 1;
                document.getElementById('estadoReserva').value = reserva.estado_reserva;
                document.getElementById('observacoes').value = reserva.observacoes || "";

                document.querySelector('#modalReserva .modal-title').innerHTML = '<i class="bi bi-pencil-square"></i> Editar Reserva';
                new bootstrap.Modal(document.getElementById('modalReserva')).show();
            } else {
                console.error('Reserva não encontrada com ID:', id);
                showAlert('error', 'Erro ao carregar reserva para edição');
            }
        }

        function verReserva(id) {
            var reserva = null;
            for (var i = 0; i < reservas.length; i++) {
                if (reservas[i].id_reserva === id) {
                    reserva = reservas[i];
                    break;
                }
            }
            if (reserva) {
                document.getElementById('detCliente').innerHTML = '<strong>' + escapeHtml(reserva.cliente_nome) + '</strong>';
                document.getElementById('detQuarto').innerHTML = escapeHtml(reserva.quarto_num || '-');
                document.getElementById('detEntrada').innerHTML = formatDate(reserva.data_entrada);
                document.getElementById('detSaida').innerHTML = formatDate(reserva.data_saida);
                document.getElementById('detHospedes').innerHTML = reserva.numero_hospedes || 1;
                document.getElementById('detEstado').innerHTML = '<span class="badge-status ' + reserva.estado_reserva + '">' + reserva.estado_reserva + '</span>';
                document.getElementById('detObs').innerHTML = reserva.observacoes || "Nenhuma observação";
                document.getElementById('detDataRegistro').innerHTML = formatDateTime(reserva.data_registro) || formatDateTime(new Date().toISOString());
                new bootstrap.Modal(document.getElementById('modalDetalhes')).show();
            }
        }

        function updateStats() {
            var total = reservas.length;
            var confirmadas = 0, pendentes = 0, finalizadas = 0, canceladas = 0;
            for (var i = 0; i < reservas.length; i++) {
                if (reservas[i].estado_reserva === "CONFIRMADA") confirmadas++;
                else if (reservas[i].estado_reserva === "PENDENTE") pendentes++;
                else if (reservas[i].estado_reserva === "FINALIZADA") finalizadas++;
                else if (reservas[i].estado_reserva === "CANCELADA") canceladas++;
            }

            var now = new Date();
            var mesAtual = now.getMonth() + 1;
            var anoAtual = now.getFullYear();
            var reservasMes = 0;
            for (var i = 0; i < reservas.length; i++) {
                if (reservas[i].data_entrada) {
                    var partes = reservas[i].data_entrada.split('-');
                    var mes = parseInt(partes[1]);
                    var ano = parseInt(partes[0]);
                    if (mes === mesAtual && ano === anoAtual) {
                        reservasMes++;
                    }
                }
            }

            document.getElementById('totalReservas').textContent = total;
            document.getElementById('reservasMes').textContent = reservasMes;
            document.getElementById('totalConfirmadas').textContent = confirmadas;
            document.getElementById('totalPendentes').textContent = pendentes;
            document.getElementById('totalCheckin').textContent = finalizadas;
        }

        function updateCharts() {
            var confirmadas = 0, pendentes = 0, finalizadas = 0, canceladas = 0;
            for (var i = 0; i < reservas.length; i++) {
                if (reservas[i].estado_reserva === "CONFIRMADA") confirmadas++;
                else if (reservas[i].estado_reserva === "PENDENTE") pendentes++;
                else if (reservas[i].estado_reserva === "FINALIZADA") finalizadas++;
                else if (reservas[i].estado_reserva === "CANCELADA") canceladas++;
            }

            var ctxEstado = document.getElementById('reservasEstadoChart').getContext('2d');
            if (estadoChart) estadoChart.destroy();
            estadoChart = new Chart(ctxEstado, {
                type: 'doughnut',
                data: {
                    labels: ['CONFIRMADAS', 'PENDENTES', 'FINALIZADAS', 'CANCELADAS'],
                    datasets: [{ data: [confirmadas, pendentes, finalizadas, canceladas], backgroundColor: ['#2E7D32', '#F57C00', '#1976D2', '#D9534F'], borderWidth: 0, borderRadius: 6 }]
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
            });

            var meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            var reservasPorMes = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            for (var i = 0; i < reservas.length; i++) {
                if (reservas[i].data_entrada) {
                    var partes = reservas[i].data_entrada.split('-');
                    var mes = parseInt(partes[1]) - 1;
                    if (mes >= 0 && mes < 12) reservasPorMes[mes]++;
                }
            }

            var ctxMes = document.getElementById('reservasMesChart').getContext('2d');
            if (mesChart) mesChart.destroy();
            mesChart = new Chart(ctxMes, {
                type: 'bar',
                data: { labels: meses, datasets: [{ label: 'Reservas', data: reservasPorMes, backgroundColor: '#FFC107', borderRadius: 6 }] },
                options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, grid: { color: '#E8DFC8' } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } }
            });
        }

        function filterReservas() {
            var result = [];
            for (var i = 0; i < reservas.length; i++) {
                var r = reservas[i];
                var matchSearch = true;
                if (currentFilter) {
                    matchSearch = (r.cliente_nome && r.cliente_nome.toLowerCase().indexOf(currentFilter) !== -1) ||
                                  (r.quarto_num && r.quarto_num.toLowerCase().indexOf(currentFilter) !== -1);
                }
                var matchStatus = true;
                if (currentStatusFilter) {
                    matchStatus = r.estado_reserva === currentStatusFilter;
                }
                var matchDate = true;
                if (currentDateFilter) {
                    matchDate = r.data_entrada === currentDateFilter || r.data_saida === currentDateFilter;
                }
                if (matchSearch && matchStatus && matchDate) {
                    result.push(r);
                }
            }
            return result;
        }

        function renderTable() {
            var filtered = filterReservas();
            var totalPages = Math.ceil(filtered.length / rowsPerPage);
            if (totalPages === 0) totalPages = 1;
            if (currentPage > totalPages) currentPage = totalPages;

            var start = (currentPage - 1) * rowsPerPage;
            var paginated = filtered.slice(start, start + rowsPerPage);

            var tbody = document.getElementById('reservasTableBody');
            tbody.innerHTML = "";

            if (paginated.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhuma reserva encontrada<\/td><\/tr>';
                document.getElementById('pagination').innerHTML = "";
                return;
            }

            for (var i = 0; i < paginated.length; i++) {
                var r = paginated[i];
                var row = '<tr>' +
                    '<td><strong>' + escapeHtml(r.cliente_nome) + '</strong><\/td>' +
                    '<td>' + escapeHtml(r.quarto_num || '-') + '<\/td>' +
                    '<td>' + formatDate(r.data_entrada) + '<\/td>' +
                    '<td>' + formatDate(r.data_saida) + '<\/td>' +
                    '<td class="text-center">' + (r.numero_hospedes || 1) + '<\/td>' +
                    '<td><span class="badge-status ' + r.estado_reserva + '">' + r.estado_reserva + '</span><\/td>' +
                    '<td class="action-buttons">' +
                        '<button class="action-btn edit" onclick="editarReserva(' + r.id_reserva + ')" title="Editar"><i class="bi bi-pencil"></i></button>' +
                        '<button class="action-btn view" onclick="verReserva(' + r.id_reserva + ')" title="Detalhes"><i class="bi bi-eye"></i></button>' +
                    '<\/td>' +
                    '<\/tr>';
                tbody.innerHTML += row;
            }

            renderPagination(totalPages);
        }

        function renderPagination(totalPages) {
            var pagination = document.getElementById('pagination');
            pagination.innerHTML = "";
            if (totalPages <= 1) return;

            pagination.innerHTML += '<li class="page-item ' + (currentPage === 1 ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(1)">«</a></li>';
            for (var i = 1; i <= totalPages; i++) {
                pagination.innerHTML += '<li class="page-item ' + (currentPage === i ? 'active' : '') + '"><a class="page-link" href="#" onclick="changePage(' + i + ')">' + i + '</a></li>';
            }
            pagination.innerHTML += '<li class="page-item ' + (currentPage === totalPages ? 'disabled' : '') + '"><a class="page-link" href="#" onclick="changePage(' + totalPages + ')">»</a></li>';
        }

        function changePage(page) {
            var filtered = filterReservas();
            var totalPages = Math.ceil(filtered.length / rowsPerPage);
            if (page < 1 || page > totalPages) return;
            currentPage = page;
            renderTable();
        }

        document.getElementById('formReserva').addEventListener('submit', async function(e) {
            e.preventDefault();
            var editId = document.getElementById('editId').value;
            var clienteId = document.getElementById('clienteId').value;
            var quartoId = document.getElementById('quartoId').value;
            var dataEntrada = document.getElementById('dataEntrada').value;
            var dataSaida = document.getElementById('dataSaida').value;
            var numHospedes = document.getElementById('numHospedes').value;
            var estado = document.getElementById('estadoReserva').value;
            var observacoes = document.getElementById('observacoes').value;

            if (!clienteId || !quartoId || !dataEntrada || !dataSaida) {
                showAlert('error', 'Preencha todos os campos obrigatórios');
                return;
            }

            var url = editId ? '/Recepcionista/api/reserva/atualizar' : '/Recepcionista/api/reserva/criar';
            var params = new URLSearchParams();
            if (editId) params.append('id_reserva', editId);
            params.append('id_cliente', clienteId);
            params.append('id_quarto', quartoId);
            params.append('data_entrada', dataEntrada);
            params.append('data_saida', dataSaida);
            params.append('numero_hospedes', numHospedes);
            params.append('estado', estado);
            params.append('observacoes', observacoes);

            var result = await fetchAPI(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: params.toString()
            });

            if (result && result.success) {
                showAlert('success', result.message);
                bootstrap.Modal.getInstance(document.getElementById('modalReserva')).hide();
                document.getElementById('formReserva').reset();
                document.getElementById('editId').value = "";
                document.querySelector('#modalReserva .modal-title').innerHTML = '<i class="bi bi-calendar-plus"></i> Nova Reserva';
                await carregarReservas();
            } else {
                showAlert('error', (result && result.error) || 'Erro ao salvar reserva');
            }
        });

        document.getElementById('modalReserva').addEventListener('hidden.bs.modal', function() {
            document.getElementById('formReserva').reset();
            document.getElementById('editId').value = "";
            document.querySelector('#modalReserva .modal-title').innerHTML = '<i class="bi bi-calendar-plus"></i> Nova Reserva';
        });

        document.getElementById('searchInput').addEventListener('input', function(e) {
            currentFilter = e.target.value.toLowerCase();
            currentPage = 1;
            renderTable();
        });

        document.getElementById('statusFilter').addEventListener('change', function(e) {
            currentStatusFilter = e.target.value;
            currentPage = 1;
            renderTable();
        });

        flatpickr("#dateFilter", {
            dateFormat: "Y-m-d",
            locale: "pt",
            onChange: function(selectedDates, dateStr) {
                currentDateFilter = dateStr;
                currentPage = 1;
                renderTable();
            }
        });

        document.querySelector('[data-bs-target="#modalReserva"]').addEventListener('show.bs.modal', function() {
            if (clientesCache.length === 0) {
                carregarClientesCache();
            } else {
                preencherSelectClientes(null);
            }
            if (quartosCache.length === 0) {
                carregarQuartosCache();
            } else {
                preencherSelectQuartos(null);
            }

            var hoje = new Date();
            var amanha = new Date();
            amanha.setDate(amanha.getDate() + 1);
            document.getElementById('dataEntrada').valueAsDate = hoje;
            document.getElementById('dataSaida').valueAsDate = amanha;
            document.getElementById('editId').value = "";
            document.getElementById('estadoReserva').value = "PENDENTE";
            document.getElementById('observacoes').value = "";
        });

        function updateClock() {
            var now = new Date();
            document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
        }
        setInterval(updateClock, 1000);
        updateClock();

        // Inicialização
        carregarReservas();
        carregarClientesCache();
        carregarQuartosCache();
        setInterval(function() { carregarReservas(); }, 30000);
    </script>
    </body>
    </html>