<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check-in / Check-out · Recepção</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #2C5F8A;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 193, 7, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFC107;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
        .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFC107; color: #2C5F8A; }
        .sidebar li.active i { color: #2C5F8A; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
        .sidebar .menu-section {
            color: #FFC107;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #FFC107; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

        .action-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .action-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid #E8DFC8;
        }
        .action-card:hover { transform: translateY(-3px); border-color: #FFC107; box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
        .action-card i { font-size: 2rem; color: #FFC107; margin-bottom: 10px; }
        .action-card h4 { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; margin-bottom: 5px; }
        .action-card p { font-size: 0.7rem; color: #8B9A87; margin: 0; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #FFC107; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .filters-bar {
            background: white;
            border-radius: 20px;
            padding: 12px 20px;
            margin-bottom: 20px;
            border: 1px solid #E8DFC8;
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            justify-content: space-between;
        }
        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #F9F6EF;
            padding: 6px 14px;
            border-radius: 40px;
        }
        .search-box i { color: #8B9A87; }
        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            width: 220px;
            font-size: 0.8rem;
        }
        .search-box input:focus { outline: none; }
        .filter-select {
            padding: 6px 14px;
            border-radius: 40px;
            border: 1px solid #E8DFC8;
            background: white;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        .filter-select:hover { border-color: #FFC107; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }
        .table-section h3 i { color: #FFC107; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFC107; color: #2C5F8A; font-weight: 600; padding: 10px 6px; }

        .btn-sm-action {
            background: #FFC107;
            border: none;
            color: #2C5F8A;
            font-size: 0.7rem;
            padding: 5px 15px;
            border-radius: 30px;
            font-weight: 500;
            transition: all 0.2s;
        }
        .btn-sm-action:hover { background: #2C5F8A; color: #FFC107; }

        .btn-outline-sm {
            background: transparent;
            border: 1px solid #E8DFC8;
            color: #8B9A87;
            font-size: 0.7rem;
            padding: 4px 12px;
            border-radius: 30px;
            font-weight: 500;
            transition: all 0.2s;
        }
        .btn-outline-sm:hover { border-color: #FFC107; color: #FFC107; }

        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .modal-custom .modal-content { border-radius: 24px; border: none; }
        .modal-header-custom {
            background: #2C5F8A;
            color: white;
            border-radius: 24px 24px 0 0;
            padding: 16px 20px;
        }
        .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #E8DFC8; }
        .detail-label { width: 120px; font-weight: 600; color: #2C5F8A; }
        .detail-value { flex: 1; color: #8B9A87; }
        .form-control-custom, .form-select-custom {
            border-radius: 12px;
            border: 1px solid #E8DFC8;
            padding: 8px 12px;
            font-size: 0.85rem;
        }

        @media (max-width: 1200px) {
            .action-cards, .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
            .filters-bar { flex-direction: column; align-items: stretch; }
            .search-box { justify-content: space-between; }
            .search-box input { width: 100%; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
    </div>

    <div class="menu-section">ATENDIMENTO</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
    </ul>

    <div class="menu-section">CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Recepção<span>Check-in / Check-out</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="action-cards">
        <div class="action-card" data-bs-toggle="modal" data-bs-target="#modalCheckin">
            <i class="bi bi-person-arms-up"></i>
            <h4>Novo Check-in</h4>
            <p>Registar entrada</p>
        </div>
        <div class="action-card" id="btnCheckoutRapido">
            <i class="bi bi-luggage"></i>
            <h4>Check-out</h4>
            <p>Finalizar estadia</p>
        </div>
        <div class="action-card" data-bs-toggle="modal" data-bs-target="#modalReservaRapida">
            <i class="bi bi-calendar-plus"></i>
            <h4>Nova Reserva</h4>
            <p>Fazer reserva</p>
        </div>
        <div class="action-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/quarto.jsp'">
            <i class="bi bi-door-open"></i>
            <h4>Ver Quartos</h4>
            <p>Disponibilidade</p>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header"><h3>CHECK-INS HOJE</h3><i class="bi bi-person-arms-up"></i></div>
            <div class="stat-value" id="checkinsHoje">--</div>
            <div class="stat-footer">Pendentes: <span id="pendentesHoje">--</span></div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>CHECK-OUTS HOJE</h3><i class="bi bi-luggage"></i></div>
            <div class="stat-value" id="checkoutsHoje">--</div>
            <div class="stat-footer">A realizar hoje</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>HÓSPEDES NO HOTEL</h3><i class="bi bi-people-fill"></i></div>
            <div class="stat-value" id="hospedesHotel">--</div>
            <div class="stat-footer">Check-in realizados</div>
        </div>
        <div class="stat-card">
            <div class="stat-header"><h3>RESERVAS PENDENTES</h3><i class="bi bi-calendar-week"></i></div>
            <div class="stat-value" id="reservasPendentes">--</div>
            <div class="stat-footer">Aguardam check-in</div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Check-ins por Período</h3>
            <div class="chart-container"><canvas id="checkinsPeriodoChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Check-ins por Hora (Hoje)</h3>
            <div class="chart-container"><canvas id="checkinsHoraChart"></canvas></div>
        </div>
    </div>

    <div class="filters-bar">
        <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" id="searchInput" placeholder="Buscar por cliente ou quarto...">
        </div>
        <div>
            <select class="filter-select" id="statusFilter">
                <option value="pendente">Check-ins Pendentes</option>
                <option value="hospedado">Hóspedes no Hotel</option>
                <option value="checkout">Check-outs Hoje</option>
            </select>
        </div>
    </div>

    <div class="table-section" id="tabelaPendentes">
        <h3><i class="bi bi-clock-history"></i> Check-ins Pendentes (Hoje)</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Hóspede</th><th>Quarto</th><th>Entrada</th><th>Saída</th><th>Hóspedes</th><th>Ação</th></tr>
                </thead>
                <tbody id="pendentesTableBody">
                    <tr><td colspan="6" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="table-section" id="tabelaHospedados" style="display: none;">
        <h3><i class="bi bi-people-fill"></i> Hóspedes no Hotel</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Hóspede</th><th>Quarto</th><th>Check-in</th><th>Saída Prevista</th><th>Consumo</th><th>Ação</th></tr>
                </thead>
                <tbody id="hospedadosTableBody">
                    <tr><td colspan="6" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                </tbody>
            </tr>
        </div>
    </div>

    <div class="table-section" id="tabelaCheckouts" style="display: none;">
        <h3><i class="bi bi-luggage"></i> Check-outs Hoje</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Hóspede</th><th>Quarto</th><th>Saída</th><th>Diárias</th><th>Consumo</th><th>Total</th><th>Ação</th></tr>
                </thead>
                <tbody id="checkoutsTableBody">
                    <tr><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos
    </div>
</div>

<!-- MODAL: Realizar Check-in -->
<div class="modal fade modal-custom" id="modalCheckin" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-person-arms-up"></i> Realizar Check-in</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" id="checkinReservaId">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="modalCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="modalQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Período:</div><div class="detail-value" id="modalPeriodo">-</div></div>
                <div class="mb-3 mt-3"><label class="form-label">Quantidade de Hóspedes</label><input type="number" class="form-control form-control-custom" id="quantidadeHospedes" value="1" min="1" max="10"></div>
                <div class="mb-3"><label class="form-label">Observações</label><textarea class="form-control form-control-custom" id="checkinObservacoes" rows="2"></textarea></div>
                <hr>
                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-outline-sm" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn-sm-action" id="confirmCheckinBtn">Confirmar Check-in</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Realizar Check-out -->
<div class="modal fade modal-custom" id="modalCheckout" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-luggage"></i> Realizar Check-out</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" id="checkoutId">
                <div class="detail-row"><div class="detail-label">Cliente:</div><div class="detail-value" id="checkoutCliente">-</div></div>
                <div class="detail-row"><div class="detail-label">Quarto:</div><div class="detail-value" id="checkoutQuarto">-</div></div>
                <div class="detail-row"><div class="detail-label">Período:</div><div class="detail-value" id="checkoutPeriodo">-</div></div>
                <div class="detail-row"><div class="detail-label">Diárias:</div><div class="detail-value" id="checkoutDiarias">-</div></div>
                <div class="detail-row"><div class="detail-label">Consumo extra:</div><div class="detail-value" id="checkoutConsumo">0 MZN</div></div>
                <div class="detail-row" style="background: #FFF8E1; margin-top: 10px; border-radius: 12px;">
                    <div class="detail-label"><strong>Valor Total:</strong></div>
                    <div class="detail-value"><strong id="checkoutTotal">0 MZN</strong></div>
                </div>
                <div class="mb-3 mt-3"><label class="form-label">Observações do Check-out</label><textarea class="form-control form-control-custom" id="checkoutObservacoes" rows="2"></textarea></div>
                <hr>
                <div class="d-flex justify-content-end gap-2">
                    <button type="button" class="btn btn-outline-sm" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn-sm-action" id="confirmCheckoutBtn">Confirmar Check-out</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MODAL: Nova Reserva Rápida -->
<div class="modal fade modal-custom" id="modalReservaRapida" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header-custom">
                <h5 class="modal-title"><i class="bi bi-calendar-plus"></i> Nova Reserva</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form id="formReservaRapida">
                    <div class="mb-3"><label class="form-label">Cliente</label><select class="form-select form-select-custom" id="clienteReserva" required><option value="">Selecione um cliente</option></select></div>
                    <div class="mb-3"><label class="form-label">Quarto</label><select class="form-select form-select-custom" id="quartoReserva" required><option value="">Selecione um quarto</option></select></div>
                    <div class="row">
                        <div class="col-md-6 mb-3"><label class="form-label">Entrada</label><input type="date" class="form-control form-control-custom" id="entradaReserva"></div>
                        <div class="col-md-6 mb-3"><label class="form-label">Saída</label><input type="date" class="form-control form-control-custom" id="saidaReserva"></div>
                    </div>
                    <div class="mb-3"><label class="form-label">Hóspedes</label><input type="number" class="form-control form-control-custom" id="hospedesReserva" value="1" min="1"></div>
                    <div class="mb-3"><label class="form-label">Observações</label><textarea class="form-control form-control-custom" id="obsReserva" rows="2"></textarea></div>
                    <hr>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn-sm-action">Criar Reserva</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let checkinsHoraChart = null;
    let checkinsPeriodoChart = null;

    function formatMoney(value) {
        if (value === undefined || value === null || isNaN(value)) return "0 MZN";
        return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " MZN";
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function showAlert(type, message) {
        var alertDiv = document.createElement('div');
        alertDiv.className = 'position-fixed bottom-0 end-0 m-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.style.background = type === 'success' ? '#2E7D32' : '#D9534F';
        alertDiv.style.color = 'white';
        alertDiv.style.borderRadius = '12px';
        alertDiv.style.padding = '10px 18px';
        alertDiv.style.fontSize = '0.8rem';
        alertDiv.innerHTML = '<i class="bi bi-' + (type === 'success' ? 'check-circle' : 'exclamation-triangle') + '"></i> ' + message;
        document.body.appendChild(alertDiv);
        setTimeout(function() { alertDiv.remove(); }, 3000);
    }

    async function fetchAPI(endpoint, options) {
        options = options || {};
        try {
            var response = await fetch(contextPath + endpoint, options);
            if (!response.ok) throw new Error('Erro: ' + response.status);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            return null;
        }
    }

    async function carregarEstatisticas() {
        var data = await fetchAPI('/Recepcionista/api/check/estatisticas', {});
        if (data) {
            document.getElementById('checkinsHoje').textContent = data.checkins_hoje || 0;
            document.getElementById('pendentesHoje').textContent = data.pendentes || 0;
            document.getElementById('checkoutsHoje').textContent = data.checkouts_hoje || 0;
            document.getElementById('hospedesHotel').textContent = data.hospedados || 0;
            document.getElementById('reservasPendentes').textContent = data.reservas_pendentes || 0;
        }
    }

    async function carregarPendentes() {
        var data = await fetchAPI('/Recepcionista/api/check/pendentes', {});
        var tbody = document.getElementById('pendentesTableBody');
        var searchTerm = document.getElementById('searchInput').value.toLowerCase();

        if (!data || data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4">Nenhum check-in pendente para hoje</td></tr>';
            return;
        }

        var filtered = data.filter(function(r) {
            return r.cliente_nome.toLowerCase().indexOf(searchTerm) !== -1 || r.quarto_num.toLowerCase().indexOf(searchTerm) !== -1;
        });

        tbody.innerHTML = '';
        for (var i = 0; i < filtered.length; i++) {
            var r = filtered[i];
            var row = '<tr>' +
                '<td><strong>' + escapeHtml(r.cliente_nome) + '</strong></td>' +
                '<td>' + escapeHtml(r.quarto_num) + '</td>' +
                '<td>' + r.data_entrada + '</td>' +
                '<td>' + r.data_saida + '</td>' +
                '<td class="text-center">' + r.numero_hospedes + '</td>' +
                '<td><button class="btn-sm-action" onclick="abrirModalCheckin(' + r.id_reserva + ')"><i class="bi bi-person-check"></i> Check-in</button></td>' +
                '</tr>';
            tbody.innerHTML += row;
        }
    }

    async function carregarHospedados() {
        var data = await fetchAPI('/Recepcionista/api/check/hospedados', {});
        var tbody = document.getElementById('hospedadosTableBody');
        var searchTerm = document.getElementById('searchInput').value.toLowerCase();

        if (!data || data.length === 0) {
            tbody.innerHTML = '<td><td colspan="6" class="text-center py-4">Nenhum hóspede no momento</td></tr>';
            return;
        }

        var filtered = data.filter(function(h) {
            return h.nome.toLowerCase().indexOf(searchTerm) !== -1 || h.quarto_num.toLowerCase().indexOf(searchTerm) !== -1;
        });

        tbody.innerHTML = '';
        for (var i = 0; i < filtered.length; i++) {
            var h = filtered[i];
            var row = '<tr>' +
                '<td><strong>' + escapeHtml(h.nome) + '</strong></td>' +
                '<td>' + escapeHtml(h.quarto_num) + '</td>' +
                '<td>' + h.data_checkin + '</td>' +
                '<td>' + h.data_saida + '</td>' +
                '<td>' + formatMoney(h.consumo_total) + '</td>' +
                '<td><button class="btn-sm-action" onclick="abrirModalCheckout(' + h.id_checkin + ')"><i class="bi bi-luggage"></i> Check-out</button></td>' +
                '</tr>';
            tbody.innerHTML += row;
        }
    }

    async function carregarCheckouts() {
        var data = await fetchAPI('/Recepcionista/api/check/checkouts', {});
        var tbody = document.getElementById('checkoutsTableBody');
        var searchTerm = document.getElementById('searchInput').value.toLowerCase();

        if (!data || data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum check-out agendado para hoje</span></td>';
            return;
        }

        var filtered = data.filter(function(c) {
            return c.nome.toLowerCase().indexOf(searchTerm) !== -1 || c.quarto_num.toLowerCase().indexOf(searchTerm) !== -1;
        });

        tbody.innerHTML = '';
        for (var i = 0; i < filtered.length; i++) {
            var c = filtered[i];
            var row = '<tr>' +
                '<td><strong>' + escapeHtml(c.nome) + '</strong></td>' +
                '<td>' + escapeHtml(c.quarto_num) + '</td>' +
                '<td>' + c.data_saida + '</td>' +
                '<td class="text-center">' + c.diarias + ' diárias</span></td>' +
                '<td>' + formatMoney(c.consumo_total) + '</span></td>' +
                '<td><strong>' + formatMoney(c.total) + '</strong></span></td>' +
                '<td><button class="btn-sm-action" onclick="abrirModalCheckout(' + c.id_checkin + ')"><i class="bi bi-check2-circle"></i> Finalizar</button></span></td>' +
                '</tr>';
            tbody.innerHTML += row;
        }
    }

    async function carregarCheckinsHora() {
        var data = await fetchAPI('/Recepcionista/api/check/hora', {});
        var ctxHora = document.getElementById('checkinsHoraChart').getContext('2d');
        if (checkinsHoraChart) checkinsHoraChart.destroy();

        var horas = [];
        var valores = [];

        if (data && data.length > 0) {
            for (var i = 0; i < data.length; i++) {
                horas.push(data[i].hora + 'h');
                valores.push(data[i].total);
            }
        } else {
            for (var i = 0; i < 24; i++) {
                horas.push(i + 'h');
                valores.push(0);
            }
        }

        checkinsHoraChart = new Chart(ctxHora, {
            type: 'bar',
            data: { labels: horas, datasets: [{ label: 'Check-ins', data: valores, backgroundColor: '#FFC107', borderRadius: 6, borderWidth: 0 }] },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, grid: { color: '#E8DFC8' }, ticks: { stepSize: 1 } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } }
        });

        var manha = 0, tarde = 0, noite = 0;
        for (var i = 6; i < 12; i++) manha += valores[i];
        for (var i = 12; i < 18; i++) tarde += valores[i];
        for (var i = 18; i < 24; i++) noite += valores[i];
        for (var i = 0; i < 6; i++) noite += valores[i];

        var ctxPeriodo = document.getElementById('checkinsPeriodoChart').getContext('2d');
        if (checkinsPeriodoChart) checkinsPeriodoChart.destroy();

        checkinsPeriodoChart = new Chart(ctxPeriodo, {
            type: 'doughnut',
            data: { labels: ['Manhã (06-12h)', 'Tarde (12-18h)', 'Noite (18-06h)'], datasets: [{ data: [manha, tarde, noite], backgroundColor: ['#2E7D32', '#FFC107', '#1976D2'], borderWidth: 0, borderRadius: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 9 } } } }, cutout: '60%' }
        });
    }

    async function abrirModalCheckin(idReserva) {
        var data = await fetchAPI('/Recepcionista/api/check/detalhes-reserva?id=' + idReserva, {});
        if (data && data.success) {
            document.getElementById('checkinReservaId').value = idReserva;
            document.getElementById('modalCliente').innerHTML = '<strong>' + escapeHtml(data.cliente_nome) + '</strong>';
            document.getElementById('modalQuarto').innerHTML = data.quarto_num;
            document.getElementById('modalPeriodo').innerHTML = data.data_entrada + " a " + data.data_saida;
            document.getElementById('quantidadeHospedes').value = data.numero_hospedes;
            document.getElementById('checkinObservacoes').value = data.observacoes || '';
            new bootstrap.Modal(document.getElementById('modalCheckin')).show();
        } else {
            showAlert('error', 'Erro ao carregar dados da reserva');
        }
    }

    document.getElementById('confirmCheckinBtn').addEventListener('click', async function() {
        var idReserva = document.getElementById('checkinReservaId').value;
        var quantidadeHospedes = document.getElementById('quantidadeHospedes').value;
        var observacoes = document.getElementById('checkinObservacoes').value;

        var result = await fetchAPI('/Recepcionista/api/check/realizar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id_reserva=' + idReserva + '&quantidade_hospedes=' + quantidadeHospedes + '&observacoes=' + encodeURIComponent(observacoes)
        });

        if (result && result.success) {
            bootstrap.Modal.getInstance(document.getElementById('modalCheckin')).hide();
            showAlert('success', result.message);
            carregarTodosDados();
        } else {
            showAlert('error', (result && result.error) || 'Erro ao realizar check-in');
        }
    });

    async function abrirModalCheckout(idCheckin) {
        var data = await fetchAPI('/Recepcionista/api/check/detalhes-checkin?id=' + idCheckin, {});
        if (data && data.success) {
            var totalQuarto = data.diarias * data.preco_diaria;
            var total = totalQuarto + data.consumo_total;
            document.getElementById('checkoutId').value = idCheckin;
            document.getElementById('checkoutCliente').innerHTML = '<strong>' + escapeHtml(data.cliente_nome) + '</strong>';
            document.getElementById('checkoutQuarto').innerHTML = data.quarto_num;
            document.getElementById('checkoutPeriodo').innerHTML = data.data_entrada + " a " + data.data_saida;
            document.getElementById('checkoutDiarias').innerHTML = data.diarias + " diárias x " + formatMoney(data.preco_diaria) + " = " + formatMoney(totalQuarto);
            document.getElementById('checkoutConsumo').innerHTML = formatMoney(data.consumo_total);
            document.getElementById('checkoutTotal').innerHTML = formatMoney(total);
            document.getElementById('checkoutObservacoes').value = '';
            new bootstrap.Modal(document.getElementById('modalCheckout')).show();
        } else {
            showAlert('error', 'Erro ao carregar dados do check-in');
        }
    }

    document.getElementById('confirmCheckoutBtn').addEventListener('click', async function() {
        var idCheckin = document.getElementById('checkoutId').value;
        var valorTotalStr = document.getElementById('checkoutTotal').innerHTML;
        var valorTotal = parseFloat(valorTotalStr.replace(' MZN', '').replace(/\./g, ''));
        var observacoes = document.getElementById('checkoutObservacoes').value;

        var result = await fetchAPI('/Recepcionista/api/check/checkout/realizar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id_checkin=' + idCheckin + '&valor_total=' + valorTotal + '&observacoes=' + encodeURIComponent(observacoes)
        });

        if (result && result.success) {
            bootstrap.Modal.getInstance(document.getElementById('modalCheckout')).hide();
            showAlert('success', result.message);
            carregarTodosDados();
        } else {
            showAlert('error', (result && result.error) || 'Erro ao realizar check-out');
        }
    });

    function updateFilter() {
        var filter = document.getElementById('statusFilter').value;
        document.getElementById('tabelaPendentes').style.display = filter === 'pendente' ? 'block' : 'none';
        document.getElementById('tabelaHospedados').style.display = filter === 'hospedado' ? 'block' : 'none';
        document.getElementById('tabelaCheckouts').style.display = filter === 'checkout' ? 'block' : 'none';
        if (filter === 'pendente') carregarPendentes();
        if (filter === 'hospedado') carregarHospedados();
        if (filter === 'checkout') carregarCheckouts();
    }

    function carregarTodosDados() {
        carregarEstatisticas();
        carregarCheckinsHora();
        var filter = document.getElementById('statusFilter').value;
        if (filter === 'pendente') carregarPendentes();
        if (filter === 'hospedado') carregarHospedados();
        if (filter === 'checkout') carregarCheckouts();
    }

    async function carregarClientes() {
        var data = await fetchAPI('/Recepcionista/api/cliente/lista', {});
        var select = document.getElementById('clienteReserva');
        if (data && data.length > 0) {
            select.innerHTML = '<option value="">Selecione um cliente</option>';
            for (var i = 0; i < data.length; i++) {
                select.innerHTML += '<option value="' + data[i].id_cliente + '">' + escapeHtml(data[i].nome_completo) + '</option>';
            }
        }
    }

    async function carregarQuartosDisponiveis() {
        var data = await fetchAPI('/Recepcionista/api/quartos/disponiveis', {});
        var select = document.getElementById('quartoReserva');
        if (data && data.length > 0) {
            select.innerHTML = '<option value="">Selecione um quarto</option>';
            for (var i = 0; i < data.length; i++) {
                select.innerHTML += '<option value="' + data[i].id_quarto + '">' + data[i].numero + ' - ' + data[i].tipo + ' - ' + formatMoney(data[i].preco_diaria) + '</option>';
            }
        }
    }

    document.getElementById('statusFilter').addEventListener('change', updateFilter);
    document.getElementById('searchInput').addEventListener('input', function() {
        var filter = document.getElementById('statusFilter').value;
        if (filter === 'pendente') carregarPendentes();
        if (filter === 'hospedado') carregarHospedados();
        if (filter === 'checkout') carregarCheckouts();
    });
    document.getElementById('btnCheckoutRapido').addEventListener('click', function() {
        document.getElementById('statusFilter').value = 'checkout';
        updateFilter();
        carregarCheckouts();
    });

    document.querySelector('[data-bs-target="#modalReservaRapida"]').addEventListener('show.bs.modal', function() {
        carregarClientes();
        carregarQuartosDisponiveis();
        var hoje = new Date();
        var amanha = new Date();
        amanha.setDate(amanha.getDate() + 1);
        document.getElementById('entradaReserva').valueAsDate = hoje;
        document.getElementById('saidaReserva').valueAsDate = amanha;
    });

    document.getElementById('formReservaRapida').addEventListener('submit', async function(e) {
        e.preventDefault();
        var result = await fetchAPI('/Recepcionista/api/reserva/criar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id_cliente=' + document.getElementById('clienteReserva').value + '&id_quarto=' + document.getElementById('quartoReserva').value + '&data_entrada=' + document.getElementById('entradaReserva').value + '&data_saida=' + document.getElementById('saidaReserva').value + '&numero_hospedes=' + document.getElementById('hospedesReserva').value + '&estado=PENDENTE&observacoes=' + encodeURIComponent(document.getElementById('obsReserva').value)
        });
        if (result && result.success) {
            showAlert('success', result.message);
            bootstrap.Modal.getInstance(document.getElementById('modalReservaRapida')).hide();
            this.reset();
            carregarTodosDados();
        } else {
            showAlert('error', (result && result.error) || 'Erro ao criar reserva');
        }
    });

    function updateClock() {
        var now = new Date();
        document.getElementById('horaAtual').innerHTML = now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        document.getElementById('dataAtual').innerHTML = now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' });
    }
    setInterval(updateClock, 1000);
    updateClock();

    carregarTodosDados();
    updateFilter();
    setInterval(function() { carregarTodosDados(); }, 30000);
</script>
</body>
</html>