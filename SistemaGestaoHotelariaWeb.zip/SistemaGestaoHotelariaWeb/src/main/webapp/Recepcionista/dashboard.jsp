<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<%@ page import="com.hotel.model.Usuario" %>
<%
    Usuario usuarioLogado = (Usuario) session.getAttribute("usuarioLogado");
    if (usuarioLogado == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepcionista · Dashboard Hotelaria</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #F0F4F8;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 270px;
            height: 100vh;
            background: #2C5F8A;
            color: #E8DFC8;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar .profile {
            text-align: center;
            padding: 28px 20px 25px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 193, 7, 0.25);
        }
        .sidebar .profile img {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 3px solid #FFC107;
            margin-bottom: 12px;
            object-fit: cover;
        }
        .sidebar .profile h3 { font-size: 1.1rem; font-weight: 600; margin: 5px 0 2px; color: #FFC107; }
        .sidebar .profile p { font-size: 0.7rem; opacity: 0.8; margin: 0; }
        .sidebar ul { list-style: none; padding: 0 16px; margin: 0; }
        .sidebar li {
            padding: 10px 16px;
            margin: 4px 0;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.25s ease;
        }
        .sidebar li i { font-size: 1.2rem; width: 26px; color: #FFC107; }
        .sidebar li:hover { background: rgba(255, 193, 7, 0.15); transform: translateX(4px); }
        .sidebar li.active { background: #FFC107; color: #2C5F8A; }
        .sidebar li.active i { color: #2C5F8A; }
        .sidebar li a { color: #E8DFC8; text-decoration: none; display: flex; align-items: center; gap: 12px; width: 100%; }
        .sidebar li.active a { color: #2C5F8A; font-weight: 500; }
        .sidebar .menu-section {
            color: #FFC107;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 20px 20px 8px;
            font-weight: 600;
        }
        .main-wrapper { margin-left: 270px; height: 100vh; overflow-y: auto; padding: 20px 28px; position: relative; }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 12px 24px;
            margin-bottom: 28px;
            border: 1px solid #E8DFC8;
        }
        .logo-area { display: flex; align-items: center; gap: 12px; }
        .logo-area i { font-size: 1.8rem; color: #FFC107; }
        .logo-text { font-size: 1.2rem; font-weight: 700; color: #2C5F8A; }
        .logo-text span { font-weight: 300; font-size: 0.65rem; color: #8B9A87; display: block; }
        .right-area { display: flex; align-items: center; gap: 25px; }
        .date-time { text-align: right; }
        .date { font-size: 0.7rem; color: #8B9A87; }
        .time { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; }

        .action-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        .action-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid #E8DFC8;
        }
        .action-card:hover { transform: translateY(-3px); border-color: #FFC107; box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
        .action-card i { font-size: 2rem; color: #FFC107; margin-bottom: 10px; }
        .action-card h4 { font-size: 0.9rem; font-weight: 600; color: #2C5F8A; margin-bottom: 5px; }
        .action-card p { font-size: 0.7rem; color: #8B9A87; margin: 0; }

        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 28px; }
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 18px 16px;
            border: 1px solid #E8DFC8;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .stat-card:hover { transform: translateY(-3px); border-color: #FFC107; }
        .stat-header { display: flex; justify-content: space-between; margin-bottom: 12px; }
        .stat-header h3 { font-size: 0.7rem; font-weight: 600; color: #8B9A87; text-transform: uppercase; }
        .stat-header i { font-size: 1.5rem; color: #FFC107; opacity: 0.7; }
        .stat-value { font-size: 1.7rem; font-weight: 700; color: #2C5F8A; margin-bottom: 6px; }
        .stat-footer { font-size: 0.7rem; color: #A0AD9B; }

        .charts-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 28px; }
        .chart-box { background: white; border-radius: 20px; padding: 18px; border: 1px solid #E8DFC8; }
        .chart-box h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
        .chart-box h3 i { color: #FFC107; }
        .chart-container { position: relative; height: 200px; width: 100%; }

        .table-section { background: white; border-radius: 20px; padding: 18px 20px; border: 1px solid #E8DFC8; margin-bottom: 28px; }
        .table-section h3 { font-size: 0.85rem; font-weight: 600; color: #2C5F8A; margin-bottom: 18px; }
        .table { margin: 0; font-size: 0.8rem; }
        .table thead th { border-bottom: 2px solid #FFC107; color: #2C5F8A; font-weight: 600; padding: 10px 6px; }

        .badge-status { padding: 4px 12px; border-radius: 30px; font-size: 0.65rem; font-weight: 500; }
        .badge-status.PENDENTE { background: #FFF8E1; color: #F57C00; }
        .badge-status.LIVRE { background: #E8F5E9; color: #2E7D32; }
        .badge-status.OCUPADO { background: #E3F2FD; color: #1976D2; }

        .btn-sm-action {
            background: #FFC107;
            border: none;
            color: #2C5F8A;
            font-size: 0.7rem;
            padding: 5px 15px;
            border-radius: 30px;
            font-weight: 500;
            transition: all 0.2s;
        }
        .btn-sm-action:hover { background: #2C5F8A; color: #FFC107; }

        .footer { text-align: center; padding: 16px; color: #8B9A87; font-size: 0.7rem; }
        .loading-spinner { display: inline-block; width: 20px; height: 20px; border: 2px solid #FFC107; border-radius: 50%; border-top-color: transparent; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        @media (max-width: 1200px) {
            .action-cards, .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .charts-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="profile">
        <c:choose>
            <c:when test="${not empty sessionScope.usuarioLogado.foto and sessionScope.usuarioLogado.foto != ''}">
                <img src="${sessionScope.usuarioLogado.foto}" alt="Foto">
            </c:when>
            <c:otherwise>
                <img src="${pageContext.request.contextPath}/assets/images/avatar-default.png" alt="Avatar Padrão">
            </c:otherwise>
        </c:choose>
        <h3>${sessionScope.usuarioLogado.nome}</h3>
        <p>${sessionScope.usuarioLogado.email}</p>
        <p style="font-size: 0.65rem;"><i class="bi bi-shield-check"></i> Perfil: Recepcionista</p>
    </div>

    <div class="menu-section">ATENDIMENTO</div>
    <ul>
        <li class="active"><a href="${pageContext.request.contextPath}/Recepcionista/dashboard.jsp"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/check.jsp"><i class="bi bi-person-check"></i> Check-in / Check-out</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/reserva.jsp"><i class="bi bi-calendar-week"></i> Reservas</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/quarto.jsp"><i class="bi bi-door-open"></i> Estado Quartos</a></li>
    </ul>

    <div class="menu-section">CLIENTES</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/hospede.jsp"><i class="bi bi-people"></i> Hóspedes</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/qr.jsp"><i class="bi bi-qr-code"></i> QR Code Acesso</a></li>
    </ul>

    <div class="menu-section">SERVIÇOS</div>
    <ul>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/consumo.jsp"><i class="bi bi-cup-straw"></i> Consumos</a></li>
        <li><a href="${pageContext.request.contextPath}/Recepcionista/pagamento.jsp"><i class="bi bi-cash-stack"></i> Pagamentos</a></li>
        <li><a href="${pageContext.request.contextPath}/logout"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
    </ul>
</div>

<div class="main-wrapper">
    <div class="topbar">
        <div class="logo-area">
            <i class="bi bi-building"></i>
            <div class="logo-text">Hotelaria Recepção<span>Atendimento ao Hóspede</span></div>
        </div>
        <div class="right-area">
            <div class="date-time">
                <div class="date"><i class="bi bi-calendar3 me-1"></i> <span id="dataAtual"></span></div>
                <div class="time"><i class="bi bi-clock me-1"></i> <span id="horaAtual"></span></div>
            </div>
        </div>
    </div>

    <div class="action-cards">
        <div class="action-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/check.jsp?action=checkin'">
            <i class="bi bi-person-arms-up"></i>
            <h4>Novo Check-in</h4>
            <p>Registar entrada</p>
        </div>
        <div class="action-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/check.jsp?action=checkout'">
            <i class="bi bi-luggage"></i>
            <h4>Check-out</h4>
            <p>Finalizar estadia</p>
        </div>
        <div class="action-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/reserva.jsp'">
            <i class="bi bi-calendar-plus"></i>
            <h4>Nova Reserva</h4>
            <p>Fazer reserva</p>
        </div>
        <div class="action-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/quarto.jsp'">
            <i class="bi bi-door-open"></i>
            <h4>Ver Quartos</h4>
            <p>Disponibilidade</p>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/check.jsp'">
            <div class="stat-header"><h3>CHECK-INS HOJE</h3><i class="bi bi-person-arms-up"></i></div>
            <div class="stat-value" id="checkinsHoje">--</div>
            <div class="stat-footer"><span id="checkinsPendentes">--</span> pendentes</div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/check.jsp'">
            <div class="stat-header"><h3>CHECK-OUTS HOJE</h3><i class="bi bi-luggage"></i></div>
            <div class="stat-value" id="checkoutsHoje">--</div>
            <div class="stat-footer"><span id="checkoutsPendentes">--</span> aguardando</div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/quarto.jsp'">
            <div class="stat-header"><h3>QUARTOS LIVRES</h3><i class="bi bi-door-open"></i></div>
            <div class="stat-value" id="quartosLivres">--</div>
            <div class="stat-footer">de <span id="totalQuartos">--</span> total</div>
        </div>
        <div class="stat-card" onclick="location.href='${pageContext.request.contextPath}/Recepcionista/quarto.jsp'">
            <div class="stat-header"><h3>OCUPAÇÃO</h3><i class="bi bi-building"></i></div>
            <div class="stat-value" id="taxaOcupacao">--%</div>
            <div class="stat-footer"><span id="hospedesAtivos">--</span> hóspedes no hotel</div>
        </div>
    </div>

    <div class="charts-grid">
        <div class="chart-box">
            <h3><i class="bi bi-bar-chart"></i> Check-ins por Hora (Hoje)</h3>
            <div class="chart-container"><canvas id="checkinsHoraChart"></canvas></div>
        </div>
        <div class="chart-box">
            <h3><i class="bi bi-pie-chart"></i> Distribuição de Quartos</h3>
            <div class="chart-container"><canvas id="quartosPieChart"></canvas></div>
        </div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-clock-history"></i> Check-ins Pendentes para Hoje</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Hóspede</th><th>Quarto</th><th>Tipo</th><th>Hora</th><th>Hóspedes</th><th>Ação</th></tr>
                </thead>
                <tbody id="pendentesTableBody">
                    <tr><td colspan="6" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-door-open"></i> Quartos Disponíveis para Check-in Imediato</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Nº</th><th>Tipo</th><th>Piso</th><th>Diária (MZN)</th><th>Descrição</th><th></th></tr>
                </thead>
                <tbody id="disponiveisTableBody">
                    <tr><td colspan="6" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></table>
                </tbody>
            </table>
        </div>
    </div>

    <div class="table-section">
        <h3><i class="bi bi-people-fill"></i> Hóspedes no Hotel</h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Nome</th><th>Telefone</th><th>Quarto</th><th>Tipo</th><th>Check-in</th><th>Check-out</th><th>Consumo</th></tr>
                </thead>
                <tbody id="hospedesTableBody">
                    <tr><td colspan="7" class="text-center py-4"><div class="loading-spinner"></div> Carregando...<\/td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="footer">
        <i class="bi bi-database"></i> Sistema Hotelaria · Dados em tempo real · Atualização automática a cada 30 segundos
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const contextPath = '${pageContext.request.contextPath}';
    let checkinsHoraChart = null;
    let quartosPieChart = null;

    function formatMoney(value) {
        if (value === undefined || value === null || isNaN(value)) return "0";
        return Number(value).toLocaleString('pt-PT', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    }

    function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    function loadDashboardStats() {
        $.ajax({
            url: contextPath + '/Recepcionista/api/dashboard',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                $('#checkinsHoje').text(data.checkins_hoje || 0);
                $('#checkinsPendentes').text(data.checkins_pendentes || 0);
                $('#checkoutsHoje').text(data.checkouts_pendentes || 0);
                $('#checkoutsPendentes').text(data.checkouts_pendentes || 0);
                $('#quartosLivres').text(data.quartos_disponiveis || 0);
                $('#totalQuartos').text(data.total_quartos || 0);
                $('#taxaOcupacao').text((data.taxa_ocupacao || 0) + '%');
                $('#hospedesAtivos').text(data.hospedes_ativos || 0);
                updateQuartosPieChart(data.quartos_disponiveis || 0, data.quartos_ocupados || 0);
            },
            error: function(xhr, status, error) {
                console.error('Erro ao carregar estatísticas:', error);
            }
        });
    }

    function loadCheckinsPendentes() {
        $.ajax({
            url: contextPath + '/Recepcionista/api/checkins/pendentes',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#pendentesTableBody');
                tbody.empty();
                if (!data || data.length === 0) {
                    tbody.html('<tr><td colspan="6" class="text-center py-4">Nenhum check-in pendente para hoje</td></tr>');
                    return;
                }
                for (var i = 0; i < data.length; i++) {
                    var c = data[i];
                    var row = '<tr>' +
                        '<td><strong>' + escapeHtml(c.cliente_nome) + '</strong></td>' +
                        '<td>' + escapeHtml(c.quarto_num) + '</td>' +
                        '<td>' + escapeHtml(c.tipo_quarto) + '</td>' +
                        '<td>' + c.hora_entrada + '</td>' +
                        '<td class="text-center">' + c.numero_hospedes + '</td>' +
                        '<td><button class="btn-sm-action" onclick="realizarCheckin(' + c.id_reserva + ')">Fazer Check-in</button></td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#pendentesTableBody').html('<td><td colspan="6" class="text-center py-4 text-danger">Erro ao carregar</td></tr>');
            }
        });
    }

    function loadQuartosDisponiveis() {
        $.ajax({
            url: contextPath + '/Recepcionista/api/quartos/disponiveis',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#disponiveisTableBody');
                tbody.empty();
                if (!data || data.length === 0) {
                    tbody.html('<tr><td colspan="6" class="text-center py-4">Nenhum quarto disponível</td></tr>');
                    return;
                }
                for (var i = 0; i < data.length; i++) {
                    var q = data[i];
                    var row = '<tr>' +
                        '<td><strong>' + q.numero + '</strong></td>' +
                        '<td>' + escapeHtml(q.tipo) + '</td>' +
                        '<td>' + q.piso + 'º</span></td>' +
                        '<td>' + formatMoney(q.preco_diaria) + ' MZN</span></td>' +
                        '<td>' + escapeHtml(q.descricao || '-') + '</span></td>' +
                        '<td><button class="btn-sm-action" onclick="fazerReserva(' + q.id_quarto + ')">Reservar</button></td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#disponiveisTableBody').html('<tr><td colspan="6" class="text-center py-4 text-danger">Erro ao carregar</td></tr>');
            }
        });
    }

    function loadHospedesAtivos() {
        $.ajax({
            url: contextPath + '/Recepcionista/api/hospedes/ativos',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var tbody = $('#hospedesTableBody');
                tbody.empty();
                if (!data || data.length === 0) {
                    tbody.html('<tr><td colspan="7" class="text-center py-4">Nenhum hóspede no momento</td></tr>');
                    return;
                }
                for (var i = 0; i < data.length; i++) {
                    var h = data[i];
                    var row = '<tr>' +
                        '<td><strong>' + escapeHtml(h.nome) + '</strong></td>' +
                        '<td>' + escapeHtml(h.telefone || '-') + '</td>' +
                        '<td>' + escapeHtml(h.quarto_num) + '</td>' +
                        '<td>' + escapeHtml(h.tipo_quarto) + '</td>' +
                        '<td>' + h.data_checkin + '</td>' +
                        '<td>' + h.data_checkout + '</td>' +
                        '<td>' + formatMoney(h.consumo_total) + ' MZN</span></td>' +
                        '</tr>';
                    tbody.append(row);
                }
            },
            error: function() {
                $('#hospedesTableBody').html('<tr><td colspan="7" class="text-center py-4 text-danger">Erro ao carregar</td></tr>');
            }
        });
    }

    function loadCheckinsPorHora() {
        $.ajax({
            url: contextPath + '/Recepcionista/api/checkins/hora',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                var ctx = document.getElementById('checkinsHoraChart').getContext('2d');
                if (checkinsHoraChart) checkinsHoraChart.destroy();
                var horas = [], valores = [];
                if (data && data.length > 0) {
                    for (var i = 0; i < data.length; i++) {
                        horas.push(data[i].hora + 'h');
                        valores.push(data[i].total);
                    }
                }
                checkinsHoraChart = new Chart(ctx, {
                    type: 'bar',
                    data: { labels: horas, datasets: [{ label: 'Check-ins', data: valores, backgroundColor: '#FFC107', borderRadius: 6, borderWidth: 0 }] },
                    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, grid: { color: '#E8DFC8' }, ticks: { stepSize: 1 } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } }
                });
            }
        });
    }

    function updateQuartosPieChart(livres, ocupados) {
        var ctx = document.getElementById('quartosPieChart').getContext('2d');
        if (quartosPieChart) quartosPieChart.destroy();
        quartosPieChart = new Chart(ctx, {
            type: 'doughnut',
            data: { labels: ['LIVRES', 'OCUPADOS'], datasets: [{ data: [livres, ocupados], backgroundColor: ['#2E7D32', '#D9534F'], borderWidth: 0, borderRadius: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 } } } }, cutout: '55%' }
        });
    }

    function realizarCheckin(idReserva) {
        window.location.href = contextPath + '/Recepcionista/check.jsp?action=checkin&id=' + idReserva;
    }

    function fazerReserva(idQuarto) {
        window.location.href = contextPath + '/Recepcionista/reserva.jsp?quarto=' + idQuarto;
    }

    function updateClock() {
        var now = new Date();
        $('#horaAtual').text(now.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        $('#dataAtual').text(now.toLocaleDateString('pt-PT', { day: '2-digit', month: 'long', year: 'numeric' }));
    }
    setInterval(updateClock, 1000);
    updateClock();

    $(document).ready(function() {
        loadDashboardStats();
        loadCheckinsPendentes();
        loadQuartosDisponiveis();
        loadHospedesAtivos();
        loadCheckinsPorHora();
        setInterval(function() {
            loadDashboardStats();
            loadCheckinsPendentes();
            loadQuartosDisponiveis();
            loadHospedesAtivos();
            loadCheckinsPorHora();
        }, 30000);
    });
</script>
</body>
</html>